(function($){
	$(document).on('click', '.wiloke-remove-group', function(event){
		event.preventDefault();

		if ( $('.wiloke-group').length == 1 ){
			alert('We need 1 box at least');
			return false;
		}

		$(this).closest('.wiloke-group').remove();
	})


	$(document).on('click', '.wiloke-widget-addnew', function(event){
		event.preventDefault();

		let $wrapper = $(this).closest('.widget-content').find('.wiloke-group-wrapper'),
			order = $(this).closest('.widget-content').find('.wiloke-group').length,
			newBox = '<div class="wiloke-group" data-order="'+order+'"><p><label for="widget-widget_services-'+order+'-content-2-heading">Heading</label><input id="widget-widget_services-'+order+'-content-2-heading" name="widget-widget_services['+order+'][content][2][heading]" value="Best Service" class="widefat " type="text"></p><p><label for="widget-widget_services-'+order+'-content-2-icon">Icon</label><input id="widget-widget_services-'+order+'-content-2-icon" name="widget-widget_services['+order+'][content][2][icon]" value="icon_chat_alt" class="widefat " type="text"></p><p><code><a href="https://goo.gl/VBiKV5" target="_blank">How to fill up an icon to the field?</a></code></p><p></p><p><label for="widget-widget_services-'+order+'-content-2-description">Description</label><textarea id="widget-widget_services-'+order+'-content-2-description" name="widget-widget_services['+order+'][content][2][description]" class="widefat" type="text">We only use the best brands of helmets, head torches, life jackets and safety equipment</textarea></p><a href="#" class="wiloke-widget wiloke-remove-group"><i class="dashicons dashicons-no"></i></a></div>';
			$wrapper.append(newBox);
	})

})(jQuery);