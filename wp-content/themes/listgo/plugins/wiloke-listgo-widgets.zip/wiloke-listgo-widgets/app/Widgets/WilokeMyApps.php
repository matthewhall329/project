<?php
/*
 * About Us/Me
 * @copyright Wiloke
 * @website https://wiloke.com
 */
use WilokeWidget\Supports\Helpers;
use WilokeListGoFunctionality\Frontend\FrontendManageSingleListing;

class WilokeMyApps extends WP_Widget
{
	public $aDef = array('title' => 'Download App', 'app_store_bg'=>'', 'app_store_url'=>'', 'google_play_bg'=>'', 'google_play_url'=>'', 'app_store_title'=>'App Store', 'google_play_title'=>'Google Play');

	public function __construct(){
		parent::__construct('wiloke_my_apps', WILOKE_WIDGET_PREFIX . '(OSP) My App', array('classname'=>'widget widget_downapp'));
	}

	public function form($aInstance){
		$aInstance = wp_parse_args($aInstance, $this->aDef);
		Helpers::textField(esc_html__('Title', 'wiloke'), $this->get_field_id('title'), $this->get_field_name('title'), $aInstance['title']);

		Helpers::textField(esc_html__('App Store Background', 'wiloke'), $this->get_field_id('app_store_bg'), $this->get_field_name('app_store_bg'), $aInstance['app_store_bg']);
		Helpers::textField(esc_html__('App Store Url', 'wiloke'), $this->get_field_id('app_store_url'), $this->get_field_name('app_store_url'), $aInstance['app_store_url']);
		Helpers::textField(esc_html__('App Store Title', 'wiloke'), $this->get_field_id('app_store_title'), $this->get_field_name('app_store_title'), $aInstance['app_store_title']);

		Helpers::textField(esc_html__('Google Play Background', 'wiloke'), $this->get_field_id('google_play_bg'), $this->get_field_name('google_play_bg'), $aInstance['google_play_bg']);
		Helpers::textField(esc_html__('Google Play Url', 'wiloke'), $this->get_field_id('google_play_url'), $this->get_field_name('google_play_url'), $aInstance['google_play_url']);
	}

	public function update($aNewinstance, $aOldinstance) {
		$aInstance = $aOldinstance;
		foreach ( $aNewinstance as $key => $val ){
			$aInstance[$key] = strip_tags($val);
		}

		return $aInstance;
	}

	public function widget($atts, $aInstance){
		$aInstance = wp_parse_args($aInstance, $this->aDef);
		echo $atts['before_widget'];
		?>
        <div class="widget widget_downapp">
            <h4 class="widget_title"><?php echo esc_html($aInstance['title']); ?></h4>
            <div class="widget-downapp__body">
                <?php if ( !empty($aInstance['app_store_url']) ) : ?>
                <a href="<?php echo esc_url($aInstance['app_store_url']); ?>" title="<?php echo esc_attr($aInstance['app_store_title']); ?>" target="_blank">
                    <img src="<?php echo esc_url($aInstance['app_store_bg']); ?>" alt="<?php echo esc_attr($aInstance['app_store_title']); ?>">
                </a>
                <?php endif; ?>
		        <?php if ( !empty($aInstance['google_play_url']) ) : ?>
                <a href="<?php echo esc_url($aInstance['google_play_url']); ?>" title="<?php echo esc_attr($aInstance['google_play_title']); ?>">
                    <img src="<?php echo esc_url($aInstance['google_play_bg']); ?>" alt="<?php echo esc_attr($aInstance['google_play_title']); ?>">
                </a>
		        <?php endif; ?>
            </div>
        </div>
		<?php
		echo $atts['after_widget'];
	}
}
