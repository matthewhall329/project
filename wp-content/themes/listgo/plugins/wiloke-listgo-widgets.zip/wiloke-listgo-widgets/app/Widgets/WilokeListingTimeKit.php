<?php
/*
 * About Us/Me
 * @copyright Wiloke
 * @website https://wiloke.com
 */
use WilokeWidget\Supports\Helpers;

class WilokeListingTimeKit extends WP_Widget
{
	public $aDef = array('title' => 'Timekit');
    public $isSupportedTimeKit = null;

	public function __construct(){
		parent::__construct('wiloke_timekit', WILOKE_WIDGET_PREFIX . ' (OSP) Timekit', array('classname'=>'widget wiloke_timekit', 'description'=>esc_html__('OSP - Only Single Page. This widget is only available for single listing page.', 'wiloke')) );
		add_action('wp_enqueue_scripts', array($this, 'enqueueScripts'));
	}

	public function isSupportedTimekit(){
	    global $post;
	    if ( $this->isSupportedTimeKit !== null ){
	        return $this->isSupportedTimeKit;
        }

		$this->isSupportedTimeKit = true;
		if ( !is_singular('listing') ){
			$this->isSupportedTimeKit = false;
			return false;
		}

		$planID = get_post_meta($post->ID, 'wiloke_submission_belongs_to_plan_ID', true);
		if ( !empty($planID) ){
			$aPlanSettings = get_post_meta($planID, 'pricing_settings', true);
			if ( isset($aPlanSettings['toggle_timekit']) && $aPlanSettings['toggle_timekit'] == 'disable' ){
				$this->isSupportedTimeKit = false;
			}
		}

		return $this->isSupportedTimeKit;
    }

	public function enqueueScripts(){
	    $this->isSupportedTimekit();

	    if ( $this->isSupportedTimeKit ){
		    wp_enqueue_script('timekit');
		    wp_enqueue_script('listgo-timekit');
        }
	}

	public function form($aInstance){
		$aInstance = wp_parse_args($aInstance, $this->aDef);
		Helpers::textField(esc_html__('Title', 'wiloke'), $this->get_field_id('title'), $this->get_field_name('title'), $aInstance['title']);
	}

	public function update($aNewinstance, $aOldinstance) {
		$aInstance = $aOldinstance;
		foreach ( $aNewinstance as $key => $val ){
			$aInstance[$key] = strip_tags($val);
		}

		return $aInstance;
	}

	public function widget($atts, $aInstance){
		global $post;
		if ( !is_singular('listing') ){
			return false;
		}
		$this->isSupportedTimekit();
        if ( !$this->isSupportedTimeKit ){
            return '';
        }

		$aInstance = wp_parse_args($aInstance, $this->aDef);


		$aTimeKitSettings = get_post_meta($post->ID, 'listing_timekit', true);
		if ( empty($aTimeKitSettings) || empty($aTimeKitSettings['app']) || empty($aTimeKitSettings['apiToken']) ){
			return '';
		}

		echo $atts['before_widget'];
		echo $atts['before_title'] . $aInstance['title'] . $atts['after_title'];
		?>
		<div class="listgo-timekit-bookingjs" data-timekit="<?php echo esc_attr(json_encode($aTimeKitSettings)); ?>"></div>
		<?php
		echo $atts['after_widget'];
	}
}
