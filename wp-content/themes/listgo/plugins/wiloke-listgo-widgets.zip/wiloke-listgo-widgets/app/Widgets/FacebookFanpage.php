<?php
class piFacebookLikeBox extends piWilokeWidgets
{
    public $aDef = array( 'title' =>'Fanpage', 'page_url'=>'', 'appid'=>'');
    public function __construct()
    {
        $args = array('classname'=>'pi_facebook_likebox', 'description'=>'');
        parent::__construct("pi_facebook_likebox", parent::PI_PREFIX . 'Facebook', $args);
    }

    public function form($aInstance)
    {
        $aInstance = wp_parse_args(  $aInstance, $this->aDef );

        $this->pi_text_field( esc_html__('Title', 'wiloke-listgo-widgets'), $this->get_field_id('title'), $this->get_field_name('title'), $aInstance['title']);
        $this->pi_text_field( esc_html__('App ID', 'wiloke-listgo-widgets'), $this->get_field_id('appid'), $this->get_field_name('appid'), $aInstance['appid']);
        ?>
        <p>
            <code><a target="_blank" href="https://developers.facebook.com/docs/plugins/page-plugin" target="_blank"><?php esc_html_e('Find my App Id', 'wiloke-listgo-widgets'); ?></a></code>
        </p>
        <?php
        $this->pi_link_field( esc_html__('Facebook Page URL:', 'wiloke-listgo-widgets'), $this->get_field_id('page_url'), $this->get_field_name('page_url'), $aInstance['page_url'], 'EG. http://www.facebook.com/envato');
    }

    public  function update($new_instance, $old_instance)
    {
        $instance = $old_instance;
        foreach ( $new_instance as $key => $val )
        {
            $instance[$key] = strip_tags($val);
        }
        return $instance;
    }

    public function widget( $atts, $aInstance )
    {
        print $atts['before_widget'];

        if( !empty($aInstance['title']) )
        {
            print $atts['before_title'].esc_html($aInstance['title']).$atts['after_title'];
        }
        echo '<div class="box-content">';

        ?>
        <iframe src="<?php echo esc_url($aInstance['page_url']); ?>" width="340" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
        <?php
        echo '</div>';

        print $atts['after_widget'];
    }
}
