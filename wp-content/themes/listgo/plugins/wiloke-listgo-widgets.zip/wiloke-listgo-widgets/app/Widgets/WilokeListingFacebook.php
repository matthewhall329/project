<?php
/*
 * About Us/Me
 * @copyright Wiloke
 * @website https://wiloke.com
 */
use WilokeWidget\Supports\Helpers;

class WilokeListingFacebook extends WP_Widget
{
	public $aDef = array('title' => 'Facebook', 'height'=>200);
	public $isSupportedFacebook = null;

	public function __construct(){
		parent::__construct('wiloke_listing_facebook', WILOKE_WIDGET_PREFIX . ' (OSP) Facebook Fanpage', array('classname'=>'widget wiloke_listing_facebook', 'description'=>esc_html__('OSP - Only Single Page. This widget is only available for single listing page.', 'wiloke-listgo-widgets')) );
	}

	public function isSupportedFacebook(){
		global $post;
		if ( $this->isSupportedFacebook !== null ){
			return $this->isSupportedFacebook;
		}

		if ( !is_singular('listing') ){
			$this->isSupportedFacebook = false;
			return false;
		}

		$this->isSupportedFacebook = true;

		$planID = get_post_meta($post->ID, 'wiloke_submission_belongs_to_plan_ID', true);
		if ( !empty($planID) ){
			$aPlanSettings = get_post_meta($planID, 'pricing_settings', true);

			if ( isset($aPlanSettings['toggle_facebook_fanpage']) && $aPlanSettings['toggle_facebook_fanpage'] == 'disable' ){
				$this->isSupportedFacebook = false;
			}
		}
		return $this->isSupportedFacebook;
	}

	public function form($aInstance){
		$aInstance = wp_parse_args($aInstance, $this->aDef);
		Helpers::textField(esc_html__('Title', 'wiloke-listgo-widgets'), $this->get_field_id('title'), $this->get_field_name('title'), $aInstance['title']);
		Helpers::textField(esc_html__('Height', 'wiloke-listgo-widgets'), $this->get_field_id('height'), $this->get_field_name('height'), $aInstance['height']);
	}

	public function update($aNewinstance, $aOldinstance) {
		$aInstance = $aOldinstance;
		foreach ( $aNewinstance as $key => $val ){
			$aInstance[$key] = strip_tags($val);
		}

		return $aInstance;
	}

	public function widget($atts, $aInstance){
		global $post;
		if ( !is_singular('listing') ){
			return false;
		}
		$this->isSupportedFacebook();
		if ( !$this->isSupportedFacebook ){
			return '';
		}

		$aInstance = wp_parse_args($aInstance, $this->aDef);


		$aFacebook = get_post_meta($post->ID, 'listing_facebook_fanpage', true);
		if ( empty($aFacebook) || empty($aFacebook['iframe_src']) ){
			return '';
		}

		echo $atts['before_widget'];
		echo $atts['before_title'] . $aInstance['title'] . $atts['after_title'];

		$aFacebook['iframe_src'] = str_replace(array('httpswww.facebook.com', '&tabs='), array('https%3A%2F%2Fwww.facebook.com%2F', '%2F&tabs='), $aFacebook['iframe_src']);
		?>
		<iframe src="<?php echo esc_url($aFacebook['iframe_src']); ?>" height="<?php echo esc_attr($aInstance['height']); ?>" width="340" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
		<?php
		echo $atts['after_widget'];
	}
}
