<?php
/*
 * About Us/Me
 * @copyright Wiloke
 * @website https://wiloke.com
 */

class WilokeSearchForm extends WP_Widget
{
	public $aDef = array('title' => '', 'keywords_field_title'=>'Enter address, city or select a suggestion', 'location_field_title'=>'Location');

	public function __construct()
	{
		parent::__construct('widget_search_form', WILOKE_WIDGET_PREFIX . ' Listing Search Form' );
		add_action('wp_enqueue_scripts', array($this, 'enqueueScripts'));
	}

	public function enqueueScripts(){
		wp_enqueue_style('wiloke-listgo-widget-search-form', WILOKE_WIDGET_URL . 'public/source/css/searchform-style.css', array(), WILOKE_WIDGET_VERSION, false);
	}

	public function form($aInstance) {
		$aInstance = wp_parse_args($aInstance, $this->aDef);
		\WilokeWidget\Supports\Helpers::textField(esc_html__('Title', 'wiloke'), $this->get_field_id('title'), $this->get_field_name('title'), $aInstance['title']);
		\WilokeWidget\Supports\Helpers::textField(esc_html__('Keywords Field Title', 'wiloke'), $this->get_field_id('keywords_field_title'), $this->get_field_name('keywords_field_title'), $aInstance['keywords_field_title']);
		\WilokeWidget\Supports\Helpers::textField(esc_html__('Location Field Title', 'wiloke'), $this->get_field_id('location_field_title'), $this->get_field_name('location_field_title'), $aInstance['location_field_title']);
	}

	public function update($aNewinstance, $aOldinstance){
		$aInstance = $aOldinstance;
		foreach ( $aNewinstance as $key => $val ){
			$aInstance[$key] = strip_tags($val);
		}

		return $aInstance;
	}

	public function widget($atts, $aInstance)
	{
		$aInstance = wp_parse_args($aInstance, $this->aDef);
		echo $atts['before_widget'];
			if ( !empty($aInstance['title']) ){
				echo $atts['before_title']  . esc_html($aInstance['title']) . $atts['after_title'];
			}

			WilokeSearchSystem::searchForm(null, false, array(
				'search_field_title' => $aInstance['keywords_field_title'],
				'location_field_title' => $aInstance['location_field_title']
			));
		echo $atts['after_widget'];
	}
}
