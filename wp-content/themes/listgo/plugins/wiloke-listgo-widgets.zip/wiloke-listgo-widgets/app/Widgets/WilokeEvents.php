<?php
/*
 * About Us/Me
 * @copyright Wiloke
 * @website https://wiloke.com
 */
use WilokeWidget\Supports\Helpers;
use WilokeListGoFunctionality\Frontend\FrontendEvents;
use WilokeListGoFunctionality\AlterTable\AlterTableGeoPosition;

class WilokeEvents extends WP_Widget
{
	public $aDef = array('title' => 'Events', 'order_by'=>'rand', 'number_of_events'=>3);
	public $orderBy = '';

	public function __construct()
	{
		parent::__construct('widget_events', WILOKE_WIDGET_PREFIX . ' Event', array('classname'=>'widget_events') );
		add_action('wp_ajax_fetch_event_show_on_sidebar', array($this, 'fetchEvents'));
		add_action('wp_ajax_nopriv_fetch_event_show_on_sidebar', array($this, 'fetchEvents'));
	}

	public function renderEvent($post, $aEventStatus){
		$aSettings = Wiloke::getPostMetaCaching($post->ID, 'event_settings');
		if ( !empty($aSettings['belongs_to']) ){
			$linkToEvent = get_permalink($aSettings['belongs_to']) . '#tab-event--goto-event-'.$post->ID;
			$target = '_self';
		}else{
			$linkToEvent = isset($aSettings['event_link']) ? $aSettings['event_link'] : '#';
			$target = '_blank';
		}
		?>
        <a class="widget-events__item" href="<?php echo esc_url($linkToEvent); ?>" target="<?php echo esc_attr($target); ?>">
        	<?php 
        	if ( has_post_thumbnail($post->ID) ){
        		echo get_the_post_thumbnail($post->ID, 'thumbnail');
        	}
        	?>
            <h2 class="widget-events__title"><?php echo esc_html(get_the_title($post->ID)); ?></h2>
            <span class="widget-events__status <?php echo esc_attr($aEventStatus['status']); ?>"><?php echo esc_html($aEventStatus['name']); ?></span>
        </a>
		<?php
	}

	public function searchLocationWithin($centerLat, $centerLng, $limit, $distance=5){
		global $wpdb;
		$geoTbl = $wpdb->prefix . AlterTableGeoPosition::$tblName;
		$postMetaTbl = $wpdb->prefix . 'postmeta';
		$postTbl = $wpdb->prefix . 'posts';

		$limit = empty($limit) ? 100000 : abs($limit);
		$distance = empty($distance) ? 10 : abs($distance);

		if ( $this->orderBy == 'events_nearby_customer' ){
			$aObjectIDs = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT $geoTbl.postID, ( 6371 * acos( cos( radians('%s') ) * cos( radians( $geoTbl.lat ) ) * cos( radians( $geoTbl.lng ) - radians('%s') ) + sin( radians('%s') ) * sin( radians( $geoTbl.lat ) ) ) ) as distance FROM $geoTbl LEFT JOIN $postTbl ON ($postTbl.ID=$geoTbl.postID) WHERE $postTbl.post_type = 'event' AND $postTbl.post_status='publish' HAVING distance < %d ORDER BY distance LIMIT 0,%d",
					$centerLat, $centerLng, $centerLat, $distance, $limit
				),
				ARRAY_A
			);
        }else{
			$aObjectIDs = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT $geoTbl.postID, ( 6371 * acos( cos( radians('%s') ) * cos( radians( $geoTbl.lat ) ) * cos( radians( $geoTbl.lng ) - radians('%s') ) + sin( radians('%s') ) * sin( radians( $geoTbl.lat ) ) ) ) as distance FROM $geoTbl LEFT JOIN $postMetaTbl ON ($postMetaTbl.post_id=$geoTbl.postID) WHERE $postMetaTbl.meta_key='toggle_show_events_on_event_widget' AND $postMetaTbl.meta_value='enable' HAVING distance < %d ORDER BY distance LIMIT 0,%d",
					$centerLat, $centerLng, $centerLat, $distance, $limit
				),
				ARRAY_A
			);
        }

		if ( empty($aObjectIDs) ){
			return false;
		}

		$aObjectIDs = array_map(function($aObject){
			return $aObject['postID'];
		}, $aObjectIDs);

		return array(
			'IDs' => $aObjectIDs
		);
    }

	public function fetchEvents(){
	    $numberOfEvents = empty($_GET['numberOfEvents']) || absint($_GET['numberOfEvents']) > 20 ? 3 : absint($_GET['numberOfEvents']);
		$this->orderBy = $_GET['orderBy'];
        if ( !empty($_GET['latLng']) ) {
	        $aEventData = $this->searchLocationWithin( trim($_GET['latLng']['lat']), trim($_GET['latLng']['lng']), $numberOfEvents, 10 );
	        if ( !empty( $aEventData ) ) {
		        $aAtts = array(
			        'post_type'   => 'event',
			        'post__in'    => $aEventData['IDs'],
			        'post_status' => 'publish'
		        );
		        $query = new WP_Query( $aAtts );
		        if ( $query->have_posts() ) {
			        ob_start();
			        while ( $query->have_posts() ) {
				        $query->the_post();
				        $aEventSettings = Wiloke::getPostMetaCaching( $query->post->ID, 'event_settings' );
				        $aEventStatus   = FrontendEvents::checkEventStatus( $aEventSettings );
				        $this->renderEvent( $query->post, $aEventStatus );
			        }
			        $content = ob_get_contents();
			        ob_end_clean();

			        wp_send_json_success(
				        array(
					        'msg' => $content
				        )
			        );
		        }
	        }
        }

        $aAtts = array(
            'post_type'      => 'event',
            'posts_per_page' => $numberOfEvents,
            'post_status'    => 'publish'
        );

        if ( $this->orderBy == 'toggle_show_events_on_event_widget' ){
	        $aAtts['meta_query'] = array(
		        'key'     => 'toggle_show_events_on_event_widget',
		        'value'   => '=',
		        'compare' => 'enable'
	        );
        }else{
	        $aAtts['orderby'] = $this->orderBy;
        }

        $query = new WP_Query($aAtts);

        if ( $query->have_posts() ){
            ob_start();
            while ($query->have_posts()){
                $query->the_post();
                $aEventSettings = Wiloke::getPostMetaCaching($query->post->ID, 'event_settings');
                $aEventStatus = FrontendEvents::checkEventStatus($aEventSettings);
                $this->renderEvent($query->post, $aEventStatus);
            }
            $content = ob_get_contents();
            ob_end_clean();

            wp_send_json_success(
                array(
                    'msg' => $content
                )
            );
        }else{
            wp_send_json_error();
        }

    }

	public function form($aInstance)
	{
		$aInstance = wp_parse_args( $aInstance, $this->aDef );
		Helpers::textField( esc_html__('Title', 'wiloke-listgo-widgets'), $this->get_field_id('title'), $this->get_field_name('title'), $aInstance['title']);
		Helpers::textField( esc_html__('Number of Events', 'wiloke-listgo-widgets'), $this->get_field_id('number_of_events'), $this->get_field_name('number_of_events'), $aInstance['number_of_events']);
		Helpers::selectField(
			esc_html__('Order By', 'wiloke-listgo-widgets'),
			$this->get_field_id('order_by'),
			$this->get_field_name('order_by'),
			array(
				'toggle_show_events_on_event_widget'    => esc_html__('Events have been granted to display on sidebar', 'wiloke-listgo-widgets'),
				'events_nearby_customer'    => esc_html__('Events Near By Customer', 'wiloke-listgo-widgets'),
				'events_nearby_customer_and_grant_to_permit'    => esc_html__('Events Near By Customer And have been granted to display on sidebar', 'wiloke-listgo-widgets'),
				'rand'          => esc_html__('Random', 'wiloke-listgo-widgets'),
				'post_date'     => esc_html__('Latest Events', 'wiloke-listgo-widgets')
			),
			$aInstance['order_by']
		);
	}

	public function update($aNewinstance, $aOldinstance) {
		$aInstance = $aOldinstance;
		foreach ( $aNewinstance as $key => $val )
		{
			if ( $key == 'number_of_posts' )
			{
				$aInstance[$key] = (int)$val;
			}else{
				$aInstance[$key] = strip_tags($val);
			}
		}
		return $aInstance;
	}

	public function widget($atts, $aInstance)
	{
	    if ( $aInstance['order_by'] !== 'events_nearby_customer_and_grant_to_permit' && $aInstance['order_by'] !='events_nearby_customer' ){
		    $aAtts =  array(
			    'post_type'      => 'event',
			    'posts_per_page' => $aInstance['number_of_events'],
			    'post_status'    => 'publish'
		    );

		    if ( $aInstance['order_by'] ){
			    $aAtts['orderby'] = $aInstance['order_by'];
		    }else{
			    $aAtts['meta_query'] = array(
				    array(
					    'key'     => 'toggle_show_events_on_event_widget',
					    'value'   => '=',
					    'compare' => 'enable'
				    )
			    );
		    }

		    $query = new WP_Query($aAtts);
		    if ( !$query->have_posts() ){
			    wp_reset_postdata();
			    return '';
		    }

		    echo $atts['before_widget'];
		    ?>
            <div class="widget widget_events">
                <h4 class="widget_title"><?php echo esc_html($aInstance['title']); ?></h4>
                <div class="widget-events__body">
				    <?php
				    while ( $query->have_posts() ) : $query->the_post();
					    $aEventSettings = Wiloke::getPostMetaCaching($query->post->ID, 'event_settings');
					    $aEventStatus = FrontendEvents::checkEventStatus($aEventSettings);
                        $this->renderEvent($query->post, $aEventStatus);
                    endwhile; wp_reset_postdata();
                    ?>
                </div>
            </div>
		    <?php
		    echo $atts['after_widget'];
        }else{
		    echo $atts['before_widget'];
		    ?>
            <div class="widget widget_events show_event_near_by_customer block-loading" data-orderby="<?php echo esc_attr($aInstance['order_by']); ?>" data-numberofevents="<?php echo esc_attr($aInstance['number_of_events']); ?>">
                <h4 class="widget_title"><?php echo esc_html($aInstance['title']); ?></h4>
                <div class="widget-events__body">

                </div>
            </div>
		    <?php
		    echo $atts['after_widget'];
        }
	}
}
