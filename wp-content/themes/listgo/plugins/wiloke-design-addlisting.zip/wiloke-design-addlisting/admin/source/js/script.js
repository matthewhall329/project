Vue.component('tabs', {
	data(){
		return {
			tabs: []
		};
	},
	template: `
		<div>
			<div class="ui top attached tabular menu">
			  <a class="item" v-for="tab in tabs" :class="{active: tab.isActive}" :data-tab="tab.tabkey">{{tab.name}}</a>
			</div>
			<slot></slot>
		</div>
	`,
	mounted() {
		this.tabs = this.$children;
	}
});

Vue.component('tab', {
	template: `
		<div class="ui bottom attached tab segment" :class="{active: isActive}" :data-tab="tabkey" :name="name"><slot></slot></div>
	`,
	props: {
		name: {required: true},
		tabkey: {required: true},
		isActive: false
	}
});

Vue.config.devtools = true;

const config = {
	errorBagName: 'errors', // change if property conflicts
	fieldsBagName: 'fields',
	delay: 0,
	locale: 'en',
	dictionary: null,
	strict: true,
	classes: false,
	classNames: {
		touched: 'touched', // the control has been blurred
		untouched: 'untouched', // the control hasn't been blurred
		valid: 'valid', // model is valid
		invalid: 'invalid', // model is invalid
		pristine: 'pristine', // control has not been interacted with
		dirty: 'dirty' // control has been interacted with
	},
	events: 'input|blur',
	inject: true,
	validity: false,
	aria: true,
	i18n: null, // the vue-i18n plugin instance,
	i18nRootKey: 'validations' // the nested key under which the validation messsages will be located
};

let blockKey = 0, oCustomField = {};
Vue.use(VeeValidate, config);
let vm = new Vue({
	el: "#wiloke-add-listing-fields",
	data: {
		usedBlock: WILOKE_SUBMISSION_LISTING_SETTINGS.usedBlock,
		availableBlock: WILOKE_SUBMISSION_LISTING_SETTINGS.availableBlock,
		allBlock: WILOKE_SUBMISSION_LISTING_SETTINGS.allBlock,
		singleTabs: WILOKE_SUBMISSION_SINGLE_LISTING_SETTINGS,
		savingXHR: null,
		// oCustomFields: WILOKE_SUBMISSION_LISTING_SETTINGS.customFields,
		oCustomFieldKeys: WILOKE_SUBMISSION_LISTING_SETTINGS.aCustomFieldKeys,
		temporarilySaveBlockName: '',
		// list: WILOKE_SUBMISSION_LISTING_SETTINGS.usedBlock,
		savedMessage:'',
		addedCustomFields: 'text',
		aCustomFields: [
			'text', 'textarea', 'select', 'gallery', 'image'
		]
	},
	props: ['list'],
	methods: {
		uCaseFirst: function (customField) {
			let lengthOfText    = customField.length,
				firstCharacter  = customField.substr(0, 1),
				restCharacter   = customField.substr(1, lengthOfText);

			return firstCharacter.toUpperCase() + restCharacter;
		},
		blockNameID: function(blockKey){
			return 'block-name-'+blockKey;
		},
		blockKeyID: function(blockKey){
			return 'block-key-'+blockKey;
		},
		addedANewBlock: function () {
			console.log(this.usedBlock);
		},
		addCustomField: function(event){
			let func = jQuery(event.currentTarget).data('func');
			func = typeof func !== 'undefined' ? func : 'push';

			switch (this.addedCustomFields){
				case 'text':
					this.usedBlock[func]({
							blockName: 'My Text Field',
							blockKey: 'my_text_field',
							isCustomField: true,
							blockType: 'text',
							fields:[
								{
									heading: 'Description',
									type: 'text',
									key: 'description',
									description: ''
								},
								{
									heading: 'Required Field?',
									type: 'checkbox',
									key: 'isRequired',
									isRequired: false
								}
							],
							id: this.usedBlock.length
						}
					);
					break;
				case 'textarea':
					this.usedBlock[func]({
						blockName: 'My Textarea Field',
						blockKey: 'my_textarea_field',
						isCustomField: true,
						blockType: 'textarea',
						fields:[
							{
								heading: 'Description',
								type: 'text',
								key: 'description',
								description: ''
							},
							{
								heading: 'Required Field?',
								type: 'checkbox',
								key: 'isRequired',
								isRequired: false
							}
						],
						id: this.usedBlock.length
					});
					break;
				case 'select':
					this.usedBlock[func]({
						blockName: 'My Select Field',
						blockKey: 'my_select_field',
						isCustomField: true,
						blockType: 'select',
						fields:[
							{
								heading: 'Description',
								type: 'text',
								key: 'description',
								description: ''
							},
							{
								heading: 'Options',
								type: 'textarea',
								key: 'options',
								options:'',
								isRequired: true,
								desc: 'Enter your options separated with commas',
							},
							{
								heading: 'Multiple Select?',
								type: 'checkbox',
								key: 'is_multiple_select',
								is_multiple_select: false,
								description:''
							},
							{
								heading: 'Required Field?',
								type: 'checkbox',
								key: 'isRequired',
								isRequired: false
							}
						],
						id: this.usedBlock.length
					});
					break;
				case 'gallery':
					this.usedBlock[func]({
							blockName: 'My Gallery',
							blockKey: 'my_gallery',
							isCustomField: true,
							blockType: 'gallery',
							fields:[
								{
									heading: 'Description',
									type: 'text',
									key: 'description',
									description: ''
								},
								{
									heading: 'Required Field?',
									type: 'checkbox',
									key: 'isRequired',
									isRequired: false
								}
							],
							id: this.usedBlock.length
						}
					);
					break;
				case 'image':
					this.usedBlock[func]({
							blockName: 'My Image',
							blockKey: 'my_image',
							isCustomField: true,
							blockType: 'image',
							fields:[
								{
									heading: 'Description',
									type: 'text',
									key: 'description',
									description: ''
								},
								{
									heading: 'Required Field?',
									type: 'checkbox',
									key: 'isRequired',
									isRequired: false
								}
							],
							id: this.usedBlock.length
						}
					);
					break;
			}
		},
		saveValues: function (event) {
			this.$validator.validateAll().then((result) => {
				if (result) {
					if ( this.savingXHR !== null && this.savingXHR.status !== 200 ){
						this.savingXHR.abort();
					}

					let aUsedBlock = this.usedBlock, $printMsg = jQuery('#print-msg'), $form = jQuery('#wiloke-design-listing-form');

					$form.addClass('loading');

					this.savingXHR = jQuery.ajax({
						type: 'POST',
						url: ajaxurl,
						data: {
							results: aUsedBlock,
							action: 'wiloke_save_design_listing_settings'
						},
						success:(response=>{
							if ( response.success ){
								this.savedMessage = response.data.msg;
								setTimeout((()=>{
									this.savedMessage = '';
								}), 10000);
							}else{
								$printMsg.addClass('hidden');
								alert(response.data.msg);
							}

							$form.removeClass('loading');
						})
					});

					return true;
				}
			});
		},
		generateKeyFromBlockname: function(blockName){
			blockName = blockName.toLowerCase();
			blockName = blockName.replace(/,|\.,\?/gi, function () {
				return '';
			});

			return blockName.split(' ').join('_').trim(' ');
		},
		changedBlockName: function(event){
			if ( jQuery(event.currentTarget).hasClass('isCustomField') ){
				let blockKeyID = jQuery(event.currentTarget).data('blockkeyid');
				this.usedBlock[blockKeyID]['blockKey'] = this.generateKeyFromBlockname(jQuery(event.currentTarget).val());
			}
		},
		removeBlock: function (event) {
			let $target = jQuery(event.currentTarget),
				order = $target.data('order');

			if ( $target.hasClass('isCustomField') ){
				let askBeforeDeleting = confirm('You want to delete this block?');
				if ( !askBeforeDeleting ){
					return false;
				}
				this.usedBlock.splice(order, 1);
			}else{
				let removedBlockKey = this.usedBlock[order].blockKey;
				this.usedBlock.splice(order, 1);

				if ( typeof this.allBlock[removedBlockKey] !== 'undefined' ){
					this.availableBlock.push(
						this.allBlock[removedBlockKey]
					);
				}
			}
		},
		printPrettyOptions: function(options){
			options = options.trim(' ');
			if ( options==='' ){
				return '';
			}else{
				let aOptions = options.split(',');
				let prettyOptions = '';
				for ( order in aOptions ){
					prettyOptions += '<li>'+aOptions[order]+'</li>';
				}

				return prettyOptions;
			}
		},
		expandBlockSettings: function (event) {
			jQuery(event.currentTarget).siblings('.dragArea__form-content').toggleClass('hidden');
		},
		addCustomSingleTab: function (event) {
			this.singleTabs.push({
				name: 'Custom Tab',
				isCustomTab: true,
				toggle: true,
				content: ''
			});
		},
		removeCustomTab: function (event) {
			let order = jQuery(event.currentTarget).data('order');
			this.singleTabs.splice(order, 1);
		},
		saveSingleListingSettings: function (event) {
			if ( this.savingXHR !== null && this.savingXHR.status !== 200 ){
				this.savingXHR.abort();
			}

			let aSingleListingSettings = this.singleTabs, $form = jQuery('#wiloke-design-single-listing-form');

			$form.addClass('loading');

			this.savingXHR = jQuery.ajax({
				type: 'POST',
				url: ajaxurl,
				data: {
					results: aSingleListingSettings,
					action: 'wiloke_save_design_single_listing'
				},
				success:(response=>{
					if ( response.success ){
						this.savedMessage = response.data.msg;
						setTimeout((()=>{
							this.savedMessage = '';
						}), 10000);
					}else{
						$printMsg.addClass('hidden');
						alert(response.data.msg);
					}

					$form.removeClass('loading');
				})
			});

			return true;
		}
	},
	computed: {
		showingCustomFields: function () {
			let aUsedCustomFields = [];
			if ( this.usedBlock.length ){
				this.usedBlock.forEach(oField=>{
					if ( oField.isCustomField ){
						aUsedCustomFields.push(oField);
					}
				});
			}

			if ( !aUsedCustomFields.length ){
				return false;
			}else{
				return aUsedCustomFields;
			}
		}
	}
});

(function ($) {
	$(document).ready(function () {
		$('.menu .item').tab();
	});
})(jQuery);