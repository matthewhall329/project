<?php
/*
 * Plugin Name: Wiloke Design AddListing
 * Plugin URI: https://wiloke.com
 * Author: Wiloke
 * Author URI: https://wiloke.com
 * Version: 1.0.2
 * Description: This tool allows customizing your Add Listing page
 * Text Domain: wiloke-design-addlisting
 * Domain Path: /languages/
 */

define('WILOKE_DESIGN_ADDLISTING_VERSION', '1.0.2');
define('WILOKE_DESIGN_ADDLISTING_URL', plugin_dir_url(__FILE__));
define('WILOKE_DESIGN_ADDLISTING_DIR', plugin_dir_path(__FILE__));

add_action( 'plugins_loaded', 'wiloke_design_addlisting_load_textdomain' );
function wiloke_design_addlisting_load_textdomain() {
	load_plugin_textdomain( 'wiloke-design-addlisting', false, basename(dirname(__FILE__)) . '/languages' );
}

require plugin_dir_path(__FILE__) . 'vendor/autoload.php';
use WilokeDesignAddListing\Register\RegisterSettings;

require WILOKE_DESIGN_ADDLISTING_DIR . 'functions.php';

new RegisterSettings();