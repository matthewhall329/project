<?php
use WilokeDesignAddListing\Framework\Helpers\Repository;

if ( !function_exists('wilokeDesignAddListingRepository') ){
	function wilokeDesignAddListingRepository(){
		return new Repository;
	}
}
