<?php
namespace WilokeDesignAddListing\Register;

use WilokeDesignAddListing\Framework\Helpers\Inc;
use WilokeDesignAddListing\Framework\Helpers\Repository;
use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
use WilokeListgoFunctionality\Framework\Helpers\SetSettings;

class RegisterSettings {
	public static $slug = 'design-addlisting-tool';
	public static $optionKey = 'wiloke_design_addlisting_page';
	public static $fieldsSettingsKey = 'wiloke_design_fields_settings';
	protected $designListingOptionsKey = 'wiloke_design_addlisting_page';
	protected $blockTitleLocationCategoriesKey = 'wiloke_block_title_cats_locations';
	protected $designSingleListingsKey = 'wiloke_design_single_listing_tab';

	public function __construct() {
		add_action('admin_init', array($this, 'setDefaultDesignAddListing'));
		add_action('admin_init', array($this, 'setDefaultDesignSingleListing'));
		add_action('admin_menu', array($this, 'register'));
		add_action('admin_enqueue_scripts', array($this, 'enqueueScripts'));
		add_action('wp_ajax_wiloke_save_design_listing_settings', array($this, 'saveSettings'));
		add_action('wp_ajax_wiloke_save_design_single_listing', array($this, 'saveSingleListingSettings'));
	}

	protected function parseBlock(){
		$aUsedBlock = $aAvailableBlock = array();
		$usedBlock = get_option(self::$optionKey);
		$aAllBlock = wilokeDesignAddListingRepository()->get('settings:aAllBlock');

		$elementID = 0;

		if ( empty($usedBlock) ){
			$i = 0;
			foreach ($aAllBlock as $blockType => $aBlock) {
				if ( isset($aBlock['isDefault']) && $aBlock['isDefault'] ){
					$aUsedBlock[$i] = $aBlock;
					$aUsedBlock[$i]['id'] = $elementID;
					$i++;
					$elementID++;
				}
			}
		}else{
			$aUsedBlock = maybe_unserialize($usedBlock);
			foreach ($aUsedBlock as $blockKey => $aBlock){
				if ( isset($aBlock['isCustomField']) ){
					continue;
				}
				
				if ( !isset($aAllBlock[$aBlock['blockKey']]['fields']) || !isset($aBlock['fields']) || (count($aAllBlock[$aBlock['blockKey']]['fields']) ==  count($aBlock['fields']))){
					continue;
				}

				$aUsedFieldKeys = array_map(function($aField){
					return $aField['key'];
				}, $aBlock['fields']);

				foreach ($aAllBlock[$aBlock['blockKey']]['fields'] as $aField){
					if ( !in_array($aField['key'], $aUsedFieldKeys) ){
						$aNewFields[] = $aField;
					}
				}

				if ( isset($aNewFields) ){
					$aUsedBlock[$blockKey]['fields'] = array_replace($aUsedBlock[$blockKey]['fields'], $aNewFields);
				}

				$aUsedBlock[$blockKey]['id'] = $elementID;
				$elementID++;
			}
		}

		if ( empty($aUsedBlock) ){
			$i = 0;
			foreach ($aAllBlock as $blockType => $aBlock) {
				$aAvailableBlock[$i] = $aBlock;
				$aAvailableBlock[$i]['id'] = $elementID;
				$elementID++;
				$i++;
			}
		}else{
			$aUsedBlockKeys = array_map(function($aField){
				return $aField['blockType'];
			}, $aUsedBlock);
			$aAllBlockKeys  = array_keys($aAllBlock);

			$aAvailableBlockKeys = array_diff($aAllBlockKeys, $aUsedBlockKeys);

			if ( !empty($aAvailableBlockKeys) ){
				$i = 0;
				foreach ($aAvailableBlockKeys as $field) {
					$aAvailableBlock[$i] = $aAllBlock[$field];
					$aAvailableBlock[$i]['id'] = $elementID;
					$elementID++;
					$i++;
				}
			}
		}

		return array(
			'allBlock' => $aAllBlock,
			'usedBlock' => $aUsedBlock,
			'availableBlock' => $aAvailableBlock
		);
	}

	public function setDefaultDesignSingleListing(){
		if ( !class_exists('WilokeListgoFunctionality\Framework\Helpers\GetSettings') ){
			return false;
		}
		if ( GetSettings::getOptions($this->designSingleListingsKey) ){
			return false;
		}

		$aDesignSingleListing = wilokeDesignAddListingRepository()->get('settings:aDesignSingleListing');
		SetSettings::setOptions($this->designSingleListingsKey, $aDesignSingleListing);
	}

	public function setDefaultDesignAddListing(){
		if ( !class_exists('WilokeListgoFunctionality\Framework\Helpers\GetSettings') ){
			return false;
		}
		
		if ( GetSettings::getOptions($this->designListingOptionsKey) ){
			return false;
		}

		$aParseBlock = $this->parseBlock();
		SetSettings::setOptions($this->designListingOptionsKey, $aParseBlock['usedBlock']);
	}

	protected function parseGeneralBlocks($aBlock){
		foreach ( $aBlock['fields'] as $aField ) {
			$aFieldSettings[$aField['key']] = $aField[$aField['key']];
		}
		return $aFieldSettings;
	}

	protected function parseTitleLocationCategoriesGroup($aBlock){
		$aFieldSettings = array();
		foreach ( $aBlock['fields'] as $aField ) {
			$aFieldSettings[$aField['key']] = $aField[$aField['key']];
		}

		$aListingTitle = array();
		$aListingCategories = array();
		$aListingLocation = array();
		$aGoogleAddress = array();

		foreach ($aFieldSettings as $key => $setting){
			if ( strpos($key, 'listing_title') !== false ){
				$aListingTitle[$key] = $setting;
			}else if ( strpos($key, 'listing_cats') !== false ){
				$aListingCategories[$key] = $setting;
			}else if(strpos($key, 'listing_location') !== false){
				$aListingLocation[$key] = $setting;
			}else{
				$aGoogleAddress[$key] = $setting;
			}
		}

		$aBlockSettings = array();
		$aBlockSettings['listing_title'] = array(
			'type'          => $aListingTitle['type'],
			'toggle'        => $aListingTitle['toggle_listing_title'],
			'isRequired'    => $aListingTitle['is_required_listing_title'],
			'title'         => $aListingTitle['listing_title'],
			'description'   => $aListingTitle['listing_title_description'],
		);
		$aBlockSettings['listing_cats'] = array(
			'toggle'        => $aListingCategories['toggle_listing_cats'],
			'isRequired'    => $aListingCategories['is_required_listing_cats'],
			'title'         => $aListingCategories['listing_cats_title'],
			'description'   => $aListingCategories['listing_cats_description'],
			'maximumSelection' => $aListingCategories['listing_cats_maximum_selection'],
		);
		$aBlockSettings['listing_location'] = array(
			'toggle'        => $aListingLocation['toggle_listing_location'],
			'isRequired'    => $aListingLocation['is_required_listing_location'],
			'title'         => $aListingLocation['listing_location_title'],
			'description'   => $aListingLocation['listing_location_description'],
		);
		$aBlockSettings['google_address'] = array(
			'toggle'        => $aGoogleAddress['toggle_google_address'],
			'isRequired'    => $aGoogleAddress['is_required_google_address'],
			'title'         => $aGoogleAddress['google_address_title'],
			'description'   => $aGoogleAddress['google_address_description'],
			'placeholder'    => $aGoogleAddress['google_address_placeholder']
		);

		update_option($this->blockTitleLocationCategoriesKey, maybe_serialize($aBlockSettings));
		return $aBlockSettings;
	}

	public function sanitizeBeforeSaving($aBlockValues){
		$aSafeBlockValues = array();
		foreach ($aBlockValues as $key => $aBlockValue){
			$aSanitizedValue = $aBlockValue;

			if ( isset($aSanitizedValue['blockName']) ){
				$aSanitizedValue['blockName'] = sanitize_text_field(stripslashes($aSanitizedValue['blockName']));
			}

			foreach ( $aBlockValue['fields'] as $fieldOrder =>  $aField ){
				switch ($aField['type']){
					case 'textarea':
						$aSanitizedValue['fields'][$fieldOrder][$aField['key']] = sanitize_textarea_field(stripslashes($aField[$aField['key']]));
						break;
					default:
						$aSanitizedValue['fields'][$fieldOrder][$aField['key']] = sanitize_text_field(stripslashes($aField[$aField['key']]));
						break;
				}
			}
			$aSafeBlockValues[$key] = $aSanitizedValue;
		}

		return $aSafeBlockValues;
	}

	public function saveSingleListingSettings(){
		if ( !current_user_can('administrator') ){
			wp_send_json_error(
				array(
					'msg' => esc_html__('You do not have permission to access this page', 'wiloke-design-addlisting')
				)
			);
		}

		$aRawData = $_POST['results'];
		$aSaveValues = array();

		foreach ($aRawData as $order => $aData){
			foreach ($aData as $fieldKey => $data){
				$aSaveValues[$order][$fieldKey] = strip_tags($data, '<br><i><a><strong><h1><h2><h3><h4><h5><h6>');
				$aSaveValues[$order][$fieldKey] = stripslashes($aSaveValues[$order][$fieldKey]);
			}
		}

		update_option($this->designSingleListingsKey, maybe_serialize($aSaveValues));

		wp_send_json_success(
			array(
				'msg' => esc_html__('Congrats! Your settings have been updated', 'wiloke-design-addlisting')
			)
		);
	}

	public function saveSettings(){
		if ( !current_user_can('administrator') ){
			wp_send_json_error(
				array(
					'msg' => esc_html__('You do not have permission to access this page', 'wiloke-design-addlisting')
				)
			);
		}

		$aValues = $this->sanitizeBeforeSaving($_POST['results']);
		$aFieldSettings = array();

		foreach ($aValues as $aBlock){
			switch ($aBlock['blockType']){
				case 'title_category_and_location_group':
					$aFieldSettings['title_category_and_location_group'] = $this->parseTitleLocationCategoriesGroup($aBlock);
					break;
				default:
					$aFieldSettings[$aBlock['blockKey']]['title'] = $aBlock['blockName'];
					$aFieldSettings[$aBlock['blockKey']]['type'] = $aBlock['blockType'];
					$aFieldSettings[$aBlock['blockKey']]['field'] = $this->parseGeneralBlocks($aBlock);
					$aFieldSettings[$aBlock['blockKey']]['key'] = $aBlock['blockKey'];
					$aFieldSettings[$aBlock['blockKey']]['isCustomField'] = isset($aBlock['isCustomField']) && $aBlock['isCustomField'] == 'true' ? true : false;
					break;
			}
		}

		update_option(self::$optionKey, maybe_serialize($aValues));
		update_option(self::$fieldsSettingsKey, maybe_serialize($aFieldSettings));

		wp_send_json_success(
			array(
				'msg' => esc_html__('Congrats! Your settings have been updated', 'wiloke-design-addlisting')
			)
		);
	}
	
	public function enqueueScripts($hook){
		if ( strpos($hook, self::$slug) === false ){
			return false;
		}

		wp_enqueue_script('vuejs', '//cdnjs.cloudflare.com/ajax/libs/vue/2.5.2/vue.min.js', array('jquery'), WILOKE_DESIGN_ADDLISTING_VERSION, true);
		wp_enqueue_script('vee-validate', 'https://unpkg.com/vee-validate@2.0.0-rc.7/dist/vee-validate.js', array('jquery'), WILOKE_DESIGN_ADDLISTING_VERSION, true);
		wp_enqueue_script('sortablejs', '//cdn.jsdelivr.net/npm/sortablejs@1.7.0/Sortable.min.js', array('jquery'), WILOKE_DESIGN_ADDLISTING_VERSION, true);
		wp_enqueue_script('draggable', '//cdnjs.cloudflare.com/ajax/libs/Vue.Draggable/2.15.0/vuedraggable.min.js', array('jquery'), WILOKE_DESIGN_ADDLISTING_VERSION, true);
		wp_enqueue_script('wiloke-design-addlisting', WILOKE_DESIGN_ADDLISTING_URL . 'admin/source/js/script.js', array('jquery'), WILOKE_DESIGN_ADDLISTING_VERSION, true);
		wp_enqueue_style('line-awesome', WILOKE_DESIGN_ADDLISTING_URL . 'admin/source/css/line-awesome.min.css', array(), WILOKE_DESIGN_ADDLISTING_VERSION);
		wp_enqueue_script('semantic-ui', WILOKE_DESIGN_ADDLISTING_URL . 'admin/assets/semantic-ui/semantic.min.js', array('jquery'), WILOKE_DESIGN_ADDLISTING_VERSION, true);
		wp_enqueue_style('semantic-ui', WILOKE_DESIGN_ADDLISTING_URL . 'admin/assets/semantic-ui/form.min.css', array(), WILOKE_DESIGN_ADDLISTING_VERSION, false);
		wp_enqueue_style('wiloke-design-addlisting', WILOKE_DESIGN_ADDLISTING_URL . 'admin/source/css/style.css', array(), WILOKE_DESIGN_ADDLISTING_VERSION);

		$aParseBlock = $this->parseBlock();

		wp_localize_script('wiloke-design-addlisting', 'WILOKE_SUBMISSION_LISTING_SETTINGS',
			array(
				'allBlock'          => $aParseBlock['allBlock'],
				'usedBlock'         => $aParseBlock['usedBlock'],
				'availableBlock'    => $aParseBlock['availableBlock']
			)
		);

		$aDesignSingleListing = get_option($this->designSingleListingsKey);

		if ( !empty($aDesignSingleListing) ){
			$aDesignSingleListing = maybe_unserialize($aDesignSingleListing);
		}else{
			$aDesignSingleListing = wilokeDesignAddListingRepository()->get('settings:aDesignSingleListing');
		}

		wp_localize_script('wiloke-design-addlisting', 'WILOKE_SUBMISSION_SINGLE_LISTING_SETTINGS', $aDesignSingleListing);
	}

	public function settingsArea(){
		Inc::file('settings:index');
	}

	public function register(){
		add_menu_page( esc_html__('Design AddListing', 'wiloke-design-addlisting'), esc_html__('Design AddListing', 'wiloke-design-addlisting'), 'edit_theme_options', self::$slug, array($this, 'settingsArea'), '', 25);
	}
}