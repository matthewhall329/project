<div id="wiloke-add-listing-fields">
    <tabs>
        <tab is-active="true" tabkey="design-add-listing-fields" name="<?php esc_html_e('Add Listing', 'wiloke-design-addlisting'); ?>">
            <h2 class="wiloke-add-listing-fields__title"><?php esc_html_e('Design Add Listing Fields', 'wiloke-design-addlisting'); ?></h2>
            <!-- drag -->
            <div class="drag">
                <div class="ui grid">
                    <div class="sixteen wide column">
                        <!-- drag__block -->
                        <div class="drag__block">
                            <h3 class="drag__title"><?php esc_html_e('Available Fields', 'wiloke-design-addlisting'); ?></h3>
                            <!-- dragArea drag__avai -->
                            <draggable v-model="availableBlock" class="dragArea drag__avai" :options="{group:'addListingFields'}">
                                <div v-for="oBlock in availableBlock" class="dragArea__item">
                                    <span class="dragArea__item-icon">
                                        <i class="la la-arrows-v"></i>
                                    </span>
                                    <span class="dragArea__item-text">
                                        {{oBlock.blockName}} <small>({{oBlock.blockType}})</small>
                                    </span>
                                </div>
                            </draggable>
                            <!-- /dragArea drag__avai -->
                        </div>
                        <!-- /drag__block -->
                    </div>
                    <div class="sixteen wide column">
                        <h3 class="drag__title"><?php esc_html_e('Used Fields', 'wiloke-design-addlisting'); ?></h3>
                        <form action="#" id="wiloke-design-listing-form" class="ui form" @submit.prevent="saveValues">
                            <!-- <div v-if="savedMessage!=''" class="print-msg ui message green active">{{savedMessage}}</div> -->
                            <div v-if="savedMessage!=''" class="print-msg wil-message success"><i class="la la-certificate"></i> {{savedMessage}}</div>
                            <!-- drag__btn-wrap -->
                            <div class="drag__btn-wrap">
                                <div class="drag__btn-group left">
                                    <select v-model="addedCustomFields" class="select dropdown ui field custom-field-options">
                                        <option v-for="customField in aCustomFields" :value="customField">{{uCaseFirst(customField)}}</option>
                                    </select>
                                    <button @click="addCustomField" data-func="unshift" class="ui pink button" type="button"><i class="la la-plus"></i> <?php esc_html_e('Add Custom Field', 'wiloke-design-addlisting'); ?></button>
                                </div>
                                <div class="drag__btn-group right">
                                    <button type="submit" class="ui green button"><i class="la la-save"></i> <?php esc_html_e('Save Changes', 'wiloke-design-addlisting'); ?></button>
                                </div>
                            </div>
                            <!-- /drag__btn-wrap -->
                            <draggable class="dragArea drag__used" v-model="usedBlock" @change="addedANewBlock" :options="{group:'addListingFields', handle: '.dragArea__form-title--icon'}">
                                <div class="dragArea__block" v-for="(oBlock, blockKey) in usedBlock" :key="oBlock.id">
                                    <div class="dragArea__form ui form field-wrapper segment">
                                        <div class="dragArea__form-title" @click.prevent="expandBlockSettings">
                                            <span class="dragArea__form-title--icon">
                                                <i class="la la-arrows-v"></i>
                                            </span>
                                            <span class="dragArea__form-title--text">
                                                {{usedBlock[blockKey].blockName}} <small>({{oBlock.blockType}})</small>
                                            </span>
                                            <span class="dragArea__form-title--remove" @click="removeBlock" :class="{'isCustomField': oBlock.isCustomField}" :data-order="blockKey" title="<?php esc_html_e('Remove field', 'wiloke-design-addlisting'); ?>">
                                                <i class="la la-times"></i>
                                            </span>
                                        </div>
                                        <div class="dragArea__form-content hidden">
                                            <input type="hidden" v-model='oBlock.blockType'>
                                            <input type="hidden" v-model='oBlock.isCustomField'>
                                            <div class="ui setting-field field">
                                                <label><?php esc_html_e('Block Name', 'wiloke-design-addlisting'); ?></label>
                                                <input :data-blockkeyid="blockKey" :class="{'isCustomField': oBlock.isCustomField}" v-on:keyup="changedBlockName" type="text" v-model='oBlock.blockName'>
                                            </div>

                                            <div v-if="typeof oBlock.blockDescription !== 'undefined'" class="ui setting-field field">
                                                <label><?php esc_html_e('Block Description', 'wiloke-design-addlisting'); ?></label>
                                                <input type="text" v-model='oBlock.blockDescription'>
                                            </div>

                                            <div v-if="oBlock.isCustomField" class="setting-field ui field">
                                                <label><?php esc_html_e('Block Key (*)', 'wiloke-design-addlisting'); ?></label>
                                                <p class="settings__desc"><i><?php esc_html_e('This field must be unique', 'wiloke-design-addlisting'); ?></i></p>
                                                <input type="text" v-model='oBlock.blockKey' v-validate="'required'" data-vv-name="oBlock.blockKey">
                                                <p v-show="errors.has(oBlock.blockKey)" class="ui red message">{{ errors.first(oBlock.blockKey) }}</p>
                                            </div>

                                            <!-- settings -->
                                            <div class="settings" v-for="(oField, fieldOrder) in oBlock.fields">
                                                <div v-if="oField.type=='text'" class="ui setting-field field">
                                                    <label class="settings__heading">{{oField.heading}}</label>
                                                    <p class="settings__desc" v-if="oField.desc!=''"><i>{{oField.desc}}</i></p>
                                                    <input type="text" v-model='oField[oField.key]'>
                                                </div>

                                                <div v-if="oField.type=='select'" class="ui setting-field field">
                                                    <label class="settings__heading">{{oField.heading}}</label>
                                                    <p class="settings__desc" v-if="oField.desc!=''"><i>{{oField.desc}}</i></p>
                                                    <select v-model="oField[oField.key]" class="ui fluid dropdown">
                                                        <option v-for="(name, value) in oField.options" :value="value">{{name}}</option>
                                                    </select>
                                                </div>

                                                <div v-if="oField.type=='textarea'" class="ui setting-field field">
                                                    <label class="settings__heading">{{oField.heading}}</label>
                                                    <p class="settings__desc" v-if="oField.desc!=''"><i>{{oField.desc}}</i></p>
                                                    <ul class="settings__list" v-if="oField.key == 'options'" v-html="printPrettyOptions(oField[oField.key])"></ul>
                                                    <textarea v-if="oField.isRequired" v-model='oField[oField.key]' v-validate="'required'" :data-vv-name="oField[oField.key]"></textarea>
                                                    <p v-if="oField.isRequired" v-show="errors.has(oField[oField.key])" class="ui red message">{{ errors.first(oField[oField.key]) }}</p>
                                                    <textarea v-if="!oField.isRequired" v-model='oField[oField.key]'></textarea>
                                                </div>

                                                <div v-if="oField.type=='checkbox'" class="ui setting-field field toggle checkbox">
                                                    <input type="checkbox" v-model="oField[oField.key]" true-value="true" false-value="false">
                                                    <label class="settings__heading">{{oField.heading}}</label>
                                                    <p class="settings__desc" v-if="oField.desc!=''"><i>{{oField.desc}}</i></p>
                                                </div>
                                            </div>
                                            <!-- /settings -->
                                        </div>
                                    </div>
                                </div>

                                <!-- <div v-if="savedMessage!=''" class="print-msg ui message green active">{{savedMessage}}</div> -->
                                <div v-if="savedMessage!=''" class="print-msg wil-message success"><i class="la la-certificate"></i> {{savedMessage}}</div>

                                <!-- drag__btn-wrap -->
                                <div class="drag__btn-wrap">
                                    <div class="drag__btn-group left">
                                        <select v-model="addedCustomFields" class="select dropdown ui field custom-field-options">
                                            <option v-for="customField in aCustomFields" :value="customField">{{uCaseFirst(customField)}}</option>
                                        </select>
                                        <button @click="addCustomField" class="ui pink button" type="button"><i class="la la-plus"></i> <?php esc_html_e('Add Custom Field', 'wiloke-design-addlisting'); ?></button>
                                    </div>
                                    <div class="drag__btn-group right">
                                        <button type="submit" class="ui green button"><i class="la la-save"></i> <?php esc_html_e('Save Changes', 'wiloke-design-addlisting'); ?></button>
                                    </div>
                                </div>
                                <!-- drag__btn-wrap -->

                            </draggable>
                        </form>
                    </div>
                </div>
            </div>
        </tab>

        <tab class="ui bottom attached tab segment" tabkey="design-add-listing-page" name="<?php esc_html_e('Single Listing', 'wiloke-design-addlisting'); ?>">
            <h2 class="wiloke-add-listing-fields__title"><?php esc_html_e('Design Single Listing page', 'wiloke-design-addlisting'); ?></h2>

            <form action="#" id="wiloke-design-single-listing-form" class="ui form" @submit.prevent="saveSingleListingSettings">
                <div class="ui red message"><?php esc_html_e('Warning: The tab name must be unique', 'wiloke-design-addlisting'); ?></div>

                <div class="ui message">
                    <div class="header">
                        <?php esc_html_e('The list of default shortcodes', 'wiloke-design-addlisting'); ?>
                    </div>
                    <ul class="list">
                        <li>[wilokeContent]: <?php esc_html_e('Displaying the listing content', 'wiloke-design-addlisting'); ?></li>
                        <li>[wilokeReview]: <?php esc_html_e('Displaying the review items and the review form', 'wiloke-design-addlisting'); ?></li>
                        <li>[wilokeContactFormAndMap]: <?php esc_html_e('Displaying the the contact form and the listing map', 'wiloke-design-addlisting'); ?></li>
                        <li>[wilokeTimeKit]: <?php esc_html_e('Displaying the Timekit', 'wiloke-design-addlisting'); ?></li>
                        <li>[wilokeCoupon popup_title='Use the coupon code below' btn_name='Get Coupon Code']: <?php esc_html_e('Displaying the counpon', 'wiloke-design-addlisting'); ?></li>
                    </ul>

                    <br>

                    <div class="header">
		                <?php esc_html_e('How to show my custom fields on the single listing page?', 'wiloke-design-addlisting'); ?>
                    </div>

                    <ul class="list">
                        <li><?php esc_html_e('To show a custom field on the single page, please put the following code  [wilokeMyCustomField type="fieldType" block_key="blockKey" heading="My Title" headingTag="h3" description=""] to the Tab Content setting.', 'wiloke-design-addlisting'); ?></li>
                    </ul>

                    <br>

                    <div v-if="showingCustomFields">
                        <div class="header">
	                        <?php esc_html_e('Your current custom fields:', 'wiloke-design-addlisting'); ?>
                        </div>
                        <ol class="list">
                            <li v-for="oField in showingCustomFields">Block Key: {{oField.blockKey}} - Type: {{oField.blockType}}</li>
                        </ol>
                    </div>
                </div>

                <div v-if="savedMessage!=''" class="print-msg wil-message success"><i class="la la-certificate"></i> {{savedMessage}}</div>

                <draggable v-model="singleTabs" class="dragArea" :options="{handle: '.dragArea__form-title--icon'}">
                    <div v-for="(oSingleTab, order) in singleTabs" class="dragArea__block">
                        <div class="dragArea__form ui form field-wrapper segment">
                            <div class="dragArea__form-title" @click.prevent="expandBlockSettings">
                                <span class="dragArea__form-title--icon">
                                    <i class="la la-arrows-v"></i>
                                </span>
                                <span class="dragArea__form-title--text">
                                    {{oSingleTab.name}}
                                </span>
                                <span v-if="oSingleTab.isCustomTab" class="dragArea__form-title--remove" @click.prevent="removeCustomTab" title="<?php esc_html_e('Remove Tab', 'wiloke-design-addlisting'); ?>" :data-order="order">
                                    <i class="la la-times"></i>
                                </span>
                            </div>
                            <div class="dragArea__form-content hidden">
                                <div class="ui setting-field field toggle checkbox">
                                    <input type="checkbox" v-model="oSingleTab.toggle" true-value="true" false-value="false">
                                    <label class="settings__heading"><?php esc_html_e('Tab Toggle', 'wiloke-design-addlisting') ?></label>
                                </div>
                                <div class="ui setting-field field">
                                    <label class="settings__heading"><?php esc_html_e('Tab Name', 'wiloke-design-addlisting'); ?></label>
                                    <input type="text" v-model='oSingleTab.name'>
                                </div>
                                <div class="ui setting-field field">
                                    <label class="settings__heading"><?php esc_html_e('Tab Content', 'wiloke-design-addlisting'); ?></label>
                                    <textarea type="text" v-model='oSingleTab.content'></textarea>
                                    <div class="ui blue message"><i><?php esc_html_e('You can use the simple html tags such as &lt;h1>, &lt;h2>, &lt;h3>, &lt;h4>, &lt;h5>, &lt;h6>, &lt;i>, &lt;br>, &lt;strong>', 'wiloke-design-addlisting'); ?></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- drag__btn-wrap -->
                    <div class="drag__btn-wrap">
                        <div class="drag__btn-group left">
                            <button @click="addCustomSingleTab" class="ui pink button" type="button"><i class="la la-plus"></i> <?php esc_html_e('Add Custom Tab', 'wiloke-design-addlisting'); ?></button>
                        </div>
                        <div class="drag__btn-group right">
                            <button type="submit" class="ui green button"><i class="la la-save"></i> <?php esc_html_e('Save Changes', 'wiloke-design-addlisting'); ?></button>
                        </div>
                    </div>
                    <!-- drag__btn-wrap -->

                </draggable>
            </form>

        </tab>

    </tabs>
</div>