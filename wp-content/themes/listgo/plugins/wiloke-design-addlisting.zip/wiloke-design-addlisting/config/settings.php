<?php
return [
	'aAllBlock' => array(
		'listing_style' => array(
			'isDefault' => true,
			'blockType' => 'listing_style',
			'blockKey' 	=> 'listing_style',
			'isShowOnAddListing' => true,
			'isRequired'=> true,
			'blockName'	=> 'Listing Style',
			'fields' => array(
				array(
					'heading' 		=> esc_html__('Description', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'description',
					'description'	=> ''
				)
			)
		),
		'title_category_and_location_group' => array(
			'isDefault' => true,
			'isGroup'   => false,
			'blockType' => 'title_category_and_location_group',
			'blockKey' 	=> 'title_category_and_location_group',
			'blockName'	=> 'Title - Location - Categories and Google Address Group ',
			'fields' => array(
				array(
					'heading' 		        => esc_html__('Toggle Listing Title', 'wiloke-design-addlisting'),
					'type' 			        => 'checkbox',
					'key' 			        => 'toggle_listing_title',
					'toggle_listing_title'  => true
				),
				array(
					'heading' 		            => esc_html__('Required Listing Title Field?', 'wiloke-design-addlisting'),
					'type' 			            => 'checkbox',
					'key' 			            => 'is_required_listing_title',
					'is_required_listing_title' => true
				),
				array(
					'heading' 		=> esc_html__('Title', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'listing_title',
					'sanitize_cb' 	=> 'sanitize_text_field',
					'listing_title' => 'Listing Title',
					'placeholder'	=> ''
				),
				array(
					'heading' 		=> esc_html__('Description', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'listing_title_description',
					'sanitize_cb' 	=> 'sanitize_text_field',
					'listing_title_description' => '',
					'placeholder'	=> ''
				),
				array(
					'heading' 		=> esc_html__('Toggle Listing Categories', 'wiloke-design-addlisting'),
					'type' 			=> 'checkbox',
					'key' 			=> 'toggle_listing_cats',
					'toggle_listing_cats' => true
				),
				array(
					'heading' 		=> esc_html__('Required Listing Categories Field?', 'wiloke-design-addlisting'),
					'type' 			=> 'checkbox',
					'key' 			=> 'is_required_listing_cats',
					'is_required_listing_cats' => true
				),
				array(
					'heading' 		=> esc_html__('Listing Categories Title', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'listing_cats_title',
					'listing_cats_title'  => 'Listing Categories',
					'placeholder'	=> ''
				),
				array(
					'heading' 		=> esc_html__('Listing Categories Description', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'listing_cats_description',
					'listing_cats_description'  => ''
				),
				array(
					'heading' 		=> esc_html__('Maximum Listing Categories/Listing', 'wiloke-design-addlisting'),
					'desc' 		    => esc_html__('Set maximum Listing Categories per Listing. Leave empty means user can add/set unlimited categories for his/her listing', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'listing_cats_maximum_selection',
					'listing_cats_maximum_selection' => ''
				),
				array(
					'heading' 		=> esc_html__('Toggle Listing Location', 'wiloke-design-addlisting'),
					'type' 			=> 'checkbox',
					'desc' 		    => esc_html__('Notice: If this setting is disabled, the location will be created by the Google Address setting below', 'wiloke-design-addlisting'),
					'key' 			=> 'toggle_listing_location',
					'toggle_listing_location' => true
				),
				array(
					'heading' 		=> esc_html__('Required Listing Location Field?', 'wiloke-design-addlisting'),
					'type' 			=> 'checkbox',
					'is_required_listing_location' => true,
					'key' 			=> 'is_required_listing_location'
				),
				array(
					'heading' 		=> esc_html__('Listing Location Title', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'listing_location_title',
					'listing_location_title' => 'Listing Location'
				),
				array(
					'heading' 		=> esc_html__('Listing Location Description', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'listing_location_description',
					'listing_location_description' => ''
				),
				array(
					'heading' 		=> esc_html__('Toggle Google Address', 'wiloke-design-addlisting'),
					'type' 			=> 'checkbox',
					'key' 			=> 'toggle_google_address',
					'toggle_google_address' => true
				),
				array(
					'heading' 		=> esc_html__('Required Google Address Field?', 'wiloke-design-addlisting'),
					'type' 			=> 'checkbox',
					'key' 			=> 'is_required_google_address',
					'is_required_google_address' => true
				),
				array(
					'heading' 		=> esc_html__('Google Address Title', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'google_address_title',
					'google_address_title'=> 'Google Address'
				),
				array(
					'heading' 		=> esc_html__('Google Address Description', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'google_address_description',
					'google_address_description'=> ''
				),
				array(
					'heading' 		=> esc_html__('Google Address Placeholder', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'google_address_placeholder',
					'google_address_placeholder'=> 'Listing Address, Eg:  Manchester, United Kingdom'
				)
			),
		),
		'price_segment' => array(
			'isDefault' => true,
			'blockType' => 'price_segment',
			'blockKey' 	=> 'price_segment',
			'isShowOnAddListing' => true,
			'isRequired'=> false,
			'blockName'	=> 'Price Segmentation',
			'fields' => array(
				array(
					'heading' 		=> esc_html__('Description', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'description',
					'description'   => ''
				),
				array(
					'heading' 		=> esc_html__('Segmentation Title', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'segmentation_title',
					'segmentation_title' => 'Segmentation'
				),
				array(
					'heading' 		=> esc_html__('Minimum Price Title', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'minimum_price_title',
					'minimum_price_title'  => 'Minimum Price'
				),
				array(
					'heading' 		=> esc_html__('Maximum Price Title', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'maximum_price_title',
					'maximum_price_title' => 'Maximum Price'
				),
				array(
					'heading' 		=> esc_html__('Required Field?', 'wiloke-design-addlisting'),
					'type' 			=> 'checkbox',
					'key' 			=> 'isRequired',
					'isRequired'    => false
				)
			)
		),
		'business_hours' => array(
			'isDefault' => true,
			'blockType' => 'business_hours',
			'blockKey' 	=> 'business_hours',
			'isShowOnAddListing' => true,
			'isRequired'=> false,
			'blockName'	=> 'Business Hours',
			'fields' => array(
				array(
					'heading' 		=> esc_html__('Description', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'description',
					'description'   => ''
				)
			)
		),
		'featured_image' => array(
			'isDefault' => true,
			'blockType' => 'featured_image',
			'isMultiple'=> false,
			'isShowOnAddListing' => true,
			'isRequired'=> true,
			'blockKey' 	=> 'featured_image',
			'blockName'	=> 'Featured Image',
			'fields' => array(
				array(
					'heading' 		=> esc_html__('Description', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'description',
					'description'   => ''
				),
				array(
					'heading' 		=> esc_html__('Required Field?', 'wiloke-design-addlisting'),
					'type' 			=> 'checkbox',
					'key' 			=> 'isRequired',
					'isRequired'    => true
				)

			)
		),
		'listing_content' => array(
			'isDefault' => true,
			'blockType' => 'wp_editor',
			'editorKey' => 'listing_content',
			'blockKey' 	=> 'listing_content',
			'isShowOnAddListing' => true,
			'isRequired'=> true,
			'blockName'	=> 'Listing Content',
			'fields' => array(
				array(
					'heading' 		=> esc_html__('Description', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'description',
					'description'   => ''
				),
				array(
					'heading' 		=> esc_html__('Required Field?', 'wiloke-design-addlisting'),
					'type' 			=> 'checkbox',
					'key' 			=> 'isRequired',
					'isRequired'    => true
				)
			)
		),
		'listing_information' => array(
			'isDefault' => true,
			'blockType' => 'listing_information',
			'blockKey' 	=> 'listing_information',
			'blockName'	=> 'Listing Information',
			'blockDescription' => 'Skip this step if you want to display your profile information.',
			'isGroup'   => true,
			'fields' => array(
			)
		),
		'listing_tags' => array(
			'isDefault' => true,
			'blockType' => 'listing_tags',
			'blockKey' 	=> 'listing_tags',
			'isRequired'=> false,
			'blockName'	=> 'Listing Tags',
			'fields' => array(
				array(
					'heading' 		=> esc_html__('Description', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'description',
					'description'   => ''
				),
				array(
					'heading' 		=> esc_html__('Placeholder', 'wiloke-design-addlisting'),
					'desc' 		    => esc_html__('A placeholder is very useful if you want to use "Add Tag By User" mode', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'placeholder',
					'placeholder'   => 'Each keyword is sereparated by a comma. Eg: wordpress,drupal'
				),
				array(
					'heading' 		=> esc_html__('Required Field?', 'wiloke-design-addlisting'),
					'type' 			=> 'checkbox',
					'key' 			=> 'isRequired',
					'isRequired'    => true
				),
				array(
					'heading' 		=> esc_html__('Listing Tag Mode', 'wiloke-design-addlisting'),
					'type' 			=> 'select',
					'key' 			=> 'mode',
					'options'       => array(
						'user'  => esc_html__('User can add whatever Listing Tags he/she want', 'wiloke-design-addlisting'),
						'admin' => esc_html__('User will select Listing Tags that created by Admin', 'wiloke-design-addlisting')
					),
					'mode' => 'admin'
				),
				array(
					'heading' 		=> esc_html__('Maximum Listing Tags', 'wiloke-design-addlisting'),
					'desc' 		    => esc_html__('Set maximum Listing Tags per Listing. Leave empty means user can add/set unlimited tags for his/her listing', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'maximumSelection',
					'maximumSelection' => ''
				)
			)
		),
		'gallery_settings' => array(
			'isDefault'             => true,
			'blockType'             => 'gallery',
			'isMultiple'            => true,
			'blockKey' 	            => 'gallery_settings',
			'blockName'	            => 'Listing Gallery',
			'fields' => array(
				array(
					'heading' 		=> esc_html__('Description', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'description',
					'description'   => '',
				),
				array(
					'heading' 		=> esc_html__('Required Field?', 'wiloke-design-addlisting'),
					'type' 			=> 'checkbox',
					'key' 			=> 'isRequired',
					'isRequired'    => false
				)
			)
		),
		'open_table' => array(
			'isDefault' => true,
			'blockType' => 'open_table',
			'blockKey' 	=> 'open_table',
			'isShowOnAddListing' => true,
			'isRequired'=> true,
			'blockName'	=> 'Open Table',
			'fields' => array(
				array(
					'heading' 		=> esc_html__('Title', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'desc'          => '',
					'key' 			=> 'title',
					'title'         => 'Restaurant Name'
				),
				array(
					'heading' 		=> esc_html__('Description', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'description',
					'description'	=> ''
				)
			)
		),
		'advanced_custom_field' => array(
			'isDefault'             => false,
			'blockType'             => 'advanced_custom_field',
			'isMultiple'            => true,
			'blockKey' 	            => 'advanced_custom_field',
			'blockName'	            => 'Advanced Custom Field',
			'fields' => array(

			)
		),
		'listing_facebook_fanpage' => array(
			'isDefault'             => false,
			'blockType'             => 'listing_facebook_fanpage',
			'isMultiple'            => true,
			'blockKey' 	            => 'listing_facebook_fanpage',
			'blockName'	            => 'Facebook Fanpage',
			'blockDescription'	    => '<a href="https://blog.wiloke.com/setup-facebook-fanpage-source-listgo/" target="_blank">How to get your Facebook Fanpage Source?</a>',
			'fields' => array(
				array(
					'heading' 		=> esc_html__('IFrame Source Label', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'desc'          => '',
					'key' 			=> 'iframeScLabel',
					'iframeScLabel' => 'IFrame Source'
				),
			)
		),
		'listing_timekit' => array(
			'isDefault'             => false,
			'blockType'             => 'listing_timekit',
			'isMultiple'            => false,
			'blockKey' 	            => 'listing_timekit',
			'blockName'	            => 'Time Kit',
			'blockDescription'	    => '',
			'fields' => array(
				array(
					'heading' 		=> esc_html__('App Label', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'desc'          => '',
					'key' 			=> 'appLabel',
					'appLabel'      => 'App Slug'
				),
				array(
					'heading' 		=> esc_html__('App Placeholder', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'desc'          => '',
					'key' 			=> 'appPlaceholder',
					'appPlaceholder'=> 'Your Timekit registered app slug'
				),
				array(
					'heading' 		=> esc_html__('Email Label', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'desc'          => '',
					'key' 			=> 'emailLabel',
					'emailLabel'    => 'Email'
				),
				array(
					'heading' 		    => esc_html__('Email Placeholder', 'wiloke-design-addlisting'),
					'type' 			    => 'text',
					'desc'              => '',
					'key' 			    => 'emailPlaceholder',
					'emailPlaceholder'  => 'Your Timekit user\'s email (used for auth)'
				),
				array(
					'heading' 		=> esc_html__('API Token', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'desc'          => '',
					'key' 			=> 'apiTokenLabel',
					'apiTokenLabel' => 'API Token'
				),
				array(
					'heading' 		=> esc_html__('API Token Placeholder', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'desc'          => '',
					'key' 			=> 'apiTokenPlaceholder',
					'apiTokenPlaceholder'       => 'Your Timekit user\'s apiToken'
				),
				array(
					'heading' 		=> esc_html__('Calendar Label', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'desc'          => '',
					'key' 			=> 'calendarLabel',
					'calendarLabel' => 'Calendar'
				),
				array(
					'heading' 		=> esc_html__('Calendar Placeholder', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'desc'          => '',
					'key' 			=> 'calendarPlaceholder',
					'calendarPlaceholder' => 'Your Timekit calendar ID that bookings should end up in'
				),
				array(
					'heading' 		=> esc_html__('Name Label', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'desc'          => '',
					'key' 			=> 'nameLabel',
					'nameLabel'     => 'Name'
				),
				array(
					'heading' 		=> esc_html__('Name placeholder', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'desc'          => '',
					'key' 			=> 'namePlaceholder',
					'namePlaceholder'  => 'Display name to show in the header and timezone helper'
				),
				array(
					'heading' 		=> esc_html__('Avatar Label', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'desc'          => '',
					'key' 			=> 'avatarLabel',
					'avatarLabel'   => 'Avatar'
				),
				array(
					'heading' 		=> esc_html__('Avatar Placeholder', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'desc'          => '',
					'key' 			=> 'avatarPlaceholder',
					'avatarPlaceholder'  => 'Provide an image URL for a circular image avatar'
				)
			)
		),
		'listing_coupon' => array(
			'isDefault' => true,
			'blockType' => 'listing_coupon',
			'blockKey' 	=> 'listing_coupon',
			'blockDescription' => '',
			'isShowOnAddListing' => true,
			'isRequired'=> true,
			'blockName'	=> 'Coupon',
			'fields' => array(
				array(
					'heading' 		=> esc_html__('Description Label Name', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'desc'          => '',
					'key' 			=> 'description_title',
					'description_title'   => 'Description'
				),
				array(
					'heading' 		=> esc_html__('Description Placeholder', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'desc'          => '',
					'key' 			=> 'placeholder',
					'placeholder'   => 'Save 10%'
				),
				array(
					'heading' 		=> esc_html__('Coupon Code', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'coupon_code',
					'coupon_code'	=> 'Coupon Code'
				),
				array(
					'heading' 		=> esc_html__('Referral link', 'wiloke-design-addlisting'),
					'type' 			=> 'text',
					'key' 			=> 'referral_link',
					'referral_link'	=> 'Referral link'
				)
			)
		),
	),
	'aDesignSingleListing' => array(
		array(
			'name'      => 'Description',
			'toggle'    => true,
			'content'   => '[wilokeCoupon] [wilokeContent]'
		),
		array(
			'name'      => 'Contact & Tab',
			'toggle'    => true,
			'content'   => '[wilokeContactFormAndMap]'
		),
		array(
			'name'      => 'Review & Rating',
			'toggle'    => true,
			'content'   => '[wilokeReview]'
		)
	)
];
