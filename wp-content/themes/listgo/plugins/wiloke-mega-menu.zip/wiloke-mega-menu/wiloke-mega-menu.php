<?php
/**
 * @package Wiloke Mega Menu
 */
/*
Plugin Name: Wiloke Mega Menu
Plugin URI: https://wiloke.com/
Description: Building Mega Menu through Visual Composer
Version: 1.1.2
Author: wiloke
Author URI: https://wiloke.com/
License: GPLv2 or later
Text Domain: wiloke-mega-menu
 */

// Make sure we don't expose any info if called directly
if (!function_exists('add_action')) {
    echo 'Hi there!  I\'m just a plugin, not much I can do when called directly.';
    exit;
}

define('WILOKEMENU_VERSION', '1.1.2');
define('WILOKEMENU_DOMAIN', 'wiloke-mega-menu');
define('WILOKEMENU__DIR', plugin_dir_path(__FILE__));
define('WILOKEMENU__URI', trailingslashit(plugins_url('', __FILE__)));

if (!class_exists('WilokeMenu')) {

    class WilokeMenu
    {
        public function __construct()
        {
            add_action('plugins_loaded', array($this, 'init'));
            add_action('plugins_loaded', array($this, 'load_textdomain'));
            add_action('admin_init', array($this, 'firstInit'));
        }

        public function firstInit(){
            if ( !get_option('wiloke_mega_menu_second_init') ){
	            global $wp_roles;
	            if ( !function_exists( 'wp_roles' ) ) {
		            if ( ! isset( $wp_roles ) ) {
			            $wp_roles = new WP_Roles();
		            }
	            }
	            $wp_roles->use_db = true;
	            $wp_roles->add_cap( 'administrator', 'vc_access_rules_post_types', 'custom' );

                update_option('wiloke_mega_menu_second_init', true);
            }
        }

        public function admin_notice()
        {
            if (!class_exists('Vc_Manager')): ?>
                <div class="warning notice notice-warning is-dismissible" id="vc-mm-notice">
                    <p>
                        <?php printf(__('Wiloke Menu requirements <a target="_blank" href="%1$s">Visual Composer</a>: Page Builder for WordPress Plugin installed', 'wiloke-mega-menu'), 'http://codecanyon.net/item/visual-composer-page-builder-for-wordpress/242431?ref=shrimp2t');?>
                    </p>
                </div>
            <?php endif;
        }

        public function init()
        {
            // Update visual support post type
//            $this->set_support_visual_editor();
                
            if (class_exists('Vc_Manager')) {

                // Includes
                $this->_includes();

                // Register Post Type
                add_action('init', array($this, 'register_menu'));
                add_action('init', array($this, 'register_menu_item'));

                // Add Shortcode
                $this->add_shortcode();

                if ( is_admin() ) {
                    
                    add_action('admin_notices', array($this, 'admin_notice'));

                    require_once WILOKEMENU__DIR . 'admin/admin.php';
                }

                require_once WILOKEMENU__DIR . 'walker-nav-menu.php';

                require_once WILOKEMENU__DIR . 'wiloke-nav.php';
            }
        }

        public function load_textdomain()
        {
	        load_plugin_textdomain('wiloke-mega-menu', false, WILOKEMENU__DIR . 'languages');
        }

        public function register_menu()
        {
            $labels = array(
                'name'               => esc_html__('Wiloke Menus', 'wiloke-mega-menu'),
                'singular_name'      => esc_html__('Wiloke Menu', 'wiloke-mega-menu'),
                'menu_name'          => esc_html__('Wiloke Menus', 'wiloke-mega-menu'),
                'name_admin_bar'     => esc_html__('Wiloke Menu', 'wiloke-mega-menu'),
                'add_new'            => esc_html__('Add New Menu', 'wiloke-mega-menu'),
                'add_new_item'       => esc_html__('Add New Menu', 'wiloke-mega-menu'),
                'new_item'           => esc_html__('New Menu', 'wiloke-mega-menu'),
                'edit_item'          => esc_html__('Edit Menu', 'wiloke-mega-menu'),
                'all_items'          => esc_html__('All Menus', 'wiloke-mega-menu'),
                'search_items'       => esc_html__('Search Menus', 'wiloke-mega-menu'),
                'parent_item_colon'  => esc_html__('Parent Menus:', 'wiloke-mega-menu'),
                'not_found'          => esc_html__('No menus found.', 'wiloke-mega-menu'),
                'not_found_in_trash' => esc_html__('No menus found in Trash.', 'wiloke-mega-menu'),
            );

            $args = array(
                'labels'             => $labels,
                'public'             => true,
                'publicly_queryable' => true,
                'show_ui'            => true,
                'show_in_menu'       => true,
                'show_in_nav_menus'  => false,
                'query_var'          => true,
                'rewrite'            => array('slug' => 'wiloke-menu'),
                'capability_type'    => 'post',
                'has_archive'        => false,
                'hierarchical'       => false,
                'menu_position'      => null,
                'supports'           => array('title'),
            );

            register_post_type('wiloke-menu', $args);

        }

        public function register_menu_item()
        {
            $labels = array(
                'name'               => esc_html__('Wiloke Menu Items', 'wiloke-mega-menu'),
                'singular_name'      => esc_html__('Wiloke Menu Item', 'wiloke-mega-menu'),
                'menu_name'          => esc_html__('Wiloke Menu Items', 'wiloke-mega-menu'),
                'name_admin_bar'     => esc_html__('Wiloke Menu Item', 'wiloke-mega-menu'),
                'add_new'            => esc_html__('Add New Item', 'wiloke-mega-menu'),
                'add_new_item'       => esc_html__('Add New Menu Item', 'wiloke-mega-menu'),
                'new_item'           => esc_html__('New Menu Item', 'wiloke-mega-menu'),
                'edit_item'          => esc_html__('Edit Menu Item', 'wiloke-mega-menu'),
                'all_items'          => esc_html__('All Menu Items', 'wiloke-mega-menu'),
                'search_items'       => esc_html__('Search Menu Items', 'wiloke-mega-menu'),
                'parent_item_colon'  => esc_html__('Parent Menu Items:', 'wiloke-mega-menu'),
                'not_found'          => esc_html__('No menu items found.', 'wiloke-mega-menu'),
                'not_found_in_trash' => esc_html__('No menu items found in Trash.', 'wiloke-mega-menu'),
            );

            $args = array(
                'labels'             => $labels,
                'public'             => true,
                'publicly_queryable' => true,
                'show_ui'            => true,
                'show_in_nav_menus'  => false,
                'show_in_admin_bar'  => true,
                'query_var'          => true,
                'rewrite'            => array('slug' => 'wiloke-menu-item'),
                'capability_type'    => 'post',
                'can_export'         => true,
                'has_archive'        => false,
                'hierarchical'       => false,
                'supports'           => array('editor'),
            );

            register_post_type('wiloke-menu-item', $args);
        }

        public function _includes() {
            // Functions
            require_once 'includes/functions.php';
        }

        public function set_support_visual_editor() {
            if( is_admin() ) {
                if ( !function_exists('is_plugin_active') ) {
                    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
                }

                if ( is_plugin_active( 'js_composer/js_composer.php' ) ) {

                    $post_type = vc_editor_post_types();
                    if ( !in_array('wiloke-menu-item', $post_type) ) {
                        $post_type[] = 'wiloke-menu-item';
                        vc_set_default_editor_post_types( $post_type );    
                    }
                }
            }
        }

        public function add_shortcode() {
            $files = apply_filters('wiloke_mega_menu/filter_shortcodes', array('shortcode_posts', 'shortcode_instagram', 'shortcode_image_carousel', 'shortcode_list'));

            foreach ($files as $file) {

                $path_shortcode = WILOKEMENU__DIR . 'includes/shortcodes/' . $file . '.php';
                $path_vcmap = WILOKEMENU__DIR . 'includes/shortcodes/vc_map/' . $file . '.php';

                if( file_exists($path_shortcode) ) {
                    require_once $path_shortcode;
                }

                if( file_exists($path_vcmap) ) {
                    require_once $path_vcmap;
                }
            }
        }
        
    }

    new WilokeMenu();
}


