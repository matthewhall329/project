(function($) {
	'use strict';

	var rtl = false;

	if ( $('html[dir="rtl"]').length ) {
		rtl = true;	
	}

	function WilokeMegaMenu() {

		$('.wiloke-menu').each(function(index, el) {

	    	var self = $(this),
	    		options = self.data().options;
			self.WilokeMegaMenu(options);
	    });
	}

	function WilokeMegaMenuSlider() {

		$('.wiloke-menu-slider').each(function(index, el) {

			var self = $(this),
				nav = self.data('nav'),
				dots = self.data('dots'),
				margin = parseInt(self.data('space')),
				xl = parseInt(self.data('col-xl')),
				lg = parseInt(self.data('col-lg')),
				md = parseInt(self.data('col-md')),
				sm = parseInt(self.data('col-sm')),
				xs = parseInt(self.data('col-xs')),
				items = parseInt(self.data('carousel-items'));

			self.owlCarousel({
				margin: margin,
				nav: nav,
				navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
				dots: dots,
				rtl: rtl,
				lazyLoad:true,
				responsive: {
					0: {
						items: xs
					},
					576: {
						items: sm
					},
					768: {
						items: md
					},
					992: {
						items: lg
					},
					1200: {
						items: xl
					},
				}
			});

		});
	}

	function WilokeMegaMenuMagnificPopup(){
		$('.wiloke-menu-maginific').magnificPopup({
			delegate: 'a',
			type: 'image',
			closeOnContentClick: false,
			closeBtnInside: false,
			mainClass: 'mfp-with-zoom mfp-img-mobile',
			image: {
				verticalFit: true,
				titleSrc: function(item) {
					return  '<a class="image-source-link" href="'+item.el.attr('data-source')+'" target="_blank">'+item.el.attr('title')+'</a>';
				}
			},
			gallery: {
				enabled: true
			}
		});
	}

	$(window).on('load', function(event) {
		WilokeMegaMenuSlider();
	});

	$(document).ready(function () {
		WilokeMegaMenu();
		WilokeMegaMenuMagnificPopup();
	});
	
})(jQuery);
