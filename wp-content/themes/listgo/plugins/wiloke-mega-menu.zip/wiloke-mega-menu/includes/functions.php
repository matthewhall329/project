<?php

if (!function_exists('wiloke_mega_menu_post_types')) {
    function wiloke_mega_menu_post_types()
    {
        $postTypes         = get_post_types(array());
        $postTypesList     = array();
        $excludedPostTypes = array(
            'revision',
            'nav_menu_item',
            'vc_grid_item',
            'wiloke-menu',
            'wiloke-menu-item',
        );

        if (is_array($postTypes) && !empty($postTypes)) {
            foreach ($postTypes as $postType) {
                if (!in_array($postType, $excludedPostTypes)) {
                    $label           = ucfirst($postType);
                    $postTypesList[] = array(
                        $postType,
                        $label,
                    );
                }
            }
        }

        return $postTypesList;
    }
}

if ( !function_exists('wiloke_mega_menu_instagram') ) {
    function wiloke_mega_menu_fetch_feeds($info, $accessToken, $count, $args){
        $url   = 'https://api.instagram.com/v1/users/'.$info.'/media/recent?access_token='.$accessToken.'&count='.$count;

        $getInstagram = wp_remote_get( esc_url_raw( $url ), $args);

        if ( !is_wp_error($getInstagram) )
        {
            $getInstagram = wp_remote_retrieve_body($getInstagram);
            $getInstagram = json_decode($getInstagram);
           
            $aFeeds = array();
            if ( $getInstagram->meta->code === 200 )
            {
                for ( $i=0; $i<$count; $i++ )
                {
                    if ( isset($getInstagram->data[$i]) ) {
                        if ( !empty($getInstagram->data[$i]->caption) ){
                            $caption = $getInstagram->data[$i]->caption->text;
                        }elseif ( !empty($getInstagram->data[$i]->location) ){
                            $caption = !empty($getInstagram->data[$i]->location->name);
                        }else{
                            $caption = $getInstagram->data[$i]->user->username;
                        }
                       
                        $aFeeds[] = array(
                            'username'  => $getInstagram->data[$i]->user->username,
                            'thumb'     => $getInstagram->data[$i]->images->thumbnail->url,
                            'description'=> $caption,
                            'link'      => $getInstagram->data[$i]->link,
                            'small'     => $getInstagram->data[$i]->images->low_resolution->url,
                            'thumbnail' => $getInstagram->data[$i]->images->thumbnail->url,
                            'large'     => $getInstagram->data[$i]->images->standard_resolution->url,
                            'original'  => $getInstagram->data[$i]->images->standard_resolution->url
                        );
                    }
                }
                return $aFeeds;
            }
        }

        return false;
    }

    function wiloke_mega_menu_get_user_id($userName, $accessToken, $args){
        $url = 'https://api.instagram.com/v1/users/search?q='.$userName.'&access_token='.$accessToken;
        $oSearchProfile = wp_remote_get( esc_url_raw( $url ), $args);
        if ( !empty($oSearchProfile) && !is_wp_error($oSearchProfile) ){
            $oSearchProfile = wp_remote_retrieve_body($oSearchProfile);
            $oSearchProfile = json_decode($oSearchProfile);
            if ( $oSearchProfile->meta->code === 200 )
            {
                foreach ( $oSearchProfile->data as $oInfo )
                {
                    if ( $oInfo->username === $userName )
                    {
                        return $oInfo->id;
                    }
                }
            }
        }
        return false;
    }

    function wiloke_mega_menu_get_instagram_feed($username, $accessToken, $count, $type){
        $args = array( 'decompress' => false, 'timeout' => 30, 'sslverify'   => true );
        $userID = wiloke_mega_menu_get_user_id($username, $accessToken, $args);
        if ( !empty($userID) )
        {
            return wiloke_mega_menu_fetch_feeds($userID, $accessToken, $count, $args);
        }
        return false;
    }

    function wiloke_mega_menu_get_instagram($username, $atts)
    {
        delete_transient('wiloke_mega_menu_instagram_'.$username);
        $aFeeds = get_transient('wiloke_mega_menu_instagram_'.$username);
        if ( empty($aFeeds) ){
            $aInstagramSettings         = get_option('_pi_instagram_settings');
            $aInstance['access_token']  = isset($aInstagramSettings['access_token']) ? $aInstagramSettings['access_token'] : '';

            $aFeeds = wiloke_mega_menu_get_instagram_feed($username, $aInstance['access_token'], $atts['number'], 'username');
            if ( !empty($aFeeds) ){
                set_transient('wiloke_mega_menu_instagram_'.$username, maybe_serialize($aFeeds), 60*60*2);
            }
        }else{
            $aFeeds = maybe_unserialize($aFeeds);
        }

        return $aFeeds;
    }
}
