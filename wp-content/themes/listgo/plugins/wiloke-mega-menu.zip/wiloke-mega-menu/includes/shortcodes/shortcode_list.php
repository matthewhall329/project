<?php
if (!function_exists('wiloke_mega_menu_shortcode_list')) {
    add_shortcode('wiloke_mega_menu_shortcode_list', 'wiloke_mega_menu_shortcode_list');
    function wiloke_mega_menu_shortcode_list($atts)
    {
        $atts = wp_parse_args($atts, array(
            'items'   => '',
            'el_class'   => '',
            'el_css'     => '',
        ));
        ob_start();
        if ( !empty($atts['items']) ) :
            $items = vc_param_group_parse_atts($atts['items']); ?>
            <ul class="wiloke-shortcode-list">
                <?php foreach ($items as $item):
                    if ( !empty($item) ) :
                        $link = vc_build_link($item['link']);  ?>
                        <li>
                            <a href="<?php echo esc_url($link['url']) ?>" target="<?php echo esc_attr($link['target']) ?>" rel="<?php echo esc_attr($link['rel']) ?>">
                                <?php if ( isset($item['icon']) && !empty($item['icon']) ): ?>
                                    <i class="<?php echo esc_attr($item['icon']) ?>"></i>
                                <?php endif ?>

                                <?php if ( !empty($link['title']) ): ?>
                                    <span><?php echo esc_html($link['title']) ?></span>
                                <?php endif ?>
                            </a>
                        </li>
                    <?php endif;
                endforeach; ?>
            </ul>
        <?php endif;
        return ob_get_clean();
    }
}
