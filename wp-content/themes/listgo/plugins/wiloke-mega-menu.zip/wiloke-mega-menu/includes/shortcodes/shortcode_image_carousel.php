<?php

if (!function_exists('wiloke_mega_menu_shortcode_image_carousel')) {

    add_shortcode('wiloke_mega_menu_shortcode_image_carousel', 'wiloke_mega_menu_shortcode_image_carousel');

    function wiloke_mega_menu_shortcode_image_carousel($atts)
    {

        $atts = wp_parse_args($atts, array(
            'images'            => '',
            'display'    		=> 'grid',
            'xl_per_row'	 	=> 5,
            'lg_per_row'	 	=> 4,
            'md_per_row'	 	=> 3,
            'sm_per_row'	 	=> 2,
            'xs_per_row'	 	=> 1,
            'space'		 		=> 20,
            'nav'				=> '',
            'dots'				=> '',
            'size'       		=> 'medium',
            'el_class'   		=> '',
            'el_css'     		=> '',
        ));

        ob_start();

        if (!empty($atts['images'])):

            $attribute = '';
            $class     = 'wiloke-menu-' . $atts['display'];

            if ($atts['display'] == 'grid') {
                $class .= ' wiloke-menu-col-xl-' . $atts['xl_per_row'];
                $class .= ' wiloke-menu-col-lg-' . $atts['lg_per_row'];
                $class .= ' wiloke-menu-col-md-' . $atts['md_per_row'];
                $class .= ' wiloke-menu-col-sm-' . $atts['sm_per_row'];
                $class .= ' wiloke-menu-col-xs-' . $atts['xs_per_row'];
                $class .= ' wiloke-menu-space-' . $atts['space'];
            }

            if ($atts['display'] == 'slider') {
                $class     .= ' owl-carousel';
                $attribute .= 'data-col-xl="' . esc_attr($atts['xl_per_row']) . '" ';
                $attribute .= 'data-col-lg="' . esc_attr($atts['lg_per_row']) . '" ';
                $attribute .= 'data-col-md="' . esc_attr($atts['md_per_row']) . '" ';
                $attribute .= 'data-col-sm="' . esc_attr($atts['sm_per_row']) . '" ';
                $attribute .= 'data-col-xs="' . esc_attr($atts['xs_per_row']) . '" ';
                $attribute .= 'data-space="'. esc_attr($atts['space']) .'" ';
                $attribute .= 'data-nav="' . esc_attr(filter_var($atts['nav'], FILTER_VALIDATE_BOOLEAN)) . '" ';
                $attribute .= 'data-dots="' . esc_attr(filter_var($atts['dots'], FILTER_VALIDATE_BOOLEAN)) . '" ';
            }

            if (!empty($atts['el_class'])) {
                $class .= ' ' . $atts['el_class'];
            }

            $class .= vc_shortcode_custom_css_class($atts['el_css']); ?>

			<div class="wiloke-menu-photos wiloke-menu-maginific <?php echo esc_attr(trim($class)) ?>" <?php print trim($attribute) ?>>

                <?php 
                    $images = explode(',', $atts['images']); 
                    $class_img = $atts['display'] == 'slider' ?  'owl-lazy' : 'lazy'; 
                ?>

            	<?php foreach ($images as $image): ?>

                    <?php 
                        if ( strpos($atts['size'], ',') !== false ){
                            $atts['size'] = explode(',', $atts['size']);
                        }
                        $_image  = wp_get_attachment_image_src( $image, $atts['size']);
                        $src = wp_get_attachment_image_src($image, 'large');
                    ?>

                    <?php if ($_image ): ?>
                        
            	    	<div class="wiloke-menu-photo">
            	    	    <a href="<?php echo esc_url($src[0]); ?>" target="_blank">
                                <img data-src="<?php echo esc_url($_image[0]) ?>" alt="<?php echo esc_attr($src['alt']); ?>" class="<?php echo esc_attr($class_img); ?>">
            	    	    </a>
            	    	</div>

                    <?php endif ?>

            	<?php endforeach?>
               
			</div>

        <?php endif;

        return ob_get_clean();
    }
}
