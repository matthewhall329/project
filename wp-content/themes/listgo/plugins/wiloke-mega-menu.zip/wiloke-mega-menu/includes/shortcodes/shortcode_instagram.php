<?php

if (!function_exists('wiloke_mega_menu_shortcode_instagram')) {

    add_shortcode('wiloke_mega_menu_shortcode_instagram', 'wiloke_mega_menu_shortcode_instagram');

    function wiloke_mega_menu_shortcode_instagram($atts)
    {

        $atts = wp_parse_args($atts, array(
            'username'   		=> '',
            'number'     		=> 4,
            'display'    		=> 'grid',
            'xl_per_row'	 	=> 5,
            'lg_per_row'	 	=> 4,
            'md_per_row'	 	=> 3,
            'sm_per_row'	 	=> 2,
            'xs_per_row'	 	=> 1,
            'space'		 		=> 20,
            'nav'				=> '',
            'dots'				=> '',
            'target'     		=> '_blank',
            'size'       		=> 'small',
            'el_class'   		=> '',
            'el_css'     		=> '',
        ));
        $username = $atts['username'];

        if( empty($username) ) {
            $aInstagramSettings   = get_option('_pi_instagram_settings');
            if ($aInstagramSettings) {
                $username = $aInstagramSettings['username']; 
            }

        }

        if ( empty($username) ){
            return esc_html__('Please go to Settings -> Wiloke Instagram and complete your Instagram Configuration', 'wiloke-mega-menu');
        }
        
        $attribute = '';
        $class     = 'wiloke-menu-' . $atts['display'];

        if ($atts['display'] == 'grid') {
            $class .= ' wiloke-menu-col-xl-' . $atts['xl_per_row'];
            $class .= ' wiloke-menu-col-lg-' . $atts['lg_per_row'];
            $class .= ' wiloke-menu-col-md-' . $atts['md_per_row'];
            $class .= ' wiloke-menu-col-sm-' . $atts['sm_per_row'];
            $class .= ' wiloke-menu-col-xs-' . $atts['xs_per_row'];
            $class .= ' wiloke-menu-space-' . $atts['space'];
        }elseif($atts['display'] == 'slider'){
            $class     .= ' owl-carousel';
            $attribute .= 'data-col-xl="' . esc_attr($atts['xl_per_row']) . '" ';
            $attribute .= 'data-col-lg="' . esc_attr($atts['lg_per_row']) . '" ';
            $attribute .= 'data-col-md="' . esc_attr($atts['md_per_row']) . '" ';
            $attribute .= 'data-col-sm="' . esc_attr($atts['sm_per_row']) . '" ';
            $attribute .= 'data-col-xs="' . esc_attr($atts['xs_per_row']) . '" ';
            $attribute .= 'data-space="'. esc_attr($atts['space']) .'" ';
            $attribute .= 'data-nav="' . esc_attr(filter_var($atts['nav'], FILTER_VALIDATE_BOOLEAN)) . '" ';
            $attribute .= 'data-dots="' . esc_attr(filter_var($atts['dots'], FILTER_VALIDATE_BOOLEAN)) . '" ';
        }

        if (!empty($atts['el_class'])) {
            $class .= ' ' . $atts['el_class'];
        }

        $class .= vc_shortcode_custom_css_class($atts['el_css']);

        $aPhotos = wiloke_mega_menu_get_instagram($username, $atts);?>

        <?php if ( empty($aPhotos) ){
            return '';
        }

        ob_start();
        ?>
		<div class="wiloke-menu-photos wiloke-menu-maginific <?php echo esc_attr(trim($class)) ?>" <?php echo trim($attribute) ?>>
        	<?php foreach ($aPhotos as $aPhoto): ?>
    	    	<div class="wiloke-menu-photo">
    	    	    <a href="<?php echo esc_url($aPhoto['original']) ?>" style="display:block;" target="<?php echo esc_attr($atts['target']); ?>" title="<?php echo esc_attr($aPhoto['description']); ?>" data-source="<?php echo esc_url($aPhoto['link']); ?>">
                        <span data-src="<?php echo esc_url($aPhoto[$atts['size']]); ?>" alt="<?php echo esc_attr($aPhoto['description']) ?>" class="lazy" style="padding-top: 75%; background-size: cover; background-position: 50% 50%; display: block;"></span>
    	    	    </a>
    	    	</div>
        	<?php endforeach?>
		</div>
        <?php
        return ob_get_clean();
    }
}
