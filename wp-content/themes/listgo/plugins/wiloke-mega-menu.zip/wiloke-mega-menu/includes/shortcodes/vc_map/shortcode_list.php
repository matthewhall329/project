<?php

if (!function_exists('wiloke_mega_menu_shortcode_list_map')) {

    add_action('vc_before_init', 'wiloke_mega_menu_shortcode_list_map');

    function wiloke_mega_menu_shortcode_list_map($atts)
    {

        vc_map(array(
            'name'     => esc_html__('Mega Menu List', 'wiloke-menu'),
            'base'     => 'wiloke_mega_menu_shortcode_list',
            'category' => esc_html__('Wiloke Mega Menu', 'wiloke-menu'),
            'params'   => array(
                array(
                    'type'        => 'param_group',
                    'heading'     => esc_html__('Items', 'wiloke-menu'),
                    'param_name'  => 'items',
                    'params' => array(
                        array(
                            'type'        => 'iconpicker',
                            'heading'     => esc_html__('Icon', 'wiloke-menu'),
                            'param_name'  => 'icon',
                            'description' => esc_html__('Select icon.', 'wiloke-menu'),
                        ),
                        array(
                            'type'       => 'vc_link',
                            'heading'    => esc_html__('Link', 'wiloke-menu'),
                            'param_name' => 'link',
                            'value'      => array(
                                esc_html__('Yes', 'wiloke-menu') => 'yes',
                            ),
                        ),
                    )
                ),
                
                array(
                    'type'        => 'textfield',
                    'heading'     => esc_html__('Extra class name', 'wiloke-menu'),
                    'param_name'  => 'el_class',
                    'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS.', 'wiloke-menu'),
                ),

                array(
                    'type'       => 'css_editor',
                    'heading'    => esc_html__('CSS box', 'wiloke-menu'),
                    'param_name' => 'el_css',
                    'group'      => esc_html__('Design Options', 'wiloke-menu'),
                ),
            ),
        ));
    }
}
