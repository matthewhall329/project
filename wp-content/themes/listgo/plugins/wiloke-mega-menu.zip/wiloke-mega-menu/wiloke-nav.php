<?php

if (!class_exists('WilokeMenu_Nav')) {
    /**
     *
     */
    class WilokeMenu_Nav extends WilokeMenu {
	    public $oMenuArgs;
	    public $aMenuOptions;

        public function __construct()
        {
            // Shortcode3
            add_filter('widget_text', 'do_shortcode');
            add_shortcode('wilokemenu_shortcode', array($this, 'shortcode_menu'));
            add_filter('wp_nav_menu_args', array($this, 'nav_menu_args'), 9);
            add_filter('wp_nav_menu', array($this, 'wp_nav_menu'), 10, 2);

            // Enqueue Script
            add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'), 1);
            add_action('wp_footer', array($this, 'wiloke_menu_style_inline'), 1000);
            
        }

        public function enqueue_scripts()
        {
            // Css
            wp_enqueue_style('font-awesome', WILOKEMENU__URI . 'assets/css/lib/font-awesome.min.css', false, '4.7.0');
            wp_enqueue_style('animated', WILOKEMENU__URI . 'assets/css/lib/animated.min.css', false, '4.7.0');
            wp_enqueue_style('magnific-popup', WILOKEMENU__URI . 'assets/css/lib/magnific-popup.min.css', false, '2.1.0');
            wp_enqueue_style('owlcarousel', WILOKEMENU__URI . 'assets/css/lib/jquery.owl.carousel.min.css', false, '2.1.0');
            wp_enqueue_style('wiloke-megamenu', WILOKEMENU__URI . 'assets/css/style.css', false, '1.0.0');
            
            // Script
            wp_enqueue_script('owlcarousel', WILOKEMENU__URI . 'assets/js/lib/jquery.owl.carousel.min.js', array('jquery'), '2.1.0', true);
            wp_enqueue_script('magnific-popup', WILOKEMENU__URI . 'assets/js/lib/jquery.magnific-popup.min.js', array('jquery'), '2.1.0', true);
            wp_enqueue_script('wiloke-megamenu', WILOKEMENU__URI . 'assets/js/lib/jquery.wiloke.megamenu.min.js', array('jquery'), '1.0', true);
            wp_enqueue_script('wiloke-megamenu.script', WILOKEMENU__URI . 'assets/js/script.min.js', array('jquery'), null, true);
        }

        public function wiloke_menu_style_inline()
        {

            if ( !empty(WilokeMenu_Walker_Nav_Menu::$css) ) {
                print '<style type="text/css">' . WilokeMenu_Walker_Nav_Menu::$css . '</style>';
            }
        }

        // Args wp_nav_menu
        public function nav_menu_args($args)
        {
            $term_id = 0;
            if (!empty($args['theme_location'])) {
                $loc = $args['theme_location'];
                $locations = get_nav_menu_locations();

                if (!isset($locations[$loc])) {
                    return $args;
                }

                $menu_object = wp_get_nav_menu_object($locations[$loc]);

                $term_id = $menu_object->term_id;
            } else {
                $term_id = $args['menu']->term_id;
            }

            $settings = get_term_meta($term_id, 'wiloke-nav-data', true);

            if ( isset($settings['megamenu']) && !empty($settings['megamenu']) ) {

                if ( isset($settings['menu']) && !empty($settings['menu']) ) {
                    $options = get_post_meta( intval($settings['menu']) , 'wiloke-menu-settings', true);

                    if ($settings) {
                        $args['container']       = 'div';
                        $args['options']        = $options;
                        $args['menu_class']      = 'wiloke-menu-list';
                        $args['container_class'] = ' wiloke-menu ' . $options['style'];
                        $args['walker']          = new WilokeMenu_Walker_Nav_Menu();

                        if (!empty($options['theme'])) {
                            $args['container_class'] .= ' wiloke-menu--theme ' . $options['theme'];
                        }

                    }
                }
            }

            return $args;
        }

        public function wp_nav_menu($nav_menu, $oWilokeMegaMenuArgs)
        {
            if (isset($oWilokeMegaMenuArgs->options) ){
                $settings = $oWilokeMegaMenuArgs->options;
                $wilokeMegaMenuOptions = array(
                    'style'      => $settings['style'],
                    'theme'      => $settings['theme'],
                    'hover'      => filter_var($settings['trigger'], FILTER_VALIDATE_BOOLEAN),
                    'breakpoint' => $settings['breakpoint'],
                    'barText'    => ''
                );

                if ($settings['style'] == 'wiloke-menu-vertical') {
	                $wilokeMegaMenuOptions['alignMenu'] = $settings['align_menu'];
                }

	            $wilokeMegaMenuOptions = apply_filters('wiloke_nav_menu', $wilokeMegaMenuOptions, $oWilokeMegaMenuArgs);
                $this->aMenuOptions = $wilokeMegaMenuOptions;
                $this->oMenuArgs = $oWilokeMegaMenuArgs;

				$nav_menu = preg_replace_callback(
					'/id="'.$oWilokeMegaMenuArgs->container_id.'"/',
					function ($aMatched){
						return 'id="'.$this->oMenuArgs->container_id.'" data-options='.json_encode($this->aMenuOptions);
					},
					$nav_menu,
					1
				);
            }

            return $nav_menu;
        }

        public function shortcode_menu($atts, $content = null)
        {
            if (isset($atts['theme_location']) || empty($atts['theme_location'])) {
                return '';
            }

            $output = wp_nav_menu(array(
                'theme_location' => $atts['theme_location'],
                'echo'           => false,
            ));

            return $output;
        }
    }

    new WilokeMenu_Nav();
}
