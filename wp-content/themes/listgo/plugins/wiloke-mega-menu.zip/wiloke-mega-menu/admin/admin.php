<?php

if (!class_exists('WilokeMenu_Admin')) {
    /**
     *
     */
    class WilokeMenu_Admin extends WilokeMenu
    {

        public function __construct()
        {
            // Include
            $this->_include();

            // Update content post before create post type wiloke-menu-item
            add_action( 'edit_form_top', array($this, 'content_update_before_create_post') );

            // Metabox Menu
            add_action( 'add_meta_boxes',  array( $this, 'add_metabox' ) );
            add_action( 'save_post', array( $this, 'update_metabox_menu' ) );

            // Enqueue Script
            add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );

            // Icon List
            add_action( 'wp_ajax_wiloke_icon_list', array( $this, 'icon_list') );
            add_action( 'wp_ajax_nopriv_wiloke_icon_list', array( $this, 'icon_list') );

            // Nav Settings
            add_action( 'wp_update_nav_menu', array( $this, 'nav_setting_save' ), 10, 1 );

            // Nav Menu Item Settings
            add_action( 'wp_ajax_wiloke_nav_item_settings', array( $this, 'nav_item_settings') );
            add_action( 'wp_ajax_wiloke_nav_item_save', array( $this, 'nav_item_save') );

            // Walker Menu Edit Item 
            add_filter( 'wp_edit_nav_menu_walker', array( $this, 'walker_nav_menu_item_edit'), 10, 2 );

            // Template Nav Settings
            add_action('admin_footer', array($this, 'template'));
        }

        public function admin_enqueue_scripts($hook) {
            
            global $post_type;

            if ( $post_type == 'wiloke-menu-item' ) {
                wp_enqueue_style( 'wiloke-post-type', WILOKEMENU__URI . 'admin/assets/css/style_post.css', false, '1.0.0' );
	            wp_enqueue_script('trigger-visual-editor', WILOKEMENU__URI . 'admin/assets/js/trigger-visual-editor.js', array('jquery'), null, true);
            }

            // CSS
            wp_enqueue_style( 'font-awesome', WILOKEMENU__URI . 'assets/css/lib/font-awesome.min.css', false, '4.7.0' );
            wp_enqueue_style( 'wiloke-mega-menu', WILOKEMENU__URI . 'admin/assets/css/style.css', false, '1.0.0' );

            // Color Picker
            wp_enqueue_style( 'wp-color-picker' );
            wp_enqueue_script( 'wp-color-picker' );

            // JS
            wp_enqueue_script( 'serializeObject', WILOKEMENU__URI . 'admin/assets/js/lib/jquery.serializeObject.min.js', array('jquery'), null, true);
            wp_enqueue_script( 'wiloke-mega-menu', WILOKEMENU__URI . 'admin/assets/js/script.min.js', array('jquery'), null, true);
        }

        public function icon_list() {
            check_ajax_referer( 'icon-list', 'security' );
            $icons  = include WILOKEMENU__DIR . 'configs/icon.php';
            wp_die( json_encode($icons) );
        }

        protected function _include() {
            require_once( WILOKEMENU__DIR . 'admin/helper.php' );
            require_once( WILOKEMENU__DIR . 'admin/walker-nav-menu-edit.php' );
        }

        // Metabox Menu
        public function add_metabox() {
            add_meta_box( 'meta-box-menu', esc_html__( 'Settings', 'wiloke-mega-menu' ), array($this, 'callback_metaboxe_nav'), 'wiloke-menu' );
        }

        public function callback_metaboxe_nav($post, $metabox) { 
            require_once( WILOKEMENU__DIR . 'configs/nav.php' );
            $values = get_post_meta($post->ID, 'wiloke-menu-settings', true);
            $helper = new WilokeMenu_Helper('wiloke-menu-settings', $args, $values);
            $helper->render();
        }

        public function update_metabox_menu($post_id) {

            if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) {
                return $post_id;
            }

            if ( isset($_POST['wiloke-menu-settings'])) {
                update_post_meta($post_id, 'wiloke-menu-settings', $_POST['wiloke-menu-settings']); 
            }

        }

        // Update content when create post type wiloke-menu-item
        public function content_update_before_create_post() {

            if( is_admin() ) {

                $screen = get_current_screen();

                if( $screen->post_type == 'wiloke-menu-item' && isset($_REQUEST['menu_item_id']) ) {

                    $id = intval($_REQUEST['menu_item_id']);

                    $data = get_post_meta($id, 'wiloke-nav-item-data', true);

                    if( isset($data['content']) ) {

                        global $post;

                        $post->post_content = $data['content'];

                    }
                }
            }
        }

        // Update Meta Nav Settings
        public function nav_setting_save($nav_menu_selected_id) {

            if ( isset($_POST['wiloke-nav-settings']) ) {
                $value = $_POST['wiloke-nav-settings'];
                update_term_meta( $nav_menu_selected_id, 'wiloke-nav-data', $value );
            } else {
                delete_term_meta( $nav_menu_selected_id, 'wiloke-nav-data');
            }

            $query = new WP_Query(array(
                'post_type' => 'wiloke-menu-item',
                'posts_per_page' => -1,
                'post_status' => 'any'
            ));

            if($query->have_posts() ) {

                $posts = $query->get_posts();
                
                foreach ($posts as $_post) {
                    wp_delete_post( $_post->ID, true );
                }
            }
        }

        // Nav Menu Item Settings
        public function nav_item_settings() {

            $return = array(
                'status'            => 204,
                'message'           => esc_html__('Error!', 'wiloke-mega-menu')
            );

            if( check_ajax_referer( 'wiloke-menu-settings', 'security', false ) ) { 

                if( isset($_POST['post_id']) ) {

                    require_once( WILOKEMENU__DIR . 'configs/item.php' );

                    $values = get_post_meta($_POST['post_id'], 'wiloke-nav-item-data', true);

                    $helper = new WilokeMenu_Helper('', $args, $values);

                    ob_start();

                    $helper->render();

                    $output = ob_get_clean();

                    $return = array(
                        'status'            => 200,
                        'data'              => $output,
                        'message'           => esc_html__('Success!', 'wiloke-mega-menu')
                    );
                }
            }

            wp_send_json($return);
        }

        public function nav_item_save()
        {
            $return = array(
                'status'            => 204,
                'message'           => esc_html__('Error!', 'wiloke-mega-menu')
            );

            if( check_ajax_referer( 'wiloke-menu-settings', 'security', false ) ) { 

                if( isset($_POST['post_id']) && isset($_POST['data']) ){

                    $post_id = $_POST['post_id'];
                    $data = $_POST['data'];

                    update_post_meta($post_id, 'wiloke-nav-item-data', $data);

                    $return = array(
                        'status'            => 200,
                        'message'           => esc_html__('Success!', 'wiloke-mega-menu')
                    );
                }
            }

            wp_send_json($return);
        }
        
        // Walker Nav Menu Item Edit
        public function walker_nav_menu_item_edit($walker, $menu_id) {
            return 'WilokeMenu_Walker_Nav_Menu_Edit';
        }

        // Template
        public function template() { 

            $nav_menus = wp_get_nav_menus(array('orderby' => 'name'));

            $menu_count = count($nav_menus);

            $nav_menu_selected_id = isset($_REQUEST['menu']) ? (int)$_REQUEST['menu'] : 0;

            $add_new_screen = (isset($_GET['menu']) && 0 == $_GET['menu']) ? true : false;

            // If we have one theme location, and zero menus, we take them right into editing their first menu
            $page_count = wp_count_posts('page');
            $one_theme_location_no_menus = (1 == count(get_registered_nav_menus()) && !$add_new_screen && empty($nav_menus) && !empty($page_count->publish)) ? true : false;

            // Get recently edited nav menu
            $recently_edited = absint(get_user_option('nav_menu_recently_edited'));
            if (empty($recently_edited) && is_nav_menu($nav_menu_selected_id))
                $recently_edited = $nav_menu_selected_id;

            // Use $recently_edited if none are selected
            if (empty($nav_menu_selected_id) && !isset($_GET['menu']) && is_nav_menu($recently_edited))
                $nav_menu_selected_id = $recently_edited;

            // On deletion of menu, if another menu exists, show it
            if (!$add_new_screen && 0 < $menu_count && isset($_GET['action']) && 'delete' == $_GET['action'])
                $nav_menu_selected_id = $nav_menus[0]->term_id;

            // Set $nav_menu_selected_id to 0 if no menus
            if ($one_theme_location_no_menus) {
                $nav_menu_selected_id = 0;
            } elseif (empty($nav_menu_selected_id) && !empty($nav_menus) && !$add_new_screen) {
                // if we have no selection yet, and we have menus, set to the first one in the list
                $nav_menu_selected_id = $nav_menus[0]->term_id;
            }

            $navSettings = get_term_meta($nav_menu_selected_id, 'wiloke-nav-data', true);

            ?>

            <script type="text/html" id="wiloke-nav-setting">

                <div class="wil-nav-setting menu-settings">

                    <h3><?php echo esc_html__('Wiloke Menu Settings', 'wiloke-mega-menu') ?></h3>

                    <dl class="wil_enable_mega">

                        <dt class="howto"><?php echo esc_html__('Enable', 'wiloke-mega-menu') ?></dt>

                        <dd class="checkbox-input">

                            <input type="checkbox" name="wiloke-nav-settings[megamenu]" value="1" class="wil-menu-enable" <?php echo isset($navSettings['megamenu']) ? 'checked' : ''; ?> >

                            <label><?php echo esc_html__('Use Wiloke Menu for this menu or not.', 'wiloke-mega-menu') ?></label>

                        </dd>

                    </dl>

                    <?php 

                        $query = new WP_Query(array( 
                            'post_type'         => 'wiloke-menu',
                            'post_status'       => 'publish'
                        ));

                        if( $query->have_posts() ) : ?>
                            
                            <dl class="wil-menu-select <?php echo isset($navSettings['megamenu']) ? 'active' : ''; ?>">

                                <dt class="howto"><?php echo esc_html__('Wiloke Menu', 'wiloke-mega-menu'); ?></dt>

                                <dd class="select-input">

                                    <select name="wiloke-nav-settings[menu]" >

                                        <?php while ( $query->have_posts() ) : $query->the_post(); ?>
                                            <option value="<?php the_ID(); ?>" <?php isset($navSettings['menu']) ? selected( $navSettings['menu'], get_the_ID(), true): '' ?> ><?php the_title(); ?></option>
                                        <?php endwhile; wp_reset_postdata() ?>

                                    </select>

                                    <label><?php echo esc_html__('Select a Menu', 'wiloke-mega-menu') ?></label> <a href="#"><?php echo esc_html__('Create a new one', 'wiloke-mega-menu') ?></a>

                                </dd>

                            </dl>

                            <?php

                        endif;

                    ?>

                </div>

            </script>

            <script type="text/html" id="wiloke-mega-menu-builder">

                <div class="wiloke-mega-menu-builder">

                    <!-- Nav Tabs -->
                    <div class="wiloke-mega-menu-builder-tab">
                        <span class="wiloke-mega-menu-builder-name"><?php esc_html_e('Mega Menu') ?></span>
                        <a class="active" href="#wiloke-mega-menu-builder-settings"><?php esc_html_e( 'Settings', 'wiloke-mega-menu' ); ?></a>
                        <a href="#wiloke-mega-menu-builder-content"><?php esc_html_e( 'Content Builder', 'wiloke-mega-menu' ); ?></a>
                    </div>
                    <!-- End / Nav Tabs -->
                    
                    <!-- Group Panel -->
                    <div class="wiloke-mega-menu-builder-group">

                        <form class="wiloke-mega-menu-builder-form" action="<?php echo esc_url(admin_url('post-new.php?post_type=wiloke-menu-item')) ?>" method="POST">

                            <!-- Actions form -->
                            <div class="wiloke-mega-menu-builder-actions">
                                <button type="reset" class="button button-large wiloke-mega-menu-builder-cancel"><?php esc_html_e('Cancel', 'wiloke-mega-menu') ?></button>
                                <button type="submit" class="button button-primary button-large wiloke-mega-menu-builder-save"><?php esc_html_e('Save Changes', 'wiloke-mega-menu') ?></button>
                            </div>
                            <!-- End / Actions form -->

                            <!-- Panel Settings -->
                            <div class="wiloke-mega-menu-builder-panel wiloke-mega-menu-builder-settings active" id="wiloke-mega-menu-builder-settings"></div>
                            <!-- End / Panel Settings -->
                            
                            <!-- Panel Content -->
                            <div class="wiloke-mega-menu-builder-panel wiloke-mega-menu-builder-content" id="wiloke-mega-menu-builder-content"></div>
                            <!-- End / Panel Content -->

                        </form>

                    </div>
                    <!-- End / Group Panel -->

                </div>

            </script>

            <?php
        }
    }

    new WilokeMenu_Admin();
}
