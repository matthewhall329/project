<?php 

/**
* 
*/
class WilokeMenu_Helper {
	private $name;
	private $args;
	private $values;

	function __construct($name, $args, $values) {
		$this->name 	= $name;
		$this->args 	= $args;
		$this->values 	= $values;
	}

	public function render() { 

		if( isset($this->args) && !empty($this->args) && is_array($this->args) ) : ?>
		
			<div class="metabox-menu">

		        <table class="form-table">
					
					<?php foreach ($this->args as $item): ?>

						<?php 

							$attributes = '';

							if ( isset($item['name']) && isset($this->values[ $item['name'] ]) ) {

								$item['value'] = $this->values[ $item['name'] ];
							}

							if( !isset($item['value']) && isset($item['std']) ) {
								$item['value'] = $item['std'];
							}

							if( !empty($this->name) ) {
								$item['name'] = trim($this->name) . '[' . trim($item['name']) . ']';
							}

							if( isset($item['dependence']) ) {

								if( isset($item['dependence']['element']) ) {
									$attributes .= 'data-dependence="'. esc_attr($this->name) .'[' . esc_attr($item['dependence']['element']) . ']" ';
								}

								if( isset($item['dependence']['value']) ) {
									$attributes .= 'data-value="' . esc_attr(json_encode($item['dependence']['value'])) . '" ';
								}
							}

						?>

				    	<tr <?php print trim($attributes) ?>>

				            <th>

				            	<?php 
					            	if ( isset($item['title']) ) {
					            		echo esc_html($item['title']);
					            	}
				            	?>

				            </th>

				            <td>

				                <fieldset>

				                	<?php 
					                	if ( isset($item['type']) && method_exists($this , $item['type']) ) {
					                		$this->{$item['type']}($item);
					                	}
				                	?>

									<?php if ( isset($item['desc']) && !empty($item['desc']) ): ?>

										<p class="description"><?php echo esc_html($item['desc']); ?></p> 

				                    <?php endif ?>                    
				                    
				                </fieldset>

				            </td>

				        </tr>

			        <?php endforeach ?>

		        </table>

	        </div>

		<?php endif;
	}

	protected function text($args) { ?>

    	<input type="text" name="<?php echo esc_attr($args['name']); ?>" class="regular-text" value="<?php echo esc_attr($args['value']) ?>">
    	
		<?php
	}

	protected function color($args) { ?>
    	<input type="text" name="<?php echo esc_attr($args['name']); ?>" class="color-picker" data-alpha="true" value="<?php echo sanitize_text_field($args['value']); ?>">
		<?php
	}

	protected function number($args) { ?>

    	<input type="number" name="<?php echo esc_attr($args['name']); ?>" value="<?php echo esc_attr($args['value']) ?>">

		<?php
	}

	protected function textarea($args) { ?>
    	<textarea name="<?php echo esc_attr($args['name']); ?>" rows="10" cols="50" class="regular-text"><?php echo esc_html($args['value']) ?></textarea>
		<?php
	}

	protected function checkbox($args) {
        if ( !isset($args['value']) && isset($args['std']) && !empty($args['std']) ){
	        $args['value'] = $args['std'];
        }
    ?>
		<label>
			<input type="checkbox" name="<?php echo esc_attr($args['name']); ?>" value="1" <?php echo (isset($args['value']) && !empty($args['value'])) ? 'checked' : ''; ?>> 
			<?php echo esc_html($args['label']) ?>
		</label>

    	<?php 
	}

	protected function checkboxs($args) {

		if( isset($args['option']) && !empty($args['option']) ) {

	    	foreach ($args['option'] as $key => $value) : ?>

				<label>
					<input type="checkbox" name="<?php echo esc_attr($args['name']); ?>[]" value="<?php echo esc_attr($key) ?>" <?php echo isset($args['value']) && in_array($key, $args['value']) ? 'checked' : ''; ?>> 
					<?php echo esc_html($value) ?>
				</label><br>

	    	<?php endforeach;
    	}
	}

	protected function select($args) {?>

		<select name="<?php echo esc_attr($args['name']); ?>">

			<?php if( isset($args['option']) && !empty($args['option']) ) :

		    	foreach ($args['option'] as $key => $value) : ?>

		    		<option value="<?php echo esc_attr($key); ?>" <?php echo isset($args['value']) && $args['value'] == $key ? 'selected' : ''; ?>><?php echo esc_html($value) ?></option>

		    	<?php endforeach;

	    	endif; ?>

    	</select>

    	<?php 
	}

	protected function radio($args) {

		if( isset($args['option']) && !empty($args['option']) ) {

	    	foreach ($args['option'] as $key => $value) : ?>

	    		<label>
	    			<input type="radio" name="<?php echo esc_attr($args['name']); ?>" value="<?php echo esc_attr($key) ?>" <?php echo isset($args['value']) && $args['value'] == $key ? 'checked' : ''; ?>> 
	    			<?php echo esc_html($value); ?>
    			</label><br>

	    	<?php endforeach;
    	}
	}

	public function spacing($args) { ?>

		<label>
			<span><?php echo esc_html__('Top: ', 'wiloke-menu') ?></span> 
			<input type="number" name="<?php echo esc_attr($args['name']); ?>[top]" class="small-text" value="<?php echo isset($args['value']['top']) ? esc_attr($args['value']['top']) : '' ?>">
		</label>

		<label>
			<span><?php echo esc_html__('Right: ', 'wiloke-menu') ?></span> 
			<input type="number" name="<?php echo esc_attr($args['name']); ?>[right]" class="small-text" value="<?php echo isset($args['value']['right']) ? esc_attr($args['value']['right']) : '' ?>">
		</label>

		<label>
			<span><?php echo esc_html__('Bottom: ', 'wiloke-menu') ?></span> 
			<input type="number" name="<?php echo esc_attr($args['name']); ?>[bottom]" class="small-text" value="<?php echo isset($args['value']['bottom']) ? esc_attr($args['value']['bottom']) : '' ?>">
		</label>

		<label>
			<span><?php echo esc_html__('Left: ', 'wiloke-menu') ?></span> 
			<input type="number" name="<?php echo esc_attr($args['name']); ?>[left]" class="small-text" value="<?php echo isset($args['value']['left']) ? esc_attr($args['value']['left']) : '' ?>">
		</label>

		<label>
			<span><?php echo esc_html__('Unit: ', 'wiloke-menu') ?></span> 
			<select name="<?php echo esc_attr($args['name']); ?>[unit]">
				<option value="px" <?php echo isset($args['value']['unit']) && $args['value']['unit'] == $key ? 'selected' : ''; ?>>px</option>
				<option value="em" <?php echo isset($args['value']['unit']) && $args['value']['unit'] == $key ? 'selected' : ''; ?>>em</option>
				<option value="%" <?php echo isset($args['value']['unit']) && $args['value']['unit'] == $key ? 'selected' : ''; ?>>%</option>
	    	</select>
    	</label>

		<?php
	}

	protected function iconpicker($args) { ?>

		<div class="wil-icon-select" data-nonce="<?php echo esc_attr(wp_create_nonce( 'icon-list' )); ?>">

			<div class="wil-icon-selector">
				<span class="wil-icon-selected"><i class="<?php echo esc_attr($args['value']) ?>"></i></span>
				<span class="wil-icon-button"><i class="fa-arrow-down fip-fa fa"></i></span>
			</div>

			<div class="wil-icon-dropdown">

				<div class="wil-icon-search">
					<input type="text" class="wil-icon-search-input" placeholder="<?php echo esc_html__('Serach Icon', 'wiloke-menu') ?>">
				</div>

				<ul class="wil-icon-list">
					
				</ul>

			</div>

			<input type="hidden" name="<?php echo esc_attr($args['name']); ?>" class="wil-icon-value" value="<?php echo esc_attr($args['value']) ?>">

		</div>

		<?php 
	}

	protected function media($args) { 

		$multiple = 'false';

		if( isset( $args['multiple']) && !empty($args['multiple']) ) {
			$multiple = $args['multiple'];
		}

		?>

		<div class="wil-media" data-multiple="<?php echo esc_attr($multiple); ?>">
		
			<ul class="wil-media-screen">
				<?php 

					if( !empty($args['value']) ) {

						$ids = explode(',', $args['value']);

						if(isset($ids) && is_array($ids) ) {

							foreach ($ids as $id) {
								$attachment = wp_get_attachment_image_src( $id, 'thumbnail');

								if( $attachment ) {
									echo '<li class="wil-media-screen-item" style="background-image: url(' . esc_url($attachment[0]) . ')"><span class="wil-media-screen-item-remove" data-id="'. esc_attr($id) .'"></span></li>';
								}
							}
						}
					}
				?>
			</ul>

			<div class="wil-media-buttons">

				<span class="wil-media-add button button-primary button-large">

					<?php 
						if ($multiple == 'true') {
							echo esc_html__('Add Gallery', 'wiloke-menu');
						} else {
							echo esc_html__('Add Image', 'wiloke-menu');
						}
					?>

				</span>

				<span class="wil-media-remove button button-default button-large"><?php echo esc_html__('Remove', 'wiloke-menu') ?></span>
			</div>
			<input type="hidden" name="<?php echo esc_attr($args['name']); ?>" class="wil-media-id" value="<?php echo esc_attr($args['value']); ?>">

		</div>

		<?php 
	}
}

function wiloke_menu_animates() {
	$animate  = include WILOKEMENU__DIR . 'configs/animated.php';
	return $animate;
}