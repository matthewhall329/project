;(function ($) {
	'use strict';

	class DirectBankTransfer{
		constructor(){
			this.$app = $('#wiloke-proceed-with-banktransfer');
			this.init();
		}

		init(){
			if ( this.$app.length ){
				this.xhr = null;
				this.$app.on('click', ((event)=>{
					event.preventDefault();
					this.$app.addClass('loading btn-primary');
					this.ajaxHandleSubmit();
				}));
			}
		}

		ajaxHandleSubmit(){
			if ( (this.xhr !== null) && this.xhr.status !== 200 ){
				this.xhr.abort();
			}
			this.xhr = $.ajax({
				type: 'POST',
				url: WILOKE_GLOBAL.ajaxurl,
				data: {
					action: 'wiloke_submission_pay_with_banktransfer',
					planID: $('#wiloke-package-id').val()
				},
				success: (response=>{
					if ( response.success ){
						window.location.href = response.data.redirectTo;
					}else{
						alert(response.data.msg);
					}

					this.$form.removeClass('loading btn-primary');
				})
			})
		}
	}

	$(document).ready(function () {
		new DirectBankTransfer();
	});

})(jQuery);