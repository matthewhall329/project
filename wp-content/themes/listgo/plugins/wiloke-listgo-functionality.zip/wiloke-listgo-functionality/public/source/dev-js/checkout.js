;(function ($) {
	'use strict';
	class WilokeProceedPaymentWithTwoCheckout{
		constructor(){
			this.$app = $('#wiloke-proceed-with-2checkout');
			this.init();
		}

		init(){
			if ( this.$app.length && typeof TCO !== 'undefined'){
				this.xhr = null;
				this.token = null;
				this.formData = null;
				this.$creditCardPopup = $('#wiloke-form-two-checkout-wrapper');
				this.$form = $('#wiloke-form-creditcard-with-2checkout');
				this.closePopup();
				TCO.loadPubKey(WILOKE_GLOBAL.twocheckoutMode);
				this.pay();
				this.$app.on('click', ((event)=>{
					event.preventDefault();
					this.$app.addClass('loading btn-primary');
					this.showPopup();
				}));
			}
		}

		ajaxHandleSubmit(){
			if ( (this.xhr !== null) && this.xhr.status !== 200 ){
				this.xhr.abort();
			}

			this.xhr = $.ajax({
				type: 'POST',
				url: WILOKE_GLOBAL.ajaxurl,
				data: {
					action: 'wiloke_submission_pay_with_2checkout',
					token: this.token,
					planID: $('#wiloke-package-id').val(),
					formData: this.$form.serializeArray()
				},
				success: (response=>{
					if ( response.success ){
						window.location.href = response.data.redirectTo;
					}else{
						this.$form.find('.message').html(response.data.msg).removeClass('hidden');
					}

					this.$form.parent().removeClass('block-loading');
				})
			})
		}

		successCallback(data){
			// Set the token as the value for the token input
			this.token = data.response.token.token;
			// IMPORTANT: Here we call `submit()` on the form element directly instead of using jQuery to prevent and infinite token request loop.
			this.ajaxHandleSubmit();
		}

		errorCallback(data){
			if (data.errorCode === 200) {
				// This error code indicates that the ajax call failed. We recommend that you retry the token request.
			} else {
				alert(data.errorMsg);
			}
			this.$form.parent().removeClass('block-loading');
		}

		tokenRequest(){
			// Setup token request arguments
			let args = {
				sellerId: WILOKE_GLOBAL.twoCheckoutSellerID,
				publishableKey: WILOKE_GLOBAL.twoCheckoutPublishableKey,
				ccNo: $("#cardNumber").val(),
				cvv: $("#cardCvv").val(),
				expMonth: $("#expMonth").val(),
				expYear: $("#expYear").val()
			};

			TCO.requestToken((data=>{
				this.successCallback(data)
			}), (data=>{
				this.errorCallback(data)
			}), args);
		}

		pay(){
			// Pull in the public encryption key for our environment

			this.$form.on('submit', ((event)=>{
				event.preventDefault();
				this.$form.parent().addClass('block-loading');
				// Call our token request function
				this.tokenRequest();
				// Prevent form from submitting
				return false;
			}));
		}

		showPopup(){
			this.$creditCardPopup.addClass('wil-modal--open');
		}

		closePopup(){
			this.$form.on('click', '.wil-modal__close', ((event)=>{
				this.$creditCardPopup.removeClass('wil-modal--open');
				this.$app.removeClass('loading');
			}));

			this.$creditCardPopup.on('closed', (event=>{
				this.$app.removeClass('loading');
			}))
		}
	}

	class ProceedPaymentWithPayPal{
		constructor(){
			this.$app = $('#wiloke-proceed-with-paypal');
			this.ajax = null;
			this.pay();
		}

		pay(){
			if ( this.ajax !== null && this.ajax.status !== 200 ){
				this.ajax.abort();
			}

			let self = this;

			this.$app.on('click', function (event) {
				let $target = $(event.target);
				event.preventDefault();
				$target.addClass('loading btn-primary');
				$target.prop('disabled', true);

				self.ajax = $.ajax({
					type: 'POST',
					url: WILOKE_GLOBAL.ajaxurl,
					data: {
						action: 'wiloke_submission_pay_with_'+$target.data('gateway'),
						planID: $('#wiloke-planID').val()
					},
					success: (response=>{
						if ( response.success ){
							window.location.href = response.data.redirectTo;
						}else{
							alert(response.data.msg);
						}
						$target.removeClass('loading');
						$target.prop('disabled', false);
					})
				})
			})
		}
	}

	class WilokeProceedPaymentWithStripe{
		constructor(){
			this.$app = $('#wiloke-proceed-with-stripe');
			this.tokenTriggered = false;
			this.init();
		}

		init(){
			if ( this.$app.length ){
				if ( WILOKE_SUBMISSION_STRIPE_CONFIGURATION.hasCustomerID === 'no' ){
					this.oStripe = StripeCheckout.configure({
						key: WILOKE_SUBMISSION_STRIPE_CONFIGURATION.publishableKey,
						locale: 'auto'
					});

					this.xhr = null;
					this.token = null;
					this.formData = null;
					this.$creditCardPopup = $('#wiloke-form-stripe-checkout-wrapper');
					this.$form = $('#wiloke-form-creditcard-with-stripe');
					this.closePopup();

					this.$app.on('click', ((event)=>{
						event.preventDefault();
						this.showPopup();
					}));
				}else{
					this.$app.on('click', ((event)=>{
						event.preventDefault();
						this.ajaxRequest();
					}));

				}
			}
		}

		showPopup(){
			this.$creditCardPopup.addClass('wil-modal--open');
			this.oData = {};
			this.oStripe.open({
				name: this.$form.find('[name="package_name"]').val(),
				zipCode: false,
				closed: (()=>{
					if ( this.tokenTriggered ){
						this.$app.addClass('loading btn-primary');
					}else{
						this.$app.removeClass('loading btn-primary');
					}
					this.$creditCardPopup.removeClass('wil-modal--open');
				}),
				token:  ((token)=>{
					this.oData.token = token.id;
					this.oData.email = token.email;
					this.oData.planID = $('#wiloke-planID').val();
					this.tokenTriggered = true;
					this.$creditCardPopup.removeClass('wil-modal--open');
					this.ajaxRequest();
				})
			});
		}

		ajaxRequest(){
			this.$app.addClass('loading btn-primary');

			$.ajax({
				type: 'POST',
				url: WILOKE_GLOBAL.ajaxurl,
				// data: {action: 'wiloke_submission_handle_stripe', aData: this.oData, post_ID: $('#post_id').val()},
				data: {
					action: 'wiloke_submission_pay_with_stripe',
					aData: this.oData
				},
				success: (response=>{
					if ( response.success ){
						if ( typeof response.data.redirectTo !== 'undefined' ){
							window.location.href = response.data.redirectTo;
						}else{
							alert(response.data.msg);
						}
						// window.location.href = response.data.redirect;
					}else{
						alert(response.data.msg);
					}
					this.$app.removeClass('loading');
				})
			})
		}

		closePopup(){
			this.$form.on('click', '.wil-modal__close', ((event)=>{
				this.$creditCardPopup.removeClass('wil-modal--open');
				this.$app.removeClass('loading btn-primary');
			}));

			this.$creditCardPopup.on('closed', (event=>{
				this.$app.removeClass('loading btn-primary');
			}))
		}
	}

	$(document).ready(function () {
		new WilokeProceedPaymentWithTwoCheckout();
		new ProceedPaymentWithPayPal();
		new WilokeProceedPaymentWithStripe();
	});

})(jQuery);