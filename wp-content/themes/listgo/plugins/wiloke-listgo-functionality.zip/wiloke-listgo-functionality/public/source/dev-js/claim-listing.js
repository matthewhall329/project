;(function ($) {
	'use strict';
	class WilokeClaim{
		constructor(){
			this.$app = $('#wiloke-claim-listing');
			this.init();
		}

		init(){
			if ( this.$app.length ){
				this.$claimForm = $('#wiloke-form-claim-information');
				this.$app.on('click', (event=>{
					event.preventDefault();
					if ( WILOKE_GLOBAL.isLoggedIn === 'no' ){
						$('div[data-modal="#modal-login"]').trigger('click');
						$('#wiloke-form-claim-information-wrapper').removeClass('wil-modal--open');
					}else{
						this.claimListing();
					}
				}));
			}
		}

		claimListing(){
			this.$claimForm.on('submit', (event=>{
				event.preventDefault();
				this.$claimForm.addClass('block-loading');

				$.ajax({
					type: 'POST',
					url: WILOKE_GLOBAL.ajaxurl,
					data: {phone: this.$claimForm.find('#claimer-phone').val(), security: WILOKE_GLOBAL.wiloke_nonce, action: 'wiloke_claim_listing', claimID: this.$claimForm.find('#claim-id').val()},
					success: (response=>{
						if ( response.success ){
							this.$claimForm.parent().html(response.data.msg);
						}else{
							this.$claimForm.find('.message').html(response.data.msg).removeClass('hidden');
						}

						this.$claimForm.removeClass('block-loading');
					})
				})
			}));
		}
	}

	$(document).ready(function () {
		new WilokeClaim;
	});

})(jQuery);