export default class{
		constructor(){
			this.setup();
			this.tokenTriggered = false;
			this.isCardModel = null;
			this.$creditCardPopup = null;
			this.init();
		}

		setup(){
			this.$creditCardPopup = $('#wiloke-form-stripe-checkout-wrapper');
			this.$form = $('#wiloke-form-creditcard-with-stripe');
			this.$app = $('#wiloke-proceed-with-stripe');
		}

		ajaxRequest(){

		}

		getFormName(){
			return this.$form.find('[name="package_name"]').val();
		}

		afterGetToken(token){
			this.oData.token = token.id;
			this.oData.email = token.email;
			this.oData.planID = $('#wiloke-planID').val();
		}

		hasCardModel(){
			if ( this.isCardModel === null ){
				this.isCardModel = this.$creditCardPopup !== null && this.$creditCardPopup.length > 0;
			}

			return this.isCardModel;
		}

		init(){
			if ( this.$app.length ){
				if ( WILOKE_SUBMISSION_STRIPE_CONFIGURATION.hasCustomerID === 'no' ){
					this.oStripe = StripeCheckout.configure({
						key: WILOKE_SUBMISSION_STRIPE_CONFIGURATION.publishableKey,
						locale: 'auto'
					});

					this.xhr = null;
					this.token = null;
					this.formData = null;

					this.closePopup();

					this.$app.on('click', ((event)=>{
						event.preventDefault();
						this.$app.addClass('loading btn-primary');
						this.showPopup();
					}));
				}else{
					this.$app.on('click', ((event)=>{
						event.preventDefault();
						this.$app.addClass('loading btn-primary');
						this.ajaxRequest();
					}));

				}
			}
		}

		showPopup(){
			if ( this.hasCardModel() ){
				this.$creditCardPopup.addClass('wil-modal--open');
			}

			this.oData = {};
			this.oStripe.open({
				name: this.getFormName(),
				zipCode: false,
				closed: (()=>{
					if ( this.tokenTriggered ){
						this.$app.addClass('loading btn-primary');
					}else{
						this.$app.removeClass('loading btn-primary');
					}
					if ( this.hasCardModel() ){
						this.$creditCardPopup.removeClass('wil-modal--open');
					}
				}),
				token:  ((token)=>{
					this.afterGetToken(token);
					this.tokenTriggered = true;
					if ( this.hasCardModel() ){
						this.$creditCardPopup.removeClass('wil-modal--open');
					}
					this.ajaxRequest();
				})
			});
		}

		closePopup(){
			if ( !this.hasCardModel() ) {
				return false;
			}
			this.$form.on('click', '.wil-modal__close', ((event)=>{
				this.$creditCardPopup.removeClass('wil-modal--open');
				this.$app.removeClass('loading btn-primary');
			}));

			this.$creditCardPopup.on('closed', (event=>{
				this.$app.removeClass('loading btn-primary');
			}))
		}
	}
