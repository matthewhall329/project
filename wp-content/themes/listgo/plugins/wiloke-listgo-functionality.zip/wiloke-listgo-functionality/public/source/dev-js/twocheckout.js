export default class{
	constructor(){
		this.setup();
		this.init();
	}

	setup(){
		this.$app = $('#wiloke-proceed-with-2checkout');
		this.$creditCardPopup = $('#wiloke-form-two-checkout-wrapper');
		this.$form = $('#wiloke-form-creditcard-with-2checkout');
	}


	ajaxRequest(){
		if ( (this.xhr !== null) && this.xhr.status !== 200 ){
			this.xhr.abort();
		}

		this.xhr = $.ajax({
			type: 'POST',
			url: WILOKE_GLOBAL.ajaxurl,
			data: {
				action: 'wiloke_submission_pay_with_2checkout',
				token: this.token,
				planID: $('#wiloke-package-id').val(),
				formData: this.$form.serializeArray()
			},
			success: (response=>{
				if ( response.success ){
					window.location.href = response.data.redirectTo;
				}else{
					this.$form.find('.message').html(response.data.msg).removeClass('hidden');
				}

				this.$form.parent().removeClass('block-loading');
			})
		})
	}

	init(){
		console.log(this.$app.length);
		if ( this.$app.length ){
			this.xhr = null;
			this.token = null;
			this.formData = null;

			this.closePopup();
			TCO.loadPubKey(WILOKE_GLOBAL.twocheckoutMode);
			this.pay();
			this.$app.on('click', ((event)=>{
				event.preventDefault();
				this.$app.addClass('loading btn-primary');
				this.showPopup();
			}));
		}
	}

	successCallback(data){
		// Set the token as the value for the token input
		this.token = data.response.token.token;
		// IMPORTANT: Here we call `submit()` on the form element directly instead of using jQuery to prevent and infinite token request loop.
		this.ajaxRequest();
	}

	errorCallback(data){
		if (data.errorCode === 200) {
			// This error code indicates that the ajax call failed. We recommend that you retry the token request.
		} else {
			alert(data.errorMsg);
		}
		this.$form.parent().removeClass('block-loading');
	}

	tokenRequest(){
		// Setup token request arguments
		let args = {
			sellerId: WILOKE_GLOBAL.twoCheckoutSellerID,
			publishableKey: WILOKE_GLOBAL.twoCheckoutPublishableKey,
			ccNo: document.getElementById('cardNumber').value,
			cvv: document.getElementById("cardCvv").value,
			expMonth: document.getElementById("expMonth").value,
			expYear: document.getElementById("expYear").value
		};

		TCO.requestToken((data=>{
			this.successCallback(data)
		}), (data=>{
			this.errorCallback(data)
		}), args);
	}

	pay(){
		// Pull in the public encryption key for our environment

		this.$form.on('submit', ((event)=>{
			event.preventDefault();
			this.$form.parent().addClass('block-loading');
			// Call our token request function
			this.tokenRequest();
			// Prevent form from submitting
			return false;
		}));
	}

	showPopup(){
		this.$creditCardPopup.addClass('wil-modal--open');
	}

	closePopup(){
		this.$form.on('click', '.wil-modal__close', ((event)=>{
			this.$creditCardPopup.removeClass('wil-modal--open');
			this.$app.removeClass('loading');
		}));

		this.$creditCardPopup.on('closed', (event=>{
			this.$app.removeClass('loading');
		}))
	}
}
