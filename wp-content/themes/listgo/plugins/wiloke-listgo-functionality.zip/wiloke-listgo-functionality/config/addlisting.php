<?php
return[
	'social_networks' => array(
		'facebook', 'twitter', 'google-plus', 'linkedin', 'tumblr', 'instagram', 'flickr', 'pinterest', 'medium', 'tripadvisor', 'wikipedia', 'vimeo', 'youtube', 'whatsapp', 'vkontakte', 'odnoklassniki'
	)
];