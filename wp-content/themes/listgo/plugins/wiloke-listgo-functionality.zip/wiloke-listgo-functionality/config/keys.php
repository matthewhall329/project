<?php
return array(
	'payment_configuration' => 'wiloke_submission_configuration'
);