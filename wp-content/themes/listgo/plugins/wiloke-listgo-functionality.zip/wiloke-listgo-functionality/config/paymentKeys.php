<?php
return [
	'info'              => 'payment_info',
	'nextBillingDate'   => 'next_billing_date',
	'paypal'    => array(
		'paymentID'            => 'paypal_payment_id',
		'billingAgreementID'   => 'paypal_billing_agreement_id',
		'discountVal'          => 'paypal_discount_value'
	),
	'2checkout' => array(
		'saleID'    => '2checkout_sale_id'
	),
	'stripe' => array(
		'subscriptionID' => 'stripe_subscription_id',
		'chargeID'       => 'stripe_charge_id'
	)
];