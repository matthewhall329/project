<?php
return apply_filters('wiloke-submission/config/mailnotifications', [
	array(
		'type'    => 'open_segment'
	),
	array(
		'text'    => esc_html__('General Settings', 'wiloke'),
		'type'    => 'header',
		'class'   => 'dividing toggle-anchor',
		'tag'     => 'h3'
	),
	array(
		'type'    => 'text',
		'heading' => esc_html__('"From" ', 'wiloke'),
		'name'    => 'wiloke_submission_email_notifications[email_from]',
		'id'      => 'email_from',
		'placeholder'=>esc_html__('Leave empty to use the admin email', 'wiloke'),
		'default' => ''
	),
	array(
		'type'    => 'text',
		'heading' => esc_html__('Brand Name (*)', 'wiloke'),
		'name'    => 'wiloke_submission_email_notifications[brandname]',
		'id'      => 'brandname',
		'default' => 'Wiloke'
	),
	array(
		'type'    => 'text',
		'heading' => esc_html__('Logo (*)', 'wiloke'),
		'name'    => 'wiloke_submission_email_notifications[email_logo_url]',
		'id'      => 'email_logo_url',
		'placeholder'=>'https://wiloke.com/images/logo.png',
		'default' => ''
	),
	array(
		'type'    => 'textarea',
		'heading' => esc_html__('Best Regards', 'wiloke'),
		'name'    => 'wiloke_submission_email_notifications[best_regard]',
		'id'      => 'best_regard',
		'placeholder'=>'',
		'default' => 'Best Regards,[breakdown] Wiloke'
	),
	array(
		'type'    => 'textarea',
		'heading' => esc_html__('Footer', 'wiloke'),
		'name'    => 'wiloke_submission_email_notifications[email_signature]',
		'id'      => 'email_signature',
		'placeholder'=>'',
		'default' => 'Wiloke - We do WordPress'
	),
	array(
		'type' => 'close_segment'
	),
	array(
		'type' => 'open_segment'
	),
	array(
		'text'    => esc_html__('Welcome Message', 'wiloke'),
		'type'    => 'header',
		'class'   => 'dividing toggle-anchor',
		'tag'     => 'h3'
	),
	array(
		'type'    => 'textarea',
		'heading' => '',
		'name'    => 'wiloke_submission_email_notifications[welcome_message]',
		'desc'    => esc_html__('To enable user "Send User Confirmation Key" feature, from the admin sidebar please click on Appearance -> Theme Options -> Signup, Signin, Review tab', 'wiloke'),
		'desc_status' => 'info',
		'id'      => 'mail_listing_submitted',
		'default' => esc_html__('Welcome to %brand%![break_down] Thank you for signing up for %brand%. Click the following link to confirm your account: %registration_confirmation_url%.' , 'wiloke')
	),
	array(
		'type' => 'close_segment'
	),
	array(
		'type' => 'open_segment'
	),
	array(
		'text'    => esc_html__('Listing Status Messages', 'wiloke'),
		'type'    => 'header',
		'class'   => 'dividing toggle-anchor',
		'tag'     => 'h3'
	),
	array(
		'type'    => 'textarea',
		'heading' => esc_html__('Listing Submitted', 'wiloke'),
		'name'    => 'wiloke_submission_email_notifications[mail_listing_submitted]',
		'id'      => 'mail_listing_submitted',
		'default' => esc_html__('Congratulations! Your article - %post_title% - on %brand% has been submitted. You will be contacted by one of our representatives shortly for the review result.' , 'wiloke')
	),
	array(
		'type'    => 'textarea',
		'heading' => esc_html__('Listing approved', 'wiloke'),
		'name'    => 'wiloke_submission_email_notifications[mail_listing_approved]',
		'id'      => 'mail_listing_approved',
		'default' => esc_html__('Congratulations! Your submission - %post_title% - on %brand% has been approved. You can view your article here: %post_link%.[break_down] Thanks for your submission!' , 'wiloke')
	),
	array(
		'type'    => 'textarea',
		'heading' => esc_html__('Listing Expired', 'wiloke'),
		'name'    => 'wiloke_submission_email_notifications[mail_listing_expired]',
		'id'      => 'mail_listing_expired',
		'default' => esc_html__('Dear %customer%! One of your listings with name %post_title% expired %expired%. But You can still renew now. If you wish to renew, simply click on the link below and follow the instructions. Renew now: %post_link%.' , 'wiloke')
	),
	array(
		'type' => 'close_segment'
	),
	array(
		'type' => 'open_segment'
	),
	array(
		'text'    => esc_html__('Claim Messages', 'wiloke'),
		'type'    => 'header',
		'class'   => 'dividing toggle-anchor',
		'tag'     => 'h3'
	),
	array(
		'type'    => 'textarea',
		'heading' => esc_html__('Claim request has been approved', 'wiloke'),
		'name'    => 'wiloke_submission_email_notifications[mail_claim_approved]',
		'id'      => 'mail_listing_submitted',
		'default' => esc_html__('Congratulations! Your claim - %post_title% - on %brand% has been approved. The claim url: %post_link%', 'wiloke')
	),
	array(
		'type'    => 'textarea',
		'heading' => esc_html__('Claim request has been rejected', 'wiloke'),
		'name'    => 'wiloke_submission_email_notifications[mail_claim_rejected]',
		'id'      => 'mail_listing_submitted',
		'default' => esc_html__('Hi![breakdown] Thank you for using %brand%. We regret to inform you that the listing %post_title% you have claimed on %brand% has been rejected.[breakdown] Please do keep sending in your suggestions and feedback to %contactinfo% and let us know if there’s anything else we can help with.', 'wiloke')
	),
	array(
		'type' => 'close_segment'
	),
	array(
		'type' => 'open_segment'
	),
	array(
		'text'    => esc_html__('Add Event Messages', 'wiloke'),
		'type'    => 'header',
		'class'   => 'dividing toggle-anchor',
		'tag'     => 'h3'
	),
	array(
		'type'    => 'textarea',
		'heading' => esc_html__('Event has been published', 'wiloke'),
		'name'    => 'wiloke_submission_email_notifications[event_published]',
		'id'      => 'event_published',
		'default' => esc_html__('Congratulations! Your event - %post_title% - on %brand% has been published successfully. You can view your event here: %listing_url%', 'wiloke')
	),
	array(
		'type' => 'close_segment'
	),
	array(
		'type' => 'open_segment'
	),
	array(
		'text'    => esc_html__('Payment Messages', 'wiloke'),
		'type'    => 'header',
		'class'   => 'dividing toggle-anchor',
		'tag'     => 'h3'
	),
	array(
		'text'    => esc_html__('Direct Bank Transfer', 'wiloke'),
		'type'    => 'header',
		'class'   => 'dividing',
		'tag'     => 'h4'
	),
	array(
		'type'    => 'textarea',
		'heading' => esc_html__('Processing order', 'wiloke'),
		'name'    => 'wiloke_submission_email_notifications[mail_bank_transfer_processing_order]',
		'id'      => 'mail_listing_outbalance',
		'default' => esc_html__('Dear %customer%![break_down]Your order has been received and now being processed. Your order details are show below for your reference:[break_down] %order_details%.[break_down]To complete this plan, please transfer your payment to the following bank accounts:[break_down] %bank_accounts%.' , 'wiloke')
	),
	array(
		'text'    => esc_html__('Subscription Messages', 'wiloke'),
		'type'    => 'header',
		'class'   => 'dividing',
		'tag'     => 'h4'
	),
	array(
		'type'    => 'textarea',
		'heading' => esc_html__('Subscription Created', 'wiloke'),
		'name'    => 'wiloke_submission_email_notifications[mail_subscription_created]',
		'id'      => 'mail_subscription_created',
		'default' => esc_html__('Congratulations! Your subscription on %brand% has been created. The subscription details:[break_down] %subscription_details%. [break_down]Thank for using our service.' , 'wiloke')
	),
	array(
		'type'    => 'textarea',
		'heading' => esc_html__('Subscription Cancelled', 'wiloke'),
		'name'    => 'wiloke_submission_email_notifications[mail_subscription_cancelled]',
		'id'      => 'mail_subscription_cancelled',
		'default' => esc_html__('Dear %customer%. Your subscription #%subscription_number% on %brand% has been cancelled, and you will no longer be billed for this plan. Thank for using our service!' , 'wiloke')
	),
	array(
		'type'    => 'textarea',
		'heading' => esc_html__('Subscription Failed', 'wiloke'),
		'name'    => 'wiloke_submission_email_notifications[mail_subscription_failed]',
		'id'      => 'mail_subscription_cancelled',
		'default' => esc_html__('Dear %customer%. Unfortunately, Your subscription #%subscription_number% on %brand% has been failed.[break_down] If you have any question, Please feel free contact us at %contactinfo%. [breakdown]Thank for using our service!' , 'wiloke')
	),
	array(
		'type'    => 'textarea',
		'heading' => esc_html__('Subscription Suspended', 'wiloke'),
		'name'    => 'wiloke_submission_email_notifications[mail_subscription_suspended]',
		'id'      => 'mail_subscription_suspended',
		'default' => esc_html__('Dear %customer%. Consider this email to be confirmation that your subscription #%subscription_number% has been suspended. [breakdown]If you have any question, Please feel free contact us at %contactinfo%. [breakdown]Thank for using our service!' , 'wiloke')
	),
	array(
		'text'    => esc_html__('Invoice Messages', 'wiloke'),
		'type'    => 'header',
		'class'   => 'dividing',
		'tag'     => 'h4'
	),
	array(
		'type'    => 'textarea',
		'heading' => esc_html__('Processing Payment', 'wiloke'),
		'name'    => 'wiloke_submission_email_notifications[mail_processing_payment]',
		'id'      => 'mail_processing_payment',
		'default' => esc_html__('Congratulations! Your invoice has been received! [breakdown] Invoice Number: %invoice_number%. [breakdown]Payment Method: %payment_method%. [breakdown] Package Name: %package_title%.' , 'wiloke')
	),
	array(
		'type'    => 'textarea',
		'heading' => esc_html__('Completed Payment', 'wiloke'),
		'name'    => 'wiloke_submission_email_notifications[mail_completed_payment]',
		'id'      => 'mail_completed_payment',
		'default' => esc_html__('Thank for your payment to %brand%! Your invoice details: [breakdown]%invoice_details%' , 'wiloke')
	),
	array(
		'type'    => 'textarea',
		'heading' => esc_html__('Failed Payment', 'wiloke'),
		'name'    => 'wiloke_submission_email_notifications[mail_failed_payment]',
		'id'      => 'mail_failed_payment',
		'default' => esc_html__('Unfortunately, Your payment has been failed. [breakdown] Invoice Number: %invoice_number%. [breakdown] Payment Method: %payment_method%. [breakdown] Package Name: %package_title%. [breakdown] Invoice Date: %invoice_date%.' , 'wiloke')
	),
	array(
		'type'    => 'close_segment'
	),
	array(
		'type' => 'submit',
		'name' => esc_html__('Submit', 'wiloke')
	)
]);