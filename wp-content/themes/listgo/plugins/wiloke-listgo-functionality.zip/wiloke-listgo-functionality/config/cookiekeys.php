<?php
return [
	'userPlanCookie' => 'wiloke_store_token_plan_session',
	'storePlanRelationshipIDSession' => 'store_plan_relationship_ID'
];