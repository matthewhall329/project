<?php
return [
	'storeTokenPlanSession' => 'wiloke_store_token_plan_session',
	'storePlanRelationshipIDSessionID' => 'store_planrelationshipID_sessionID',
	'storePostID'  => 'store_postID',
	'storePlanID'  => 'wiloke_submission_store_planID',
	'storeDiscountValue' => 'wiloke_submission_store_discount_value',
	'startFreePlan' => 'wiloke_submission_start_free_plan',
	'planType'      => 'wiloke_submission_plan_type',
];