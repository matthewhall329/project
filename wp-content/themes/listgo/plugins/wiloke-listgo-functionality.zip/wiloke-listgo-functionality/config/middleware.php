<?php
return apply_filters(
	'wiloke-listgo-functionality/config/middleware',
	[
		'editListingPendingAllowable'       => 'WilokeListgoFunctionality\Middleware\EditListingPendingAllowable',
		'isUserLoggedIn'                    => 'WilokeListgoFunctionality\Middleware\IsUserLoggedIn',
		'planExists'                        => 'WilokeListgoFunctionality\Middleware\AddListingPlanExistsMiddleware',
		'userBanned'                        => 'WilokeListgoFunctionality\Middleware\UserBannedMiddleware',
		'role'                              => 'WilokeListgoFunctionality\Middleware\RoleMiddleware',
		'upload'                            => 'WilokeListgoFunctionality\Middleware\UploadMiddleware',
		'ggRecaptcha'                       => 'WilokeListgoFunctionality\Middleware\GGRecaptchaMiddleware',
		'isAddListingPlanInCustomerPlan'    => 'WilokeListgoFunctionality\Middleware\IsAddListingPlanInCustomerPlans',
		'validateAddListing'                => 'WilokeListgoFunctionality\Middleware\ValidateAddListing',
		'addListingPlanPermission'          => 'WilokeListgoFunctionality\Middleware\AddListingPlanPermissionMiddleware',
		'outStandingBalance'                => 'WilokeListgoFunctionality\Middleware\OutstandingBalanceMiddleware',
		'avoidChangeToCurrentPlan'          => 'WilokeListgoFunctionality\Middleware\AvoidChangeToCurrentPlan',
		'avoidDowngradeToFreePlan'          => 'WilokeListgoFunctionality\Middleware\AvoidDowngradeToFreePlanMiddleware',
		'validateCardInfoMiddleware'        => 'WilokeListgoFunctionality\Middleware\ValidateCardInfoMiddleware',
		'isPostAuthor'                      => 'WilokeListgoFunctionality\Middleware\IsPostAuthorMiddleware',
		'UpdateSessionPermission'           => 'WilokeListgoFunctionality\Middleware\UpdateSessionPermissionMiddleware',
		'isEventExpired'                    => 'WilokeListgoFunctionality\Middleware\IsEventExpiredMiddleWare',
		'validateEventPlan'                 => 'WilokeListgoFunctionality\Middleware\ValidateEventPlanMiddleware',
		'validateEventsAtts'                => 'WilokeListgoFunctionality\Middleware\ValidateEventsAttsMiddleware',
		'validateBankTransferStatus'        => 'WilokeListgoFunctionality\Middleware\ValidateBankTransferStatusMiddleware',
		'isAvailableFreePlan'               => 'WilokeListgoFunctionality\Middleware\IsAvailableFreePlanMiddleware',
		'isPublishingPost'                  => 'WilokeListgoFunctionality\Middleware\IsPublishingPostMiddleware'
	]
);