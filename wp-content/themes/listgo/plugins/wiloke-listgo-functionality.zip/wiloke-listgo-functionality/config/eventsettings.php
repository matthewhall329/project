<?php
return array(
	'toggleEventOnCarousel' => 'toggle_show_events_on_event_carousel',
	'toggleEventOnListing'  => 'toggle_show_events_on_event_listing',
	'toggleEventOnWidget'   => 'toggle_show_events_on_event_widget',
	'eventStart'            => 'wiloke_listgo_event_start',
	'eventEnded'            => 'wiloke_listgo_event_ended'
);