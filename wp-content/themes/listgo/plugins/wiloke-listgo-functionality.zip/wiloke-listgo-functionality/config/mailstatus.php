<?php
return [
	'type' => array(
		'requestClaimStatus'=> 'requestClaimStatus',
		'postsExpired'     => 'postsExpired',
		'sessionCreated'   => 'sessionCreated',
		'sessionsExpired'  => 'sessionsExpired',
		'paymentSucceeded' => 'paymentSucceeded',
		'sessionFailed'    => 'sessionFailed',
		'sessionProcessing'=> 'sessionProcessing',
		'sessionCancelled' => 'sessionCancelled',
		'sessionSucceeded' => 'sessionSucceeded',
		'sessionSuspended' => 'sessionSuspended',
		'sessionStatus'    => 'sessionStatus',
		'reviewStatus'     => 'reviewStatus',
		'submittedPost'    => 'submittedPost',
		'postApproved'     => 'postApproved',
		'deletedEvents'    => 'deletedEvents',
		'expiredEvents'    => 'expiredEvents',
		'userClaimedListing' => 'userClaimedListing',
		'claimStatus'       => 'claimStatus',
		'banktransferProcessing' => 'banktransferProcessing'
	)
];