<?php
namespace WilokeListgoFunctionality\Helpers;


class Helpers{
	public static function addParamToLink($link, $aParams){
		$params = '';
		foreach ( $aParams as $key => $val ){
			$params .= $key . "=" . $val . "&amp;";
		}

		if ( strpos($link, '?') !== false ){
			$link .= "&amp;". $params;
		}else{
			$link .= '?' .  $params;
		}

		$link = trim($link,"&amp;");

		return $link;
	}
}