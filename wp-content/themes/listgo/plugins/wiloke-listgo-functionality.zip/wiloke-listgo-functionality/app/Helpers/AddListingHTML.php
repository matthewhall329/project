<?php

namespace WilokeListgoFunctionality\Helpers;


class AddListingHTML {
    public static function printRequired($aFieldSettings){
	    if( !isset($aFieldSettings['isRequired']) || ($aFieldSettings['isRequired'] == 'false') ){
            return '';
        }
        ?>
        <sup>*</sup>
        <?php
    }

    public static function renderLabelAndDesc($fieldKey, $aFieldSettings){
	    if ( !empty($aFieldSettings['title']) ) : ?>
            <label class="label" for="<?php echo esc_attr($fieldKey); ?>"><?php echo esc_html($aFieldSettings['title']); ?> <?php self::printRequired($aFieldSettings); ?></label>
	    <?php endif; ?>
        <?php if ( !empty($aFieldSettings['description']) ) : ?>
            <div class="description"><?php \Wiloke::wiloke_kses_simple_html($aFieldSettings['description']); ?></div>
	    <?php endif;
    }

    public static function printRequiredAttribute($aFieldSettings){
	    if( !isset($aFieldSettings['isRequired']) || ($aFieldSettings['isRequired'] == 'false') ){
		    return '';
	    }
	    echo 'required';
    }

	public static function printMultipleAttribute($aFieldSettings){
		if( !isset($aFieldSettings['isMultiple']) || ($aFieldSettings['isMultiple'] == 'false') ){
			return '';
		}
		echo 'multiple';
	}

	public static function textField($fieldKey, $aFieldSettings){
	    $class = isset($aFieldSettings['class']) ? 'form-item '.$aFieldSettings['class'] : 'form-item';
		?>
		<div class="<?php echo esc_attr($class); ?>">
			<?php if ( isset($aFieldSettings['title']) && !empty($aFieldSettings['title']) ) : ?>
			<label for="<?php echo esc_attr($fieldKey); ?>" class="label"><?php echo esc_html($aFieldSettings['title']); ?> <?php self::printRequired($aFieldSettings); ?></label>
			<?php endif; ?>
			<?php if ( isset($aFieldSettings['description']) && !empty($aFieldSettings['description']) ) : ?>
            <div class="description"><?php echo esc_html($aFieldSettings['description']); ?></div>
			<?php endif; ?>
			<span class="input-text active">
                <input placeholder="<?php echo isset($aFieldSettings['placeholder']) ? esc_attr($aFieldSettings['placeholder']) : ''; ?>" id="<?php echo esc_attr($fieldKey); ?>" type="text" name="<?php echo esc_attr($fieldKey); ?>" value="<?php echo esc_attr($aFieldSettings['value']); ?>" <?php self::printRequiredAttribute($aFieldSettings); ?>>
            </span>
		</div>
		<?php
	}

	public static function checkboxField($fieldKey, $aFieldSettings){
		$class = isset($aFieldSettings['class']) ? 'form-item '.$aFieldSettings['class'] : 'form-item';
		?>
        <div class="<?php echo esc_attr($class); ?>">
			<?php if ( isset($aFieldSettings['title']) && !empty($aFieldSettings['title']) ) : ?>
                <label for="<?php echo esc_attr($fieldKey); ?>" class="label"><?php echo esc_html($aFieldSettings['title']); ?> <?php self::printRequired($aFieldSettings); ?></label>
			<?php endif; ?>
			<?php if ( isset($aFieldSettings['description']) && !empty($aFieldSettings['description']) ) : ?>
                <div class="description"><?php echo esc_html($aFieldSettings['description']); ?></div>
			<?php endif; ?>
            <span class="input-text active">
                <input id="<?php echo esc_attr($fieldKey); ?>" type="checkbox" name="<?php echo esc_attr($fieldKey); ?>" value="1" <?php checked($aFieldSettings['value'], 1); ?>>
            </span>
        </div>
		<?php
	}

	public static function textereaField($fieldKey, $aFieldSettings){
		$class = isset($aFieldSettings['class']) ? 'form-item '.$aFieldSettings['class'] : 'form-item';
		?>
        <div class="<?php echo esc_attr($class); ?>">
			<?php self::renderLabelAndDesc($fieldKey, $aFieldSettings); ?>
            <span class="input-text">
                <textarea name="<?php echo esc_attr($fieldKey); ?>" id="<?php echo esc_attr($fieldKey); ?>" rows="4" cols="10" placeholder="<?php echo esc_attr($aFieldSettings['placeholder']); ?>"><?php echo esc_textarea($aFieldSettings['value']); ?></textarea>
            </span>
        </div>
		<?php
	}

	public static function selectField($fieldKey, $aFieldSettings){
		$class = isset($aFieldSettings['class']) ? 'form-item ' . $aFieldSettings['class'] : 'form-item';
		?>
        <div class="<?php echo esc_attr($class); ?>">
	        <?php if ( isset($aFieldSettings['title']) && !empty($aFieldSettings['title']) ) : ?>
            <label for="<?php echo esc_attr($fieldKey); ?>" class="label"><?php echo esc_html($aFieldSettings['title']); ?> <?php self::printRequired($aFieldSettings); ?></label>
	        <?php endif; ?>
            <span>
                <select id="<?php echo esc_attr($fieldKey); ?>" name="<?php echo esc_attr($fieldKey); ?>">
                    <?php foreach ( $aFieldSettings['options'] as $key => $val ): ?>
                    <option value="<?php echo esc_attr($key); ?>" <?php selected($aFieldSettings['value'], $key); ?>><?php echo esc_html($val); ?></option>
                    <?php endforeach; ?>
                </select>
            </span>
        </div>
		<?php
	}

	public static function selectTwoField($fieldKey, $aFieldSettings){
	    $class = 'form-item';

	    if ( isset($aFieldSettings['isMultiple']) && $aFieldSettings['isMultiple'] ){
		    $fieldKey =  $fieldKey . '[]';
        }

	    $class .= isset($aFieldSettings['class']) ? ' ' . $aFieldSettings['class'] : '';
	    ?>
        <div class="<?php echo esc_attr($class); ?>">
		    <?php if ( isset($aFieldSettings['title']) && !empty($aFieldSettings['title']) ) : ?>
            <label for="<?php echo esc_attr($fieldKey); ?>" class="label"><?php echo esc_attr($aFieldSettings['title']); ?> <?php self::printRequired($aFieldSettings); ?></label>
            <?php endif; ?>
	        <?php if ( isset($aFieldSettings['description']) && !empty($aFieldSettings['description']) ) : ?>
            <div class="description"><?php echo esc_html($aFieldSettings['description']); ?></div>
	        <?php endif; ?>
            <span class="input-select2">
                <select id="<?php echo esc_attr($fieldKey); ?>" name="<?php echo esc_attr($fieldKey); ?>" data-placeholder="<?php echo esc_attr($aFieldSettings['description']); ?>" <?php self::printRequiredAttribute($aFieldSettings); ?> <?php self::printMultipleAttribute($aFieldSettings);?> data-maximum-selection="<?php echo isset($aFieldSettings['maximumSelection']) ? esc_attr($aFieldSettings['maximumSelection']) : 1000; ?>">
                    <?php
                    foreach ( $aFieldSettings['options'] as $val => $name ) :
                        $selected = '';
                        if ( !empty($aFieldSettings['value']) && in_array($val, $aFieldSettings['value']) ){
                            $selected = 'selected';
                        }
                        ?>
                        <option value="<?php echo esc_attr($val) ?>" <?php echo esc_attr($selected); ?>><?php echo esc_html($name); ?></option>
                        <?php
                    endforeach;
                    ?>
                </select>
            </span>
        </div>
        <?php
    }

	public static function googleAddress($aFieldSettings){
		?>
        <div class="form-item add-listing-input-location">
    		<?php if ( isset($aFieldSettings['title']) && !empty($aFieldSettings['title']) ) : ?>
            <label for="wiloke-latlong" class="label"><?php echo esc_html($aFieldSettings['title']); ?><?php self::printRequired($aFieldSettings); ?></label>
            <?php endif; ?>
	        <?php if ( isset($aFieldSettings['description']) && !empty($aFieldSettings['description']) ) : ?>
            <div class="description"><?php echo esc_html($aFieldSettings['description']); ?></div>
	        <?php endif; ?>
            <div class="wiloke-latlongwrapper input-text input-icon-inside">
                <input id="wiloke-location" type="text" class="text" placeholder="<?php echo esc_attr($aFieldSettings['placeholder']); ?>" name="listing_address" value="<?php echo !empty($aFieldSettings['value']) ? esc_attr($aFieldSettings['value']['location']) : ''; ?>" <?php self::printRequiredAttribute($aFieldSettings); ?>>
                <i id="wiloke-fill-my-location" class="input-icon fa fa-crosshairs"></i>
                <input id="wiloke-latlong" type="hidden" name="listing_latlng" value="<?php echo !empty($aFieldSettings['value']) ? esc_attr($aFieldSettings['value']['latlong']) : ''; ?>" <?php self::printRequiredAttribute($aFieldSettings); ?>>
                <input id="wiloke-place-information" type="hidden" name="listing_place_information" <?php self::printRequiredAttribute($aFieldSettings); ?>>
            </div>
        </div>
		<?php
	}

    public static function uploadFeaturedImg($aFieldSettings){
	    if ( is_user_logged_in() ) :
        ?>
            <div class="form-item">
                <!-- Featured Image And Header Image -->
                <?php self::renderLabelAndDesc('featured_image', $aFieldSettings); ?>
                <div class="add-listing__upload-img add-listing__upload-single wiloke-add-featured-image">
                    <div class="add-listing__upload-preview" style="<?php if (!empty($aFieldSettings['url'])){?>background-image: url(<?php echo esc_url($aFieldSettings['url']); ?>)<?php }; ?>">
                        <span class="add-listing__upload-placeholder"><i class="icon_image"></i><span class="add-listing__upload-placeholder-title"><?php esc_html_e('Featured Image', 'wiloke'); ?></span></span>
                    </div>
                    <input type="hidden" id="wiloke_feature_image" class="wiloke-insert-id" name="featured_image" value="<?php echo esc_attr($aFieldSettings['value']); ?>">
                </div>
            </div>
	    <?php else : ?>
            <div class="form-item upload-file">
	            <?php self::renderLabelAndDesc('featured_image', $aFieldSettings); ?>
                <div id="wiloke-show-featured-image" class="wil-addlisting-gallery single-upload">
                    <ul class="wil-addlisting-gallery__list"></ul>
                </div>
                <label class="input-upload-file">
                    <input type="hidden" id="wiloke_feature_image" class="wiloke-insert-id" name="featured_image" value="">
                    <input id="wiloke-upload-feature-image" class="wiloke-simple-upload wiloke_feature_image" name="wiloke_raw_featured_image" type="file" value="">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17"><path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"></path></svg>
                    <span><?php echo esc_attr($aFieldSettings['title']); ?></span>
                </label>
                <span class="input-text wiloke-submission-reminder"><?php echo esc_html__('The image size should smaller or equal ', 'wiloke') . \WilokePublic::getMaxFileSize(); ?></span>
            </div>
	    <?php
        endif;
    }

	public static function uploadImages($fieldKey, $aFieldSettings){
        $rawField = $fieldKey . '_raw';
	    if ( isset($aFieldSettings['isMultiple']) && $aFieldSettings['isMultiple']   ){
		    $uploadMode = 'multiple-upload';
		    $btnName = esc_html__('Upload Gallery', 'wiloke');
		    $rawField .= '[]';
        }else{
		    $uploadMode = 'single-upload';
		    $btnName = esc_html__('Upload Image', 'wiloke');
        }
		if ( is_user_logged_in() ) :
    ?>
        <div class="form-item upload-file">
            <?php self::renderLabelAndDesc($fieldKey, $aFieldSettings); ?>
            <div class="wil-addlisting-gallery">
                <ul class="wil-addlisting-gallery__list <?php echo esc_attr($uploadMode); ?>">
                    <?php
                    if ( isset($aFieldSettings['value']) && !empty($aFieldSettings['value']) ) :
                        if ( !is_array($aFieldSettings['value']) ){
                            $aImgIds = array($aFieldSettings['value']);
                        }else{
                            $aImgIds = $aFieldSettings['value'];
                        }
                        foreach ($aImgIds as $imgID) :
                    ?>
                        <li data-id="<?php echo esc_attr($imgID); ?>" class="bg-scroll gallery-item" style="background-image: url(<?php echo esc_url(wp_get_attachment_image_url($imgID, 'thumbnail')) ?>);">
                            <span class="wil-addlisting-gallery__list-remove"><?php esc_html_e('Remove', 'wiloke'); ?></span>
                        </li>
                    <?php
                        endforeach;
                    endif;
                    ?>
                    <li class="wil-addlisting-gallery__placeholder" title="<?php echo esc_html($btnName); ?>">
                        <button class="wiloke-upload-image" data-uploadmode="<?php echo esc_attr($uploadMode); ?>"><i class="icon_images"></i></button>
                    </li>
                </ul>
            </div>
            <input type="hidden" id="<?php echo esc_attr($fieldKey); ?>" class="wiloke-insert-id wiloke-gallery-ids" name="<?php echo esc_attr($fieldKey); ?>" value="<?php echo is_array($aFieldSettings['value']) ? implode(',', $aFieldSettings['value']) : ''; ?>">
        </div>
		<?php else : ?>
        <div id="<?php echo esc_attr(uniqid('wiloke-image-images-')); ?>" class="form-item upload-file">
	        <?php self::renderLabelAndDesc($fieldKey, $aFieldSettings); ?>
            <div class="wil-addlisting-gallery <?php echo esc_attr($uploadMode); ?>">
                <ul class="wil-addlisting-gallery__list wiloke-show-images"></ul>
            </div>
            <label class="input-upload-file">
                <input type="hidden" class="wiloke-insert-id wiloke-gallery-ids" name="<?php echo esc_attr($fieldKey); ?>" value="">
                <input class="wiloke-simple-upload" data-uploadmode="<?php echo esc_attr($uploadMode); ?>" id="<?php echo esc_attr($fieldKey); ?>" name="<?php echo esc_attr($rawField); ?>" type="file" value="" <?php self::printRequiredAttribute($aFieldSettings); ?> <?php self::printMultipleAttribute($aFieldSettings); ?>>
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17"><path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"></path></svg>
                <span><?php echo esc_html($btnName); ?></span>
            </label>
            <span class="input-text wiloke-submission-reminder"><?php echo esc_html__('The image size should smaller or equal to ', 'wiloke') . \WilokePublic::getMaxFileSize(); ?></span>
        </div>
		<?php
        endif;
    }

    public static function wpEditor($fieldKey, $aFieldSettings, $isEnableMediaBtn=true){
	    ?>
        <div class="form-item">
            <?php self::renderLabelAndDesc($fieldKey, $aFieldSettings); ?>
            <span class="input-text">
                <?php wp_editor($aFieldSettings['value'], $fieldKey, array(
	                'tinymce' => array(
		                'content_css' => WP_PLUGIN_URL . '/wiloke-listgo-functionality/public/source/css/placeholder-editor.css'
	                ),
                    'media_buttons' => $isEnableMediaBtn
                )); ?>
            </span>
        </div>
        <?php
    }
}