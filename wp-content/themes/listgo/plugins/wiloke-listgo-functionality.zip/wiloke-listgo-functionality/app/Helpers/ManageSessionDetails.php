<?php
namespace WilokeListgoFunctionality\Helpers;


class ManageSessionDetails {
	public static function isAllowChangingPlan($nextBillingDate, $aDetails){
		$isAllow = isset($nextBillingDate) || ( isset($nextBillingDate) && !empty($nextBillingDate) );
		$isAllow = apply_filters('wiloke-submission/app/Helpers/isAllowChangingPlan', $isAllow, $aDetails);

		return $isAllow;
	}
}