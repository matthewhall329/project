<?php
namespace WilokeListgoFunctionality\Helpers;


class View {
	public static $folder;
	public static $fileName;
	public static $fileInfo;
	public static $path;
	public static $baseDir;

	public static function parse(){
		if ( strpos(self::$fileInfo, '@') != false ){
			$aParse = explode('@', self::$fileInfo);
			self::$fileName = $aParse[1] . '.php';
			self::$folder = $aParse[0];

			self::$path = self::$folder . '/' . self::$fileName;
		}else{
			self::$fileName = self::$fileInfo . '.php';
			self::$path = self::$fileName;
		}
	}

	public static function path($fileInfo){
		self::$fileInfo = $fileInfo;
		self::parse();

		return self::$baseDir. 'views/' . self::$path;
	}

	public static function url($fileInfo){
		self::$fileInfo = $fileInfo;
		self::parse();

		return WILOKE_LISTGO_FUNC_URL . 'views/' . self::$path;
	}

	public static function inc($fileInfo, array $aArgs){
		extract($aArgs);
		self::$baseDir = isset($baseDir) ? $baseDir : WILOKE_LISTGO_FUNC_PATH;
		$path = self::path($fileInfo);
		include $path;
	}
}