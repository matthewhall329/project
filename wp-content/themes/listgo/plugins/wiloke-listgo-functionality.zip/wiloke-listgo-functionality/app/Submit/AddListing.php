<?php
/**
 * This class cares everything relate to Submit Listing
 *
 * @since 1.0
 * @author wiloke
 * @package Wiloke/Themes
 * @subpackage Listgo
 * @link https://wiloke.com
 */
namespace WilokeListgoFunctionality\Submit;


use WilokeListgoFunctionality\Email\SendMail;
use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use WilokeListgoFunctionality\Framework\Store\Session;
use WilokeListgoFunctionality\Register\RegisterWilokeSubmission;
use WilokeListgoFunctionality\Frontend\FrontendListingManagement;
use WilokeListgoFunctionality\Model\AddListing as AddListingModel;
use WilokeListgoFunctionality\Framework\Helpers\DebugStatus;

class AddListing{
	public static $listingIDSessionKey = 'wiloke_listgo_listing_id';
	public static $aListingStatuses = array('renew', 'pending', 'expired', 'processing');
	public static $postType = 'listing';
	public static $packageIDOfListing = 'wiloke_listgo_package_id_of_listing';
	public $aTermAllows = array('listing_location', 'listing_cat', 'listing_tag');
	protected $_allowSize = 0;
	public $sessisonSubmittedStatus = 'wiloke_submission_submitted_at';
	public static $termCreatedByKey = 'wiloke_location_created_by';
	private $aParsePlaceInfo = array();
	private $aCountry = array();
	private $oLocation = array();
	private $locationID = null;
	private $parentLocationID = -1;
	private $countryLocationID = -1;
	private $administratorLevel1 = null;
	public $aData = array();
	public $listingID = null;
	public $placeID = null;
	private $menuOrder = 1;
	private $_userID = null;


	public function __construct() {
		add_action('admin_init', array($this, 'redirectWilokeSubmissionToFrontEnd'), 10, 1);
		add_action('wiloke/wiloke_submission/afterUpdated', array($this, 'afterUpdatedClaimListing'), 10, 2);
		add_action('wiloke/listgo/single-listing/after_related_post', array($this, 'renderPaymentEndEditButton'), 10, 1);
		add_action('wiloke/listgo/wiloke-submission/addlisting/before_listing_information', array($this, 'addOpenTableToListing'), 10, 5);
	}

	public function afterPurchasedListingPlan($aData){
		$aData['listing_ID'] =  \Wiloke::getSession(self::$listingIDSessionKey);
        $oAddListingModel = new AddListingModel();
        $oAddListingModel->updatingPaymentRelationShip($aData);
        $oAddListingModel->updatingListingStatus($aData['listing_ID']);
		\Wiloke::removeSession(self::$listingIDSessionKey);
    }


	public function addOpenTableToListing($postID, $packageID, $aPackageSettings, $aGeneralSettings, $style){
	    if ( isset($aPackageSettings['toggle_open_table']) && ($aPackageSettings['toggle_open_table'] == 'enable') ){
		    include plugin_dir_path(__FILE__) . 'fields/opentable.php';
        }
    }

	public function renderPaymentEndEditButton($post){
        if ( !isset($post->post_status) ){
        	if ( ($post->post_status == 'pending') && !DebugStatus::status('WILOKE_TURNON_VERIFY_CLAIM') ){
        		return '';
        	}
        }
        
        if ( ((Session::getSession(wilokeRepository('sessionkeys:storePostID')) != $post->ID) || !PaymentConfiguration::isAllowEditingPublishedPost()) && ($post->post_status == 'publish')  ){
            return '';
        }

        if ( !empty(\WilokePublic::$oUserInfo->ID) &&  ($post->post_author == \WilokePublic::$oUserInfo->ID) && ((\WilokePublic::$oUserInfo->role === 'wiloke_submission') || current_user_can('edit_theme_options'))  ) :
        ?>
            <div class="listing-single-actions">
                <a href="<?php echo esc_url(apply_filters('wiloke-submission/edit-listing-btn-url', $post->ID)); ?>" class="listgo-btn listgo-btn--sm listgo-btn--round"><i class="fa fa-pencil"></i><span><?php esc_html_e('Edit Listing', 'wiloke'); ?></span></a>
                <a id="wiloke-listgo-submit-listing" data-postid="<?php echo esc_attr($post->ID); ?>" href="#" class="listgo-btn listgo-btn--round listgo-btn--sm btn-primary not-active"><i class="fa fa-send"></i><span><?php esc_html_e('Submit Listing', 'wiloke'); ?></span></a>
            </div>
		<?php
		endif;
    }

	/**
	 * Redirect all Wiloke Submissions to front-end excerpt ajax way
	 * @since 1.0
	 */
	public function redirectWilokeSubmissionToFrontEnd(){
		if ( defined('DOING_AJAX') && DOING_AJAX )
		{
			$isAllowed = true;
		}

		if ( !isset($isAllowed) ){
			$userID = get_current_user_id();
			$oUserData = get_userdata($userID);

			if ( in_array(User::$wilokeSubmissionRole, $oUserData->roles) ){
				$aPaymentSettings = get_option(RegisterWilokeSubmission::$submissionConfigurationKey);
				$aPaymentSettings = !empty($aPaymentSettings) ? json_decode(stripslashes($aPaymentSettings), true) : '';

				if ( isset($aPaymentSettings['myaccount']) ){
						wp_redirect(get_permalink($aPaymentSettings['myaccount']));
					exit();
				}
			}
		}
	}

	/*
	 * After Updated Claim Listing
	 * @since 1.0
	 */
	public function afterUpdatedClaimListing($aData, $userID){
		$this->_userID = $userID;
		$this->aData = $aData;
		if ( \WilokePublic::addLocationBy() == 'default' ){
			$this->insertLocationByDefault($this->aData['post_id']);
		}else{
			$this->insertLocationByGoogle($this->aData['post_id']);
		}
	}
    
	public function convertNameToSlug($slug, $isReplaceDash=false){
		$slug = sanitize_title($slug);
		return $isReplaceDash ? str_replace('-', '', $slug) : $slug;
	}

	private function insertLocationByDefault($postID){
		$listingLocation = absint($this->aData['listing_location_add_listing_location_by_default']);
		if ( term_exists($listingLocation, 'listing_location') ){
			wp_set_post_terms($postID, $listingLocation, 'listing_location');
		}
	}

	protected function findLocationByName($aName){
		$aLocation = get_term_by('slug', $this->convertNameToSlug($aName['long_name']), 'listing_location');
		if ( !empty($aLocation) && !is_wp_error($aLocation) ){
			return $aLocation;
		}

		$aLocation = get_term_by('slug', $this->convertNameToSlug($aName['long_name'], true), 'listing_location');
		if ( !empty($aLocation) && !is_wp_error($aLocation) ){
			return $aLocation;
		}

		$aLocation = get_term_by('slug', $this->convertNameToSlug($aName['short_name']), 'listing_location');
		if ( !empty($aLocation) && !is_wp_error($aLocation) ){
			return $aLocation;
		}

		$aLocation = get_term_by('slug', $this->convertNameToSlug($aName['short_name'], true), 'listing_location');
		if ( !empty($aLocation) && !is_wp_error($aLocation) ){
			return $aLocation;
		}

		return false;
	}

	protected function findLocationByPlaceID($name){
		global $wiloke;
		$url = 'https://maps.googleapis.com/maps/api/place/autocomplete/json?input='.$name.'&types=geocode&key='.$wiloke->aThemeOptions['general_map_api'];

		$aPlaceInfo = wp_remote_get(esc_url_raw($url));

		if ( is_wp_error($aPlaceInfo) ){
			return false;
		}

		$aPlaceInfo = wp_remote_retrieve_body( $aPlaceInfo );
		$aPlaceInfo = json_decode($aPlaceInfo, true);

		if ( !isset($aPlaceInfo['predictions']) || empty($aPlaceInfo['predictions']) ) {
			return false;
		}

		$aTerms = get_terms(array(
			'taxonomy'   => 'listing_location',
			'hide_empty' => false,
			'meta_query' => array(
				array(
					'key'       => 'wiloke_listing_location_place_id',
					'value'     => $aPlaceInfo['predictions'][0]['place_id'],
					'compare'   => '='
				)
			)
		));

		if ( empty($aTerms) || is_wp_error($aTerms) ){
			return false;
		}

		return array(
			'term'      => $aTerms[0],
			'term_id'   => $aTerms[0]->term_id,
			'place_id'  => $aPlaceInfo['body']['predictions'][0]['place_id']
		);
	}

	private function maybeTermCountryExisting(){
		$oParent = get_term_by('slug', $this->convertNameToSlug($this->aCountry['long_name']), 'listing_location');
		if ( !empty($oParent) && !is_wp_error($oParent) ){
			$this->countryLocationID = $oParent->term_id;
			return true;
		}

		$oParent = get_term_by('slug', $this->convertNameToSlug($this->aCountry['long_name'], true), 'listing_location');
		if ( !empty($oParent) && !is_wp_error($oParent) ){
			$this->countryLocationID = $oParent->term_id;
			return true;
		}

		$oParent = get_term_by('slug', $this->convertNameToSlug($this->aCountry['short_name']), 'listing_location');
		if ( !empty($oParent) && !is_wp_error($oParent) ){
			$this->countryLocationID = $oParent->term_id;
			return true;
		}

		$oParent = get_term_by('slug', $this->convertNameToSlug($this->aCountry['short_name'], true), 'listing_location');
		if ( !empty($oParent) && !is_wp_error($oParent) ){
			$this->countryLocationID = $oParent->term_id;
			return true;
		}

		$aParent = $this->findLocationByPlaceID($this->aCountry['long_name']);

		if ( $aParent ){
			$this->countryLocationID = $oParent['term_id'];
			return true;
		}

		return false;
	}

	private function maybeTermParentExisting(){
		$oParent = get_term_by('slug', $this->convertNameToSlug($this->administratorLevel1['long_name']), 'listing_location');
		if ( !empty($oParent) && !is_wp_error($oParent) ){
			$this->parentLocationID = $oParent->term_id;
			return true;
		}

		$oParent = get_term_by('slug', $this->convertNameToSlug($this->administratorLevel1['long_name'], true), 'listing_location');
		if ( !empty($oParent) && !is_wp_error($oParent) ){
			$this->parentLocationID = $oParent->term_id;
			return true;
		}

		$oParent = get_term_by('slug', $this->convertNameToSlug($this->administratorLevel1['short_name']), 'listing_location');
		if ( !empty($oParent) && !is_wp_error($oParent) ){
			$this->parentLocationID = $oParent->term_id;
			return true;
		}

		$oParent = get_term_by('slug', $this->convertNameToSlug($this->administratorLevel1['short_name'], true), 'listing_location');
		if ( !empty($oParent) && !is_wp_error($oParent) ){
			$this->parentLocationID = $oParent->term_id;
			return true;
		}

		$aParent = $this->findLocationByPlaceID($this->administratorLevel1['long_name']);

		if ( $aParent ){
			$this->parentLocationID = $oParent['term_id'];
			return true;
		}

		return false;
	}

	private function parseLocationCategoryName(){
		if ( $this->aParsePlaceInfo['address_components'][0]['types'][0] === 'administrative_area_level_2' ){
			return $this->aParsePlaceInfo['address_components'][0];
		}else{
			foreach ( $this->aParsePlaceInfo['address_components'] as $aPolitical ){
				if ( $aPolitical['types'][0] === 'administrative_area_level_2' ){
					return $aPolitical;
					break;
				}

				if($aPolitical['types'][0] === 'administrative_area_level_1'){
					$this->administratorLevel1 = $aPolitical;
				}
			}
		}

		if ( !empty($this->administratorLevel1) ){
			return $this->administratorLevel1;
		}

		$total = count($this->aParsePlaceInfo['address_components']);
		if ( $total < 3 ){
			return $this->aParsePlaceInfo['address_components'][0];
		}else{
			return $this->aParsePlaceInfo['address_components'][$total-2];
		}
	}

	private function setMenuOrder($packageID){
		if ( empty($packageID) ){
			return 0;
		}
		$aPackageData = \Wiloke::getPostMetaCaching($packageID, 'pricing_settings');
		$price = isset($aPackageData['price']) ? absint($aPackageData['price']) : 0;

		$this->menuOrder = 100000000*($price)*($this->menuOrder);
		return $this->menuOrder;
	}

	private function insertNewTerm($name){
		if ( empty($this->parentLocationID) && !empty($this->administratorLevel1) ){
			$aNewTerm = wp_insert_term( $this->administratorLevel1['long_name'], 'listing_location', array(
				'parent' => $this->countryLocationID
			));
			$this->parentLocationID = $aNewTerm['term_id'];
		}

		$aNewTerm = wp_insert_term( $name, 'listing_location', array(
			'parent' => $this->parentLocationID
		));
		$this->locationID = $aNewTerm['term_id'];

		\Wiloke::updateOption('_wiloke_cat_settings_'.$this->locationID, array(
			'placeid' => $this->placeID,
            'timezone'=> $this->getTimeZoneByGoogleAPI($this->aData['listing_latlng'])
		));
		update_term_meta($this->locationID, self::$termCreatedByKey, $this->_userID);
		update_term_meta($this->locationID, 'wiloke_listing_location_place_id', $this->placeID);
		update_term_meta($this->locationID, 'wiloke_listing_location_place_id', $this->placeID);
	}

	public function detectCountry($aData){
		$total = count($aData);

		for ( $order = absint($total - 2); $order >= 0; $order-- ){
			if ( $aData[$order]['types'][0] === 'country' ){
				$this->aCountry = $aData[$order];
				break;
			}
		}
	}

	protected function getTimeZoneByGoogleAPI($latLng){
	    global $wiloke;
		$aTimeZone = wp_remote_get(esc_url_raw('https://maps.googleapis.com/maps/api/timezone/json?location='.$latLng.'&timestamp='.time().'&key='.$wiloke->aThemeOptions['general_map_api']));
		if ( is_wp_error($aTimeZone)  ){
			return '';
		}else{
			$oTimeZone = json_decode($aTimeZone['body']);
			return $oTimeZone->timeZoneId;
		}
    }

	private function insertLocationByGoogle($postID){
		if ( !isset($this->aData['listing_place_information']) || empty($this->aData['listing_place_information']) ){
			return false;
		}

		$this->aParsePlaceInfo = base64_decode($this->aData['listing_place_information']);

		if ( empty($this->aParsePlaceInfo) ){
			return false;
		}

		$this->aParsePlaceInfo = json_decode($this->aParsePlaceInfo, true);
		$aLocation = $this->parseLocationCategoryName();

		if ( !empty($this->administratorLevel1) && $this->administratorLevel1['long_name'] == $aLocation['long_name'] ){
			$this->administratorLevel1 = null;
		}

		$oLocationExist = $this->findLocationByName($aLocation);
		$this->aCountry = end($this->aParsePlaceInfo['address_components']);
		if ( $this->aCountry['types'][0] !== 'country' ){
			$this->detectCountry($this->aParsePlaceInfo['address_components']);
		}

		if ( !$oLocationExist ){
			$oLocationExist = $this->findLocationByPlaceID($aLocation['long_name']);
			if ( !$oLocationExist ){
				if ( !empty($this->administratorLevel1) ){
					$this->maybeTermParentExisting();
				}

				if ( !empty($this->aCountry) ){
					$this->maybeTermCountryExisting();
				}

				if ( !empty($aLocation['long_name']) ){
					$this->insertNewTerm($aLocation['long_name']);
				}
			}else{
				$this->aLocation  = $oLocationExist['term'];
				$this->locationID = $oLocationExist['term_id'];
				$this->placeID    = $oLocationExist['place_id'];
			}
		}else{
			$this->oLocation = $oLocationExist;
			$this->locationID = $oLocationExist->term_id;
		}

		if ( !empty($this->locationID) ){
			wp_set_post_terms($postID, $this->locationID, 'listing_location');
		}
		return true;
	}

	protected function allowRenderingTarget($target){
		$aAuthorMeta = \Wiloke::getUserMeta(get_current_user_id());
		if ( $aAuthorMeta['role'] == 'wiloke_submission' ){
			$aPackageSettings = \Wiloke::getPostMetaCaching($this->aData['package_id'], 'pricing_settings');
			if ( isset($aPackageSettings[$target]) && $aPackageSettings[$target] == 'disable' ){
				return false;
			}
		}

		return true;
	}

	public static function isEditingPublishedListing($postID){
		if ( empty($postID) ){
			return false;
		}

		if ( get_post_field('post_status', $postID) !== 'publish' ){
			return false;
		}

		if ( current_user_can('edit_theme_options') ){
		    return true;
        }

		if ( get_post_field('post_author', $postID) != get_current_user_id() ){
			return false;
		}

		if ( !FrontendListingManagement::publishedListingEditable() ){
			return false;
		}

		return true;
	}

	public static function allowAddingListing(){
		if ( !current_user_can('edit_theme_options') && ( \WilokePublic::$oUserInfo->role != User::$wilokeSubmissionRole ) ){
		    return false;
        }

	    $aPaymentSettings = \WilokePublic::getPaymentField();

		if ( isset($aPaymentSettings['toggle']) && ($aPaymentSettings['toggle'] == 'enable') ) {
            return true;
        }

        return false;
    }

    public static function getImgPreview($previewName){
        $directoryUrl = apply_filters('wiloke/wiloke-listgo-functionality/app/submit/preview_uri', get_template_directory_uri() . '/img/preview/');
        return $directoryUrl . $previewName;
    }

	public static function packageAllow(){
		$packageID = trim($_REQUEST['package_id']);
		$packageID = apply_filters('wiloke/wiloke-listgo-functionality/App/Submit/Add/packageAllow/packageID', $packageID);
		$aPackageSettings = \Wiloke::getPostMetaCaching($packageID, 'pricing_settings');
		return $aPackageSettings;
	}
}