<?php
namespace WilokeListgoFunctionality\Register;


use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
use WilokeListgoFunctionality\Framework\Helpers\SetSettings;

class RegisterEmailNotificationSubMenu implements RegisterInterface {
	use WilokeSubmissionConfiguration;
	public $emailNotificationSlug = 'email-notification';
	protected $aSubscriptions = array();
	protected $optionKey = 'wiloke_submission_email_notifications';

	public function __construct() {
		add_action('admin_menu', array($this, 'register'), 20);
		add_action('admin_enqueue_scripts', array($this, 'enqueueScripts'));
		add_action('admin_init', array($this, 'setupDefault'));
	}

	public function enqueueScripts($hook){
		$this->parentEnqueueScripts($hook);

		if ( strpos($hook, $this->emailNotificationSlug) ){
			wp_dequeue_script('semantic-selection-ui');
			wp_enqueue_style('semantic-ui', plugin_dir_url(__FILE__) . '../../admin/assets/semantic-ui/form.min.css');
			wp_enqueue_script('semantic-ui', plugin_dir_url(__FILE__) . '../../admin/assets/semantic-ui/semantic.min.js', array('jquery'), WILOKE_LISTGO_FC_VERSION, true);
		}
	}

	public function register() {
		add_submenu_page($this->parentSlug, esc_html__('Email Notification', 'wiloke'), esc_html__('Email Notification', 'wiloke'), 'administrator', $this->emailNotificationSlug, array($this, 'emailNotification'));
	}

	public function setupDefault(){
		$aData = GetSettings::getOptions($this->optionKey);
		if ( !empty($aData) ){
		    return false;
        }

		$aDefault = array();
		foreach ( wilokeRepository('mailnotifications') as $aField ){
			if ( !isset($aField['name']) ){
				continue;
			}

			$name = str_replace(array('wiloke_submission_email_notifications', '[', ']'), array('', '', ''), $aField['name']);
			$aDefault[$name] = isset($aField['default']) ? $aField['default'] : '';
		}
		SetSettings::setOptions($this->optionKey, $aDefault);
    }

	protected function save(){
        if ( !current_user_can('edit_theme_options') ){
            return false;
        }

		if ( !isset($_POST['wiloke_submission_email_notifications']) || empty($_POST['wiloke_submission_email_notifications']) ){
            return false;
		}

		SetSettings::setOptions($this->optionKey, $_POST['wiloke_submission_email_notifications']);
    }

	public function emailNotification(){
		$this->save();
		$aData = GetSettings::getOptions($this->optionKey);
		?>
		<div id="wiloke-submission-wrapper" class="wrap">
			<form class="form ui" action="<?php echo esc_url(admin_url('admin.php?page='.$this->emailNotificationSlug)); ?>" method="POST">
				<?php
				\WilokeHtmlHelper::semantic_render_desc_field(
					array(
						'desc_id' => 'wiloke-submission-message-after-addnew',
						'desc'    => '',
						'status'  => 'error hidden'
					)
				);

				wp_nonce_field('wiloke_add_new_order_action', 'wiloke_add_new_order_nonce');
				foreach ( wilokeRepository('mailnotifications') as $aField ){
					if ( $aField['type'] == 'password' || $aField['type'] == 'text' || $aField['type'] == 'select_post' || $aField['type'] == 'select_ui' || $aField['type'] == 'select' || $aField['type'] == 'textarea' ){
						$name = str_replace(array('wiloke_submission_email_notifications', '[', ']'), array('', '', ''), $aField['name']);
						$aField['value'] = isset($aData[$name]) ? $aData[$name] : $aField['default'];
					}

					switch ($aField['type']){
						case 'open_segment';
							\WilokeHtmlHelper::semantic_render_open_segment($aField);
							break;
						case 'open_accordion';
							\WilokeHtmlHelper::semantic_render_open_accordion($aField);
							break;
						case 'open_fields_group';
							\WilokeHtmlHelper::semantic_render_open_fields_group($aField);
							break;
						case 'close';
							\WilokeHtmlHelper::semantic_render_close();
							break;
						case 'close_segment';
							\WilokeHtmlHelper::semantic_render_close_segment();
							break;
						case 'password':
							\WilokeHtmlHelper::semantic_render_password_field($aField);
							break;
						case 'text';
							\WilokeHtmlHelper::semantic_render_text_field($aField);
							break;
						case 'select_post';
						case 'select_ui';
							\WilokeHtmlHelper::semantic_render_select_ui_field($aField);
							break;
						case 'select':
							\WilokeHtmlHelper::semantic_render_select_field($aField);
							break;
						case 'textarea':
							\WilokeHtmlHelper::semantic_render_textarea_field($aField);
							break;
						case 'submit':
							\WilokeHtmlHelper::semantic_render_submit($aField);
							break;
						case 'header':
							\WilokeHtmlHelper::semantic_render_header($aField);
							break;
						case 'desc';
							\WilokeHtmlHelper::semantic_render_desc($aField);
							break;
					}
				}
				?>
			</form>
		</div>
		<?php
	}
}