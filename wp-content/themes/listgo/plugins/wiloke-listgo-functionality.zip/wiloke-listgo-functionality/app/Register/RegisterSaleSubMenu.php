<?php
namespace WilokeListgoFunctionality\Register;


use WilokeListgoFunctionality\AlterTable\AlterTableSessions;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;

class RegisterSaleSubMenu implements RegisterInterface {
	use WilokeSubmissionConfiguration;
	public $saleSlug = 'sale';
	protected $aSales = array();

	public function __construct() {
		add_action('admin_menu', array($this, 'register'), 20);
		add_action('admin_enqueue_scripts', array($this, 'enqueueScripts'));
		add_action('wp_ajax_wiloke_submission_export_sales', array($this, 'exportFile'));
	}

	public function exportFile(){
		if ( !current_user_can('edit_posts') ){
			return false;
		}
		$aQuery = json_decode(urldecode($_POST['args']), true);
		$this->fetchSales($aQuery);

		$now = gmdate("D, d M Y H:i:s");
		header("Expires: Tue, 03 Jul 2001 06:00:00 GMT");
		header("Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate");
		header("Last-Modified: {$now} GMT");

		// force download
		header("Content-Type: application/force-download");
		header("Content-Type: application/octet-stream");
		header("Content-Type: application/download");

		// disposition / encoding on response body
		header("Content-Disposition: attachment;filename=wiloke-sales-statistic-".date('Y-m-D') . '.csv');
		header("Content-Transfer-Encoding: binary");
		$csv_header = '';
		$csv_header .= 'ID, Customer Name, Customer Email, Plan Name, Status, Subscription Gateway, Created At' . "\n";
		$csv_row ='';
		foreach ( $this->aSales as $aInfo ){
			$oUser = get_userdata($aInfo['userID']);
			$csv_row .= $aInfo['ID'] . ', ' . $oUser->display_name . ',' . $oUser->user_email . ', ' . get_the_title($aInfo['planID']) . ', ' . $aInfo['status'] . ', ' . $aInfo['created_at'] . "\n";
		}
		echo $csv_header . $csv_row;
		die();
	}

	public function enqueueScripts($hook){
		$this->parentEnqueueScripts($hook);

		if ( strpos($hook, $this->saleSlug) ){
			wp_dequeue_script('semantic-selection-ui');
			wp_enqueue_style('semantic-ui', plugin_dir_url(__FILE__) . '../../admin/assets/semantic-ui/form.min.css');
			wp_enqueue_script('semantic-ui', plugin_dir_url(__FILE__) . '../../admin/assets/semantic-ui/semantic.min.js', array('jquery'), WILOKE_LISTGO_FC_VERSION, true);
		}
	}

	public function register() {
		add_submenu_page($this->parentSlug, esc_html__('Sales', 'wiloke'), esc_html__('Sales', 'wiloke'), 'administrator', $this->saleSlug, array($this, 'showSales'));
	}

	protected function fetchSales($aQuery){
		if ( !current_user_can('edit_posts') ){
			return false;
		}

		global $wpdb;
		$paged = isset($aQuery['paged']) ? $aQuery['paged'] : 1;
		$tblSession = $wpdb->prefix . AlterTableSessions::$tblName;
		$offset = ($paged - 1)*$this->postPerPages;
		$this->postPerPages = isset($aQuery['posts_per_page']) && !empty($aQuery['posts_per_page']) ? $aQuery['posts_per_page'] : $this->postPerPages;

		$sql = "SELECT SQL_CALC_FOUND_ROWS $tblSession.* FROM $tblSession WHERE billing_type='".wilokeRepository('app:billingTypes', true)->sub('nonrecurring')."'";
		$concat = " AND";

		if ( isset($aQuery['package_id']) && $aQuery['package_id'] !== 'any' ){
			$sql .= $concat . " $tblSession.planID=".esc_sql($aQuery['package_id']);
			$aParams[] = $aQuery['package_id'];
			$concat = " AND";
		}

		$additionalQuery = '';
		if ( isset($aQuery['payment_status']) && $aQuery['payment_status'] !== 'any' ){
			$additionalQuery .= $concat . " $tblSession.status='".esc_sql($aQuery['payment_status'])."'";
			$concat = " AND";
		}

		if ( isset($aQuery['gateway']) && ($aQuery['gateway'] != 'all') ){
			$additionalQuery .= $concat . " $tblSession.gateway='".esc_sql($aQuery['gateway'])."'";
			$concat = " AND";
		}

		if ( isset($aQuery['date']) && $aQuery['date'] !== 'any' ){
			if ( $aQuery['date'] === 'this_week' ){
				$additionalQuery .= $concat. " DATE_SUB(CURDATE(), INTERVAL DAYOFWEEK(CURDATE()) DAY) <= $tblSession.created_at";
			}elseif ( $aQuery['date'] === 'this_month' ){
				$additionalQuery .= $concat. " $tblSession.created_at >= DATE_SUB(CURDATE(), INTERVAL DAYOFMONTH(CURDATE()) DAY) ";
			}else{
				if ( empty($aQuery['from']) ){
					$from = date('Y-m-d');
				}else{

					$from = date('Y-m-d', strtotime($aQuery['from']));
				}

				if ( empty($aQuery['to']) ){
					$to = date('Y-m-d');
				}else{
					$to = date('Y-m-d', strtotime($aQuery['to']));
				}
				$additionalQuery .= $concat . " ($tblSession.created_at BETWEEN '".esc_sql($from)."' AND '".esc_sql($to)."')";
			}
		}

		if ( !empty($additionalQuery) ){
			$sql .= $additionalQuery;
		}

		$sql .= " ORDER BY $tblSession.ID DESC LIMIT ".esc_sql($this->postPerPages)." OFFSET ".esc_sql($offset);

		$this->aSales = $wpdb->get_results($sql,ARRAY_A);
		$this->total = $wpdb->get_var("SELECT FOUND_ROWS()");
	}

	public function showSales(){
		$this->fetchSales($_REQUEST);
		$pagination = absint(ceil($this->total/$this->postPerPages));
		$paged = isset($_REQUEST['paged']) && !empty($_REQUEST['paged']) ? absint($_REQUEST['paged']) : 1;
		$aRequest = isset($_REQUEST) ? $_REQUEST : array();
		?>
		<div id="listgo-table-wrapper" style="margin: 30px auto">
			<h2><?php esc_html_e('Sales', 'wiloke'); ?></h2>
			<div class="searchform">
				<form class="form ui" action="<?php echo esc_url(admin_url('admin.php')); ?>" method="GET">
					<div class="equal width fields">
						<input type="hidden" name="paged" value="<?php echo esc_attr($paged); ?>">
						<input type="hidden" name="page" value="<?php echo esc_attr($this->saleSlug); ?>">
						<div class="search-field field">
							<label for="payment_status"><?php esc_html_e('Status', 'wiloke'); ?></label>
							<select id="payment_status" class="ui dropdown" name="payment_status">
								<?php
								foreach (wilokeRepository('app:saleStatus') as $status => $title) :
									$selected = isset($_REQUEST['payment_status']) && $_REQUEST['payment_status'] === $status ? 'selected' : '';
									?>
									<option value="<?php echo esc_attr($status); ?>" <?php echo esc_attr($selected); ?>><?php echo esc_html($title); ?></option>
								<?php endforeach; ?>
							</select>
						</div>
						<div class="search-field field">
							<label for="filter-by-date"><?php esc_html_e('Date', 'wiloke'); ?></label>
							<select id="filter-by-date" class="ui dropdown" name="date">
								<?php foreach ($this->aFilterByDate as $date => $title):
									$selected = isset($_REQUEST['date']) && $_REQUEST['date'] === $date ? 'selected' : '';
									?>
									<option value="<?php echo esc_attr($date); ?>" <?php echo esc_attr($selected); ?>><?php echo esc_html($title); ?></option>
								<?php endforeach; ?>
							</select>
						</div>
						<div id="filter-by-period" class="search-field field">
							<input class="wiloke_datepicker" type="text" name="from" value="" placeholder="<?php echo esc_html_e('Date Start', 'wiloke') ?>">
							<input class="wiloke_datepicker" type="text" name="to" value="" placeholder="<?php echo esc_html_e('Date End', 'wiloke') ?>">
						</div>
						<div class="search-field field">
							<label for="filter-by-gateway"><?php esc_html_e('Gateway', 'wiloke'); ?></label>
							<select id="filter-by-gateway" class="ui dropdown" name="gateway">
								<option value="all"><?php esc_html_e('All', 'wiloke'); ?></option>
								<?php foreach (PaymentConfiguration::getPaymentGateways() as $gateway):
									$selected = isset($_REQUEST['gateway']) && $_REQUEST['gateway'] === $gateway ? 'selected' : '';
									?>
									<option value="<?php echo esc_attr($gateway); ?>" <?php echo esc_attr($selected); ?>><?php echo esc_html($gateway); ?></option>
								<?php endforeach; ?>
							</select>
						</div>
						<div class="search-field field">
							<label for="posts_per_page"><?php esc_html_e('Posts Per Page', 'wiloke'); ?></label>
							<input id="posts_per_page" type="text" name="posts_per_page" value="<?php echo esc_attr($this->postPerPages); ?>">
						</div>
						<div class="search-field field">
							<label for="posts_per_page"><?php esc_html_e('Apply', 'wiloke'); ?></label>
							<input type="submit" class="button ui basic green" value="<?php esc_html_e('Filter', 'wiloke'); ?>">
						</div>
					</div>
				</form>
			</div>

			<table id="listgo-table" class="ui striped table">
				<thead>
				<tr>
					<th class="invoices-id manage-column check-column">#</th>
					<th class="invoices-package manage-column"><?php esc_html_e('Customer', 'wiloke'); ?></th>
					<th class="invoices-package manage-column"><?php esc_html_e('Plan Type', 'wiloke'); ?></th>
					<th class="invoices-package manage-column"><?php esc_html_e('Plan Name', 'wiloke'); ?></th>
					<th class="invoices-package manage-column"><?php esc_html_e('Status', 'wiloke'); ?></th>
					<th class="invoices-package manage-column"><?php esc_html_e('Gateway', 'wiloke'); ?></th>
					<th class="invoices-date manage-column"><?php esc_html_e('Date', 'wiloke'); ?></th>
<!--					<th class="invoices-remove manage-column">--><?php //esc_html_e('Remove', 'wiloke'); ?><!--</th>-->
				</tr>
				</thead>

				<tbody>
				<?php if ( empty($this->aSales) ) : ?>
					<tr><td colspan="7" class="text-center"><strong><?php esc_html_e('There are no subscriptions yet.', 'wiloke'); ?></strong></td></tr>
				<?php else: ?>
					<?php
					foreach ( $this->aSales as  $aSession ) :
						$editLink = admin_url('admin.php') . '?page='.$this->detailSlug.'&sessionID='.$aSession['ID'];
						?>
						<tr class="item">
							<td class="invoices-id check-column manage-column"><a href="<?php echo esc_url($editLink); ?>" title="<?php esc_html_e('View Invoice Detail', 'wiloke'); ?>"><?php echo esc_html($aSession['ID']); ?></a></td>
							<td class="invoices-customer manage-column column-primary" data-colname="<?php esc_html_e('Customer', 'wiloke'); ?>"><a title="<?php esc_html_e('View customer information', 'wiloke'); ?>" href="<?php echo esc_url(admin_url('user-edit.php?user_id='.$aSession['userID'])); ?>"><?php echo esc_html(get_user_meta($aSession['userID'], 'nickname', true)); ?></a></td>
							<td class="invoices-package manage-column" data-colname="<?php esc_html_e('Plan Type', 'wiloke'); ?>"><a href="<?php echo esc_url($editLink); ?>" title="<?php esc_html_e('View Sale Details', 'wiloke'); ?>"><?php echo get_post_field('post_type', $aSession['planID']); ?></a></td>
							<td class="invoices-package manage-column" data-colname="<?php esc_html_e('Plan Name', 'wiloke'); ?>"><a href="<?php echo esc_url($editLink); ?>" title="<?php esc_html_e('View Sale Details', 'wiloke'); ?>"><?php echo get_the_title($aSession['planID']); ?></a></td>
							<td class="invoices-date manage-column" data-colname="<?php esc_html_e('Status', 'wiloke'); ?>"><a href="<?php echo esc_url($editLink); ?>" title="<?php esc_html_e('View Sale Details', 'wiloke'); ?>"><?php echo esc_html($aSession['status']);  ?></a></td>
							<td class="invoices-date manage-column" data-colname="<?php esc_html_e('Gateway', 'wiloke'); ?>"><a href="<?php echo esc_url($editLink); ?>" title="<?php esc_html_e('View Sale Details', 'wiloke'); ?>"><?php echo esc_html($aSession['gateway']);  ?></a></td>
							<td class="invoices-date manage-column" data-colname="<?php esc_html_e('Date', 'wiloke'); ?>"><a href="<?php echo esc_url($editLink); ?>" title="<?php esc_html_e('View Sale Details', 'wiloke'); ?>"><?php echo esc_html($aSession['created_at']);  ?></a></td>
							<td class="invoices-remove manage-column" data-colname="<?php esc_html_e('Remove', 'wiloke'); ?>">
								<a class="js_delete_payment" href="<?php echo esc_url($editLink); ?>" title="<?php esc_html_e('Delete Payment', 'wiloke'); ?>" data-paymentID="<?php echo esc_attr($aSession['ID']); ?>"><?php esc_html_e('Remove', 'wiloke') ?></a>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
				</tbody>

				<?php if ( $pagination !== 1 && $pagination !== 0 ) : ?>
					<tfoot>
					<tr>
						<th colspan="7">
							<div class="ui right floated pagination menu" style="padding-top: 0 !important;">
								<?php for ($i = 1; $i <= $pagination; $i++ ) :
									$actived = $paged === $i ? 'active' : '';
									$aRequest['paged'] = $i;
									$aRequest['page']  = $this->saleSlug;
									$request = '';
									foreach ($aRequest as $key => $val){
										$request .= empty($request) ? $key.'='.$val :  '&'.$key.'='.$val;
									}
									?>
									<a class="<?php echo esc_attr($actived); ?> item" href="<?php echo esc_url(admin_url('admin.php?'.$request)); ?>"><?php echo esc_html($i); ?></a>
								<?php endfor; ?>
							</div>
						</th>
					</tr>
					</tfoot>
				<?php endif; ?>
			</table>

			<?php if ( !empty($this->aSales) ) : ?>
			<div class="ui segment">
<!--				<a class="button ui basic green" href="--><?php //echo esc_url($this->addNewOrder); ?><!--">--><?php //esc_html_e('Add New order', 'wiloke'); ?><!--</a>-->
                <form action="<?php echo esc_url(admin_url('admin-ajax.php')); ?>" method="POST" style="display: inline-block;">
                    <input type="hidden" name="args" value="<?php echo esc_attr(urlencode(json_encode($_REQUEST))); ?>">
                    <input type="hidden" name="action" value="wiloke_submission_export_sales">
                    <button class="js_export button ui basic purple"><?php esc_html_e('Export Payments', 'wiloke'); ?></button>
                </form>
			</div>
			<?php endif; ?>

		</div>
		<?php
	}
}