<?php
namespace WilokeListgoFunctionality\Register;


use WilokeListgoFunctionality\Framework\Payment\Checkout;
use WilokeListgoFunctionality\Framework\Payment\DirectBankTransfer\NonRecurringPaymentMethod;
use WilokeListgoFunctionality\Framework\Payment\DirectBankTransfer\RecurringPaymentMethod;
use WilokeListgoFunctionality\Framework\Payment\DirectBankTransfer\Token;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use WilokeListgoFunctionality\Framework\Payment\Receipt;
use WilokeListgoFunctionality\Model\PaymentModel;

class RegisterAddNewOrder implements RegisterInterface {
	use WilokeSubmissionConfiguration;
	public $addNewSlug = 'addnew-session';
	
	public function __construct() {
		add_action('admin_menu', array($this, 'register'), 20);
		add_action('admin_enqueue_scripts', array($this, 'enqueueScripts'));
		add_action('wp_ajax_wiloke_submission_create_session', array($this, 'createSession'));
	}

	public function createSession(){
	    if ( !current_user_can('administrator') ){
	        wp_send_json_error(
                array(
                     'msg' => esc_html__('You do not have permission to access this page', 'wiloke')
                )
            );
        }

        $aSessionInfo = array();
        foreach ($_POST['data'] as $aData){
	        $aSessionInfo[$aData['name']] = $aData['value'];
        }

        if ( empty($aSessionInfo['planID']) ){
	        wp_send_json_error(
		        array(
			        'msg' => esc_html__('You do not have permission to access this page', 'wiloke')
		        )
	        );
        }

		$aData['token']  = Token::generateToken();
		$aData['planID'] = $aSessionInfo['planID'];
		$instReceipt = new Receipt($aData);

        if ( PaymentConfiguration::isNonRecurringPayment() ){
	        $oPaymentMethod = new NonRecurringPaymentMethod();
	        $billingType = wilokeRepository('app:billingTypes', true)->sub('nonrecurring');
        }else{
	        $oPaymentMethod = new RecurringPaymentMethod();
	        $billingType = wilokeRepository('app:billingTypes', true)->sub('recurring');
        }

		$oPaymentMethod->setFocus(true);
		$oPaymentMethod->userID = $aSessionInfo['customerID'];

		$oCheckout = new Checkout();
		$aPaymentStatus = $oCheckout->begin($instReceipt, $oPaymentMethod);

		if ( $aPaymentStatus['status'] == 'success' ){
			$userIP = get_user_meta($aSessionInfo['customerID'], 'wiloke_user_IP', true);
            if ( empty($userIP) ){
                PaymentModel::updateWhereEqualToID(
                    array(
                        'value' => array(
                            'customer_ip' => $userIP
                        ),
                        'format' => array(
                            '%s'
                        )
                    ),
                    $userIP
                );
            }

            /*
             * @hooked UserController@createUserPlan
             */
            do_action('wiloke/wiloke-submission/manually-add-order', array(
	            'userID'        => $aSessionInfo['customerID'],
	            'sessionID'     => $aPaymentStatus['sessionID'],
	            'planID'        => $aSessionInfo['planID'],
	            'newStatus'     => 'processing',
	            'gateway'       => 'banktransfer',
	            'billingType'   => $billingType
            ));

            wp_send_json_success(
                array(
                    'redirectTo' => urlencode(admin_url('admin.php?page=detail&sessionID='.$aPaymentStatus['sessionID']))
                )
            );
        }else{
		    wp_send_json_error(
                array(
	                'msg' => $aPaymentStatus['msg']
                )
            );
        }
	}

	public function enqueueScripts($hook){
		$this->parentEnqueueScripts($hook);

		if ( strpos($hook, $this->addNewSlug) ){
			wp_dequeue_script('semantic-selection-ui');
			wp_enqueue_style('semantic-ui', plugin_dir_url(__FILE__) . '../../admin/assets/semantic-ui/form.min.css');
			wp_enqueue_script('semantic-ui', plugin_dir_url(__FILE__) . '../../admin/assets/semantic-ui/semantic.min.js', array('jquery'), WILOKE_LISTGO_FC_VERSION, true);
			wp_enqueue_script('session-detail', plugin_dir_url(__FILE__) . '../../admin/js/session-details.js', array('jquery'), WILOKE_LISTGO_FC_VERSION, true);
		}
	}

	public function register() {
		add_submenu_page($this->parentSlug, esc_html__('Add New Order', 'wiloke'), esc_html__('Add New Order', 'wiloke'), 'administrator', $this->addNewSlug, array($this, 'addNewSession'));
	}

	public function addNewSession(){
		?>
		<div id="wiloke-submission-wrapper" class="wrap">
			<form id="wiloke-submission-create-session" class="form ui" action="" method="POST">
				<?php
				\WilokeHtmlHelper::semantic_render_desc_field(
					array(
						'desc_id' => 'wiloke-submission-message-after-update',
						'desc'    => esc_html__('Your update has been successfully', 'wiloke'),
						'status'  => 'success hidden'
					)
				);

				echo '<div class="two fields">';
				$aPlanOptions = PaymentConfiguration::getField('customer_plans');

				if ( empty($aPlanOptions) ){
					\WilokeHtmlHelper::semantic_render_desc_field(
						array(
							'desc'    => esc_html__('You has not configure Customer Plan yet. Please go to Wiloke Submission -> Settings -> Customer Plans to complete this setting.', 'wiloke'),
							'status'  => 'danger'
						)
					);
				}else{
					$aPlanOptions = explode(',', $aPlanOptions);
					$aCustomerPlans = array();
					foreach ($aPlanOptions as $planID){
						$aCustomerPlans[$planID] = get_the_title($planID);
					}
					\WilokeHtmlHelper::semantic_render_select_field(
						array(
							'id'            => 'planID',
							'name'          => 'planID',
							'post_type'     => 'pricing',
							'heading'       => esc_html__('Plan Name', 'wiloke'),
							'options'       => $aCustomerPlans
						)
					);

					\WilokeHtmlHelper::semantic_render_text_field(
						array(
							'id'            => 'gateway',
							'name'          => 'gateway',
							'heading'       => esc_html__('Gateway', 'wiloke'),
							'value'         => 'banktransfer',
							'is_readonly'   => true
						)
					);
				}
				echo '</div>';

				echo '<div class="two fields">';
				\WilokeHtmlHelper::semantic_render_select2_field(
					array(
						'id'            => 'customerID',
						'name'          => 'customerID',
						'heading'       => esc_html__('Customer ID', 'wiloke')
					)
				);

				\WilokeHtmlHelper::semantic_render_text_field(
					array(
						'id'            => 'billing_type',
						'name'          => 'billing_type',
						'heading'       => esc_html__('Billing Type', 'wiloke'),
						'value'         => PaymentConfiguration::getField('billing_type'),
						'is_readonly'   => true
					)
				);
				echo '</div>';

				echo '<div class="field">';
				\WilokeHtmlHelper::semantic_render_submit(
					array(
						'name'       => esc_html__('Submit', 'wiloke'),
						'class'      => 'green'
					)
				);
				echo '</div>';
                ?>
			</form>
		</div>
		<?php
	}
}
