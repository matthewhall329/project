<?php
namespace WilokeListgoFunctionality\Register;


use WilokeListgoFunctionality\AlterTable\AlterTableSessions;
use WilokeListgoFunctionality\Framework\Payment\DirectBankTransfer\DirectBankTransfer;
use WilokeListgoFunctionality\Helpers\ManageSessionDetails;
use WilokeListgoFunctionality\Model\UserModel;

class RegisterSessionDetail implements RegisterInterface {
	use WilokeSubmissionConfiguration;

	public function __construct() {
		add_action('admin_menu', array($this, 'register'), 20);
		add_action('admin_enqueue_scripts', array($this, 'enqueueScripts'));
	}

	public function enqueueScripts($hook){
		$this->parentEnqueueScripts($hook);

		if ( strpos($hook, $this->detailSlug) ){
			wp_dequeue_script('semantic-selection-ui');
			wp_enqueue_style('semantic-ui', plugin_dir_url(__FILE__) . '../../admin/assets/semantic-ui/form.min.css');
			wp_enqueue_script('semantic-ui', plugin_dir_url(__FILE__) . '../../admin/assets/semantic-ui/semantic.min.js', array('jquery'), WILOKE_LISTGO_FC_VERSION, true);
			wp_enqueue_script('session-detail', plugin_dir_url(__FILE__) . '../../admin/js/session-details.js', array('jquery'), WILOKE_LISTGO_FC_VERSION, true);
		}
	}

	public function register() {
		add_submenu_page($this->parentSlug, esc_html__('Session Details', 'wiloke'), esc_html__('Session Details', 'wiloke'), 'administrator', $this->detailSlug, array($this, 'sessionDetailArea'));
	}

	public function sessionDetailArea(){
		global $WilokeListgoFunctionalityApp;
		if ( isset($_GET['type']) && (($_GET['type'] === 'addneworder') || ($_GET['type'] === 'editorder'))  ) :
			if ( $_GET['type'] === 'addneworder' ){
				unset($_SESSION[$this->sessionKey]);
			}

			if ( isset($_REQUEST['payment_ID']) && !empty($_REQUEST['payment_ID']) ){
				$_SESSION[$this->sessionKey] = $_REQUEST['payment_ID'];
			}
			?>
			<div id="wiloke-submission-wrapper" class="wrap">
				<form id="wiloke-submission-add-new-order" class="form ui" action="#" method="POST">
					<?php
					\WilokeHtmlHelper::semantic_render_desc_field(
						array(
							'desc_id' => 'wiloke-submission-message-after-addnew',
							'desc'    => '',
							'status'  => 'error hidden'
						)
					);

					wp_nonce_field('wiloke_add_new_order_action', 'wiloke_add_new_order_nonce');
					foreach ( $WilokeListgoFunctionalityApp['settings']['addneworder']['fields'] as $aField ){
						if ( $aField['type'] == 'text' || $aField['type'] == 'password' || $aField['type'] == 'select_post' || $aField['type'] == 'select_ui' || $aField['type'] == 'select_user' || $aField['type'] == 'select' ){
							$name = str_replace(array('wiloke_submission_order', '[', ']'), array('', '', ''), $aField['name']);
							$aField['value'] = isset($aData[$name]) ? $aData[$name] : $aField['default'];
						}

						switch ($aField['type']){
							case 'open_segment';
								\WilokeHtmlHelper::semantic_render_open_segment($aField);
								break;
							case 'close';
								\WilokeHtmlHelper::semantic_render_close();
								break;
							case 'open_fields_group';
								\WilokeHtmlHelper::semantic_render_open_fields_group($aField);
								break;
							case 'open_accordion';
								\WilokeHtmlHelper::semantic_render_open_accordion($aField);
								break;
							case 'close_segment';
								\WilokeHtmlHelper::semantic_render_close_segment();
								break;
							case 'password':
								\WilokeHtmlHelper::semantic_render_password_field($aField);
								break;
							case 'text';
								\WilokeHtmlHelper::semantic_render_text_field($aField);
								break;
							case 'select_post';
							case 'select_ui';
								\WilokeHtmlHelper::semantic_render_select_ui_field($aField);
								break;
							case 'select_user';
								\WilokeHtmlHelper::semantic_render_select_user_field($aField);
								break;
							case 'select':
								\WilokeHtmlHelper::semantic_render_select_field($aField);
								break;
							case 'submit':
								\WilokeHtmlHelper::semantic_render_submit($aField);
								break;
							case 'desc';
								\WilokeHtmlHelper::semantic_render_desc_field($aField);
								break;
						}
					}
					?>
				</form>
			</div>
			<?php
			return false;
		endif;

		$sessionID = isset($_REQUEST['sessionID']) ? $_REQUEST['sessionID'] : '';
		if ( empty($sessionID) ){
			return false;
		}

		global $wpdb;
		$tblName = $wpdb->prefix . AlterTableSessions::$tblName;

		$aDetails = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $tblName WHERE ID=%d",
				$sessionID
			),
			ARRAY_A
		);
		?>
		<div id="wiloke-submission-wrapper" class="wrap">
<!--			<a class="wiloke-submission-addnew" href="--><?php //echo esc_url($this->addNewOrder); ?><!--">--><?php //esc_html_e('Add New Subscription', 'wiloke'); ?><!--</a>-->
			<?php if ( empty($aDetails) ) : ?>
				<p><?php esc_html_e('This order does not exist', 'wiloke'); ?></p>
				<?php
			else:
				$userID = $aDetails['userID'];
				$oUser = get_userdata($userID);
				?>
				<form id="wiloke-submission-change-customer-order" class="form ui" action="" method="POST">
					<h2 class="ui dividing header"><?php \Wiloke::wiloke_kses_simple_html( sprintf(__('Order #%d details.', 'wiloke'), $aDetails['ID']), false ); ?></h2>
					<?php
					\WilokeHtmlHelper::semantic_render_desc_field(
						array(
							'desc_id' => 'wiloke-submission-message-after-update',
							'desc'    => esc_html__('Your update has been successfully', 'wiloke'),
							'status'  => 'success hidden'
						)
					);

					\WilokeHtmlHelper::render_hidden_field(
						array(
							'name'          => 'sessionID',
							'value'         => $aDetails['ID']
						)
					);
					\WilokeHtmlHelper::render_hidden_field(
						array(
							'name'          => 'planID',
							'value'         => $aDetails['planID']
						)
					);

					?>
                    <h3 class="ui dividing header"><?php esc_html_e( 'Order Information', 'wiloke' ); ?></h3>
                    <?php

                    do_action('wiloke-submission/app/session-detail/after_order_information_open', $aDetails);

					echo '<div class="two fields">';
					\WilokeHtmlHelper::semantic_render_text_field(
						array(
							'id'            => 'planName',
							'name'          => 'planName',
							'post_type'     => get_post_type($aDetails['planID']),
							'heading'       => esc_html__('Plan Name', 'wiloke'),
							'desc'          => sprintf(__('<a href="%s" target="_blank">Click to view plan detail</a>', 'wiloke'), admin_url('post.php?post='.$aDetails['planID'].'&action=edit')),
							'desc_status'   => 'info',
							'value'         => get_the_title($aDetails['planID']),
                            'is_readonly'   => true
						)
					);
					\WilokeHtmlHelper::semantic_render_text_field(
						array(
							'id'            => 'gateway',
							'name'          => 'gateway',
							'heading'       => esc_html__('Gateway', 'wiloke'),
							'value'         => $aDetails['gateway'],
							'is_readonly'   => true
						)
					);
					echo '</div>';

					echo '<div class="two fields">';
					\WilokeHtmlHelper::semantic_render_text_field(
						array(
							'id'            => 'billing_type',
							'name'          => 'billing_type',
							'heading'       => esc_html__('Billing Type', 'wiloke'),
							'value'         => $aDetails['billing_type'],
							'is_readonly'   => true
						)
					);

					\WilokeHtmlHelper::semantic_render_text_field(
						array(
							'id'            => 'customer_ip',
							'name'          => 'customer_ip',
							'heading'       => esc_html__('Customer IP', 'wiloke'),
							'value'         => $aDetails['customer_ip'],
							'is_readonly'   => true
						)
					);
					echo '</div>';

					echo '<div class="two fields">';
					\WilokeHtmlHelper::render_hidden_field(
						array(
							'name'          => 'userID',
							'value'         => $aDetails['userID']
						)
					);

					\WilokeHtmlHelper::semantic_render_text_field(
						array(
							'id'            => 'customer_name',
							'name'          => 'customer_name',
							'heading'       => esc_html__('Customer', 'wiloke'),
							'value'         => $oUser->display_name,
							'is_readonly'   => true,
							'desc_status'   => 'info',
							'desc'          => \Wiloke::wiloke_kses_simple_html(sprintf(__('<a href="%s">Check Customer Information</a>', 'wiloke'), esc_url(admin_url('user-edit.php?user_id='.$userID))), true)
						)
					);

					\WilokeHtmlHelper::semantic_render_text_field(
						array(
							'id'            => 'customer_email',
							'name'          => 'customer_email',
							'heading'       => esc_html__('Customer Email', 'wiloke'),
							'value'         => $oUser->user_email,
							'is_readonly'   => true,
							'desc_status'   => 'info',
							'desc'          => \Wiloke::wiloke_kses_simple_html(sprintf(__('<a href="mailto:%s">Mail to customer</a>', 'wiloke'), esc_url(admin_url('user-edit.php?user_id='.$oUser->user_email))), true)
						)
					);
					echo '</div>';

					echo '<div class="fields two">';
					\WilokeHtmlHelper::semantic_render_text_field(
						array(
							'id'            => 'order_date',
							'name'          => 'order_date',
							'heading'       => esc_html__('Order date', 'wiloke'),
							'value'         => $aDetails['created_at'],
							'is_readonly'   => true
						)
					);

                    \WilokeHtmlHelper::semantic_render_text_field(
	                    array(
		                    'id'      => 'order_status',
		                    'name'    => 'order_status',
		                    'heading' => $aDetails['billing_type'] == wilokeRepository('app:billingTypes', true)->sub('nonrecurring') ? esc_html__( 'Order Status', 'wiloke' ) : esc_html__('Subscription Status', 'wiloke'),
                            'value'   => $aDetails['status'],
		                    'is_readonly' => true
	                    )
                    );
                    echo '</div>';

                    do_action('wiloke-submission/app/session-detail/before_order_information_close', $aDetails);

					if ( $aDetails['billing_type'] == wilokeRepository('app:billingTypes', true)->sub('recurring') ) {
						// Displaying the next billing date information. (Direct bank transfer only)
						if ( $aDetails['gateway'] == 'banktransfer' && ( ($aDetails['status'] == wilokeRepository('app:paymentStatus', true)->sub('processing')) || ($aDetails['status'] == wilokeRepository('app:paymentStatus', true)->sub('succeeded')) ) ) :
                        ?>
                            <h3 class="ui dividing header"><?php esc_html_e( 'Next Billing Date', 'wiloke' ); ?></h3>
                            <?php
                            echo '<div class="fields two">';
                            $nextBillingDate = DirectBankTransfer::getNextBillingDate($aDetails['ID']);
                            \WilokeHtmlHelper::semantic_render_text_field(
                                array(
                                    'id'            => 'next_billing_date',
                                    'name'          => 'next_billing_date',
                                    'heading'       => esc_html__('Ended at', 'wiloke'),
                                    'value'         => empty($nextBillingDate) ? esc_html__('Now', 'wiloke') : date(DATE_ATOM, $nextBillingDate),
                                    'is_readonly'   => true
                                )
                            );

                            \WilokeHtmlHelper::semantic_render_button_field(
                                array(
                                    'heading'       => esc_html__('Charge the next Billing date', 'wiloke'),
                                    'id'            => 'wiloke-charge-the-next-billing-date',
                                    'name'          => esc_html__('Create new Invoice', 'wiloke'),
                                    'class'         => 'green'
                                )
                            );
                            echo '</div>';
                        endif;
					}

                    ## Change Order Status
                    if ( isset($nextBillingDate) && ManageSessionDetails::isAllowChangingPlan($nextBillingDate, $aDetails) ) :
	                    ## Change Plan
	                    ?>
                        <h3 class="ui dividing header"><?php esc_html_e( 'Change Plan', 'wiloke' ); ?></h3>
	                    <?php
	                    echo '<div class="fields two">';
	                    \WilokeHtmlHelper::semantic_render_select_ui_field(
		                    array(
			                    'id'        => 'change_to_new_plan',
			                    'name'      => 'change_to_new_plan',
			                    'post_type' => get_post_type($aDetails['planID']),
			                    'heading'   => esc_html__( 'New Plan', 'wiloke' ),
			                    'value'     => '',
			                    'options'   => wilokeRepository( 'app:saleStatus' )
		                    )
	                    );
	                    \WilokeHtmlHelper::semantic_render_button_field(
		                    array(
			                    'heading'       => esc_html__('Change My Plan', 'wiloke'),
			                    'id'            => 'wiloke-submission-change-my-plan',
			                    'name'          => esc_html__('Execute', 'wiloke'),
			                    'class'         => 'green'
		                    )
	                    );
	                    echo '</div>';
	                    ## End / Change Plan
                    endif;
                    ?>
                    <h3 class="ui dividing header"><?php esc_html_e( 'Change Sale / Subscription Status', 'wiloke' ); ?></h3>
                    <?php
                    \WilokeHtmlHelper::semantic_render_desc(
                        array(
                            'desc'        => esc_html__('Caution: Change Sale / Subscription status will take affect to Listing status. For example, if you change Sale status to Failed status, all Published Listings, which belong to this plan will be temporarily removed from the Front-end till the plan re-change to active/succeeded status.', 'wiloke'),
                            'desc_status' => 'error visible'
                        )
                    );
                    echo '<div class="fields two">';
                    \WilokeHtmlHelper::semantic_render_select_field(
                        array(
                            'id'        => 'change_to_new_order_status',
                            'name'      => 'change_to_new_order_status',
                            'post_type' => get_post_type($aDetails['planID']),
                            'heading'   => esc_html__( 'New Status', 'wiloke' ),
                            'value'     => '',
                            'options'   => $aDetails['billing_type'] == wilokeRepository('app:billingTypes', true)->sub('nonrecurring') ? wilokeRepository( 'app:saleStatus' ) : wilokeRepository( 'app:subscriptionStatus' )
                        )
                    );
                    \WilokeHtmlHelper::semantic_render_button_field(
                        array(
                            'heading'       => esc_html__('Change Sale / Subscription Status', 'wiloke'),
                            'id'            => 'wiloke-submission-change-order-status',
                            'name'          => esc_html__('Execute', 'wiloke'),
                            'class'         => 'green'
                        )
                    );
                    echo '</div>';
					## End / Change Order Status
					?>
				</form>
			<?php endif; ?>
		</div>
		<?php
	}
}
