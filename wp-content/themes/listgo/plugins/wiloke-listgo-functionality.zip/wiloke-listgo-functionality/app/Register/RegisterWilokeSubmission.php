<?php
namespace WilokeListgoFunctionality\Register;
$sessionID = session_id();
if ( empty($sessionID) && (!is_admin() || (isset($_GET['page']) && ($_GET['page'] === 'detail'))) ){
    session_start();
}

use WilokeListgoFunctionality\AlterTable\AlterTablePaymentHistory as PaymentHistory;
use WilokeListgoFunctionality\AlterTable\AlterTablePackageStatus as PackageStatus;
use WilokeListgoFunctionality\AlterTable\AlterTableSessions;
use WilokeListgoFunctionality\CustomerPlan\CustomerPlan;
use WilokeListgoFunctionality\Payment\Payment;
use WilokeListgoFunctionality\Payment\CheckPayment;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;

class RegisterWilokeSubmission implements RegisterInterface{
    use WilokeSubmissionConfiguration;

	public $invoicesSlug = 'invoices';
	public $settingsSlug = 'settings';
	public static $submissionConfigurationKey = 'wiloke_submission_configuration';
	public $aPaymentStatus = array(
        'any'       => 'Any',
        'completed' => 'Completed',
        'processing'=> 'Processing',
        'pending'   => 'Pending',
        'canceled'  => 'Canceled',
        'failed'    => 'Failed'
    );

	public $aPackages = array();
	public $aErrors = array();

	public function __construct() {
		add_action('init', array($this, 'init'));
		add_action('admin_init', array($this, 'adminInit'));
		add_action('admin_menu', array($this, 'register'));
		add_action('admin_enqueue_scripts', array($this, 'enqueueScripts'), 10, 1);
		add_action('wp_ajax_wiloke_submission_install_pages', array($this, 'installPages'));
	}

	public function init(){
		$this->setDefault();
    }

	public function adminInit(){
		$this->addNewOrder = admin_url('admin.php?page='.$this->detailSlug.'&type=addneworder');
		$this->editOrder = admin_url('admin.php?page='.$this->detailSlug.'&type=editorder&payment_ID=');
    }

    public static function setDefaultSubmissionPages(){
	    $aSubmissionPages = \Wiloke::getOption(self::$submissionConfigurationKey);
	    if ( !empty($aSubmissionPages) ){
	        return false;
        }

	    $aPages = array(
		    'package'   => array(
			    'post_title'    => esc_html__('Wiloke Package', 'wiloke'),
			    'post_content'  => ''
		    ),
		    'addlisting'=> array(
			    'post_title'    => esc_html__('Wiloke Submission', 'wiloke'),
			    'post_content'  => '',
			    'page_template' => 'wiloke-submission/addlisting.php'
		    ),
		    'checkout'  => array(
			    'post_title'    => esc_html__('Wiloke Checkout', 'wiloke'),
			    'post_content'  => '',
			    'page_template' => 'wiloke-submission/checkout.php'
		    ),
		    'myaccount' => array(
			    'post_title'    => esc_html__('Wiloke My Account', 'wiloke'),
			    'post_content'  => '',
			    'page_template' => 'wiloke-submission/myaccount.php'
		    ),
		    'thankyou'  => array(
			    'post_title'    => esc_html__('Wiloke Thank You', 'wiloke'),
			    'post_content'  => 'Thanks for submitting with ' . get_option('blogname') . '!. We will mail to you when your article be approved.',
			    'page_template' => 'wiloke-submission/payment-thankyou.php'
		    ),
		    'cancel'    => array(
			    'post_title'    => esc_html__('Wiloke Cancel', 'wiloke'),
			    'post_content'  => 'Thanks for submitting with ' . get_option('blogname') . '!. It seems not right time but feel free come back when you are ready. Hope to see you soon ;)!',
			    'page_template' => 'wiloke-submission/payment-cancel.php'
		    )
	    );

	    $aPostIDs = array();
        foreach ( $aPages as $key => $aArgs ){
            $aArgs['post_type'] = 'page';
            $aArgs['post_status'] = 'publish';
            $aPostIDs[$key] = wp_insert_post($aArgs);
        }

	    \Wiloke::updateOption(self::$submissionConfigurationKey, $aPostIDs);
	}
    
    protected function setDefault(){
	    if ( !get_option(self::$submissionConfigurationKey) ){
		    global $WilokeListgoFunctionalityApp;

		    $aDefault = array();
		    foreach ( $WilokeListgoFunctionalityApp['settings']['submission']['fields'] as $aField ){
			    if ( isset($aField['name']) ){
			        $fieldName = str_replace(array('wiloke_listgo[', ']'), array('', ''), $aField['name']);
				    $aDefault[$fieldName] = isset($aField['default'])  ? $aField['default'] : '';
			    }
		    }
		    update_option(self::$submissionConfigurationKey, json_encode($aDefault));
        }
    }

	public function enqueueScripts($hook){
        $this->parentEnqueueScripts($hook);

		if ( strpos($hook, $this->settingsSlug) ){
			wp_dequeue_script('semantic-selection-ui');
			wp_register_style('semantic-ui', plugin_dir_url(__FILE__) . '../../admin/assets/semantic-ui/form.min.css');
			wp_enqueue_style('semantic-ui');

			wp_register_script('semantic-ui', plugin_dir_url(__FILE__) . '../../admin/assets/semantic-ui/semantic.min.js', array('jquery'), WILOKE_LISTGO_FC_VERSION, true);
			wp_enqueue_script('semantic-ui');

			wp_enqueue_script('session-detail', plugin_dir_url(__FILE__) . '../../admin/js/session-details.js', array('jquery'), WILOKE_LISTGO_FC_VERSION, true);
		}
	}

	public function register() {
		add_menu_page( esc_html__( 'Wiloke Submission', 'wiloke' ), esc_html__( 'Wiloke Submission', 'wiloke' ), 'administrator', 'wiloke-submission', array($this, 'submissionArea'), 'dashicons-hammer', 29 );
		add_submenu_page($this->parentSlug, esc_html__('Settings', 'wiloke'), esc_html__('Settings', 'wiloke'), 'administrator', $this->settingsSlug, array($this, 'settingsArea'));
	}

	/**
	 * Install Wiloke Submission Pages
     * @since 1.0
	 */
	public function installPages(){
	    if ( !current_user_can('edit_theme_options') ){
	        wp_send_json_error(
                array(
                    'message' => esc_html__('You do not have permission to access this page!', 'wiloke')
                )
            );
        }

        $aPages = array(
            'package'   => array(
                'post_title'    => esc_html__('Wiloke Package', 'wiloke'),
                'post_content'  => '',
                'page_template' => 'default'
            ),
            'addlisting'=> array(
                'post_title'    => esc_html__('Wiloke Submission', 'wiloke'),
                'post_content'  => '',
                'page_template' => 'wiloke-submission/addlisting.php'
            ),
            'checkout'  => array(
                'post_title'    => esc_html__('Wiloke Checkout', 'wiloke'),
                'post_content'  => '',
                'page_template' => 'wiloke-submission/checkout.php'
            ),
            'myaccount' => array(
                'post_title'    => esc_html__('Wiloke My Account', 'wiloke'),
                'post_content'  => '',
                'page_template' => 'wiloke-submission/myaccount.php'
            ),
            'thankyou'  => array(
                'post_title'    => esc_html__('Wiloke Thank You', 'wiloke'),
                'post_content'  => 'Thanks for submitting with ' . get_option('blogname') . '!. We will mail to you when your article be approved.',
                'page_template' => 'wiloke-submission/payment-thankyou.php'
            ),
            'cancel'    => array(
                'post_title'    => esc_html__('Wiloke Cancel', 'wiloke'),
                'post_content'  => 'Thanks for submitting with ' . get_option('blogname') . '!. It seems not right time but feel free come back when you are ready. Hope to see you soon ;)!',
                'page_template' => 'wiloke-submission/payment-cancel.php'
            )
        );

	    $aPostIDs = array();
        $aSubmissionPages = \Wiloke::getOption(self::$submissionConfigurationKey);

        if ( empty($aSubmissionPages) ){
            foreach ( $aPages as $key => $aArgs ){
	            $aArgs['post_type'] = 'page';
	            $aArgs['post_status'] = 'publish';
	            $aPostIDs[$key] = wp_insert_post($aArgs);
            }
        }else{
            foreach ( $aPages as $key => $aArgs ){
                if ( !isset($aSubmissionPages[$key]) || empty($aSubmissionPages[$key]) ){
	                $oPage = get_posts(array(
                        'post_type'  => 'page',
		                'fields'     => 'ids',
		                'nopaging'   => true,
		                'meta_key'   => '_wp_page_template',
		                'meta_value' => $aArgs['page_template']
	                ));
	                $aArgs['post_type']     = 'page';
	                $aArgs['post_status']   = 'publish';

	                if ( !empty($oPage) ){
		                $postID = end($oPage);
		                wp_update_post(
                            array(
                                'ID' => $postID,
                                'post_status' => 'publish'
                            )
                        );
		                $aPostIDs[$key] = $postID;
                    }else {
		                $aPostIDs[$key] = wp_insert_post($aArgs);
                    }
                }else{
	                wp_update_post(
		                array(
			                'ID' => $aSubmissionPages[$key],
			                'post_status' => 'publish'
		                )
	                );
                }
            }
        }

        if ( empty($aPostIDs) ) {
            wp_send_json_success(
                array(
                    'message' => esc_html__('You have already installed all required pages before.', 'wiloke')
                )
            );
        }

		$aSubmissionPages = empty($aSubmissionPages) ? $aPostIDs : array_merge($aSubmissionPages, $aPostIDs);
        \Wiloke::updateOption(self::$submissionConfigurationKey, $aSubmissionPages);

        $msg = '<div class="header">'. esc_html__('Congratulations! Your setup has been successfully.', 'wiloke') . '</div>';
		$msg .= '<p>'. esc_html__('Here are list of pages have been installed: ', 'wiloke') . '</p>';
        $msg .= '<ul class="list">';
        foreach ( $aPostIDs as $key => $postID ){
	        $msg .= '<li><a href="'.esc_url(admin_url('post.php?post='.$postID.'&action=edit')).'">' .get_the_title($postID). '</a></li>';
        }
		$msg .= '</ul>';
		$msg .= '<p class="error ui">' . esc_html__('One more thing, The pricing page - Where you show your packages  -  requires at least one package. So if you have not created any package yet before, please click on Pricings -> Creating some packages. Then go to Pages -> Pricing Tables page and insert those packages to this page. Please refer to Wiloke Guide -> FAQs -> Looking for Creating Package page to know more.', 'wiloke') . '</p>';

		wp_send_json_success(
            array(
                'message' => $msg
            )
        );
    }

	public function submissionArea(){
        ?>
        <div id="wiloke-submission-wrap" class="wrap">
            <h3 class="header"><?php esc_html_e('Tools', 'wiloke'); ?></h3>

            <h4 class="header ui dividing"><?php esc_html_e('Install Wiloke Submission Pages', 'wiloke'); ?></h4>
            <form id="ws-install-pages" action="<?php echo esc_url(admin_url('admin.php?page='.$this->parentSlug)); ?>" class="ui form">
                <?php
                    \WilokeHtmlHelper::semantic_render_desc_field(
                        array(
                            'status' => 'info',
                            'desc' => esc_html__('This tool will install all the missing Wiloke Submission pages. Pages already defined and set up will not be replaced.', 'wiloke')
                        )
                    );
                    \WilokeHtmlHelper::semantic_render_submit(
                        array(
                            'name' => esc_html__('Install', 'wiloke')
                        )
                    );
                ?>
            </form>
        </div>
        <?php
    }

	public function save(){
	    if ( !current_user_can('edit_theme_options') ){
            return false;
        }

		if ( isset($_POST['wiloke_nonce_field']) && !empty($_POST['wiloke_nonce_field']) && wp_verify_nonce($_POST['wiloke_nonce_field'], 'wiloke_nonce_action') ){
	        $options = json_encode($_POST['wiloke_listgo']);
			update_option(self::$submissionConfigurationKey, $options);
			do_action('wiloke/wiloke-listgo-functionality/app/Register/RegisterWilokeSubmission/save', $_POST);
		}
	}

    public static function getSettings(){
        $aOptions = get_option(self::$submissionConfigurationKey);
        $aOptions = !empty($aOptions) ? json_decode($aOptions, true) : array();
        return $aOptions;
    }

	public function settingsArea(){
		global $WilokeListgoFunctionalityApp;
		$this->save();
		$aOptions = get_option(self::$submissionConfigurationKey);
		$aOptions = !empty($aOptions) ? json_decode($aOptions, true) : array();
		?>
        <div id="wiloke-submission-wrapper" class="wrap">
            <form class="form ui" action="<?php echo esc_url(admin_url('admin.php?page='.$this->settingsSlug)); ?>" method="POST">
				<?php wp_nonce_field('wiloke_nonce_action', 'wiloke_nonce_field'); ?>
				<?php
				foreach ( $WilokeListgoFunctionalityApp['settings']['submission']['fields'] as $aField ){
					if ( $aField['type'] == 'password' || $aField['type'] == 'text' || $aField['type'] == 'select_post' || $aField['type'] == 'select_ui' || $aField['type'] == 'select' || $aField['type'] == 'textarea' ){
						$name = str_replace(array('wiloke_listgo', '[', ']'), array('', '', ''), $aField['name']);
						$aField['value'] = isset($aOptions[$name]) ? $aOptions[$name] : $aField['default'];
					}

					switch ($aField['type']){
						case 'open_segment';
							\WilokeHtmlHelper::semantic_render_open_segment($aField);
							break;
						case 'open_accordion';
							\WilokeHtmlHelper::semantic_render_open_accordion($aField);
							break;
						case 'open_fields_group';
							\WilokeHtmlHelper::semantic_render_open_fields_group($aField);
							break;
						case 'close';
							\WilokeHtmlHelper::semantic_render_close();
							break;
						case 'close_segment';
							\WilokeHtmlHelper::semantic_render_close_segment();
							break;
						case 'password':
							\WilokeHtmlHelper::semantic_render_password_field($aField);
							break;
						case 'text';
							\WilokeHtmlHelper::semantic_render_text_field($aField);
							break;
						case 'select_post';
						case 'select_ui';
							\WilokeHtmlHelper::semantic_render_select_ui_field($aField);
							break;
						case 'select':
							\WilokeHtmlHelper::semantic_render_select_field($aField);
							break;
						case 'textarea':
							\WilokeHtmlHelper::semantic_render_textarea_field($aField);
							break;
						case 'submit':
							\WilokeHtmlHelper::semantic_render_submit($aField);
							break;
						case 'header':
							\WilokeHtmlHelper::semantic_render_header($aField);
							break;
						case 'desc';
							\WilokeHtmlHelper::semantic_render_desc($aField);
							break;
					}
				}
				?>
            </form>
        </div>
		<?php
	}

    public function getPaymentStatusIcon($status){
        switch ($status){
            case 'completed':
                $icon = 'dashicons-yes';
                break;
	        case 'pending':
		        $icon = 'dashicons-clock';
		        break;
	        case 'processing':
		        $icon = 'dashicons-update';
		        break;
            case 'canceled':
                $icon = 'dashicons-warning';
                break;
	        case 'failed':
            case 'denied':
		        $icon = 'dashicons-thumbs-down';
		        break;
            default:
                $icon = 'dashicons-visibility';
                break;
        }
        return $icon;
    }
}