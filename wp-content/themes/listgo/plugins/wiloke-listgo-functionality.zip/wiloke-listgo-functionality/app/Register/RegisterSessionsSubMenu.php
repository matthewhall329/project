<?php

namespace WilokeListgoFunctionality\Register;


class RegisterSessionsSubMenu implements RegisterInterface {
	public $parentSlug = 'wiloke-submission';

	public function __construct() {

	}

	public function register() {
		// TODO: Implement register() method.
	}
}