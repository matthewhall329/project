<?php
namespace WilokeListgoFunctionality\Register;

use WilokeListgoFunctionality\Framework\Helpers\DebugStatus;
use WilokeListgoFunctionality\Framework\Helpers\General;
use WilokeListgoFunctionality\Framework\Helpers\GetSettings;

class RegisterPricingSettings implements RegisterInterface{
	public $parent = 'pricing';
	public static $redisPricing = 'wiloke_pricing';
	public $slug = 'pricing-settings';

	public function __construct() {
		add_filter('wiloke_filter_metaboxes', array($this, 'addMoreOptionsToListingPricing'), 20, 1);
	}

	public function addMoreOptionsToListingPricing($aConfigurations){
		if ( General::detectPostType() != $this->parent ){
			return $aConfigurations;
		}

		$aFieldsSettings = GetSettings::getOptions('wiloke_design_fields_settings');
		$aCustomFieldCollection = array();

		foreach ( $aFieldsSettings as $aFieldSetting ) {
			if ( ! isset( $aFieldSetting['isCustomField'] ) || ! $aFieldSetting['isCustomField'] ) {
				continue;
			}
			$aCustomFieldCollection[$aFieldSetting['key']] = $aFieldSetting['title'];
		}

		if ( isset($aCustomFieldCollection) && !empty($aCustomFieldCollection) ){
			$aExceptCustomFields = array(
				'type'         => 'multicheck',
				'id'           => 'except_custom_fields',
				'name'         => esc_html__('Except Custom Fields', 'wiloke'),
				'desc'         => esc_html__('Specifying what custom fields will not be used in this plan', 'wiloke'),
				'default'      => '',
				'options'      => $aCustomFieldCollection
			);
			$aConfigurations['pricing_settings']['fields'][] = $aExceptCustomFields;

		}
		return $aConfigurations;
	}

	public function putToRedis($postID, $post){
        if ( $post->post_type === $this->parent ){
            global $wiloke;

            if ( \Wiloke::$wilokePredis ){
                $aCaching = array(
                    'ID'            => $post->ID,
                    'post_title'    => $post->post_title,
                    'post_content'  => $post->post_content,
                    'featured_image'=> get_the_post_thumbnail_url($post->ID, 'medium'),
                    'post_meta'     => \Wiloke::getPostMetaCaching($post->ID, $wiloke->aConfigs['metaboxes']['pricing_settings']['id'])
                );
                \Wiloke::$wilokePredis->hSet(self::$redisPricing, $post->ID, json_encode($aCaching));
            }
        }
    }

	public function register() {

	}
}