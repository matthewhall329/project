<?php
namespace WilokeListgoFunctionality\Register;


trait WilokeSubmissionConfiguration {
	public $parentSlug = 'wiloke-submission';
	public $postPerPages = 10;
	public $total = 0;
	public $detailSlug = 'detail';
	public $addNewOrder;
	public $editOrder;
	protected $sessionKey = 'wiloke_listgo_save_payment_ID';

	public $aFilterByDate = array(
		'any'       => 'Any',
		'this_week' => 'This Week',
		'this_month'=> 'This Month',
		'period'    => 'Period'
	);

	public function parentEnqueueScripts($hook){
		wp_enqueue_style('wiloke-submission-general', plugin_dir_url(__FILE__) . '../../admin/css/submission-general.css', array(), WILOKE_LISTGO_FC_VERSION);
		wp_enqueue_script('wiloke-submission-general', plugin_dir_url(__FILE__) . '../../admin/js/wiloke-submission-general.js', array('jquery'), WILOKE_LISTGO_FC_VERSION, true);
		if (  strpos($hook, $this->parentSlug) !== false ){
			wp_enqueue_style('jquery-ui-style', '//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');
			wp_enqueue_script($this->parentSlug, plugin_dir_url(__FILE__) . '../../admin/js/wiloke-submission.js', array('jquery', 'jquery-ui-datepicker', 'jquery-ui-tooltip'), WILOKE_LISTGO_FC_VERSION, true);
		}
	}
}