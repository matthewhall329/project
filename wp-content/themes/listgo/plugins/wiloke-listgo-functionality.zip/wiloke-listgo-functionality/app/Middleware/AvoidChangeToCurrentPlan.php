<?php
namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;
use WilokeListgoFunctionality\Model\PaymentModel;
use WilokeListgoFunctionality\Model\UserModel;

class AvoidChangeToCurrentPlan implements InterfaceMiddleware {
	public $msg;

	public function handle( array $aOptions ) {
		$this->msg = esc_html__('Knock ... Knock ... Knock! You are using this plan already!', 'wiloke');

		if ( !isset($aOptions['aCurrentPlanInfo']) ){
			$aCheckPlanExists = UserModel::getUserDetailPlan($aOptions['userID'], $aOptions['planID']);
		}else{
			$aCheckPlanExists = $aOptions['aCurrentPlanInfo'];
		}

		if ( empty($aCheckPlanExists) ){
			return true;
		}

		if ( !isset($aCheckPlanExists['sessionID']) || empty($aCheckPlanExists['sessionID']) ){
			return true;
		}

		$sessionStatus = PaymentModel::getSessionStatus($aCheckPlanExists['sessionID']);

		if ( $sessionStatus == wilokeRepository('app:paymentStatus', true)->sub('succeeded') && ($aCheckPlanExists['planID'] == $aOptions['planID']) ){
			return false;
		}

		return true;
	}
}