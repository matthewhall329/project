<?php
namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;

class GGRecaptchaMiddleware implements InterfaceMiddleware {
	public $msg;

	public function handle(array $aOptions = []){
		if ( is_user_logged_in() ){
			return true;
		}

		$aThemeOptions = GetSettings::getOptions(wilokeRepository('app:themeoptions'));
		if ( $aThemeOptions['toggle_google_recaptcha'] == 'disable' ){
			return true;
		}

		$this->msg = esc_html__('Gah! CAPTCHA verification failed', 'wiloke');
		if ( empty($aOptions['ggCaptcha']) || empty($aThemeOptions['google_recaptcha_site_secret']) ){
			return false;
		}

		if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) {
			$remoteIP = $_SERVER['HTTP_CF_CONNECTING_IP'];
		}else{
			$remoteIP = $_SERVER['REMOTE_ADDR'];
		}

		$response = wp_remote_post( 'https://www.google.com/recaptcha/api/siteverify', array(
				'method'        => 'POST',
				'timeout'       => 45,
				'redirection'   => 5,
				'httpversion'   => '1.0',
				'blocking'      => true,
				'headers'       => array(
					'Content-type'=>'application/x-www-form-urlencoded'
				),
				'body' => array(
					'secret'    => $aThemeOptions['google_recaptcha_site_secret'],
					'response'  => $aOptions['ggCaptcha'],
					'remoteip'  => $remoteIP
				),
				'cookies' => array()
			)
		);

		if ( is_wp_error( $response ) ) {
			return false;
		} else {
			$aAPIResponse = json_decode( wp_remote_retrieve_body( $response ), true );
			if ( $aAPIResponse['success'] === false ){
				return false;
			}
		}

		return true;
	}
}