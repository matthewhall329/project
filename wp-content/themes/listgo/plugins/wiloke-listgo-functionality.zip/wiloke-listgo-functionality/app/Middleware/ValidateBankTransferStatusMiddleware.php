<?php
namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;
use WilokeListgoFunctionality\Model\PaymentModel;

class ValidateBankTransferStatusMiddleware implements InterfaceMiddleware {
	public $msg;
	protected $gateway = 'banktransfer';

	public function handle( array $aOptions ) {
		if ( empty($aOptions['aUserPlan']) ){
			return true;
		}

		if ( $aOptions['aUserPlan']['gateway'] != $this->gateway ){
			return true;
		}

		$paymentStatus = PaymentModel::getSessionStatus($aOptions['aUserPlan']['sessionID']);
		if ( $paymentStatus == wilokeRepository('app:paymentStatus', true)->sub('processing') ){
			$this->msg = sprintf(esc_html__('Please transfer your order recently #%d to continue submitting. In case, you have already transferred to our bank account, please contact us to confirm your payment.', 'wiloke'), $aOptions['aUserPlan']['sessionID']);
			return false;
		}

		return true;
	}
}