<?php
namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Helpers\DebugStatus;
use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;

class ValidateEventPlanMiddleware implements InterfaceMiddleware {
	public $msg;
	public function handle( array $aOptions ) {

		if ( !DebugStatus::status('WILOKE_SUBMISSION_CHECK_EVEN_ADMIN') && current_user_can('edit_theme_options') ){
			return true;
		}

		if ( !isset($aOptions['eventPlanID']) || empty($aOptions['eventPlanID']) ){
			$this->msg = esc_html__('The event plan is required', 'wiloke');
			return false;
		}

		if ( get_post_field('post_status', $aOptions['eventPlanID']) != 'publish' ){
			$this->msg = esc_html__('This event plan does not exists', 'wiloke');
			return false;
		}

		if ( get_post_field('post_type', $aOptions['eventPlanID']) != 'event-pricing' ){
			$this->msg = esc_html__('This event plan does not exists', 'wiloke');
			return false;
		}

		return true;
	}
}