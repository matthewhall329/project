<?php

namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;

class ValidateAddListing implements InterfaceMiddleware {
	public $msg;

	public function handle( array $aOptions ) {
		if ( !defined('WILOKE_TUNROFF_DESIGN_ADDLISTING_UC') || !WILOKE_TUNROFF_DESIGN_ADDLISTING_UC ){
			return true;
		}

		$this->msg = esc_html__('We need your', 'wiloke');
		$aThemeOptions = GetSettings::getOptions(wilokeRepository('app:themeoptions'));

		if ( !isset($aOptions['listingInfo']['listing_title']) || empty($aOptions['listingInfo']['listing_title']) ){
			$this->msg .= ' ' . esc_html__('Listing Title', 'wiloke');
			return false;
		}

		if ( !isset($aOptions['listingInfo']['content']) || empty($aOptions['listingInfo']['content']) ){
			$this->msg .= ' ' . esc_html__(' Content', 'wiloke');
			return false;
		}

		if ( $aThemeOptions['add_listing_select_location_type'] == 'default' ){
			if ( empty($aOptions['listingInfo']['listing_location']) ){
				$this->msg .= ' ' . esc_html__(' Listing Location', 'wiloke');
				return false;
			}else{
				if ( empty(term_exists(abs($aOptions['listingInfo']['listing_location']), 'listing_location')) ){
					$this->msg = ' ' . esc_html__('Please select a Listing Location that has been provided by us', 'wiloke');
					return false;
				}
			}
		}else{
			if ( empty($aOptions['listingInfo']['listing_address']) ){
				$this->msg .= ' ' . esc_html__(' Listing Address', 'wiloke');
				return false;
			}
		}

		return true;
	}
}