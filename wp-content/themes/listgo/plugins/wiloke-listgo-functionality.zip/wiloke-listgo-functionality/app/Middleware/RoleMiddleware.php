<?php
namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;

class RoleMiddleware implements InterfaceMiddleware{
	public function handle( array $aOptions = [] ) {
		if ( current_user_can('edit_theme_options') ){
			return true;
		}

		if ( !current_user_can('wiloke_submission') ){
			return false;
		}

		return true;
	}
}