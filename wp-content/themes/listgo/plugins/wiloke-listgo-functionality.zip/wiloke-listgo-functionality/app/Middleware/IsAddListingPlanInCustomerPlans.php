<?php

namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;

class IsAddListingPlanInCustomerPlans implements InterfaceMiddleware {
	public $msg;

	public function handle( array $aOptions ) {
		if ( !empty($aOptions['postID']) ){
			return true;
		}

		$aWilokeSubmissionSettings = PaymentConfiguration::get();
		$aCustomerPlans = explode(',', $aWilokeSubmissionSettings['customer_plans']);
		$this->msg = esc_html__('Whoops! We do not support the plan that you are providing', 'wiloke');


		if ( empty($aCustomerPlans) ){
			return false;
		}

		if ( !in_array($aOptions['planID'], $aCustomerPlans) ){
			return false;
		}

		return true;
	}
}