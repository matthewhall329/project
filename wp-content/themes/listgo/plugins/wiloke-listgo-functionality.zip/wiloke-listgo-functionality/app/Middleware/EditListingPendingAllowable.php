<?php
namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;

class EditListingPendingAllowable implements InterfaceMiddleware {
	public $msg;

	public function handle( array $aOptions = [] ) {
		$this->msg = esc_html__('Whoops! Our team is reviewing this article so You can not edit it in this time.', 'wiloke');

		if ( get_post_status($aOptions['postID']) != 'pending' ){
			return true;
		}

		if ( isset($aWilokeSubmissionSettings['published_listing_editable']) && ( ($aWilokeSubmissionSettings['published_listing_editable']=='allow_need_review') || ($aWilokeSubmissionSettings['published_listing_editable']=='allow_trust_approved') )  ){
			return true;
		}

		return false;
	}
}