<?php

namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;

class AvoidDowngradePlanMiddleware implements InterfaceMiddleware {

	public function handle( array $aOptions ) {
		
	}

}