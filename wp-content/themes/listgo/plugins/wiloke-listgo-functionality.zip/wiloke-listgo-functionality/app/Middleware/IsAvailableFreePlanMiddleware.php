<?php
namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;
use WilokeListgoFunctionality\Model\PlanRelationshipModel;

class IsAvailableFreePlanMiddleware implements InterfaceMiddleware {
	public $msg;

	public function handle( array $aOptions ) {
		if ( PaymentConfiguration::isFreeAddListingMode() ){
			return true;
		}

		if ( !empty($aOptions['aPlanSettings']['price']) || !empty($aOptions['postID']) ){
			return true;
		}

		$countAddedItems = PlanRelationshipModel::countItemsUsedByUserIDAndPlanID($aOptions['authorID'], $aOptions['planID']);
		$availabilityItems = abs($aOptions['aPlanSettings']['number_of_posts']);

		$this->msg = esc_html__('You have exceeded the number of free listings. Please purchase a premium plan to continue adding', 'wiloke');

		if ( $availabilityItems <= $countAddedItems ){
			return false;
		}

		return true;
	}
}