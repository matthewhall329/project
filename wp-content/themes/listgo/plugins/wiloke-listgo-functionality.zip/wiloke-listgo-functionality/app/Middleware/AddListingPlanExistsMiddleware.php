<?php
namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;

class AddListingPlanExistsMiddleware implements InterfaceMiddleware{
	public $msg;

	public function handle( array $aOptions = [] ) {
		$this->msg = esc_html__('Whoops! This plan does not exists or no longer available anymore.', 'wiloke');

		if ( !isset($aOptions['planID']) || empty($aOptions['planID']) ){
			$this->msg = esc_html__('Whoops! Please select a plan before.', 'wiloke');
			return false;
		}

		if ( get_post_status($aOptions['planID']) != 'publish' ){
			$this->msg = esc_html__('Whoops! This plan is no longer available.', 'wiloke');
			return false;
		}

		if ( current_user_can('administrator') ){
			return true;
		}

		if ( isset($aOptions['postID']) && !empty($aOptions['postID']) ){
			return true;
		}

		$aWilokeSubmissionSettings = PaymentConfiguration::get();
		if ( !isset($aWilokeSubmissionSettings['customer_plans']) || empty($aWilokeSubmissionSettings['customer_plans']) ){
			return false;
		}

		$aListingPlans = explode(',', $aWilokeSubmissionSettings['customer_plans']);

		if ( !in_array($aOptions['planID'], $aListingPlans) ){
			return false;
		}

		return true;
	}
}