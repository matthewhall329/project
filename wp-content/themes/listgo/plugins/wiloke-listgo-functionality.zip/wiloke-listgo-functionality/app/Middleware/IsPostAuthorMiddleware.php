<?php
namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;

class IsPostAuthorMiddleware implements InterfaceMiddleware{
	public $msg;

	public function handle( array $aOptions = [] ) {
		if ( !isset($aOptions['postID']) || empty($aOptions['postID']) ){
			return true;
		}

		if ( !is_user_logged_in() ){
			return false;
		}

		$this->msg = esc_html__('You do not have permission to edit this post', 'wiloke');

		if ( !isset($aOptions['postID']) || (get_post_field('post_author', $aOptions['postID']) != get_current_user_id()) ){
			return false;
		}

		return true;
	}
}