<?php
namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Helpers\Time;
use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;

class IsEventExpiredMiddleWare implements InterfaceMiddleware {
	public $msg;
	public $period = 1800;

	public function handle( array $aOptions ) {
		if ( !isset($aOptions['eventID']) || empty($aOptions['eventID']) ){
			return true;
		}

		if ( get_post_field('post_author', $aOptions['eventID']) != get_current_user_id() ){
			$this->msg = esc_html__('You do not have permission the access this page', 'wiloke');
			return false;
		}

		$eventCreatedAtGmt = get_post_field('post_date_gmt', $aOptions['eventID']);
		$now = Time::timestampUTCNow();

		if ( ($eventCreatedAtGmt - $now)  >= $this->period ){
			$this->msg = esc_html__('The deadline editing event has expired', 'wiloke');
		}

		return true;
	}
}