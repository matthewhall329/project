<?php
namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use WilokeListgoFunctionality\Model\UserModel;

class AvoidDowngradeToFreePlanMiddleware implements InterfaceMiddleware {
	public $msg;

	public function handle( array $aOptions = [] ) {
		$this->msg = esc_html__('Whoops! You can not downgrade from Premium plan to Free Plan', 'wiloke');
		$aUserPlans = UserModel::getUserPlansByPlanType($aOptions['userID'], get_post_type($aOptions['planID']));

		if ( !empty($aUserPlans) && empty($aOptions['aNewPlanSettings']['price']) ){
			return false;
		}

		return true;
	}
}