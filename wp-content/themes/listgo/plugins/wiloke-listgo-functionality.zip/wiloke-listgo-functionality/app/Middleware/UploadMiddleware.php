<?php
namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;

class UploadMiddleware implements InterfaceMiddleware {
	public function handle( array $aOptions ) {
		// TODO: Implement handle() method.
		return true;
	}
}