<?php
namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Helpers\GetSettings;

class UserBannedMiddleware {
	public function handle( array $aOptions ) {
		return (GetSettings::getUserMeta(get_current_user_id(), wilokeRepository('app:bannedUser')) != 1);
	}
}