<?php
namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;

class UpdateSessionPermissionMiddleware implements InterfaceMiddleware{
	public $msg;

	public function handle( array $aOptions = [] ) {
		$this->msg = esc_html__('You do not have permission to access this page', 'wiloke');
		if ( !current_user_can('administrator') ){
			return false;
		}

		return true;
	}
}