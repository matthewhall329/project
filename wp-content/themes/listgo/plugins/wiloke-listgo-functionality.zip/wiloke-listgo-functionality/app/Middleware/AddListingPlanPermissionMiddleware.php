<?php

namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;

class AddListingPlanPermissionMiddleware implements InterfaceMiddleware {
	public $msg;

	public function handle( array $aOptions ) {
		$aPlanSettings = GetSettings::getPostMeta($aOptions['planID'], get_post_type($aOptions['planID']));

		return true;
//
//		// Open Table
//		if ( $aPlanSettings['toggle_open_table'] == 'disable' ){
//			return false;
//		}
//
//
	}
}