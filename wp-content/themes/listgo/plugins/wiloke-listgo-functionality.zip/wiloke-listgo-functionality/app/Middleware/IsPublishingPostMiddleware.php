<?php
namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;

class IsPublishingPostMiddleware implements InterfaceMiddleware{
	public $msg;

	public function handle( array $aOptions = [] ) {
		$this->msg = esc_html__('You do not have permission to access this post', 'wiloke');

		if ( !isset($aOptions['postID']) || empty($aOptions['postID']) ){
			return false;
		}

		if ( get_post_status($aOptions['postID']) != 'publish' ){
			return false;
		}

		return true;
	}
}