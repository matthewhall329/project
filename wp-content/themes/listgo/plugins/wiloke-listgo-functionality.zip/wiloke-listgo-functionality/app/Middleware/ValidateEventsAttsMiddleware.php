<?php
namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;
use WilokeListgoFunctionality\Model\UserModel;

class ValidateEventsAttsMiddleware implements InterfaceMiddleware {
	public $msg;
	public function handle( array $aAttributes ) {
		if ( !isset($aAttributes['event_title']) || empty($aAttributes['event_title']) ){
			$this->msg = esc_html__('We need your event title', 'wiloke');
			return false;
		}

		if ( !isset($aAttributes['event_content']) || empty($aAttributes['event_content']) ){
			$this->msg = esc_html__('We need your event content', 'wiloke');
			return false;
		}

		if ( !isset($aAttributes['start_on']) || empty($aAttributes['start_on']) ){
			$this->msg = esc_html__('Start value is required', 'wiloke');
			return false;
		}

		if ( !isset($aAttributes['end_on']) || empty($aAttributes['end_on']) ){
			$this->msg = esc_html__('The ending value is required', 'wiloke');
			return false;
		}

		$startAt = empty($aAttributes['start_at']) ? 0 : strtotime($aAttributes['start_at']);
		$endAt   = empty($aAttributes['end_at']) ? 0 : strtotime($aAttributes['end_at']);

		$start = (strtotime($aAttributes['start_on']) + $startAt) > ($endAt + strtotime($aAttributes['end_on']));

		if ( $start ){
			$this->msg = esc_html__('The end value must be bigger than start value.', 'wiloke');
			return false;
		}

		if ( empty($aAttributes['latitude']) || empty($aAttributes['longitude']) ){
			$this->msg = esc_html__('The address is required.', 'wiloke');
			return false;
		}

		return true;
	}
}