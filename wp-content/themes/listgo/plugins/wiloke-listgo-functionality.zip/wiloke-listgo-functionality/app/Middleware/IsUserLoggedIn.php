<?php
namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;

class IsUserLoggedIn implements InterfaceMiddleware{
	public function handle( array $aOptions = [] ) {
		if ( !is_user_logged_in() ){
			return false;
		}

		return true;
	}
}