<?php
namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;

class ValidateCardInfoMiddleware implements InterfaceMiddleware {
	public $msg;

	public $aValidation = array(
		'card_name',
		'card_address1',
		'city',
		'country',
		'email',
		'phoneNumber',
	);

	public function handle( array $aOptions ) {
		$this->msg = esc_html__('Please provide your card information', 'wiloke');

		if ( empty($aOptions['card']) ){
			return false;
		}

		foreach ($this->aValidation as $info){
			if ( !isset($aOptions['card'][$info]) || empty($aOptions['card'][$info]) ){
				return false;
			}
		}

		return true;
	}
}