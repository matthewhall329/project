<?php
namespace WilokeListgoFunctionality\Middleware;


use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
use WilokeListgoFunctionality\Framework\Routing\InterfaceMiddleware;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;

class OutstandingBalanceMiddleware implements InterfaceMiddleware {
	public $msg;

	public function handle( array $aOptions = [] ) {
		return true;
		$this->msg = esc_html__('Whoops! You can not downgrade from Premium plan to Free Plan', 'wiloke');

		if ( get_post_status($aOptions['currentPlanID']) != 'publish' ){
			return true;
		}

		$aCurrentPlanSettings = GetSettings::getPostMeta($aOptions['currentPlanID'], get_post_type($aOptions['currentPlanID']));
		$aNewPlanSettings = GetSettings::getPostMeta($aOptions['newPlanID'], get_post_type($aOptions['newPlanID']));

		if ( abs($aNewPlanSettings['price']) < abs($aCurrentPlanSettings['price']) && empty($aNewPlanSettings['price']) ){
			return false;
		}

		return true;
	}
}