<?php
namespace WilokeListgoFunctionality\Model;


use WilokeListgoFunctionality\AlterTable\AlterTableSessions;

class PayPalModel {
	protected static $gateway = 'paypal';

	/**
	 * Get Agreement ID by the specified $sessionID and $metaKey
	 *
	 * @param number $sessionID
	 * @param string $metaKey
	 *
	 * @return string $agreementID
	 */
	public static function getAgreementID($sessionID){
		$oPaymentInfo = PaymentMetaModel::get($sessionID, wilokeRepository('paymentKeys:info'));

		if ( empty($oPaymentInfo) ){
			return false;
		}

		if ( !isset($oPaymentInfo->id) ){
			return false;
		}

		return $oPaymentInfo->id;
	}


	/**
	 * Get Last Suspended status by specified Plan ID and User ID
	 *
	 * @param number $planID
	 * @param number $userID
	 *
	 * @return mixed $sessionID
	 */
	public static function getUserLastSuspendedSessionIDEnqualToPlanID($userID, $planID){
		global $wpdb;
		$tblName = $wpdb->prefix . AlterTableSessions::$tblName;

		$sessionID = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID FROM {$tblName} WHERE userID=%d  AND planID=%d AND billing_type=%s AND status=%s AND gateway=%s ORDER BY ID DESC",
				$userID, $planID, wilokeRepository('app:billingTypes', true)->sub('recurring'), wilokeRepository('app:paymentStatus', true)->sub('suspended'), self::$gateway
			)
		);

		if ( empty($sessionID) ){
			return false;
		}
		return $sessionID;
	}

	/**
	 * Save Payment ID
	 *
	 * @param string $paymentID
	 * @param number $sessionID
	 *
	 * @return bool
	 */
	public static function setPaymentID($paymentID, $sessionID){
		return PaymentMetaModel::set($sessionID, wilokeRepository('paymentKeys:paypal', true)->sub('paymentID'), $paymentID);
	}

	/**
	 * Save billing Agreement ID
	 *
	 * @param string $billingAgreementID
	 * @param number $sessionID
	 *
	 * @return bool
	 */
	public static function setBillingAgreementID($billingAgreementID, $sessionID){
		return PaymentMetaModel::set($sessionID, wilokeRepository('paymentKeys:paypal', true)->sub('billingAgreementID'), $billingAgreementID);
	}

	/**
	 * Get Agreement ID
	 *
	 * @param number $sessionID
	 *
	 * @return string
	 */
	public static function getAgreementIDWhereEqualToSessionID($sessionID){
		return PaymentMetaModel::get($sessionID, wilokeRepository('paymentKeys:paypal', true)->sub('billingAgreementID'));
	}

	/**
	 * Save Payment ID
	 *
	 * @param number $sessionID
	 *
	 * @return string
	 */
	public static function getPaymentIDWhereEqualToSessionID($sessionID){
		return PaymentMetaModel::get($sessionID, wilokeRepository('paymentKeys:paypal', true)->sub('paymentID'));
	}

	/**
	 * Get Agreement ID
	 *
	 * @param string $billingAgreementID
	 *
	 * @return string
	 */
	public static function getSessionIDWhereEqualToBillingAgreementID($billingAgreementID){
		return PaymentMetaModel::getSessionWhereEqualToMetaValue(wilokeRepository('paymentKeys:paypal', true)->sub('billingAgreementID'), $billingAgreementID);
	}

	/**
	 * Save Payment ID
	 *
	 * @param string $paymentID
	 * @param number $sessionID
	 *
	 * @return string
	 */
	public static function getSessionIDWhereEqualToPaymentID($paymentID){
		return PaymentMetaModel::getSessionWhereEqualToMetaValue(wilokeRepository('paymentKeys:paypal', true)->sub('paymentID'), $paymentID);
	}
}