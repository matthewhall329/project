<?php
namespace WilokeListgoFunctionality\Model;


use Carbon\Carbon;
use Symfony\Component\HttpKernel\Exception\NotAcceptableHttpException;
use WilokeListgoFunctionality\AlterTable\AlterTableInvoices;
use WilokeListgoFunctionality\AlterTable\AlterTablePlanRelationships;
use WilokeListgoFunctionality\AlterTable\AlterTableSessions;
use WilokeListgoFunctionality\Framework\Helpers\FindPostTypeByPlanType;
use WilokeListgoFunctionality\Framework\Helpers\Time;

class PlanRelationshipModel {
	public static $tblName;
	protected static $aRequiredColumns = array('planID', 'objectID', 'userID');

	public static function generateTableName(){
		global $wpdb;
		self::$tblName = $wpdb->prefix . AlterTablePlanRelationships::$tblName;
	}

	/**
	 * Inserting a new relationship
	 *
	 * @param array $aData
	 * @return mixed $ID
	 */
	public static function insert($aData){
		global $wpdb;
		self::generateTableName();

		foreach (self::$aRequiredColumns as $column){
			if ( !isset($aData[$column]) ){
				throw new NotAcceptableHttpException( sprintf(__('The %s value is required', 'wiloke'), $column) );
			}
		}

		$wpdb->insert(
			self::$tblName,
			array(
				'planID'            => $aData['planID'],
				'objectID'          => $aData['objectID'],
				'sessionID'         => $aData['sessionID'],
				'userID'            => $aData['userID'],
				'created_at_gmt'    => Carbon::now()->toAtomString()
			),
			array(
				'%d',
				'%d',
				'%d',
				'%d',
				'%s'
			)
		);

		return empty($wpdb->insert_id) || is_wp_error($wpdb->insert_id) ? false : $wpdb->insert_id;
	}

	/**
	 * Get Session ID by the specified conditionals
	 *
	 * @param array $aWhere
	 * @return  bool
	 */
	public static function updateEmptySessionID($sessionID, $aWhere){
		global $wpdb;
		self::generateTableName();

		$aWhere['value']['sessionID'] = 0;
		$aWhere['format'][] = '%d';

		return $wpdb->update(
			self::$tblName,
			array(
				'sessionID' => $sessionID,
				'created_at_gmt' => Carbon::now()->toAtomString()
			),
			$aWhere['value'],
			array(
				'%d',
				'%s'
			),
			$aWhere['format']
		);
	}


	/**
	 * Updating a row by specifying value
	 *
	 * @param array $aUpdate
	 * @param array $aWhere
	 */
	public static function update($aUpdate, $aWhere){
		global $wpdb;
		self::generateTableName();

		$wpdb->update(
			self::$tblName,
			$aUpdate['value'],
			$aUpdate['format'],
			$aWhere['value'],
			$aWhere['format']
		);
	}

	/**
	 * Deleting a row
	 *
	 * @param array $aWhere
	 */
	public static function deleteWherePlanIdEqualTo($aWhere){
		global $wpdb;
		self::generateTableName();

		$wpdb->delete(
			self::$tblName,
			$aWhere['value'],
			$aWhere['format']
		);
	}

	/**
	 * Deleting a row
	 *
	 * @param array $aWhere
	 */
	public static function deleteWhereSessionEqualTo($sessionID){
		global $wpdb;
		self::generateTableName();

		$wpdb->delete(
			self::$tblName,
			array(
				'sessionID' => $sessionID
			),
			array(
				'%d'
			)
		);
	}


	/**
	 * Count total items has been used by specifying the bottom block and period time
	 *
	 * @param string $bottomBlockTime
	 * @param number $period
	 * $param number $postAuthor
	 * $param number $planID
	 *
	 * @return number $numberOfID
	 */
	public static function countItemsUsedByBottomBlock($bottomBlockTime, $period, $postAuthor, $planID){
		global $wpdb;
		self::generateTableName();

		$numberOfIDs = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(objectID) FROM ".self::$tblName." WHERE (created_at_gmt BETWEEN %s AND DATE_ADD(%s, INTERVAL %d DAY)) AND userID=%d AND planID=%d",
				$bottomBlockTime, $bottomBlockTime, $period, $postAuthor, $planID
			)
		);

		return abs($numberOfIDs);
	}

	/**
	 * Count total items has been used by specifying the userId and Plan ID. It is useful to detect number of items were used in the free plan
	 *
	 * $param number $userID
	 * $param number $planID
	 *
	 * @return number $numberOfID
	 */
	public static function countItemsUsedByUserIDAndPlanID($userID,  $planID){
		global $wpdb;
		self::generateTableName();

		$numberOfIDs = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(objectID) FROM ".self::$tblName." WHERE userID=%d AND planID=%d",
				$userID, $planID
			)
		);

		return abs($numberOfIDs);
	}

	/**
	 * Count total items has been used by specifying the sub and period time
	 *
	 * @param string $upBlockTime
	 * @param number $period
	 * $param number $userID
	 * $param number $sessionID
	 * $param number $planID
	 *
	 * @return number $numberOfID
	 */
	public static function countItemsUsedByUpBlock($upBlockTime, $period, $userID, $sessionID, $planID){
		global $wpdb;
		self::generateTableName();

		$numberOfIDs = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(objectID) FROM ".self::$tblName." WHERE (created_at_gmt BETWEEN (%s - INTERVAL %d DAY - INTERVAL 5 MINUTE) AND %s) AND userID=%d AND sessionID=%d AND planID=%d",
				$upBlockTime, $period, $upBlockTime, $userID, $sessionID, $planID
			)
		);

		return abs($numberOfIDs);
	}

	/**
	 * Count total items has been used in the specified plan ID
	 *
	 * $param number $planID
	 * $param number $userID
	 * $param number $sessionID
	 *
	 * @return number $numberOfID
	 */
	public static function countItemsUsedBySessionIDAndPlanID($userID, $sessionID, $planID){
		global $wpdb;
		self::generateTableName();
		$numberOfIDs = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(objectID) FROM ".self::$tblName." WHERE  userID=%d AND sessionID=%d AND planID=%d",
				$userID, $sessionID, $planID
			)
		);

		return abs($numberOfIDs);
	}

	/**
	 * Get all Object IDs by the specified Session ID and planID
	 *
	 * @param number $sessionID
	 * @param number $planID
	 *
	 * @return array
	 */
	public static function getObjectIDWhereEqualToSessionIDAndPlanID($sessionID, $planID){
		global $wpdb;
		self::generateTableName();

		$aObjectID = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT objectID FROM ".self::$tblName." WHERE  sessionID=%d AND planID=%d",
				$sessionID, $planID
			),
			ARRAY_A
		);

		return $aObjectID;
	}

	/**
	 * Get planID by the specified Session ID
	 *
	 * @param number $sessionID
	 *
	 * @return number
	 */
	public static function getPlanIDWhereEqualToSessionID($sessionID){
		global $wpdb;
		self::generateTableName();

		$planID = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT planID FROM ".self::$tblName." WHERE  sessionID=%d",
				$sessionID
			)
		);

		return abs($planID);
	}

	public static function getAllInfoWhereEqualToSessionID($sessionID){
		global $wpdb;
		self::generateTableName();

		$aInfo = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM ".self::$tblName." WHERE  sessionID=%d",
				$sessionID
			),
			ARRAY_A
		);

		return $aInfo;
	}

	/**
	 * Change Plan
	 *
	 * @param number $newPlanID
	 * @param number $sessionID
	 * @param number $currentPlanID
	 *
	 * @return bool
	 */
	public static function updateNewPlanWhereEqualToSessionIDAndPlanID($newPlanID, $sessionID, $currentPlanID){
		global $wpdb;
		$tblName = $wpdb->prefix . AlterTablePlanRelationships::$tblName;

		return $wpdb->update(
			$tblName,
			array(
				'planID' => $newPlanID
			),
			array(
				'sessionID' => $sessionID,
				'planID'    => $currentPlanID
			),
			array(
				'%d'
			),
			array(
				'%d',
				'%d'
			)
		);
	}

	/**
	 * Get user ID By Session ID
	 *
	 * @param number $sessionID
	 * @param number $planID
	 * @param number $nextBillingDate
	 *
	 * @return array
	 */
	public static function getObjectIDsCreatedBefore($sessionID, $nextBillingDate){
		global $wpdb;
		$tblName = $wpdb->prefix . AlterTablePlanRelationships::$tblName;

		$aPostIDs = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT objectID FROM $tblName WHERE sessionID=%d AND created_at_gmt <= %s",
				$sessionID, Time::toAtomUTC($nextBillingDate)
			),
			ARRAY_A
		);

		return $aPostIDs;
	}

	/**
	 * Get all posts belongs to Session IDs
	 *
	 * @param number $sessionID
	 *
	 * @return array $aPostIDs
	 */
	public static function getObjectIDsWhereEqualToSessionID($sessionID){
		global $wpdb;
		$tblName = $wpdb->prefix . AlterTablePlanRelationships::$tblName;

		$aPostIDs = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT objectID FROM $tblName WHERE sessionID=%d",
				$sessionID
			),
			ARRAY_A
		);

		return $aPostIDs;
	}

	/**
	 * Count all non-recurring publish posts
	 *
	 * @return number $total
	 */
	public static function countAllNonRecurringPublishPosts(){
		global $wpdb;
		$relationShipTbl = $wpdb->prefix . AlterTablePlanRelationships::$tblName;
		$postsTbl = $wpdb->posts;
		$sessionTbl = $wpdb->prefix . AlterTableSessions::$tblName;

		$total = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT($relationShipTbl.objectID) FROM $relationShipTbl LEFT JOIN $sessionTbl ON ($sessionTbl.ID=$relationShipTbl.sessionID) LEFT JOIN $postsTbl ON ($relationShipTbl.objectID = $postsTbl.ID) WHERE $sessionTbl.billing_type=%s AND $postsTbl.post_status=%s",
				wilokeRepository('app:billingTypes', true)->sub('nonrecurring'), 'publish'
			)
		);

		return abs($total);
	}

	/**
	 * Get all posts that belong to non-recurring plan
	 *
	 * @return mixed
	 */
	public static function getNonRecurringPublishPosts(){
		global $wpdb;

		$totalPosts = self::countAllNonRecurringPublishPosts();
		if ( empty($totalPosts) ){
			return false;
		}

		$limit = $totalPosts > 100 ? ceil($totalPosts/ 4 ) : $totalPosts;

		$relationShipTbl = $wpdb->prefix . AlterTablePlanRelationships::$tblName;
		$postsTbl = $wpdb->posts;
		$sessionTbl = $wpdb->prefix . AlterTableSessions::$tblName;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT $relationShipTbl.objectID, $relationShipTbl.planID, $relationShipTbl.created_at_gmt, $sessionTbl.status FROM $relationShipTbl LEFT JOIN $sessionTbl ON ($sessionTbl.ID=$relationShipTbl.sessionID) LEFT JOIN $postsTbl ON ($relationShipTbl.objectID = $postsTbl.ID) WHERE $sessionTbl.billing_type=%s AND $postsTbl.post_status=%s ORDER BY $relationShipTbl.objectID DESC LIMIT $limit",
				wilokeRepository('app:billingTypes', true)->sub('nonrecurring'), 'publish'
			)
		);
	}
}