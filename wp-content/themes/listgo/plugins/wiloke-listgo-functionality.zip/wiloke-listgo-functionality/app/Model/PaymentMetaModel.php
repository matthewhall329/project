<?php
namespace WilokeListgoFunctionality\Model;


use WilokeListgoFunctionality\AlterTable\AlterTablePaymentMeta;

class PaymentMetaModel {
	public static $tblName;

	/**
	 * @return void
	 */
	public static function generateTableName($wpdb){
		self::$tblName = $wpdb->prefix . AlterTablePaymentMeta::$tblName;
	}

	/**
	 * Set Payment Meta
	 *
	 * @param number $sessionID
	 * @param string $metaKey
	 * @param mixed $val
	 *
	 * @return bool
	 */
	public static function set($sessionID, $metaKey, $val){
		global $wpdb;
		self::generateTableName($wpdb);

		if ( empty(self::get($sessionID, $metaKey)) ){
			return $wpdb->insert(
				self::$tblName,
				array(
					'sessionID' => $sessionID,
					'meta_key'  => $metaKey,
					'meta_value'=> maybe_serialize($val)
				),
				array(
					'%d',
					'%s',
					'%s'
				)
			);
		}else{
			return self::patch($sessionID, $metaKey, $val);
		}
	}

	public static function patch($sessionID, $metaKey, $val){
		global $wpdb;
		self::generateTableName($wpdb);

		return $wpdb->update(
			self::$tblName,
			array(
				'meta_value' => maybe_serialize($val)
			),
			array(
				'sessionID' => $sessionID,
				'meta_key' => $metaKey,
			),
			array(
				'%s'
			),
			array(
				'%d',
				'%s'
			)
		);
	}

	public static function update($sessionID, $metaKey, $val){
		return self::patch($sessionID, $metaKey, $val);
	}

	/**
	 * Get Payment Meta by specifying meta key and sessionID
	 *
	 * @param number $sessionID
	 * @param string $metaKey
	 *
	 * @return mixed
	 */
	public static function get($sessionID, $metaKey){
		global $wpdb;
		self::generateTableName($wpdb);

		$aResult = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT meta_value FROM ".self::$tblName. " WHERE sessionID=%d AND meta_key=%s ORDER BY ID DESC",
				$sessionID, $metaKey
			)
		);

		if ( empty($aResult) ){
			return false;
		}

		return maybe_unserialize($aResult);
	}

	/**
	 * Get Session ID By Meta Value
	 *
	 * @param string $metaValue
	 * @return number $sessionID
	 */
	public static function getSessionWhereEqualToMetaValue($metaKey, $metaVal){
		global $wpdb;
		self::generateTableName($wpdb);

		$sessionID = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT sessionID FROM ".self::$tblName. " WHERE meta_key=%s AND meta_value=%s",
				$metaKey, $metaVal
			)
		);

		return abs($sessionID);
	}
}