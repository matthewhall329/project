<?php

namespace WilokeListgoFunctionality\Model;


use WilokeListgoFunctionality\AlterTable\AlterTableSessions;
use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
use WilokeListgoFunctionality\Framework\Helpers\SetSettings;

class StripeModel {
	protected static $gateway = 'stripe';

	/**
	 * Get Agreement ID by the specified $sessionID and $metaKey
	 *
	 * @param number $sessionID
	 * @param string $metaKey
	 *
	 * @return $subscriptionID
	 */
	public static function getSubscriptionID($sessionID){
		$oPaymentInfo = PaymentMetaModel::get($sessionID, wilokeRepository('paymentKeys:info'));

		if ( empty($oPaymentInfo) ){
			return false;
		}

		if ( is_array($oPaymentInfo) ){
			settype($oPaymentInfo, 'object');
		}

		if ( !isset($oPaymentInfo->id) ){
			return false;
		}

		return $oPaymentInfo->id;
	}

	/**
	 * Get Last Suspended status by specified Plan ID and User ID
	 *
	 * @param number $planID
	 * @param number $userID
	 *
	 * @return mixed $sessionID
	 */
	public static function getUserLastSuspendedSessionIDEnqualToPlanID($userID, $planID){
		global $wpdb;
		$tblName = $wpdb->prefix . AlterTableSessions::$tblName;

		$sessionID = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID FROM {$tblName} WHERE userID=%d  AND planID=%d AND billing_type=%s AND status=%s AND gateway=%s ORDER BY ID DESC",
				$userID, $planID, wilokeRepository('app:billingTypes', true)->sub('recurring'), wilokeRepository('app:paymentStatus', true)->sub('suspended'), self::$gateway
			)
		);

		if ( empty($sessionID) ){
			return false;
		}

		return $sessionID;
	}

	/**
	 * Updating Token ID
	 *
	 * @param string $tokenID
	 *
	 * @return bool
	 */
	public static function updateSessionToken($tokenID, $userID=null){
		$userID = $userID === null ? get_current_user_id() : $userID;

		SetSettings::setUserMeta($userID, wilokeRepository('app:stripe', true)->sub('tokenID'), $tokenID);
	}

	/**
	 * Get Token ID
	 *
	 * @param string $tokenID
	 * @return bool
	 */
	public static function getSessionToken($userID){
		return GetSettings::getUserMeta($userID, wilokeRepository('app:stripe', true)->sub('tokenID'));
	}

	/**
	 * Updating Customer ID
	 *
	 * @param string $chargeID
	 * @param number $sessionID
	 *
	 * @return bool
	 */
	public static function setChargeID($chargeID, $sessionID){
		return PaymentMetaModel::set($sessionID, wilokeRepository('paymentKeys:stripe', true)->sub('chargeID'), $chargeID);
	}

	/**
	 * Updating Customer ID
	 *
	 * @param number $sessionID
	 *
	 * @return string $chargeID
	 */
	public static function getChargeIDWhereEqualToSessionID($sessionID){
		return PaymentMetaModel::get($sessionID, wilokeRepository('paymentKeys:stripe', true)->sub('chargeID'));
	}

	/**
	 * Updating Customer ID
	 *
	 * @param string $chargeID
	 *
	 * @return number $sessionID
	 */
	public static function getSessionIDWhereEqualToChargeID($chargeID){
		return PaymentMetaModel::getSessionWhereEqualToMetaValue(wilokeRepository('paymentKeys:stripe', true)->sub('chargeID'), $chargeID);
	}


	/**
	 * Updating Customer ID
	 *
	 * @param string $customerID
	 *
	 * @return bool
	 */
	public static function updateCustomerID($customerID, $userID=null){
		$userID = $userID === null ? get_current_user_id() : $userID;

		SetSettings::setUserMeta($userID, wilokeRepository('app:stripe', true)->sub('customerID'), $customerID);
	}

	public static function deleteCustomerID($userID=null){
		$userID = empty($userID) ? get_current_user_id() : $userID;
		return delete_user_meta($userID, wilokeRepository('app:stripe', true)->sub('customerID'));
	}

	/**
	 * Updating Customer ID
	 *
	 * @param string $subscriptionID
	 * @param number $sessionID
	 *
	 * @return bool
	 */
	public static function setSubscriptionID($subscriptionID, $sessionID){
		PaymentMetaModel::set($sessionID, wilokeRepository('paymentKeys:stripe', true)->sub('subscriptionID'), $subscriptionID);
	}

	/**
	 * Updating Customer ID
	 *
	 * @param string $subscriptionID
	 * @param number $sessionID
	 *
	 * @return number
	 */
	public static function getSessionIDWhereEqualToSubscriptionID($subscriptionID){
		return PaymentMetaModel::getSessionWhereEqualToMetaValue(wilokeRepository('paymentKeys:stripe', true)->sub('subscriptionID'), $subscriptionID);
	}

	/**
	 * Get Customer ID
	 *
	 * @param number $userID
	 *
	 * @return mixed
	 */
	public static function getCustomerID($userID){
		return GetSettings::getUserMeta($userID, wilokeRepository('app:stripe', true)->sub('customerID'));
	}
}