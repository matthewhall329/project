<?php
namespace WilokeListgoFunctionality\Model;


class PostsModel{
	public static function updatePostsStatus($aPostIDs, $status){
		global $wpdb;
		$postTbl = $wpdb->posts;

		$wpdb->query($wpdb->prepare(
			"UPDATE ".$postTbl." SET post_status=%s WHERE ID IN (".implode(',', $aPostIDs).")",
			$status
		));
	}

	public static function updatePostStatus($postID, $status){
		wp_update_post(
			array(
				'ID' => $postID,
				'post_status' => $status
			)
		);
	}
}