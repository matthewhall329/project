<?php
namespace WilokeListgoFunctionality\Model;


use WilokeListgoFunctionality\AlterTable;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;

class EventModel{
	public static $postType = 'event';
	public static $eventSettingsKey = 'event_settings';

	public static function updateEventsStatus($paymentID, $status){
		global $wpdb;
		$tbl = $wpdb->prefix . AlterTable\AlterTablePaymentRelationships::$tblName;

		$aEventIDs = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT event_ID FROM $tbl WHERE payment_ID=%d",
				$paymentID
			)
		);

		foreach ( $aEventIDs as $oEvent ){
			wp_update_post(
				array(
					'ID' => $oEvent->event_ID,
					'post_status' => $status
				)
			);
		}
	}

	public static function countAllDraftEvents(){
		global $wpdb;
		$postTbl = $wpdb->posts;

		$period = PaymentConfiguration::getField('delete_listing_conditional');
		$period = empty($period) ? 24 : abs($period);

		return $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(ID) FROM $postTbl WHERE post_type=%s AND post_status=%s AND DATE_SUB(CURRENT_DATE, INTERVAL %d HOUR)",
				self::$postType, 'draft', $period
			)
		);
	}

	public static function countAllPublishEvents(){
		global $wpdb;
		$postTbl = $wpdb->posts;

		return $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(ID) FROM $postTbl WHERE post_type=%s AND post_status=%s",
				self::$postType, 'publish'
			)
		);
	}

	public static function checkEventStatus($aEventSettings){
		$timeZone = '';
		if ( !empty($aEventSettings['belongs_to']) ){
			$aLocation = wp_get_post_terms($aEventSettings['belongs_to'], 'listing_location');
			if ( !empty($aLocation) && !is_wp_error($aLocation) ){
				$oLocation = end($aLocation);
				$aLocationData = \Wiloke::getTermOption($oLocation->term_id);
				if ( isset($aLocationData['timezone']) ){
					$timeZone = $aLocationData['timezone'];
				}
			}
		}

		date_default_timezone_set(\WilokePublic::timezoneString($timeZone));
		$now   = time();
		$start = trim($aEventSettings['start_on']) . ' ' . trim($aEventSettings['start_at']);
		$start = strtotime($start);

		$end = trim($aEventSettings['end_on']) . ' ' . trim($aEventSettings['end_at']);
		$end = strtotime($end);

		if ( $now > $end ){
			return array(
				'status'    => 'expired',
				'name'      => __('Expired', 'wiloke'),
				'longname'  => __('Expired Event', 'wiloke')
			);
		}else if ( $now < $start ){
			return array(
				'status' => 'upcomming',
				'name'   => __('Upcoming', 'wiloke'),
				'longname'  => __('Upcoming Event', 'wiloke')
			);
		}else{
			return array(
				'status' => 'ongoing',
				'name'   => __('Ongoing', 'wiloke'),
				'longname'  => __('Ongoing Event', 'wiloke')
			);
		}
	}

	public static function getExpiredEvents(){
		$total = self::countAllPublishEvents();
		if ( empty($total) ){
			return false;
		}

		$numberOfEvents = $total <= 100 ? $total : ceil($total/4);

		$query = new \WP_Query(
			array(
				'post_type'         => self::$postType,
				'post_status'       => 'publish',
				'posts_per_page'    => $numberOfEvents
			)
		);

		$aExpiredEvents = array();
		if ( $query->have_posts() ){
			while ($query->have_posts()){
				$query->the_post();
				$aEventSettings = \Wiloke::getPostMetaCaching($query->post->ID, self::$eventSettingsKey);
				$aEventStatus = self::checkEventStatus($aEventSettings);
				if ( $aEventStatus['status'] == 'expired' ){
					$aExpiredEvents[] = $query->post->ID;
				}
			}
			wp_reset_postdata();
		}

		return $aExpiredEvents;
	}

	public static function getDraftEvents(){
		global $wpdb;
		$postTbl = $wpdb->posts;

		$total = self::countAllDraftEvents();

		if ( empty($total) ){
			return false;
		}

		$period = PaymentConfiguration::getField('delete_listing_conditional');
		$period = empty($period) ? 24 : abs($period);
		$numberOfEvents = $total <= 100 ? $total : ceil($total/4);

		$aEvents = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID FROM $postTbl WHERE post_type=%s AND post_status=%s AND DATE_SUB(CURRENT_DATE, INTERVAL %d HOUR) ORDER BY ID DESC LIMIT $numberOfEvents",
				self::$postType, 'draft', $period
			),
			ARRAY_A
		);

		return $aEvents;
	}

	public static function getUserEventPlan($userID){
		$aEventPlans = UserModel::getUserPlansByPlanType($userID, 'event-pricing');
		
		if ( empty($aEventPlans) ){
			return false;
		}

		return end($aEventPlans);
	}

	public static function getUserEventPlanDetail($userID, $eventID){
		$aEventPlans = self::getUserEventPlan($userID);
		if ( empty($aEventPlans) ){
			return false;
		}

		return isset($aEventPlans[$eventID]) ? $aEventPlans[$eventID] : false;
	}
}