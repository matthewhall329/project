<?php
namespace WilokeListgoFunctionality\Model;


use WilokeListgoFunctionality\AlterTable\AlterTableSessions;
use WilokeListgoFunctionality\Framework\Config\Repository;
use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
use WilokeListgoFunctionality\Framework\Helpers\SetSettings;
use WilokeListgoFunctionality\Framework\Store\Cookie;
use WilokeListgoFunctionality\Framework\Store\Session;
use WilokeListgoFunctionality\Framework\Helpers\GeneratePrefix;

class UserModel{
	protected $userID;
	protected $planType; // listing plan, event plan
	protected $nextBillingDate;
	protected $detailPaymentID;
	protected $planID;
	protected $sessionID;
	protected $billingType;
	protected static $userPlansKey = 'user_plans';
	protected static $recurringKey = 'RecurringPayment';
	protected static $nonRecurring = 'NonRecurringPayment';
	protected static $aPlans;
	protected $gateway;
	protected $addListingMode;

	public static function generateKey(){
		return GeneratePrefix::generateKey(self::$userPlansKey);
	}
	
	/*
	 * Set Plan Functions
	 * @since 1.0
	 */
	public static function getPlansByUserID($userID){
		$aPlans = get_user_meta($userID, self::generateKey(), true);
		return $aPlans;
	}

	public function setEventPlan(){
		$aPlans = self::getAllPlansByUserID($this->userID);
		$nextBillingDate = is_string($this->nextBillingDate) ? strtotime($this->nextBillingDate) : $this->nextBillingDate;
		$aEventPlans = GetSettings::getPostMeta($this->planID, 'event_pricing_settings');
		$aNewPlan = array(
			'nextBillingDate'   => $nextBillingDate,
			'gateway'           => $this->gateway,
			'sessionID'         => $this->sessionID,
			'billingType'       => $this->billingType,
			'planID'            => $this->planID,
			'remainingItems'	=> $aEventPlans['number_of_posts']
		);

		if ( empty($aPlans) ){
			$aPlans = array(
				$this->planType => array(
					$this->planID => $aNewPlan
				)
			);
		}else{
			unset($aPlans[$this->planType][$this->planID]);
			$aPlans[$this->planType][$this->planID] = $aNewPlan;
		}

		update_user_meta($this->userID, self::generateKey(), $aPlans);
	}

	public function setUserPlan(){
		$aPlans = self::getAllPlansByUserID($this->userID);
		$nextBillingDate = is_string($this->nextBillingDate) ? strtotime($this->nextBillingDate) : $this->nextBillingDate;
		$aNewPlan = array(
			'nextBillingDate'   => $nextBillingDate,
			'gateway'           => $this->gateway,
			'sessionID'         => $this->sessionID,
			'billingType'       => $this->billingType,
			'planID'            => $this->planID
		);

		if ( empty($aPlans) ){
			$aPlans = array(
				$this->planType => array(
					$this->planID => $aNewPlan
				)
			);
		}else{
			unset($aPlans[$this->planType][$this->planID]);
			$aPlans[$this->planType][$this->planID] = $aNewPlan;
		}

		update_user_meta($this->userID, self::generateKey(), $aPlans);
		self::updateUserRemainingItemsByPlanID($this->userID, $this->planID);

		if ( $this->billingType == wilokeRepository('app:billingTypes', true)->sub('recurring') ){
			if ( PaymentMetaModel::get($this->sessionID, wilokeRepository('paymentKeys:nextBillingDate')) ){
				PaymentMetaModel::patch($this->sessionID, wilokeRepository('paymentKeys:nextBillingDate'), $nextBillingDate);
			}else{
				PaymentMetaModel::set($this->sessionID, wilokeRepository('paymentKeys:nextBillingDate'), $nextBillingDate);
			}
		}
		do_action('wiloke-submission/update-user-plan-cookie', GetSettings::getUserData($this->userID));
	}

	public function setAddListingMode($addListingMode=null){
		$this->addListingMode = empty($addListingMode) ? wilokeRepository('app:addListingMode', true)->sub('selectPlan') : trim($addListingMode);
	}

	public static function updateUserNextBillingDateWhereEqualToPlanID($userID, $planID, $nextBillingDate){
		$aPlans = self::getAllPlansByUserID($userID);
		$sessionID = $aPlans[get_post_type($planID)][$planID]['sessionID'];
		$aPlans[get_post_type($planID)][$planID]['nextBillingDate'] = is_string($nextBillingDate) ? strtotime($nextBillingDate) : $nextBillingDate;
		
		if ( PaymentMetaModel::get($sessionID, wilokeRepository('paymentKeys:nextBillingDate')) ){
			PaymentMetaModel::patch($sessionID, wilokeRepository('paymentKeys:nextBillingDate'), $nextBillingDate);
		}else{
			PaymentMetaModel::set($sessionID, wilokeRepository('paymentKeys:nextBillingDate'), $nextBillingDate);
		}

		update_user_meta($userID, self::generateKey(), $aPlans);
	}

	public static function updateUserNewPlanWhereEqualToPlanID($userID, $currentPlanID, $newPlanID){
		$aPlans                 = self::getAllPlansByUserID($userID);
		$postType               = get_post_type($currentPlanID);
		$aCurrentPlan           = $aPlans[$postType][$currentPlanID];
		$aCurrentPlan['planID'] = $newPlanID;
		unset($aPlans[$postType][$currentPlanID]);
		$aPlans[$postType][$newPlanID] = $aCurrentPlan;

		update_user_meta($userID, self::generateKey(), $aPlans);
	}

	public static function updateUserRemainingItemsByPlanID($userID, $planID){
		$planType = get_post_field('post_type', $planID);
		$aPlans   = self::getAllPlansByUserID($userID);
		$aPlans[$planType][$planID]['remainingItems'] = wilokeGetRemainingItems($planID, $aPlans[$planType][$planID], $userID)->remainingItems();
		update_user_meta($userID, self::generateKey(), $aPlans);
		do_action('wiloke-submission/app/model/usermodel/updateUserRemainingItemsByPlanID', $userID, $planID);
	}

	public function setBillingType($billingType){
		if ( $billingType == wilokeRepository('app:billingTypes', true)->sub('nonrecurring') ){
			$this->billingType = self::$nonRecurring;
		}else{
			$this->billingType = self::$recurringKey;
		}

		return $this;
	}

	public function setGateway($gateway){
		$this->gateway = $gateway;
		return $this;
	}

	public function setUserID($userID){
		$this->userID = $userID;
		return $this;
	}

	public function setPlanID($planID){
		$this->planID = $planID;
		$this->setPlanType();
		return $this;
	}

	public function setPlanType(){
		$this->planType = get_post_field('post_type', $this->planID);
		return $this;
	}

	public function setNextBillingDate($nextBillingDate){
		$this->nextBillingDate = $nextBillingDate;
		return $this;
	}

	public function setSessionID($sessionID){
		$this->sessionID = $sessionID;
		return $this;
	}

	/**
	 * Save the id of the recurring/nonrecurring payment id
	 */
	public function setDetailPaymentID($detailPaymentID){
		$this->detailPaymentID = $detailPaymentID;
		return $this;
	}

	/*
	 * Get Plan Functions
	 * @since 1.0
	 */
	public static function getAllPlansByUserID($userID){
		return get_user_meta($userID, self::generateKey(), true);
	}

	public static function getAllPlans($isFocus=false){
		if ( $isFocus || empty(self::$aPlans) ){
			self::$aPlans = self::getAllPlansByUserID(get_current_user_id());
			return self::$aPlans;
		}else{
			return self::$aPlans;
		}
	}

	public static function getPlansByPlanType($planType){
		self::getAllPlans();
		if ( !isset(self::$aPlans[$planType]) ){
			return false;
		}
		return self::$aPlans[$planType];
	}

	public static function getLatestPlanByPlanType($planType){
		self::getAllPlans();
		if ( !isset(self::$aPlans[$planType]) ){
			return false;
		}
		return end(self::$aPlans[$planType]);
	}

	public static function getUserPlansByPlanType($userID, $planType){
		$aUserPlans = self::getAllPlansByUserID($userID);
		if ( !isset($aUserPlans[$planType]) ){
			return false;
		}
		return $aUserPlans[$planType];
	}

	public static function getDetailPlan($planID){
		$planType = get_post_field('post_type', $planID);
		$aPlans = self::getPlansByPlanType($planType);

		if ( !$aPlans ){
			return false;
		}
		if ( !isset($aPlans[$planID]) ){
			return false;
		}
		return $aPlans[$planID];
	}

	public static function getUserDetailPlan($userID, $planID){
		$planType = get_post_field('post_type', $planID);
		$aPlans = self::getUserPlansByPlanType($userID, $planType);
		if ( !$aPlans ){
			return false;
		}

		if ( !isset($aPlans[$planID]) ){
			return false;
		}

		return $aPlans[$planID];
	}

	/*
	 * Remove Plan
	 * @since 1.0
	 */
	public static function removePlanType($planType){
		$userID = get_current_user_id();
		self::removeUserPlanType($userID, $planType);
		do_action('wiloke-submission/update-user-plan-cookie', GetSettings::getUserData($userID));
	}

	public static function removeUserPlanType($userID, $planType){
		$aPlans = self::getAllPlansByUserID($userID);
		if ( !isset($aPlans[$planType]) ){
			return false;
		}

		unset($aPlans[$planType]);
		update_user_meta($userID, self::generateKey(), $aPlans);

		do_action('wiloke-submission/update-user-plan-cookie', GetSettings::getUserData($userID));
	}

	public static function removePlan($planID){
		$userID = get_current_user_id();
		self::removeUserPlanByPlanID($userID, $planID);
		do_action('wiloke-submission/update-user-plan-cookie', GetSettings::getUserData($userID));
	}

	public static function removeUserPlanByPlanID($userID, $planID){
		$planType = get_post_type($planID);
		$aPlans = self::getAllPlansByUserID($userID);
		if ( !isset($aPlans[$planType]) ){
			return false;
		}

		if ( !isset($aPlans[$planType][$planID]) ){
			return false;
		}

		unset($aPlans[$planType][$planID]);

		update_user_meta($userID, self::generateKey(), $aPlans);

		do_action('wiloke-submission/app/model/usermodel/updateUserRemainingItemsByPlanID', $userID);
	}

	public static function saveCardInfo($aData, $userID=null){
		$userID = empty($userID) ? get_current_user_id() : $userID;
		SetSettings::setUserMeta($userID, wilokeRepository('app:card_info'), $aData);
	}

	public static function getCardInfo($userID){
		return GetSettings::getUserMeta($userID, wilokeRepository('app:card_info'));
	}

	public static function getUserEventPlan($userID){
		$aEventPlans = self::getUserPlansByPlanType($userID, 'event-pricing');
		if ( empty($aEventPlans) ){
			return false;
		}

		return end($aEventPlans);
	}

	public static function getUserEventPlanDetail($userID, $eventID){
		$aEventPlans = self::getUserEventPlan($userID);
		if ( empty($aEventPlans) ){
			return false;
		}

		return isset($aEventPlans[$eventID]) ? $aEventPlans[$eventID] : false;
	}
}