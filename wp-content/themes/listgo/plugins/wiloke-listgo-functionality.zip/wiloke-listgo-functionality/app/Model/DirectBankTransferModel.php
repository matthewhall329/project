<?php
namespace WilokeListgoFunctionality\Model;


use WilokeListgoFunctionality\Framework\Helpers\GetSettings;

class DirectBankTransferModel {
	/**
	 * Get Session ID By Invoice ID
	 *
	 * @param string $invoiceID
	 *
	 * @return bool
	 */
	public static function updateNewPlanInfo($newPlanID, $sessionID){
		$aPaymentMeta = PaymentMetaModel::get($sessionID, wilokeRepository('paymentKeys:info'));

		$aPaymentMeta['plan']   = array(
			'ID'    => $newPlanID,
			'name'  => get_the_title($newPlanID),
			'type'  => get_post_type($newPlanID),
			'info'  => GetSettings::getPostMeta($newPlanID, get_post_type($newPlanID))
		);

		return PaymentMetaModel::update($sessionID, wilokeRepository('paymentKeys:info'), $aPaymentMeta);
	}
}