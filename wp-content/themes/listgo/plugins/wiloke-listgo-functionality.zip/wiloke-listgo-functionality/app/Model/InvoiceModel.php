<?php
namespace WilokeListgoFunctionality\Model;

use Carbon\Carbon;
use WilokeListgoFunctionality\AlterTable\AlterTableInvoices;

class InvoiceModel{
	public static $tblName;

	public static function generateTableName($wpdb){
		self::$tblName = $wpdb->prefix . AlterTableInvoices::$tblName;
	}

	/*
	 * Insert a new invoice
	 *
	 * @param array $aInfo
	 *
	 * @return mixed $insertID or failed
	 */
	public static function insert($aInfo){
		global $wpdb;
		self::generateTableName($wpdb);
		$billedAt = current_time(DATE_ATOM);
		$status = $wpdb->insert(
			self::$tblName,
			array(
				'sessionID'     => $aInfo['sessionID'],
				'regular_price' => $aInfo['regular_price'],
				'discount'      => isset($aInfo['discount']) ? $aInfo['discount'] : 0,
				'currency'      => $aInfo['currency'],
				'message'       => maybe_serialize($aInfo['message']),
				'created_at'    => $billedAt
			),
			array(
				'%d',
				'%s',
				'%s',
				'%s',
				'%s',
				'%s'
			)
		);
		$aInfo['invoiceID'] = $wpdb->insert_id;
		$aInfo['billed_at'] = $billedAt;

		if ( $status ){
			do_action('wiloke-submission/mail', array(
				'type'     => wilokeRepository('mailstatus:type', true)->sub('paymentSucceeded'),
				'aInfo'    => $aInfo
			));
		}

		return $status;
	}

	public static function getIDWhereEqualToSessionID($sessionID){
		global $wpdb;
		self::generateTableName($wpdb);

		return $wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID FROM ".self::$tblName." WHERE sessionID=%d",
				$sessionID
			)
		);
	}

	public static function update($invoiceID, $sessionID, $message){
		global $wpdb;
		self::generateTableName($wpdb);

		return $wpdb->update(
			self::$tblName,
			array(
				'message'    => $message,
				'updated_at' => current_time(DATE_ATOM)
			),
			array(
				'sessionID' => $sessionID,
				'ID'        => $invoiceID
			),
			array(
				'%s',
				'%s'
			),
			array(
				'%d',
				'%d'
			)
		);
	}

	public static function deleteWhereEqualToSession($sessionID){
		global $wpdb;
		self::generateTableName($wpdb);

		return $wpdb->delete(
			self::$tblName,
			array(
				'sessionID' => $sessionID
			),
			array(
				'%d'
			)
		);
	}
}