<?php
namespace WilokeListgoFunctionality\Model;


use WilokeListgoFunctionality\Framework\Config\Repository;
use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
use WilokeListgoFunctionality\Framework\Helpers\SetSettings;
use WilokeListgoFunctionality\Framework\Store\Cookie;
use WilokeListgoFunctionality\Framework\Store\Session;
use WilokeListgoFunctionality\Framework\Helpers\GeneratePrefix;

class AddEventPlan{
	protected $userID;
	protected $planType = 'event-pricing'; // listing plan, event plan

	public static function getUserRemainingEvents($userID){
		$aEventPlans = UserModel::getUserEventPlan($userID);
		
		if ( empty($aEventPlans) ){
			return false;
		}

		return ($aEventPlans['remainingItems']);
	}
}