<?php
namespace WilokeListgoFunctionality\Model;


use WilokeListgoFunctionality\AlterTable\AlterTableRecurringPayment;

class RecurringPaymentModel {
	public static $tblName;

	public static function generateTableName($wpdb){
		self::$tblName = $wpdb->prefix . AlterTableRecurringPayment::$tblName;
	}

	/**
	 * Inserting new recurring payment info
	 *
	 * @param number $sessionID
	 * @param string $period (it has  to be smaller than or equal to 365
	 * @param mixed $nextBillingDate
	 *
	 * @return number $insertID
	 */
	public static function insert($sessionID, $nextBillingDate){
		global $wpdb;
		self::generateTableName($wpdb);

		$wpdb->insert(
			self::$tblName,
			array(
				'sessionID' => $sessionID,
				'next_billing_date' => $nextBillingDate
			),
			array(
				'%d',
				'%s'
			)
		);

		return $wpdb->insert_id;
	}

	/**
	 * Updating a row by the specified session ID
	 *
	 * @param array $aValue
	 * @param number $sessionID
	 *
	 * @return bool
	 */
	public static function updateWhereEqualToSessionID($aValue, $sessionID){
		global $wpdb;
		self::generateTableName($wpdb);

		return $wpdb->update(
			self::$tblName,
			$aValue['value'],
			array(
				'sessionID' => $sessionID,
			),
			$aValue['format'],
			array(
				'%d'
			)
		);
	}
}