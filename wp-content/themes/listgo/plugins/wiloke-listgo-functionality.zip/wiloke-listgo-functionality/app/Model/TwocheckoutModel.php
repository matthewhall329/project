<?php
namespace WilokeListgoFunctionality\Model;


class TwocheckoutModel {
	/**
	 * Get Sale ID
	 *
	 * @param number $sessionID
	 *
	 * @return string $saleID
	 */
	public static function getSaleID($sessionID){
		return PaymentMetaModel::get($sessionID, wilokeRepository('app:2checkout', true)->sub('saleID'));
	}


	/**
	 * Get Invoice ID
	 *
	 * @param number $sessionID
	 *
	 * @return string $invoiceID
	 */
	public static function getInvoiceID($sessionID){
		return PaymentMetaModel::get($sessionID, wilokeRepository('app:2checkout', true)->sub('invoiceID'));
	}

	public static function getTransactionID($sessionID){
		return PaymentMetaModel::get($sessionID, wilokeRepository('app:2checkout', true)->sub('invoiceID'));
	}


	/**
	 * Update Sale ID
	 *
	 * @param number $sessionID
	 * @param string $saleID
	 *
	 * @return bool
	 */
	public static function updateSaleID($sessionID, $saleID){
		return PaymentMetaModel::set($sessionID, wilokeRepository('app:2checkout', true)->sub('saleID'), $saleID);
	}

	/**
	 * Invoice ID
	 *
	 * @param number $sessionID
	 * @param string $invoiceID
	 *
	 * @return bool
	 */
	public static function updateInvoiceID($sessionID, $invoiceID){
		return PaymentMetaModel::set($sessionID, wilokeRepository('app:2checkout', true)->sub('invoiceID'), $invoiceID);
	}

	/**
	 * Invoice ID
	 *
	 * @param number $sessionID
	 * @param string $transactionID
	 *
	 * @return bool
	 */
	public static function updateTransactionID($sessionID, $transactionID){
		return self::updateInvoiceID($sessionID, $transactionID);
	}

	/**
	 * Get Session ID By Sale ID
	 *
	 * @param string $saleID
	 * @return number $sessionID
	 */
	public static function getSessionIDBySaleID($saleID){
		return PaymentMetaModel::getSessionWhereEqualToMetaValue(wilokeRepository('app:2checkout', true)->sub('saleID'), $saleID);
	}

	/**
	 * Get Session ID By Invoice ID
	 *
	 * @param string $invoiceID
	 * @return number $sessionID
	 */
	public static function getSessionIDByInvoiceID($invoiceID){
		return PaymentMetaModel::getSessionWhereEqualToMetaValue(wilokeRepository('app:2checkout', true)->sub('invoiceID'), $invoiceID);
	}
}