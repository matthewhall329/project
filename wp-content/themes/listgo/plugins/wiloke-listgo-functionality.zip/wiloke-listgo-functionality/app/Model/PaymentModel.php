<?php
namespace WilokeListgoFunctionality\Model;

use WilokeListgoFunctionality\Framework\Helpers\General;
use WilokeListgoFunctionality\Framework\Payment\PaymentMethodInterface;
use WilokeListgoFunctionality\Framework\Payment\Receipt;
use WilokeListgoFunctionality\AlterTable\AlterTableSessions;

class PaymentModel{
	protected static $tblName;

	protected static function createTblName(){
		global $wpdb;
		self::$tblName = $wpdb->prefix . AlterTableSessions::$tblName;
	}

	/**
	 * @since 1.0
	 * Before redirecting to PayPal, We will insert a new transaction to wiloke_submission_transaction
	 * @param $instPaymentMethod
	 * @param $instReceipt
	 * @param number $userID
	 * @param string $status
	 *
	 * @return number $transactionID
	 */
	public static function insert(PaymentMethodInterface $instPaymentMethod, Receipt $instReceipt, $userID=null, $status='processing'){
		global $wpdb;
		$tbl = $wpdb->prefix . AlterTableSessions::$tblName;
		$userID = empty($userID) ? get_current_user_id() : $userID;

		$wpdb->insert(
			$tbl,
			array(
				'gateway'       => $instPaymentMethod->gateway,
				'planID'        => $instReceipt->planID,
				'userID'        => $userID,
				'couponID'      => $instReceipt->couponID,
				'token'         => $instPaymentMethod->token,
				'status'        => $status,
				'billing_type'  => $instPaymentMethod->getBillingType(),
				'customer_ip'   => General::clientIP(),
				'created_at_gmt'=> current_time(DATE_ATOM, 1)
			),
			array(
				'%s',
				'%d',
				'%d',
				'%d',
				'%s',
				'%s',
				'%s',
				'%s',
				'%s'
			)
		);

		$sessionID = $wpdb->insert_id;

		do_action('wiloke-submission/mail', array(
			'type'       => wilokeRepository('mailstatus:type', true)->sub('sessionCreated'),
			'sessionID'  => $sessionID,
			'gateway'    => $instPaymentMethod->gateway,
			'status'     => 'subscription_created',
			'billingType'=>$instPaymentMethod->getBillingType(),
			'userID'     => $userID
		));

		return $sessionID;
	}

	public static function addUpdatedTime($aParams){
		$aParams['value']['updated_at_gmt'] = current_time(DATE_ATOM, 1);
		$aParams['value']['updated_at'] = current_time(DATE_ATOM, 0);
		$aParams['format'][] = '%s';
		$aParams['format'][] = '%s';
		return $aParams;
	}

	public static function getSessionInfo($sessionID){
		global $wpdb;
		$sessionTbl = $wpdb->prefix . AlterTableSessions::$tblName;

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $sessionTbl WHERE ID=%d",
				$sessionID
			),
			ARRAY_A
		);
	}

	public static function updateWhereEqualToID($aParams, $sessionID){
		global $wpdb;
		$wilokeSubmissionTransactionTbl = $wpdb->prefix . AlterTableSessions::$tblName;
		$aParams = self::addUpdatedTime($aParams);

		$wpdb->update(
			$wilokeSubmissionTransactionTbl,
			$aParams['value'],
			array(
				'ID' => $sessionID
			),
			$aParams['format'],
			array(
				'%d'
			)
		);
	}

	/**
	 * Switch To Suspended Status by specifying SessionID
	 *
	 * @param string $newStatus
	 * @param number $sessionID
	 * @return bool
	 */
	public static function updatePaymentStatusWhereEqualToSessionID($newStatus, $sessionID){
		global $wpdb;
		$tbl = $wpdb->prefix . AlterTableSessions::$tblName;

		$status = $wpdb->update(
			$tbl,
			array(
				'status'            => $newStatus,
				'updated_at'        => current_time(DATE_ATOM, 0),
				'updated_at_gmt'    => current_time(DATE_ATOM, 1)
			),
			array(
				'ID' => $sessionID
			),
			array(
				'%s',
				'%s',
				'%s'
			),
			array(
				'%d'
			)
		);

		if ( $status ){
			do_action('wiloke-submission/mail', array(
				'type'       => wilokeRepository('mailstatus:type', true)->sub('sessionStatus'),
				'sessionID'  => $sessionID,
				'newStatus'  => $newStatus
			));
		}

		return $status;
	}

	/**
	 * Switch To Suspended Status by specifying SessionID
	 *
	 * @param number $sessionID
	 * @return bool
	 */
	public static function updateToSuspendedStatusWhereEqualToSessionID($sessionID){
		global $wpdb;
		$tbl = $wpdb->prefix . AlterTableSessions::$tblName;

		$status = $wpdb->update(
			$tbl,
			array(
				'status'            => wilokeRepository('app:paymentStatus', true)->sub('suspended'),
				'updated_at'        => current_time(DATE_ATOM, 0),
				'updated_at_gmt'    => current_time(DATE_ATOM, 1)
			),
			array(
				'ID' => $sessionID
			),
			array(
				'%s',
				'%s',
				'%s'
			),
			array(
				'%d'
			)
		);

		if ( $status ){
			do_action('wiloke-submission/mail', array(
				'type'       => wilokeRepository('mailstatus:type', true)->sub('sessionSuspended'),
				'sessionID'  => $sessionID
			));
		}

		return $status;
	}

	/**
	 * Switch To Succeeded Status by specifying SessionID
	 *
	 * @param number $sessionID succeed
	 * @return bool
	 */
	public static function updateToSucceededStatusWhereEqualToSessionID($sessionID){
		global $wpdb;
		$tbl = $wpdb->prefix . AlterTableSessions::$tblName;
		$status = $wpdb->update(
			$tbl,
			array(
				'status' => wilokeRepository('app:paymentStatus', true)->sub('succeeded'),
				'updated_at'        => current_time(DATE_ATOM, 0),
				'updated_at_gmt'    => current_time(DATE_ATOM, 1)
			),
			array(
				'ID' => $sessionID
			),
			array(
				'%s',
				'%s',
				'%s'
			),
			array(
				'%d'
			)
		);

		if ( $status ){
			do_action('wiloke-submission/mail', array(
				'type'       => wilokeRepository('mailstatus:type', true)->sub('sessionSucceeded'),
				'sessionID'  => $sessionID
			));
		}

		return $status;
	}

	/**
	 * Switch To Cancelled Status by specifying SessionID
	 *
	 * @param number $sessionID succeed
	 * @return bool
	 */
	public static function updateToCancelledStatusWhereEqualToSessionID($sessionID){
		global $wpdb;
		$tbl = $wpdb->prefix . AlterTableSessions::$tblName;
		$status = $wpdb->update(
			$tbl,
			array(
				'status' => wilokeRepository('app:paymentStatus', true)->sub('canceled'),
				'updated_at'        => current_time(DATE_ATOM, 0),
				'updated_at_gmt'    => current_time(DATE_ATOM, 1)
			),
			array(
				'ID' => $sessionID
			),
			array(
				'%s',
				'%s',
				'%s'
			),
			array(
				'%d'
			)
		);

		if ( $status ){
			do_action('wiloke-submission/mail', array(
				'type'       => wilokeRepository('mailstatus:type', true)->sub('sessionCancelled'),
				'sessionID'  => $sessionID
			));
		}

		return $status;
	}

	/**
	 * Switch To Failed Status by specifying SessionID
	 *
	 * @param number $sessionID succeed
	 * @return bool
	 */
	public static function updateToFailedStatusWhereEqualToSessionID($sessionID){
		global $wpdb;
		$tbl = $wpdb->prefix . AlterTableSessions::$tblName;
		$status = $wpdb->update(
			$tbl,
			array(
				'status' => wilokeRepository('app:paymentStatus', true)->sub('failed'),
				'updated_at'        => current_time(DATE_ATOM, 0),
				'updated_at_gmt'    => current_time(DATE_ATOM, 1)
			),
			array(
				'ID' => $sessionID
			),
			array(
				'%s',
				'%s',
				'%s'
			),
			array(
				'%d'
			)
		);

		if ( $status ){
			do_action('wiloke-submission/mail', array(
				'type'       => wilokeRepository('mailstatus:type', true)->sub('sessionFailed'),
				'sessionID'  => $sessionID
			));
		}

		return $status;
	}

	/**
	 * Switch To Processing Status by specifying SessionID
	 *
	 * @param number $sessionID succeed
	 * @return bool
	 */
	public static function updateToProcessingStatusWhereEqualToSessionID($sessionID){
		global $wpdb;
		$tbl = $wpdb->prefix . AlterTableSessions::$tblName;
		$status = $wpdb->update(
			$tbl,
			array(
				'status' => wilokeRepository('app:paymentStatus', true)->sub('processing'),
				'updated_at'        => current_time(DATE_ATOM, 0),
				'updated_at_gmt'    => current_time(DATE_ATOM, 1)
			),
			array(
				'ID' => $sessionID
			),
			array(
				'%s',
				'%s',
				'%s'
			),
			array(
				'%d'
			)
		);

		if ( $status ){
			do_action('wiloke-submission/mail', array(
				'type'       => wilokeRepository('mailstatus:type', true)->sub('sessionProcessing'),
				'sessionID'  => $sessionID
			));
		}

		return $status;
	}

	public static function updateWhereEqualToken($aParams, $token){
		global $wpdb;
		$tbl = $wpdb->prefix . AlterTableSessions::$tblName;
		$aParams = self::addUpdatedTime($aParams);

		$wpdb->update(
			$tbl,
			$aParams['value'],
			array(
				'token' => $token
			),
			$aParams['format'],
			array(
				'%s'
			)
		);
	}

	/*
	 * @param $token
	 * @return number $transactionID
	 */
	public static function getSessionIDByToken($token){
		global $wpdb;
		$tblName = $wpdb->prefix . AlterTableSessions::$tblName;
		return $wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID FROM $tblName WHERE token=%s",
				$token
			)
		);
	}

	/**
	 * Get Payment Status Pay Session ID
	 *
	 * @param number $sessionID
	 * @return string $status
	 */
	public static function getSessionStatus($sessionID){
		global $wpdb;

		self::createTblName();

		return $wpdb->get_var(
			$wpdb->prepare(
				"SELECT status FROM ".static::$tblName." WHERE ID=%d",
				$sessionID
			)
		);
	}

	public static function getSessionGateway($sessionID){
		global $wpdb;

		self::createTblName();

		return $wpdb->get_var(
			$wpdb->prepare(
				"SELECT gateway FROM ".static::$tblName." WHERE ID=%d",
				$sessionID
			)
		);
	}

	/**
	 * Get date of session
	 *
	 * @param number $sessionID
	 *
	 * @return string $createdAt
	 */
	public static function getCreatedDate($sessionID){
		global $wpdb;
		$tblName = $wpdb->prefix . AlterTableSessions::$tblName;

		return $wpdb->get_var(
			$wpdb->prepare(
				"SELECT created_at_gmt FROM $tblName WHERE ID=%d",
				$sessionID
			)
		);
	}

	/**
	 * Delete Session
	 *
	 * @param number $sessionID
	 *
	 * @return bool
	 */
	public static function removeSessionBySessionID($sessionID){
		global $wpdb;
		$tblName = $wpdb->prefix . AlterTableSessions::$tblName;

		return $wpdb->delete(
			$tblName,
			array(
				'ID' => $sessionID
			),
			array(
				'%d'
			)
		);
	}

	/**
	 * Get plan ID By Session ID
	 *
	 * @param number $sessionID
	 * @return number $planID
	 */
	public static function getPlanIDWhereEqualToSessionID($sessionID){
		global $wpdb;
		$tblName = $wpdb->prefix . AlterTableSessions::$tblName;

		$planID = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT planID FROM $tblName WHERE ID=%d",
				$sessionID
			)
		);

		return abs($planID);
	}

	/**
	 * Get user ID By Session ID
	 *
	 * @param number $sessionID
	 * @return number $userID
	 */
	public static function getUserIDWhereEqualToSessionID($sessionID){
		global $wpdb;
		$tblName = $wpdb->prefix . AlterTableSessions::$tblName;

		$userID = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT userID FROM $tblName WHERE ID=%d",
				$sessionID
			)
		);

		return abs($userID);
	}

	/**
	 * Count all non-recurring publish posts
	 *
	 * @return number $total
	 */
	public static function countAllActivationsAccounts(){
		global $wpdb;
		$sessionTbl = $wpdb->prefix . AlterTableSessions::$tblName;

		$total = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT($sessionTbl.ID) FROM $sessionTbl WHERE $sessionTbl.billing_type=%s AND $sessionTbl.status=%s",
				wilokeRepository('app:billingTypes', true)->sub('recurring'), wilokeRepository('app:paymentStatus', true)->sub('succeeded')
			)
		);

		return abs($total);
	}

	/**
	 * Get all posts that belong to non-recurring plan
	 *
	 * @return mixed
	 */
	public static function getAllActivationsAccountInfo(){
		global $wpdb;

		$totalAccounts = self::countAllActivationsAccounts();

		if ( empty($totalAccounts) ){
			return false;
		}

		$limit = $totalAccounts > 100 ? ceil($totalAccounts/ 4 ) : $totalAccounts;
		$sessionTbl = $wpdb->prefix . AlterTableSessions::$tblName;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT $sessionTbl.ID FROM $sessionTbl WHERE $sessionTbl.billing_type=%s AND $sessionTbl.status=%s ORDER BY $sessionTbl.ID DESC LIMIT $limit",
				wilokeRepository('app:billingTypes', true)->sub('recurring'), wilokeRepository('app:paymentStatus', true)->sub('succeeded')
			)
		);
	}

	/**
	 * Get Latest SessionID by specifying planID
	 *
	 * @return array
	 */
	public static function getUserLatestSessionInfoWhereEqualToPlanID($planID, $userID){
		global $wpdb;
		$sessionTbl = $wpdb->prefix . AlterTableSessions::$tblName;

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $sessionTbl WHERE $sessionTbl.planID=%d AND $sessionTbl.userID=%d ORDER BY $sessionTbl.ID DESC LIMIT 1",
				$planID, $userID
			),
			ARRAY_A
		);
	}
}