<?php
namespace WilokeListgoFunctionality\Model;


use WilokeListgoFunctionality\AlterTable\AlterTablePaymentRelationships;

class AddListing{
	public function updatingPaymentRelationShip($aData){
		global $wpdb;
		$tbl = $wpdb->prefix . AlterTablePaymentRelationships::$tblName;
		$wpdb->insert(
			$tbl,
			array(
				'payment_ID' => $aData['payment_ID'],
				'package_ID' => $aData['plan_ID'],
				'object_ID'  => $aData['listing_ID'],
				'status'     => 'addnew'
			),
			array(
				'%d',
				'%d',
				'%d',
				'%s'
			)
		);
	}

	public function updatingListingStatus($listingID){
		$postStatus = get_post_field('post_status', $listingID);
		if ( $postStatus === 'expired' ){
			$newStatus = 'renew';
		}else{
			$newStatus = 'pending';
		}

		wp_update_post(
			array(
				'ID'            => $listingID,
				'post_status'   => $newStatus
			)
		);
	}
}