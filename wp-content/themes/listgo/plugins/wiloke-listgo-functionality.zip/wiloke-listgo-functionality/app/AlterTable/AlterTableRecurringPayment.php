<?php
namespace WilokeListgoFunctionality\AlterTable;


class AlterTableRecurringPayment implements AlterTableInterface {
	use TableExists;
	public static $tblName = 'wiloke_submission_recurring_payment';
	protected $version = '1.0';

	public function __construct() {
		add_action('plugins_loaded', array($this, 'createTable'));
	}

	public function createTable() {
		global $wpdb;

		if ( $this->isTableExists() ){
			return false;
		}

		$charsetCollate = $wpdb->get_charset_collate();
		$tblName = $wpdb->prefix . self::$tblName;

		$sql = "CREATE TABLE $tblName(
				ID BIGINT(20) NOT NULL AUTO_INCREMENT,
				sessionID BIGINT(100) NOT NULL,
				next_billing_date TIMESTAMP NOT NULL,
				created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
				updated_at TIMESTAMP NULL DEFAULT NULL,
				PRIMARY KEY(ID)
			) $charsetCollate";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta($sql);

		update_option(self::$tblName, $this->version);
	}

	public function deleteTable() {
	}
}