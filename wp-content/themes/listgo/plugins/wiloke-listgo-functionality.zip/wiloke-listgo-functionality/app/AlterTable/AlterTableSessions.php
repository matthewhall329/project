<?php
namespace WilokeListgoFunctionality\AlterTable;


class AlterTableSessions implements AlterTableInterface {
	use TableExists;
	public $version = '1.6';
	public static $tblName = 'wiloke_submission_sessions';

	public function __construct() {
		add_action('plugins_loaded', array($this, 'createTable'));
	}

	public function createTable() {
		global $wpdb;

		if ( $this->isTableExists() ){
			return false;
		}

		$charsetCollate = $wpdb->get_charset_collate();
		$tblName = $wpdb->prefix . self::$tblName;

		$sql = "CREATE TABLE $tblName(
				ID bigint(20) NOT NULL AUTO_INCREMENT,
				gateway VARCHAR(100) NOT NULL,
				planID bigint(20) NOT NULL,
				userID bigint(50) NOT NULL,
				couponID bigint(50) NULL DEFAULT NULL,
				token VARCHAR (200) NOT NULL,
				status VARCHAR(100) NOT NULL,
				billing_type VARCHAR(40) NOT NULL,
				customer_ip VARCHAR(100) NOT NULL,
				created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
				updated_at TIMESTAMP NULL DEFAULT NULL,
				created_at_gmt TIMESTAMP NOT NULL,
				updated_at_gmt TIMESTAMP NULL,
				PRIMARY KEY(ID)
			) $charsetCollate";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta($sql);

		update_option(self::$tblName, $this->version);
	}

	public function deleteTable() {
		// TODO: Implement deleteTable() method.
	}
}