<?php
namespace WilokeListgoFunctionality\AlterTable;


trait TableExists {
	public function isTableExists(){
		if ( get_option(self::$tblName) && (version_compare(get_option(self::$tblName), $this->version, '>=')) ){
			return true;
		}
		global $wpdb;
		$tblName = $wpdb->prefix . self::$tblName;
		if ($result = $wpdb->query("SHOW TABLES LIKE '".$tblName."'") ){
			update_option(self::$tblName, $this->version);
			return true;
		}

		return false;
	}
}