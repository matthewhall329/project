<?php
namespace WilokeListgoFunctionality\AlterTable;

class AlterTableStripeRecurringPayment implements AlterTableInterface {
	public static $tblName = 'wiloke_listgo_stripe_recurring_payment';
	public $version = '1.0';
	public function __construct() {
		add_action('plugins_loaded', array($this, 'createTable'));
	}

	public function createTable() {
		if ( get_option(self::$tblName) && (version_compare(get_option(self::$tblName), $this->version, '>=')) ){
			return false;
		}

		global $wpdb;
		$tblName = $wpdb->prefix . self::$tblName;

		if ($result = $wpdb->query("SHOW TABLES LIKE '".$tblName."'") ){
			update_option(self::$tblName, $this->version);
			return false;
		}

		$charsetCollate = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE $tblName (
          payment_ID bigint(9) NOT NULL AUTO_INCREMENT,
          subscription_ID VARCHAR (4) NOT NULL,
          customer_ID bigint(9) unsigned NOT NULL,
          event_ID bigint(100)  NOT NULL
        ) $charsetCollate";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta($sql);

		update_option(self::$tblName, $this->version);
	}

	public function deleteTable() {
		// TODO: Implement deleteTable() method.
	}
}