<?php
namespace WilokeListgoFunctionality\Framework\Payment;


use Braintree\Exception;
use WilokeListgoFunctionality\Framework\Payment\PayPal\PayPalChangePlan;
use WilokeListgoFunctionality\Framework\Payment\Stripe\StripeChangePlan;
use WilokeListgoFunctionality\Framework\Payment\Twocheckout\TwocheckoutChangePlan;

class ChangePlanFactory {
	protected $gateway;
	protected $planID;
	protected $userID;
	protected $aArgs;
	protected $twocheckoutToken;

	public $oInstance = null;


	/**
	 * Set Gateway
	 *
	 * @param string $gateway
	 * @return object $this
	 */
	public function setGateway($gateway){
		$this->gateway = $gateway;
		return $this;
	}

	/**
	 * Set userID
	 *
	 * @param number $userID
	 * @return object $this
	 */
	public function setUserID($userID){
		$this->userID = $userID;
		return $this;
	}


	/**
	 * Set planID
	 *
	 * @param number $planID
	 * @return object $this
	 */
	public function setPlanID($planID){
		$this->planID = $planID;
		return $this;
	}

	/**
	 * Other Data. This is all data query
	 *
	 * @param array $aArgs
	 * @return $this;
	 */
	public function setArgs($aArgs){
		$this->aArgs = $aArgs;
		return $this;
	}

	/**
	 * Determining Instance
	 *
	 */
	public function determineInstance(){
		switch ($this->gateway){
			case 'paypal':
				$this->oInstance = new PayPalChangePlan($this->userID, $this->planID);
				break;
			case 'stripe':
				$this->oInstance = new StripeChangePlan($this->userID, $this->planID);
				break;
			case '2checkout':
				$this->oInstance = new TwocheckoutChangePlan($this->userID, $this->planID, $this->aArgs);
				break;
			default:
				if ( has_filter('wiloke-submission/app/Framework/ChangePlanFactory') ){
					$this->oInstance = apply_filters('wiloke-submission/app/Framework/ChangePlanFactory', $this->gateway, wilokeRepository('app:billingTypes', true)->sub('recurring'), $this->userID, $this->planID);
				}
				break;
		}

		if ( empty($this->oInstance) ){
			if ( wp_doing_ajax() ){
				wp_send_json_error(
					array(
						'msg' => esc_html__('Sorry, We could not support this gateway', 'wiloke')
					)
				);
			}else{
				throw new Exception( esc_html__('Sorry, We could not support this gateway', 'wiloke') );
			}
		}

		return $this->oInstance;
	}
}