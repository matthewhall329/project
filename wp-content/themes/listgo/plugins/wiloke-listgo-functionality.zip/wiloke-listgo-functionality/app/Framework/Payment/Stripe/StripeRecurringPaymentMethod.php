<?php
namespace WilokeListgoFunctionality\Framework\Payment\Stripe;

use Stripe\Stripe;
use Stripe\Customer as StripeCustomer;
use Stripe\Subscription as StripeSubscription;

use WilokeListgoFunctionality\Framework\Helpers\Time;
use WilokeListgoFunctionality\Framework\Payment\Coupon;
use WilokeListgoFunctionality\Framework\Payment\PaymentMethodInterface;

use WilokeListgoFunctionality\Framework\Store\Session;
use WilokeListgoFunctionality\Model\PaymentMetaModel;
use WilokeListgoFunctionality\Model\StripeModel;
use WilokeListgoFunctionality\Model\UserModel;
use WilokeListgoFunctionality\Model\PaymentModel;

class StripeRecurringPaymentMethod implements PaymentMethodInterface{
	use StripeConfiguration;

	protected $storeTokenPlanSession;
	protected $sessionID;
	protected $userID;
	protected $planSlug;

	public function getBillingType() {
		return wilokeRepository('app:billingTypes', true)->sub('recurring');
	}

	private function retrievePlan(){
		try{
			$oPlanInfo = \Stripe\Plan::retrieve($this->planSlug);
			return $oPlanInfo;
		}catch (\Exception $oException){
			return false;
		}
	}

	/*
	 * If the plan does not exist, we will create a new plan
	 */
	private function createPlan(){
		$result = $this->retrievePlan();
		if ( !$result ){
			$zeroDecimal = empty($this->oApiContext->zeroDecimal) ? 1 : $this->oApiContext->zeroDecimal;
			\Stripe\Plan::create(array(
				'currency'          => $this->aConfiguration['currency_code'],
				'interval'          => 'day',
				'name'              => $this->oReceipt->planName,
				'amount'            => $this->oReceipt->total*$zeroDecimal,
				'id'                => $this->planSlug,
				'interval_count'    => $this->oReceipt->regularPeriod
			));
		}
	}

	public function createNewUser(){
		try{
			$oCustomer = StripeCustomer::create(array(
				'email'  => $this->oReceipt->aInfo['email'],
				'source' => $this->token
			));
			StripeModel::updateCustomerID($oCustomer->id);
			StripeModel::updateSessionToken($this->token);
			return $oCustomer;
		}catch (\Exception $oE){
			return array(
				'status' => 'error',
				'msg'    => $oE->getMessage()
			);
		}
	}

	public function proceedPayment($oReceipt){
		$this->setApiContext();
		$this->setReceipt($oReceipt);

		$this->planSlug = get_post_field('post_name', $this->oReceipt->planID);

		$this->getCustomerID();
		$this->createPlan();
		if ( empty($this->customerID) ){
			$oCustomer = $this->createNewUser();
		}else{
			try{
				$oCustomer = StripeCustomer::retrieve($this->customerID);
				if ( $oCustomer->deleted ){
					StripeModel::deleteCustomerID($this->userID);
					return array(
						'status' => 'error',
						'msg'    => esc_html__('Your stripe account has been deleted. Please refresh the site and try to pay again', 'wiloke')
					);
				}
			}catch (\Exception $oE){
				StripeModel::deleteCustomerID($this->userID);
				return array(
					'status' => 'error',
					'msg'    => esc_html__('Your stripe account has been deleted. Please refresh the site and try to pay again', 'wiloke')
				);
			}

			$this->token = StripeModel::getSessionToken($this->userID);
		}

		if ( is_array($oCustomer) && ($oCustomer['status'] == 'error') ){
			return $oCustomer;
		}

		try{
			$oSubscription = StripeSubscription::create(array(
				'customer' => $oCustomer->id,
				'items' => array(
					array(
						'plan' => $this->planSlug
					)
				)
			));

			$this->insertingNewSession();
			$this->insertingNewPaymentMeta($oSubscription->__toArray());

			/**
			 * @hook PlanRelationship@updateSessionID 5
			 * @hook UserController@createUserPlan 10
			 */
			do_action('wiloke/wiloke-submission/payment/after_payment', array(
				'gateway'           => $this->gateway,
				'nextBillingDate'   => $oSubscription->current_period_end,
				'status'            => 'succeeded',
				'billingType'       => $this->getBillingType(),
				'sessionID'         => $this->sessionID,
				'planID'            => $oReceipt->planID,
				'planName'          => $oReceipt->planName,
				'postID'            => Session::getSession(wilokeRepository('sessionkeys:storePostID'), true),
				'planRelationshipID'=> Session::getSession(wilokeRepository('sessionkeys:storePlanRelationshipIDSessionID'), true)
			));

			StripeModel::setSubscriptionID($oSubscription->id, $this->sessionID);
			Session::destroySession(wilokeRepository('sessionkeys:storePlanID'));
			return array(
				'status' => 'success',
				'msg'    => esc_html__('Congratulations! Your payment has been processed successfully', 'wiloke')
			);
		}catch (\Exception $oE) {
			return array(
				'status' => 'error',
				'msg'    => $oE->getMessage()
			);
		}
	}

	private function insertingNewSession(){
		$this->sessionID = PaymentModel::insert($this, $this->oReceipt, $this->userID, wilokeRepository('app:paymentStatus', true)->sub('succeeded'));
	}

	private function insertingNewPaymentMeta($aVal){
		PaymentMetaModel::set($this->sessionID, wilokeRepository('paymentKeys:info'), $aVal);
	}
}