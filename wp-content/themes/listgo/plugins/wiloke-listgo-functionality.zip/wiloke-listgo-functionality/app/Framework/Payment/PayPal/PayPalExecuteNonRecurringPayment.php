<?php
namespace WilokeListgoFunctionality\Framework\Payment\PayPal;

use PayPal\Api\Amount;
use PayPal\Api\Details;
use PayPal\Api\Payment;
use PayPal\Api\PaymentExecution;
use PayPal\Api\Transaction;
use PayPal\Exception\PayPalConnectionException;

use WilokeListgoFunctionality\Framework\Config\Repository;
use WilokeListgoFunctionality\Framework\Store\Session;

use WilokeListgoFunctionality\Model\PaymentMetaModel;
use WilokeListgoFunctionality\Model\PaymentModel;
use WilokeListgoFunctionality\Model\PayPalModel;

class PayPalExecuteNonRecurringPayment{
	use PayPalValidations;

	public $gateway = 'paypal';
	private $storeTokenPlanSession;
	private $oApiContext;
	public $token;
	public $payerID;
	public $paymentID;
	protected $planID;

	public function executePayment(){
		$this->storeTokenPlanSession = wilokeRepository('sessionkeys:storeTokenPlanSession');
		$aSessionStore = Session::getSession($this->storeTokenPlanSession);

		if ( !$this->validateBeforeExecuting() ){
			return false;
		}

		/*
		 * It's an array: token presents to key and planId presents to value
		 */
		$this->paymentID = $_REQUEST['paymentId'];
		$this->token = $_REQUEST['token'];
		$this->payerID = $_REQUEST['PayerID'];
		$this->planID = $aSessionStore[$this->token];

		$planName = get_the_title($aSessionStore[$this->token]);

		$instPayPalConfiguration = PayPalConfiguration::setup();
		$this->oApiContext = $instPayPalConfiguration->getApiContext();

		$instPayment = Payment::get($this->paymentID, $this->oApiContext);

		// Execute payment with payer id
		$instPaymentExecution = new PaymentExecution();
		$instPaymentExecution->setPayerId($this->payerID);

		/*
		 * Get Session ID
		 */
		$sessionID = PaymentModel::getSessionIDByToken($this->token);
		$sessionID = abs($sessionID);

		try {
			// Execute payment
			$oResponse = $instPayment->execute($instPaymentExecution, $this->oApiContext);
			$paymentInfo = $oResponse;
			/*
			 * Updating Payment Status
			 */
			PaymentModel::updateWhereEqualToken(
				array(
					'value' => array(
						'status' => 'succeeded'
					),
					'format' => array(
						'%s'
					)
				),
				$this->token
			);

			/**
			 * @hook PlanRelationship@updateSessionID 5
			 * @hook UserController@createUserPlan 10
			 * @hook AddEventController@updateEventStatus 10
			 */
			do_action('wiloke/wiloke-submission/payment/after_payment', array(
//				'planType'          => Session::getSession(wilokeRepository('sessionkeys:planType'), true),
				'gateway'           => $this->gateway,
				'status'            => 'succeeded',
				'billingType'       => wilokeRepository('app:billingTypes', true)->sub('nonrecurring'),
				'sessionID'         => $sessionID,
				'planID'            => $this->planID,
				'planName'          => $planName,
				'postID'            => Session::getSession(wilokeRepository('sessionkeys:storePostID'), true),
				'planRelationshipID'=> Session::getSession(wilokeRepository('sessionkeys:storePlanRelationshipIDSessionID'), true)
			));

			PayPalModel::setPaymentID($oResponse->id, $sessionID);

			if ( $discountVal = Session::getSession(wilokeRepository('paymentKeys:storeDiscountValue') . '_' . $this->token) ){
				set_transient($oResponse->id, $discountVal, 60*60*24);
			}

		}catch(PayPalConnectionException $ex){
			/*
			 * Updating Payment Status
			 */
			PaymentModel::updateWhereEqualToken(
				array(
					'value' => array(
						'status' => 'failed'
					),
					'format' => array(
						'%s'
					)
				),
				$this->token
			);

			$paymentInfo = $ex->getData();

			do_action('wiloke/wiloke-submission/payment/after_payment', array(
				'gateway'       => 'paypal',
				'status'        => 'failed',
				'billingType'   => 'NonRecurringPayment',
				'sessionID'     => $sessionID,
				'planID'        => $this->planID,
				'planName'      => $planName
			));
		} catch (\Exception $ex) {
			$paymentInfo = $ex->getMessage();

			/*
			 * Updating Transaction Message
			 */
			do_action('wiloke/wiloke-submission/payment/after_payment', array(
				'gateway'       => 'paypal',
				'status'        => 'failed',
				'billingType'   => 'NonRecurringPayment',
				'sessionID'     => $sessionID,
				'planID'        => $this->planID,
				'planName'      => $planName
			));
		}

		PaymentMetaModel::set($sessionID, wilokeRepository('paymentKeys:info'), $paymentInfo);
	}
}