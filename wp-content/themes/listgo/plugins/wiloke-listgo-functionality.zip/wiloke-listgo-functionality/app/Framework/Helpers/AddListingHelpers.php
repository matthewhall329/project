<?php
namespace WilokeListgoFunctionality\Framework\Helpers;


class AddListingHelpers{
	public static function toggleClass($aPackageSettings, $key, $additionalClass=''){
		if ( isset($aPackageSettings[$key]) && $aPackageSettings[$key] == 'disable'  ){
			$class = $additionalClass . ' disabled';
		}else{
			$class = $additionalClass;
		}

		return trim($class);
	}

	public static function toggleCustomFieldClass($aPackageSettings, $fieldName, $additionalClass=''){
		if ( !isset($aPackageSettings['except_custom_fields']) ){
			return trim($additionalClass);
		}

		if ( in_array($fieldName, $aPackageSettings['except_custom_fields']) ){
			$class = $additionalClass . ' disabled';
		}else{
			$class = $additionalClass;
		}

		return trim($class);
	}

	public static function toggleSocialNetworkClass($aPackageSettings, $fieldName, $additionalClass=''){
		if ( !isset($aPackageSettings['except_social_networks']) ){
			return trim($additionalClass);
		}

		if ( in_array($fieldName, $aPackageSettings['except_social_networks']) ){
			$class = $additionalClass . ' disabled';
		}else{
			$class = $additionalClass;
		}

		return trim($class);
	}

	public static function isExceptThisField($aPackageSettings, $fieldName){
		if ( isset($aPackageSettings[$fieldName]) && $aPackageSettings[$fieldName] == 'disable'  ){
			return true;
		}else{
			return false;
		}
	}

	public static function isExceptThisCustomField($aPackageSettings, $fieldName){
		if ( !isset($aPackageSettings['except_custom_fields']) ){
			return false;
		}

		if ( in_array($fieldName, $aPackageSettings['except_custom_fields']) ){
			return true;
		}else{
			return false;
		}
	}

	public static function isExceptThisSocial($aPackageSettings, $fieldName){
		if ( !isset($aPackageSettings['except_social_networks']) ){
			return false;
		}

		if ( in_array($fieldName, $aPackageSettings['except_social_networks']) ){
			return true;
		}else{
			return false;
		}
	}
}