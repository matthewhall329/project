<?php
namespace WilokeListgoFunctionality\Framework\Payment;

use WilokeListgoFunctionality\Framework\Helpers\GetSettings;

class PaymentConfiguration{
	private static $aPaymentConfiguration;
	private static $newPostStatus;
	public static $isFocusNonRecurring = false;

	public static function get(){
		if ( !empty(self::$aPaymentConfiguration) ){
			return self::$aPaymentConfiguration;
		}

		$configuration = GetSettings::getOptions(wilokeRepository('app:wiloke_submission_key'));

		if ( !empty($configuration) ){
			self::$aPaymentConfiguration = json_decode($configuration, true);
			if ( empty(self::$aPaymentConfiguration) ){
				self::$aPaymentConfiguration = json_decode(stripslashes($configuration), true);
			}
		}

		return self::$aPaymentConfiguration;
	}

	public static function renderTotal($price, $gateway, $billingType){
		if ( $gateway == 'stripe' && $billingType == wilokeRepository('app:billingTypes', true)->sub('recurring') ){
			$zeroDecimal = self::getField('stripe_zero_decimal');
			$price = number_format(floatval($price/$zeroDecimal), 2);
		}
		return $price;
	}

	public static function getCurrencyCode(){
		$currency = self::getCurrency();
		$aCurrencySymbol = wilokeRepository('app:currencySymbol');
		return $aCurrencySymbol[$currency];
	}

	public static function getCurrency(){
		self::get();
		return self::$aPaymentConfiguration['currency_code'];
	}

	/*
	 * Get Wiloke Submission Setting by specify Field name
	 *
	 * @param string $fieldName
	 *
	 * @return mixed
	 */
	public static function getField($fieldName){
		self::get();
		return isset(self::$aPaymentConfiguration[$fieldName]) ? self::$aPaymentConfiguration[$fieldName] : '';
	}

	public static function getPaymentGateways($aExcept=array()){
		self::get();
		if ( empty(self::$aPaymentConfiguration['payment_gateways']) ){
			return false;
		}

		$aGateways = explode(',', self::$aPaymentConfiguration['payment_gateways']);

		if ( empty($aExcept) ){
			return $aGateways;
		}

		return array_diff($aGateways, $aExcept);
	}

	public static function getCustomerPlans(){
		self::get();

		if ( isset(self::$aPaymentConfiguration['customer_plans']) && !empty(self::$aPaymentConfiguration['customer_plans']) ){
			return explode(',', self::$aPaymentConfiguration['customer_plans']);
		}

		return false;
	}

	public static function getFreePlan(){
		$aPlans = self::getCustomerPlans();
		if ( !$aPlans ){
			return false;
		}

		return end($aPlans);
	}

	public static function newPostStatus(){
		if ( !empty(self::$newPostStatus) ){
			return self::$newPostStatus;
		}

		$aWilokeSubmissionSettings = PaymentConfiguration::get();
		if ( $aWilokeSubmissionSettings['approved_method'] != 'manual_review' ){
			self::$newPostStatus = 'publish';
		}else{
			self::$newPostStatus = 'pending';
		}

		return self::$newPostStatus;
	}

	public static function getGatewaySettings($aExcept=array()){
		$aGatewayAcceptable = self::getPaymentGateways($aExcept);
		if ( empty($aGatewayAcceptable) ){
			return false;
		}

		$aWilokeSubmissionSettings = wilokeRepository('app:settings', true)->sub('submission');
		foreach ( $aWilokeSubmissionSettings['fields'] as $aSettings ){
			if ( !isset($aSettings['id']) || ($aSettings['id'] != 'payment_gateways') ){
				continue;
			}
			$aFindGateway = $aSettings['options'];
			break;
		}

		$aResult = array();
		foreach ($aFindGateway as $aSettings){
			if ( in_array($aSettings['value'], $aGatewayAcceptable) ){
				$aResult[$aSettings['value']] = $aSettings;
			}
		}

		return $aResult;
	}

	public static function checkGateway($gateway){
		$aGateways = self::getPaymentGateways();
		if ( empty($aGateways) ){
			return false;
		}

		return in_array($gateway, $aGateways);
	}

	public static function getPaymentType(){
		self::get();
		return self::$aPaymentConfiguration['billing_type'];
	}

	public static function isNonRecurringPayment($billingType=null){
		if ( !empty($billingType) ){
			return $billingType == wilokeRepository('app:billingTypes', true)->sub('nonrecurring');
		}

		if ( self::$isFocusNonRecurring ){
			return true;
		}

		$paymentType = self::getPaymentType();
		return strtolower($paymentType) == 'none';
	}

	public static function isRecurringPayment(){
		$paymentType = self::getPaymentType();
		return strtolower($paymentType) != 'none';
	}

	public static function isFreeAddListingMode(){
		$addListingMode = PaymentConfiguration::getField('add_listing_mode');
		return $addListingMode == 'free_add_listing';
	}

	public static function isPlanExists($planID){
		$aCustomerPlans = self::getCustomerPlans();
		if ( empty($aCustomerPlans) ){
			return false;
		}

		return in_array($planID, $aCustomerPlans);
	}

	public static function thankyouUrl(){
		self::get();
		return get_permalink(self::$aPaymentConfiguration['thankyou']);
	}

	public static function cancelUrl(){
		self::get();
		return get_permalink(self::$aPaymentConfiguration['cancel']);
	}

	public static function getBankAccounts(){
		$aBankDetails = array();
		self::get();

		$aGroup = array(
			'bank_transfer_account_name',
			'bank_transfer_account_number',
			'bank_transfer_name',
			'bank_transfer_short_code',
			'bank_transfer_iban',
			'bank_transfer_swift'
		);

		for ( $i = 1; $i <= 4; $i++ ){
			if ( !empty(self::$aPaymentConfiguration['bank_transfer_account_name_' . $i]) && !empty(self::$aPaymentConfiguration['bank_transfer_account_number_' . $i]) ){
				foreach ( $aGroup as $param ){
					$aBankDetails[$i][$param] = self::$aPaymentConfiguration[$param . '_' . $i];
				}
			}
		}

		return $aBankDetails;
	}

	public static function isAllowEditingPublishedPost(){
		return PaymentConfiguration::getField('published_listing_editable') != 'not_allow';
	}
}