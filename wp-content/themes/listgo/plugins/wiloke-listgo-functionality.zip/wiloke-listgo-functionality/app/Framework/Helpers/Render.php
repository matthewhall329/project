<?php
namespace WilokeListgoFunctionality\Framework\Helpers;


use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;

class Render{
	public static function price($price, $isReturn=false, $currency=null){
		$aWilokeSubmissionSettings = PaymentConfiguration::get();
		$currency = empty($currency) ? self::getCurrency() : $currency;
		switch ($aWilokeSubmissionSettings['currency_position']){
			case 'right':
				$price = $price . $currency;
				break;
			case 'right_space':
				$price = $price . ' ' . $currency;
				break;
			case 'left_space':
				$price = $currency . ' ' . $price;
				break;
			default:
				$price = $currency . $price;
				break;
		}

		if ( $isReturn ){
			return $price;
		}

		echo esc_html($price);
	}

	public static function getCurrency(){
		$aConfiguration = wilokeRepository('app');
		$aWilokeSubmissionSettings = PaymentConfiguration::get();

		if ( empty($aWilokeSubmissionSettings) ){
			return $aConfiguration['currencySymbol']['USD'];
		}else{
			return $aConfiguration['currencySymbol'][$aWilokeSubmissionSettings['currency_code']];
		}
	}

	public static function getCurrencyBySymbol($currency){
		$aConfiguration = wilokeRepository('app');
		$currency = strtoupper($currency);
		return $aConfiguration['currencySymbol'][$currency];
	}
}