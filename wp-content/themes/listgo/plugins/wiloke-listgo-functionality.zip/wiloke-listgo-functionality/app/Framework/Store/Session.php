<?php
namespace WilokeListgoFunctionality\Framework\Store;


use WilokeListgoFunctionality\Framework\Helpers\DebugStatus;
use WilokeListgoFunctionality\Framework\Helpers\GeneratePrefix;

class Session{
	protected static $isSessionStarted=false;
	protected static $expiration = 900;

	protected static function generateTransientName($name){
		return GeneratePrefix::generateKey($name) . get_current_user_id();
	}

	public static function setSession($name, $value){
		if ( DebugStatus::status('WILOKE_STORE_WITH_DB') ){
			set_transient(self::generateTransientName($name), $value, self::$expiration);
		}else{
			if ( empty(session_id()) ){
				session_start();
			}

			$_SESSION[GeneratePrefix::generateKey($name)] = $value;
		}
	}

	public static function getSession($name, $thenDestroy=false){
		if ( DebugStatus::status('WILOKE_STORE_WITH_DB') ){
			$sessionID = get_transient(self::generateTransientName($name));
		}else{
			if ( empty(session_id()) ){
				session_start();
			}

			$sessionID = isset($_SESSION[GeneratePrefix::generateKey($name)]) ? $_SESSION[GeneratePrefix::generateKey($name)] : false;
		}

		if ( empty($sessionID) ){
			return false;
		}

		if ( $thenDestroy ){
			self::destroySession(GeneratePrefix::generateKey($name));
		}

		return $sessionID;
	}

	public static function destroySession($name=null){
		if ( DebugStatus::status('WILOKE_STORE_WITH_DB') ){
			delete_transient(GeneratePrefix::generateKey($name));
		}else{
			if ( !empty(GeneratePrefix::generateKey($name)) ){
				unset($_SESSION[GeneratePrefix::generateKey($name)]);
			}else{
				session_destroy();
			}
		}
	}
}