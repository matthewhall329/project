<?php
namespace WilokeListgoFunctionality\Framework\Payment\PayPal;

use PayPal\Api\Amount;
use PayPal\Api\Refund;
use PayPal\Api\Sale;
use PayPal\Exception\PayPalConnectionException;
use PayPal\Api\Payment;

use WilokeListgoFunctionality\Payment\PaymentConfiguration;


class PayPalRefundNonRecurringPayment {
	protected $oApiContext;
	protected $saleID;
	protected $oSale;

	protected function getSaleInfo(){
		try {
			$this->oSale = Sale::get($this->saleID, $this->oApiContext);
		} catch (\Exception $ex) {
			$aError = array(
				'status' => 'error'
			);
		}

		if ( isset($aError) ){
			return $aError;
		}

		return array(
			'status' => 'success'
		);
	}

	public function refund($saleID){
		$aConfiguration = PaymentConfiguration::getPaymentConfiguration();
		$instPayPalConfiguration = PayPalConfiguration::setup();
		$this->aConfiguration = $instPayPalConfiguration->getConfiguration();
		$this->oApiContext = $instPayPalConfiguration->getApiContext();
		$this->saleID = $saleID;
		$aStatus = $this->getSaleInfo();

		if ( $aStatus['status'] != 'success' ){
			return $aStatus;
		}

		$amt = new Amount();
		$amt->setTotal($amount)
		    ->setCurrency($aConfiguration['currency_code']);

		$refund = new Refund();
		$refund->setAmount($amt);

		$sale = new Sale();
		$sale->setId($saleID);

		try {
			$refundedSale = $sale->refund($refund, $this->oApiContext);
		} catch (PayPalConnectionException $ex) {
			echo $ex->getCode();
			echo $ex->getData();
			die($ex);
		} catch (\Exception $ex) {
			die($ex);
		}

	}
}