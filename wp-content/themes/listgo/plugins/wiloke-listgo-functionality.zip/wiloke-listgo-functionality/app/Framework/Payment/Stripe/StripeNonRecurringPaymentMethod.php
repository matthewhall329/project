<?php
namespace WilokeListgoFunctionality\Framework\Payment\Stripe;

use WilokeListgoFunctionality\Framework\Payment\PaymentMethodInterface;
use WilokeListgoFunctionality\Framework\Payment\Receipt;
use WilokeListgoFunctionality\Framework\Store\Session;
use WilokeListgoFunctionality\Model\InvoiceModel;
use WilokeListgoFunctionality\Model\PaymentMetaModel;
use WilokeListgoFunctionality\Model\PaymentModel;
use WilokeListgoFunctionality\Model\StripeModel;
use Stripe\Customer as StripeCustomer;

class StripeNonRecurringPaymentMethod implements PaymentMethodInterface{
	use StripeConfiguration;
	protected $storeTokenPlanSession;
	protected $sessionID;
	protected $aPaymentInfo;
	protected $oCharge;
	protected $relationshipID;
	protected $userID;

	public function getBillingType() {
		return wilokeRepository('app:billingTypes', true)->sub('nonrecurring');
	}

	public function proceedWithSingleToken(Receipt $oReceipt){
		$this->setApiContext();

		$instGenerateToken = new StripeGenerateToken();
		$instGenerateToken->generate();
		$oReceipt->setToken($instGenerateToken->getTokenID());
		$this->setReceipt($oReceipt);
		return $this->charge($instGenerateToken->getCustomerInfo());
	}

	public function proceedPayment($oReceipt){
		$this->setApiContext();
		$this->setReceipt($oReceipt);

		$this->getCustomerID();

		if ( empty($this->customerID) ){
			try{
				$oCustomer = StripeCustomer::create(array(
					'email'  => $this->oReceipt->aInfo['email'],
					'source' => $this->token
				));

				StripeModel::updateCustomerID($oCustomer->id);
				StripeModel::updateSessionToken($this->token);

			}catch (\Exception $oE){
				return array(
					'status' => 'error',
					'msg'    => $oE->getMessage()
				);
			}
		}else{
			$oCustomer = StripeCustomer::retrieve($this->customerID);
			$this->token = StripeModel::getSessionToken($this->userID);
		}

		return $this->charge($oCustomer);
	}

	protected function charge($oCustomer){
		$zeroDecimal = empty($this->oApiContext->zeroDecimal) ? 1 : $this->oApiContext->zeroDecimal;

		try {
			$oCharge = \Stripe\Charge::create(array(
				'amount'        => absint($zeroDecimal)*$this->oReceipt->total,
				'currency'      => $this->aConfiguration['currency_code'],
				'description'   => get_the_title($this->oReceipt->planID),
				'customer'      => $oCustomer->id
			));

			// Once the session has been completed, We need to record to wiloke_subission_sessions table -> It will generate a sessionID
			$this->insertingNewSession();

			// Payment Meta Data
			$this->insertingNewPaymentMeta($oCharge->__toArray());
			
			// Set Charge ID
			StripeModel::setChargeID($oCharge->id, $this->sessionID);

			/**
			 * @hook PlanRelationship@updateSessionID 5
			 * @hook UserController@createUserPlan 10
			 */
			do_action('wiloke/wiloke-submission/payment/after_payment', array(
				'gateway'           => $this->gateway,
				'status'            => 'succeeded',
				'billingType'       => $this->getBillingType(),
				'sessionID'         => $this->sessionID,
				'planID'            => $this->oReceipt->planID,
				'planName'          => $this->oReceipt->planName,
				'postID'            => Session::getSession(wilokeRepository('sessionkeys:storePostID'), true),
				'planRelationshipID'=> Session::getSession(wilokeRepository('sessionkeys:storePlanRelationshipIDSessionID'), true)
			));

			InvoiceModel::insert(
				array(
					'sessionID'     => $this->sessionID,
					'regular_price' => $this->oReceipt->total,
					'currency'      => $this->aConfiguration['currency_code'],
					'message'       => $oCharge,
					'discount'      => 0
				)
			);

			Session::destroySession(wilokeRepository('sessionkeys:storePlanID'));
			return array(
				'status' => 'success',
				'msg'    => esc_html__('Congratulations! Your payment has been successfully', 'wiloke')
			);

		} catch (\Exception $e) {
			return array(
				'status' => 'error',
				'msg'    => $e->getMessage()
			);
		}
	}

	private function insertingNewSession(){
		$this->sessionID = PaymentModel::insert($this, $this->oReceipt, $this->userID, wilokeRepository('app:paymentStatus', true)->sub('succeeded'));
	}

	private function insertingNewPaymentMeta($aVal){
		PaymentMetaModel::set($this->sessionID, wilokeRepository('paymentKeys:info'), $aVal);
	}
}