<?php
namespace WilokeListgoFunctionality\Framework\Payment\PayPal;

use PayPal\Exception\PayPalConnectionException;
use PayPal\Api\Agreement;

use WilokeListgoFunctionality\Model\PaymentMetaModel;
use WilokeListgoFunctionality\Model\PaymentModel;
use WilokeListgoFunctionality\Model\PayPalModel;
use WilokeListgoFunctionality\Model\RecurringPaymentModel;
use WilokeListgoFunctionality\Framework\Store\Session;


class PayPalExecuteRecurringPayment{
	use PayPalValidations;

	public $gateway = 'paypal';
	protected $storeTokenPlanSession;
	private $oApiContext;
	protected $token;
	protected $planID;

	public function executePayment(){
		$this->storeTokenPlanSession = wilokeRepository('sessionkeys:storeTokenPlanSession');
		$aSessionStore = Session::getSession($this->storeTokenPlanSession);
		if ( !$this->validateBeforeExecuting() ){
			return false;
		}

		/*
		 * It's an array: token presents to key and planId presents to value
		 */
		$this->token = $_GET['token'];
		$this->planID = $aSessionStore[$this->token];
		$planName = get_the_title($this->planID);
		$instPayPalConfiguration = PayPalConfiguration::setup();
		$this->oApiContext = $instPayPalConfiguration->getApiContext();
		$agreement = new Agreement();

		/*
		 * Get Session ID
		 */
		$sessionID = abs(PaymentModel::getSessionIDByToken($this->token));

		try {
			// Execute agreement
			$oResult = $agreement->execute($this->token, $this->oApiContext);
			$paymentInfo = $oResult;
			/*
			 * Updating Payment Status
			 */
			PaymentModel::updateWhereEqualToken(
				array(
					'value' => array(
						'status' => 'succeeded'
					),
					'format' => array(
						'%s'
					)
				),
				$this->token
			);

			PayPalModel::setBillingAgreementID($oResult->id, $sessionID);

			$aReturn = array(
				'status' => 'success',
				'data'   => $oResult
			);

			/**
			 * @hook PlanRelationship@updateSessionID 5
			 * @hook UserController@createUserPlan 10
			 */
			do_action('wiloke/wiloke-submission/payment/after_payment', array(
//				'planType'           => Session::getSession(wilokeRepository('sessionkeys:planType'), true),
				'gateway'            => $this->gateway,
				'status'             => 'succeeded',
				'billingType'        => wilokeRepository('app:billingTypes', true)->sub('recurring'),
				'sessionID'          => $sessionID,
				'planID'             => $aSessionStore[$this->token],
				'planName'           => $planName,
				'nextBillingDate'    => strtotime($oResult->agreement_details->next_billing_date),
				'postID'             => Session::getSession(wilokeRepository('sessionkeys:storePostID'), true),
				'planRelationshipID' => Session::getSession(wilokeRepository('sessionkeys:storePlanRelationshipIDSessionID'), true)
			));

			PayPalModel::setPaymentID($oResult->id, $sessionID);

		} catch (PayPalConnectionException $ex) {
			/*
			 * Updating Payment Status
			 */
			PaymentModel::updateWhereEqualToken(
				array(
					'value' => array(
						'status' => 'failed'
					),
					'format' => array(
						'%s'
					)
				),
				$this->token
			);

			$paymentInfo = $ex->getData();

			$aReturn = array(
				'status' => 'error',
				'data'   => $ex->getData(),
				'code'   => $ex->getCode()
			);

			do_action('wiloke/wiloke-submission/payment/after_payment', array(
				'gateway'       => 'paypal',
				'status'        => 'failed',
				'billingType'   => wilokeRepository('wiloke_submission:recurring'),
				'sessionID'     => $sessionID,
				'planID'        => $aSessionStore[$this->token],
				'planName'      => $planName
			));
		} catch (\Exception $ex) {
			$paymentInfo = $ex->getMessage();

			/*
			 * Updating Payment Status
			 */
			PaymentModel::updateWhereEqualToken(
				array(
					'value' => array(
						'status' => 'failed'
					),
					'format' => array(
						'%s'
					)
				),
				$this->token
			);

			$aReturn = array(
				'status' => 'error',
				'data'   => $ex->getMessage()
			);

			do_action('wiloke/wiloke-submission/payment/after_payment', array(
				'gateway'       => 'paypal',
				'status'        => 'failed',
				'billingType'   => wilokeRepository('wiloke_submission:recurring'),
				'sessionID'     => $sessionID,
				'planID'        => $aSessionStore[$this->token],
				'planName'      => $planName
			));
		}

		PaymentMetaModel::set(abs($sessionID), wilokeRepository('paymentKeys:info'), $paymentInfo);

		return $aReturn;
	}

}