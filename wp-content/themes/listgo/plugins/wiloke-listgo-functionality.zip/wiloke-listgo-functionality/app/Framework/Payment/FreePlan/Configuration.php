<?php
namespace WilokeListgoFunctionality\Framework\Payment\FreePlan;


trait Configuration {
	public $gateway = 'banktransfer';
	public $aConfiguration;
	public $oReceipt;
	private $oApiContext;
	public $token;
	public $userID;

	protected function setApiContext(){
		$this->userID = get_current_user_id();
	}

	protected function setReceipt($oReceipt){
		$this->oReceipt = $oReceipt;
		$this->token    = $this->oReceipt->aInfo['token'];
	}

	protected function setUserID($userID){
		$this->userID = $userID;
	}
}