<?php
namespace WilokeListgoFunctionality\Framework\Payment\DirectBankTransfer;


use WilokeListgoFunctionality\Model\PaymentMetaModel;

class GetRecuringPaymentInfo {


}