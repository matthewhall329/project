<?php

namespace WilokeListgoFunctionality\Framework\Payment\PayPal;

use Carbon\Carbon;
use PayPal\Common\PayPalModel;
use WilokeListgoFunctionality\Model\PaymentMetaModel;
use WilokeListgoFunctionality\Model\PaymentModel;
use WilokeListgoFunctionality\Model\PayPalModel as WilokePayPalModel;
use WilokeListgoFunctionality\Model\PlanRelationshipModel;
use WilokeListgoFunctionality\Framework\UserPlan\RemainingItemsInRecurringPaymentInterface;
use WilokeListgoFunctionality\Framework\UserPlan\GetUserPlan;

class RemainingItemsInRecurringPayPal extends GetUserPlan implements RemainingItemsInRecurringPaymentInterface{
	protected $userID;
	protected $planID;
	protected $sessionID;
	protected $unlimitedItems = 100000000000;

	/**
	 * @param array $aUserInfo: It contains userID and planID
	 */
	public function __construct(array $aUserInfo) {
		$this->setUserID($aUserInfo['userID']);
		$this->setPlanID($aUserInfo['planID']);
		$this->setSessionID($aUserInfo['sessionID']);
		$this->getUserPlan();
		$this->getPlanType();
		$this->getPlan();
		$this->getNextBillingDate();
//		$this->getDetailPaymentID();
		$this->getPlanSettings();
	}

	public function setUserID($userID){
		$this->userID = $userID;
	}

	public function setPlanID($planID){
		$this->planID = $planID;
	}

	public function setSessionID($sessionID){
		$this->sessionID = $sessionID;
	}

	/**
	 * Calculating the remaining item
	 *
	 * @return number $remainingItems
	 */
	public function remainingItems(){
		$instSubscriptionStatus = new PayPalGetSubscriptionStatus;
		$oDateTime    = Carbon::now('UTC');
		$timestampNow   = $oDateTime->timestamp;
		date_default_timezone_set('UTC');
		$nextBillingToDateFormat = date(DATE_ATOM, $this->nextBillingDate);

		if ( $this->nextBillingDate > $timestampNow ){
			$status = PaymentModel::getSessionStatus($this->sessionID);
			if ( $status != 'succeeded' ){
				return 0;
			}
		}else{
			$agreementID = WilokePayPalModel::getAgreementID($this->sessionID);

			if ( empty($agreementID) ){
				return 0;
			}

			$instSubscriptionStatus->setRequestID($agreementID);
			$status = $instSubscriptionStatus->getStatus();

			if ( $status != 'active' ){
				return 0;
			}
		}
		if ( empty($this->aPlanSettings['number_of_posts']) ){
			return $this->unlimitedItems;
		}

		$maximumAllowableItems = abs($this->aPlanSettings['number_of_posts']);

		$period = abs($this->aPlanSettings['regular_period']);

		$countItemsUsed = PlanRelationshipModel::countItemsUsedByUpBlock($nextBillingToDateFormat, $period, $this->userID, $this->sessionID, $this->planID);

		return $maximumAllowableItems - $countItemsUsed;
	}
}