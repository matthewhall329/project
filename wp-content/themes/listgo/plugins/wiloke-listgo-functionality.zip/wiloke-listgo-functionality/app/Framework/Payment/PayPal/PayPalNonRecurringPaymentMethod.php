<?php
namespace WilokeListgoFunctionality\Framework\Payment\PayPal;

use PayPal\Api\Amount;
use PayPal\Api\Details;
use PayPal\Api\Item;
use PayPal\Api\ItemList;
use PayPal\Api\Payer;
use PayPal\Api\Payment;
use PayPal\Api\RedirectUrls;
use PayPal\Api\Transaction;
use PayPal\Exception\PayPalConnectionException;

use WilokeListgoFunctionality\Framework\Payment\PaymentMethodInterface;
use WilokeListgoFunctionality\Framework\Payment\Coupon;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use WilokeListgoFunctionality\Framework\Store\Session;

use WilokeListgoFunctionality\Model\PaymentModel;


class PayPalNonRecurringPaymentMethod implements PaymentMethodInterface{
	use PayPalGenerateUrls;
	use PayPalSetup;

	public $gateway = 'paypal';
	protected $storeTokenPlanSession;
	protected $aConfiguration = array();
	protected $oReceipt;
	protected $oApiContext = array();
	protected $paymentDescription = 'AgreePayment'; // This description is very important if you are using recurring payment
	protected $thankyouUrl = null;
	protected $cancelUrl = null;
	public $token = null;
	protected $aPayPayConfiguration;
	protected $instPayPalConfiguration;

	public function getBillingType() {
		return wilokeRepository('app:billingTypes', true)->sub('nonrecurring');
	}

	public function proceedPayment($oReceipt){
		$this->setup($oReceipt);
		$aResult = $this->getApprovalUrl();
		return $aResult;
	}

	private function parseTokenFromApprovalUrl($approvalUrl){
		$aParseData = explode('token=', $approvalUrl);
		$this->token = trim($aParseData[1]);
	}

	private function storeTokenAndPlanId(){
		if ( !$this->oReceipt->isMultiplePlan ){
			Session::setSession($this->storeTokenPlanSession, array(
				$this->token => $this->oReceipt->planID
			));
		}else{
			Session::setSession($this->storeTokenPlanSession, array(
				$this->token => $this->oReceipt->aPlans
			));
		}
	}

	private function getApprovalUrl(){
		// Create new payer and method
		$payer = new Payer();
		$payer->setPaymentMethod('paypal');

		$aItems = array();

		if ( !$this->oReceipt->isMultiplePlan ){
			$instPlan = new Item();
			$instPlan->setName($this->oReceipt->planName)
			         ->setCurrency($this->aConfiguration['currency_code'])
			         ->setQuantity(1)
			         ->setPrice($this->oReceipt->total);
			$aItems[] = $instPlan;
		}else{
			foreach ($this->oReceipt->aPlans as $planID => $aPlanInfo){
				$instPlan = new Item();
				$instPlan->setName($aPlanInfo['planName'])
				         ->setCurrency($this->aConfiguration['currency_code'])
				         ->setQuantity(1)
				         ->setPrice($aPlanInfo['total']);
				$aItems[] = $instPlan;
			}
		}

		$instItemList = new ItemList();
		$instItemList->setItems($aItems);

		// Maybe discount
//		$insDiscount = new Item();
//		$insDiscount->setName('Granola bars')
//		      ->setCurrency('USD')
//		      ->setQuantity(1)
//		      ->setPrice('-0.01');



//		if ( !empty($this->oReceipt->couponID) ){
//			$instCoupon = new Coupon($this->oReceipt->couponID);
//
//			if ( $instCoupon->isAvailable() ){
//				$discount = $instCoupon->getDiscount($this->oReceipt->total);
//				$instDetails = new Details();
//				$instDetails->setShippingDiscount($discount);
//				$instDetails->setSubtotal($total);
//				$total = $total - $discount;
//				$this->oReceipt->total = $total;
//				$amount->setDetails($instDetails);
//			}
//		}
//
		$instDetails = new Details();
		$instDetails->setSubtotal($this->oReceipt->subTotal);

		$instAmount = new Amount();
		$instAmount->setCurrency($this->aConfiguration['currency_code'])
		       ->setTotal($this->oReceipt->amountTotal)
		       ->setDetails($instDetails);

		$instAmount->setCurrency($this->aConfiguration['currency_code'])
		       ->setTotal($this->oReceipt->amountTotal);

		// Set transaction object
		$transaction = new Transaction();
		$transaction->setItemList($instItemList)
					->setAmount($instAmount)
					->setInvoiceNumber(uniqid())
		            ->setDescription($this->paymentDescription);

		// Set redirect urls
		$redirectUrls = new RedirectUrls();
		$redirectUrls->setReturnUrl($this->thankyouUrl)
		             ->setCancelUrl($this->cancelUrl);
		// Create the full payment object
		$payment = new Payment();
		$payment->setIntent('sale')
		        ->setPayer($payer)
		        ->setRedirectUrls($redirectUrls)
		        ->setTransactions(array($transaction));
		// Create payment with valid API context
		try {
			$payment->create($this->oApiContext);
			// Get PayPal redirect URL and redirect user
			$approvalUrl = $payment->getApprovalLink();
			$this->parseTokenFromApprovalUrl($approvalUrl);
			// Insert wiloke_submission_transaction and wiloke_submission_paypal_nonrecurring_payment before redirecting to PayPal
			$sessionID = PaymentModel::insert($this, $this->oReceipt);

			//
//			Session::setSession(wilokeRepository('paymentKeys:storeDiscountValue') . '_' . $this->token, '0.01');

			if ( empty($sessionID) ){
				return array(
					'status' => 'error',
					'msg'    => esc_html__('We could not create this session', 'wiloke')
				);
			}else{
				$this->storeTokenAndPlanId();
				return array(
					'status'    => 'success',
					'msg'       => esc_html__('Got Approval url', 'wiloke-submission'),
					'next'      => $approvalUrl,
					'redirectTo'=> $approvalUrl
				);
			}
		} catch (PayPalConnectionException $ex) {
			return array(
				'code'   => $ex->getCode(),
				'status' => 'error',
				'msg'    => $ex->getMessage()
			);
		} catch (\Exception $ex) {
			return array(
				'status' => 'error',
				'msg'    => $ex->getMessage()
			);
		}
	}
}