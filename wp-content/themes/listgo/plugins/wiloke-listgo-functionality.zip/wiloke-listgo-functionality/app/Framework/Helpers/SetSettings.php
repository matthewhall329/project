<?php
namespace WilokeListgoFunctionality\Framework\Helpers;

class SetSettings{

	/**
	 * We will use cache in the feature
	 *
	 * @param number $postID
	 * @param string $metaKey
	 *
	 * @return mixed
	 */
	public static function setPostMeta($postID, $metaKey, $val){
		return update_post_meta($postID, $metaKey, $val);
	}

	/**
	 * Get User Meta
	 *
	 * @param number $userID
	 * @param string $metaKey
	 *
	 * @return mixed
	 */
	public static function setUserMeta($userID, $metaKey, $value){
		update_user_meta($userID, $metaKey, $value);
	}

	public static function setOptions($key, $value){
		update_option($key, maybe_serialize($value));
	}
}