<?php
namespace WilokeListgoFunctionality\Framework\Payment\PayPal;

use PayPal\Api\Agreement;
use PayPal\Api\AgreementStateDescriptor;
use WilokeListgoFunctionality\Framework\Payment\SuspendPlanInterface;
use WilokeListgoFunctionality\Model\PaymentModel;
use WilokeListgoFunctionality\Model\PayPalModel;
use WilokeListgoFunctionality\Model\UserModel;

class PayPalSuspendPlan extends PayPalSetupAPIContext implements SuspendPlanInterface {
	protected $oApiContext;
	protected $aUserPlanInfo;
	protected $descriptor = 'Suspending the agreement';
	protected $agreementID;
	protected $userID;
	protected $planType;
	protected $sessionID;
	protected $planID;
	protected $agreementStatus;

	public function __construct($userID, array $aUserPlanInfo) {
		parent::__construct();
		$this->aUserPlanInfo = $aUserPlanInfo;
		$this->descriptor  = apply_filters('wiloke-submission/app/payment/paypal/PayPalSuspendPlan/descriptor', $this->descriptor);
		$this->init();
	}

	protected function init(){
		$this->setUserID($this->aUserPlanInfo['userID']);
		$this->setPlanID($this->aUserPlanInfo['planID']);
		$this->setSessionID($this->aUserPlanInfo['sessionID']);
		$this->setPlanType(get_post_type($this->planID));
		$this->getAgreementStatus();
	}

	public function setPlanID($planID){
		$this->planID = $planID;
		return $this;
	}

	public function setUserID($userID){
		$this->userID = $userID;
		return $this;
	}

	public function setAgreementID($agreementID){
		$this->agreementID = $agreementID;
		return $this;
	}

	public function setSessionID($sessionID){
		$this->sessionID = $sessionID;
		return $this;
	}

	public function setPlanType($planType){
		$this->planType = $planType;
		return $this;
	}

	public function execute(){
		if ( $this->agreementStatus == 'active' ){
			//Create an Agreement State Descriptor, explaining the reason to suspend.
			$instAgreementStateDescriptor = new AgreementStateDescriptor();
			$instAgreementStateDescriptor->setNote($this->descriptor);
			$oAgreementInfo = Agreement::get($this->agreementID, $this->oApiContext);

			try {
				//Lets get the updated Agreement Object
				$oAgreementInfo->suspend($instAgreementStateDescriptor, $this->oApiContext);
				$oNewAgreementInfo = Agreement::get($this->agreementID, $this->oApiContext);

				return array(
					'status' => 'success',
					'isRealSuspended' => true,
					'msg'    => $oNewAgreementInfo
				);
			} catch (\Exception $ex) {
				return array(
					'status' => 'error',
					'msg'    => $ex->getMessage()
				);
			}
		}else{
			return array(
				'status' => 'success',
				'msg'    => esc_html__('The current plan status: ', 'wiloke') . $this->agreementStatus
			);
		}
	}

	/**
	 * Get current Plan Key
	 */
	public function getAgreementStatus(){
		$this->agreementID = PayPalModel::getAgreementID($this->sessionID);
		$agreementStatus = PayPalHelps::billingAgreementStatus($this->agreementID);
		$this->agreementStatus = $agreementStatus;
	}
}