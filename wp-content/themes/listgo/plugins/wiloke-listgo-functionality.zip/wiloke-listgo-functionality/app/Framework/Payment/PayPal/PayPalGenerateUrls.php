<?php
namespace WilokeListgoFunctionality\Framework\Payment\PayPal;

use WilokeListgoFunctionality\Framework\Helpers\GenerateUrl;
use WilokeListgoFunctionality\Framework\Helpers\NotFoundHttpException;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;

trait PayPalGenerateUrls{
	public function thankyouUrl(){
		if( !empty($this->oReceipt->thankyourUrl) ){
			$thankyouUrl = $this->oReceipt->thankyourUrl;
		}else{
			$thankyouUrl = get_permalink($this->aConfiguration['thankyou']);
		}

		if ( empty($thankyouUrl) ){
			new NotFoundHttpException(esc_html__('The thankyou page is required.', 'wiloke'));
		}

		$this->thankyouUrl = GenerateUrl::url($thankyouUrl, array(
			'billingType' => $this->getBillingType(),
			'planID'      => $this->oReceipt->planID
		));
		return urlencode($this->thankyouUrl);
	}

	public function cancelUrl(){
		if(!empty($this->oReceipt->cancelUrl)){
			$cancelUrl = $this->oReceipt->cancelUrl;
		}else{
			$cancelUrl = get_permalink($this->aConfiguration['cancel']);
		}

		if ( empty($cancelUrl) ){
			if ( empty($thankyouUrl) ){
				new NotFoundHttpException(esc_html__('The cancel page is required.', 'wiloke'));
			}
		}

		$this->cancelUrl = GenerateUrl::url($cancelUrl, array(
			'billingType' => PaymentConfiguration::isNonRecurringPayment() ? wilokeRepository('app:billingTypes', true)->sub('nonrecurring') : wilokeRepository('app:billingTypes', true)->sub('recurring'),
			'planID'      => $this->oReceipt->planID
		));
		return urlencode($this->cancelUrl);
	}

}