<?php

namespace WilokeListgoFunctionality\Framework\Helpers;


class Upload {
	public static function listgoFolder(){
		$uploadDir = wp_upload_dir();
		if ( !empty($uploadDir['basedir']) ) {
			$wilokeDir = $uploadDir['basedir'].'/listgo';
			if ( ! file_exists( $wilokeDir ) ) {
				wp_mkdir_p( $wilokeDir );
			}
		}

		return $uploadDir['basedir'] . '/listgo/';
	}
}