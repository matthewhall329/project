<?php
namespace WilokeListgoFunctionality\Framework\Payment;

use PayPal\Api\Payment;

class Tax{
	protected $aConfiguration;
	public function __construct($price) {
		$this->plusTax();
	}

	public function plusTax(){
		$this->aConfiguration = PaymentConfiguration::getPaymentConfiguration();
		if ( $this->aConfiguration['toggle_tax'] ){
			return 0;
		}

//		return $this->aConfiguration
	}
}