<?php
namespace WilokeListgoFunctionality\Framework\Payment\PayPal;

use WilokeListgoFunctionality\Model\InvoiceModel;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use WilokeListgoFunctionality\Model\PaymentMetaModel;
use WilokeListgoFunctionality\Model\PaymentModel;
use WilokeListgoFunctionality\Model\PayPalModel as WilokePayPalModel;
use WilokeListgoFunctionality\Model\UserModel;

class Webhook{
	public $gateway = 'paypal';

	public function __construct() {
		$this->listener();
	}

	public function listener(){
		$aGateways = PaymentConfiguration::getPaymentGateways();
		if ( empty($aGateways) ){
			return false;
		}

		if ( !in_array($this->gateway, $aGateways) ){
			return false;
		}

		$rawdata = file_get_contents('php://input');
		if ( empty($rawdata) ){
			return false;
		}

		$oEventInfo = json_decode($rawdata);

		switch ($oEventInfo->event_type){
			case 'PAYMENT.SALE.COMPLETED':
				if ( isset($oEventInfo->resource->billing_agreement_id) ){
					// Recurring Payment
					$sessionID = WilokePayPalModel::getSessionIDWhereEqualToBillingAgreementID($oEventInfo->resource->billing_agreement_id);
					$sessionID = abs($sessionID);
					if ( empty($sessionID) ){
						return false;
					}

					InvoiceModel::insert(
						array(
							'sessionID'     => $sessionID,
							'regular_price' => $oEventInfo->resource->amount->total,
							'currency'      => $oEventInfo->resource->amount->currency,
							'message'       => $oEventInfo,
							'discount'      => 0
						)
					);

					// After the subscription was expended successfully, We need to be re-publish all listings that belong to this session and change all listings
					// that are holding processing status to pending status.
					$planID = PaymentModel::getPlanIDWhereEqualToSessionID($sessionID);
					$userID = PaymentModel::getUserIDWhereEqualToSessionID($sessionID);

					$oAgreement = PayPalGetBillingAgreement::get($oEventInfo->resource->billing_agreement_id);
					$instUserModel = new UserModel();
					$instUserModel->setUserID($userID)
					              ->setNextBillingDate($oAgreement->agreement_details->next_billing_date)
					              ->setPlanID($planID)
					              ->setSessionID($sessionID)
					              ->setGateway($this->gateway)
					              ->setBillingType(wilokeRepository('app:billingTypes', true)->sub('recurring'))
					              ->setUserPlan();

					PaymentMetaModel::patch($sessionID, wilokeRepository('app:paymentKeys', true)->sub('info'), $oAgreement);
					PaymentModel::updateToSucceededStatusWhereEqualToSessionID($sessionID);
					do_action('wiloke_submission/after-subscription-extended', array(
						'sessionID'         => $sessionID,
						'planID'            => $planID,
						'nextBillingDate'   => $oAgreement->agreement_details->next_billing_date
					));

					do_action('wiloke_submission/after-subscription-extended-'.get_post_type($planID), array(
						'sessionID'         => $sessionID,
						'planID'            => $planID,
						'nextBillingDate'   => $oAgreement->agreement_details->next_billing_date
					));

				}else{
					// Non-Recurring Payment
					$paymentID = $oEventInfo->resource->parent_payment;
					$sessionID = WilokePayPalModel::getSessionIDWhereEqualToPaymentID($paymentID);
					if ( empty($sessionID) ){
						return false;
					}

					$discountVal = get_transient($paymentID);
					delete_transient($paymentID);

					InvoiceModel::insert(
						array(
							'sessionID'     => $sessionID,
							'regular_price' => $oEventInfo->resource->amount->total,
							'currency'      => $oEventInfo->resource->amount->currency,
							'message'       => $oEventInfo,
							'discount'      => empty($discountVal) ? 0 : $discountVal
						)
					);
				}
				break;
			case 'PAYMENT.SALE.REFUNDED':
			case 'PAYMENT.SALE.DENIED':
				$paymentID = $oEventInfo->resource->parent_payment;
				$sessionID = WilokePayPalModel::getSessionIDWhereEqualToPaymentID($paymentID);
				$sessionID = abs($sessionID);
				if ( empty($sessionID) ){
					return false;
				}

				InvoiceModel::insert(
					array(
						'sessionID'     => $sessionID,
						'regular_price' => $oEventInfo->resource->amount->total,
						'currency'      => $oEventInfo->resource->amount->currency,
						'message'       => $oEventInfo,
						'discount'      => 0
					)
				);

				if ( $oEventInfo->event_type == 'PAYMENT.SALE.REFUNDED' ){
					$paymentStatus = wilokeRepository('app:paymentStatus', true)->sub('refunded');
				}else{
					$paymentStatus = wilokeRepository('app:paymentStatus', true)->sub('denined');
				}

				PaymentModel::updatePaymentStatusWhereEqualToSessionID($paymentStatus, $sessionID);
				do_action('wiloke_submission/migrate-posts-to-expired-status', $sessionID);
				break;
			case 'BILLING.SUBSCRIPTION.CANCELLED':
			case 'BILLING.SUBSCRIPTION.SUSPENDED':
				$sessionID = WilokePayPalModel::getSessionIDWhereEqualToBillingAgreementID($oEventInfo->resource->id);
				$sessionID = abs($sessionID);
				if ( empty($sessionID) ){
					return false;
				}

				if ( $oEventInfo->event_type == 'BILLING.SUBSCRIPTION.CANCELLED' ){
					PaymentModel::updateToCancelledStatusWhereEqualToSessionID($sessionID);
				}else{
					PaymentModel::updateToSuspendedStatusWhereEqualToSessionID($sessionID);
				}

				$aPaymentMeta = PaymentMetaModel::get($sessionID, wilokeRepository('paymentKeys:info'));
				if ( !isset($aPaymentMeta['nextBillingDate']) ){
					do_action('wiloke_submission/migrate-posts-to-expired-status', $sessionID);
				}else{
					$nextBillingDate = $aPaymentMeta['nextBillingDate'];
					$nextBillingDate = is_string($nextBillingDate) ? strtotime($nextBillingDate) : $aPaymentMeta['nextBillingDate'];
					$now = strtotime(current_time(DATE_ATOM, 1));

					if ( $now >= $nextBillingDate ){
						$planID = PaymentModel::getPlanIDWhereEqualToSessionID($sessionID);
						do_action('wiloke_submission/migrate-posts-to-expired-status', $sessionID);

						$userID = PaymentModel::getUserIDWhereEqualToSessionID($sessionID);
						UserModel::removeUserPlanByPlanID($userID, $planID);
						$oAgreement = PayPalGetBillingAgreement::get($oEventInfo->resource->id);
						PaymentMetaModel::patch($sessionID, wilokeRepository('app:paymentKeys', true)->sub('info'), $oAgreement);
					}
				}
				break;
			case 'BILLING.SUBSCRIPTION.RE-ACTIVATED':
				$sessionID = WilokePayPalModel::getSessionIDWhereEqualToBillingAgreementID($oEventInfo->resource->id);
				$sessionID = abs($sessionID);
				if ( empty($sessionID) ){
					return false;
				}
				// After the subscription was expended successfully, We need to be re-publish all listings that belong to this session and change all listings
				// that are holding processing status to pending status.
				$planID = PaymentModel::getPlanIDWhereEqualToSessionID($sessionID);
				$userID = PaymentModel::getUserIDWhereEqualToSessionID($sessionID);

				$oAgreement = PayPalGetBillingAgreement::get($oEventInfo->resource->id);
				$instUserModel = new UserModel();
				$instUserModel->setUserID($userID)
				              ->setNextBillingDate($oAgreement->agreement_details->next_billing_date)
				              ->setPlanID($planID)
				              ->setSessionID($sessionID)
				              ->setGateway($this->gateway)
				              ->setBillingType(wilokeRepository('app:billingTypes', true)->sub('recurring'))
				              ->setUserPlan();

				PaymentMetaModel::patch($sessionID, wilokeRepository('app:paymentKeys', true)->sub('info'), $oAgreement);
				PaymentModel::updateToSucceededStatusWhereEqualToSessionID($sessionID);
				do_action('wiloke_submission/after-subscription-extended', array(
					'sessionID'         => $sessionID,
					'planID'            => $planID,
					'nextBillingDate'   => $oAgreement->agreement_details->next_billing_date
				));

				do_action('wiloke_submission/after-subscription-extended-'.get_post_type($planID), array(
					'sessionID'         => $sessionID,
					'planID'            => $planID,
					'nextBillingDate'   => $oAgreement->agreement_details->next_billing_date
				));
				break;
		}
	}
}