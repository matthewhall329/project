<?php
namespace WilokeListgoFunctionality\Framework\Payment\Stripe;


use WilokeListgoFunctionality\Framework\Helpers\Exception;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use WilokeListgoFunctionality\Model\StripeModel;


trait StripeConfiguration{
	public $gateway = 'stripe';
	public $aConfiguration;
	public $oReceipt;
	private $oApiContext;
	public $token;
	public $thankyouUrl;
	public $cancelUrl;
	protected $customerID;

	private function setApiContext(){
		$this->aConfiguration = PaymentConfiguration::get();
		if ( empty($this->aConfiguration) ){
			Exception::error(esc_html__('The Stripe has not configured yet!', 'wiloke'));
		}

		$this->aConfiguration['payment_gateways'] = explode(',', $this->aConfiguration['payment_gateways']);
		if ( !in_array('stripe', $this->aConfiguration['payment_gateways']) ){
			Exception::error(esc_html__('The Stripe has not configured yet!', 'wiloke'));
		}

		$this->oApiContext['secretKey']     = $this->aConfiguration['stripe_secret_key'];
		$this->oApiContext['zeroDecimal']   = $this->aConfiguration['stripe_zero_decimal'];

		settype($this->oApiContext, 'object');
		\Stripe\Stripe::setApiKey($this->oApiContext->secretKey);
	}

	private function setReceipt($oReceipt){
		$this->oReceipt = $oReceipt;
		$this->token    = $this->oReceipt->aInfo['token'];
		$this->userID   = get_current_user_id();
	}


	/**
	 * If user has already executed a session before, We will have his/her customer id
	 *
	 * @return void
	 */
	protected function getCustomerID(){
		$this->customerID = StripeModel::getCustomerID($this->userID);
	}

	private function setUserID($userID){
		$this->userID = $userID;
	}
}