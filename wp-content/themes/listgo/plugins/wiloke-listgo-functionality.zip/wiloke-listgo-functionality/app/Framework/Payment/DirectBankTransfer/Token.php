<?php

namespace WilokeListgoFunctionality\Framework\Payment\DirectBankTransfer;


class Token {
	// Temporary token
	public static function generateToken(){
		return time();
	}
}