<?php
namespace WilokeListgoFunctionality\Framework\Payment;


interface SuspendPlanInterface {
	public function execute();
}