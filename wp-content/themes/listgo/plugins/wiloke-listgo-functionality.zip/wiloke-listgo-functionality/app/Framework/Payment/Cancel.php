<?php
namespace WilokeListgoFunctionality\Framework\Payment;


class Cancel{
	public $aReceipt;
	public $oPayment;

	public function __construct(Receipt $aReceipt, PaymentMethodInterface $oPayment) {
		$this->aReceipt = $aReceipt;
		$this->oPayment = $oPayment;
	}

	public function generateUrl(){
		if ( isset($this->aReceipt['cancelUrl']) ){
			return $this->aReceipt['cancelUrl'];
		}

		return get_permalink($this->oPayment->aConfiguration['cancel']);
	}
}