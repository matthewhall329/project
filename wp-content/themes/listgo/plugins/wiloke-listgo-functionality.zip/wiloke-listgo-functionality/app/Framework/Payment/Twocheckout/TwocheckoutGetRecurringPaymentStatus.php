<?php
namespace WilokeListgoFunctionality\Framework\Payment\Twocheckout;

class TwocheckoutGetRecurringPaymentStatus {
	use TwocheckoutConfiguration;

	protected $requestID;

	/*
	 * Request ID is sale ID
	 *
	 * @param string $saleID
	 */
	public function setRequestID($saleID){
		$this->requestID = $saleID;
	}


	/**
	 * Get Status
	 */
	public function getStatus(){
		$this->setApiContext();
		$aSale = \Twocheckout_Sale::retrieve(
			array(
				'sale_id' => $this->requestID
			)
		);

		if ( empty($aSale) ){
			return 'empty';
		}

		if ( !empty($aSale['sale']['recurring_decline']) ){
			return wilokeRepository('app:paymentStatus', true)->sub('cancelled');
		}

		if ( !isset($aSale['sale']['invoices']) || empty($aSale['sale']['invoices']) ){
			return 'empty';
		}

		$aLastInvoice = end($aSale['sale']['invoices']);
		$aLastLineItem = end($aLastInvoice['lineitems']);

		return $aLastLineItem['billing']['recurring_status'];
	}

}