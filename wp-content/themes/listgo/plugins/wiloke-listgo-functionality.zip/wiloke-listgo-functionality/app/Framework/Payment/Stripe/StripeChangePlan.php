<?php
namespace WilokeListgoFunctionality\Framework\Payment\Stripe;


use WilokeListgoFunctionality\Framework\Payment\Checkout;
use WilokeListgoFunctionality\Framework\Payment\Receipt;
use WilokeListgoFunctionality\Model\PaymentMetaModel;
use WilokeListgoFunctionality\Model\PaymentModel;
use WilokeListgoFunctionality\Model\StripeModel;


class StripeChangePlan {
	use StripeConfiguration;

	protected $newPlanID;
	private $newSubscriptionID;
	protected $newSessionID;
	protected $customerID;
	protected $aArgs;
	protected $userID;

	public function __construct($userID, $planID) {
		$this->userID = $userID;
		$this->newPlanID = $planID;
	}

	/**
	 * If user has already executed a session before, We will have his/her customer id
	 *
	 * @return void
	 */
	protected function getCustomerID(){
		$this->customerID = StripeModel::getCustomerID($this->userID);
	}

	public function execute(){
		$agreementStatus = $this->getBillingStatusOfTheNewPlan();

		//If this plan is already created before, We will reactivated it
		if ( $agreementStatus == wilokeRepository('app:paymentStatus', true)->sub('suspended') ){
			$instStripeReactivatePlan = new StripeReactivatePlan($this->newSubscriptionID);
			$aReactivationStatus = $instStripeReactivatePlan->execute();
			// If we could not renew the plan, We will create new one
			if ( $aReactivationStatus['status'] == 'success' ){
				PaymentMetaModel::update($this->newSessionID, wilokeRepository('paymentKeys:info'), $aReactivationStatus['msg']);
				PaymentModel::updateToSucceededStatusWhereEqualToSessionID($this->newSessionID);

				/**
				 * @hook PlanRelationship@updateSessionID 5
				 * @hook UserController@createUserPlan 10
				 */
				do_action('wiloke/wiloke-submission/payment/after_payment', array(
					'gateway'            => $this->gateway,
					'status'             => 'succeeded',
					'billingType'        => wilokeRepository('app:billingTypes', true)->sub('recurring'),
					'sessionID'          => $this->newSessionID,
					'planID'             => $this->newPlanID,
					'planName'           => get_the_title($this->newPlanID),
					'nextBillingDate'    => $aReactivationStatus['msg']->current_period_end,
					'postID'             => '',
					'planRelationshipID' => ''
				));

				return array(
					'status' => 'success',
					'msg'    => esc_html__('Congratulations! Your plan has been reactivated successfully!', 'wiloke')
				);
			}
		}

		// If it's first time you use this plan, We will create a new billing plan
		$aData = array(
			'planID'    => $this->newPlanID,
			'couponID'  => ''
		);

		$this->getCustomerID();
		if ( empty($this->customerID) ){
			// Generating Stripe Token
			$instStripeToken = new StripeGenerateToken;
			$instStripeToken->generate();
			$aData['token'] = $instStripeToken->getTokenID();
		}

		$oReceipt       = new Receipt($aData);
		$oPayPalMethod  = new StripeRecurringPaymentMethod();
		$oCheckout      = new Checkout();

		/*
		 * Referring PayPalRecurringPayment.php to get more
		 */
		$aCheckAcceptPaymentStatus = $oCheckout->begin($oReceipt, $oPayPalMethod);

		return $aCheckAcceptPaymentStatus;
	}

	/**
	 * Check whether this plan contain an agreement ID or not
	 */
	protected function getBillingStatusOfTheNewPlan(){
		$lastSuspendedSessionID = StripeModel::getUserLastSuspendedSessionIDEnqualToPlanID($this->userID, $this->newPlanID);

		$this->newSessionID = abs($lastSuspendedSessionID);

		if ( $this->newSessionID ){
			$this->newSubscriptionID = StripeModel::getSubscriptionID($this->newSessionID);

			$instStripeGetRecurringPaymentStatus = new StripeGetRecurringPaymentStatus();
			$instStripeGetRecurringPaymentStatus->setRequestID($this->newSubscriptionID);

			return $agreementStatus = $instStripeGetRecurringPaymentStatus->getStatus();
		}

		return false;
	}
}