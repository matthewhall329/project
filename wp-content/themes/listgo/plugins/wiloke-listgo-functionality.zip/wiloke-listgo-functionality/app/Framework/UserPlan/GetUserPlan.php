<?php
namespace WilokeListgoFunctionality\Framework\UserPlan;


use WilokeListgoFunctionality\Model\UserModel;
use WilokeListgoFunctionality\Model\PaymentModel;
use WilokeListgoFunctionality\Framework\Helpers\GetSettings;


abstract class GetUserPlan {
	protected $userID;
	protected $planID;
	protected $aUserPlan;
	protected $sessionID;
	protected $nextBillingDate;
	protected $billedDate;
	protected $detailPaymentID;
	protected $planType;
	protected $aPlanSettings;

	/**
	 * Get post type by plan id
	 * @return void
	 */
	public function getPlanType(){
		$this->planType = get_post_field('post_type', $this->planID);
	}

	/**
	 * Get User's plan
	 *
	 * @refer UserModel
	 * @return void
	 */
	public function getPlan(){
		$this->aUserPlan = UserModel::getUserDetailPlan($this->userID, $this->planID);
	}

	/**
	 * Get User's plan
	 *
	 * @refer UserModel
	 * @return void
	 */
	public function getUserPlan(){
		$this->aUserPlan = UserModel::getDetailPlan($this->planID);
	}

	/**
	 * Get Session ID in wiloke_submission_session table
	 *
	 * @return void
	 */
	public function getSessionID(){
		$this->sessionID = isset($this->aUserPlan['sessionID']) ? $this->aUserPlan['sessionID'] : '';
	}

	/**
	 * Get plan settings of the specified plan ID
	 *
	 * @return void
	 */
	public function getPlanSettings(){
		$metaKey = get_post_field('post_type', $this->planID);
		$this->aPlanSettings = GetSettings::getPostMeta($this->planID, $metaKey);
	}

	/**
	 * Get the next billing date
	 *
	 * @return void
	 */
	public function getNextBillingDate(){
		if ( isset($this->aUserPlan['nextBillingDate']) ){
			if ( is_string($this->aUserPlan['nextBillingDate']) ){
				$this->nextBillingDate = strtotime($this->aUserPlan['nextBillingDate']);
			}else{
				$this->nextBillingDate = $this->aUserPlan['nextBillingDate'];
			}
		}else{
			$this->nextBillingDate = '';
		}
	}

	/**
	 * Get recurring payment id of the user
	 *
	 * @return void
	 */
	public function getDetailPaymentID(){
		$this->detailPaymentID = isset($this->aUserPlan['detailPaymentID']) ? $this->aUserPlan['detailPaymentID'] : '';
	}

	/**
	 * Get Billed Date of the Non Recurring Payment
	 *
	 * @return void
	 */
	public function getBilledDate(){
		$this->billedDate = PaymentModel::getCreatedDate($this->sessionID);
	}
}