<?php
namespace WilokeListgoFunctionality\Framework\Helpers;

use Symfony\Component\HttpKernel\Exception\NotFoundHttpException as SymfonyNotFoundHttpException ;

class NotFoundHttpException {
	public function __construct($msg){
		if ( wp_doing_ajax() ){
			wp_send_json_error(
				array(
					'msg' => $msg
				)
			);
		}else{
			throw new SymfonyNotFoundHttpException($msg);
		}
	}
}