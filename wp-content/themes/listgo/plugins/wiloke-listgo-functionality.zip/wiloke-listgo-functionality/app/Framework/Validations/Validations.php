<?php
namespace WilokeListgoFunctionality\Framework\Validations;


class Validations {
	/**
	 * Checking whether term is exists or not
	 *
	 * @param number $termID
	 * $param string $taxonomy
	 *
	 * @return bool
	 */
	public static function termExists($termID, $taxonomy){

	}
}