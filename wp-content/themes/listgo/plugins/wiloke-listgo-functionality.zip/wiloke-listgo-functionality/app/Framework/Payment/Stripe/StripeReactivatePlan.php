<?php
namespace WilokeListgoFunctionality\Framework\Payment\Stripe;


class StripeReactivatePlan {
	use StripeConfiguration;

	protected $subscriptionID;

	public function __construct($subscriptionID) {
		$this->subscriptionID = $subscriptionID;
	}

	public function execute(){
		$this->setApiContext();
		try{
			$oSubscription = \Stripe\Subscription::retrieve($this->subscriptionID);
			$oSubscription->coupon = NULL; // <= It's very important, We will get rid of Free Forever Coupon From this plan
			$oSubscription->save();

			return array(
				'status' => 'success',
				'msg'    => \Stripe\Subscription::retrieve($this->subscriptionID)
			);
		}catch (\Exception $oE){
			return array(
				'status' => 'error',
				'msg'    => $oE->getMessage()
			);
		}
	}
}