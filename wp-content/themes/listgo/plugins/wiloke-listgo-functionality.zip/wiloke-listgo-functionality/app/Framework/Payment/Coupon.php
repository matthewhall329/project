<?php
namespace WilokeListgoFunctionality\Framework\Payment;


class Coupon{
	protected $couponID;
	protected $price;
	protected $couponType;
	protected $aSettings;

	public function __construct($couponID) {
		$this->couponID = $couponID;
		$this->settings();

	}

	public function settings(){
		$this->aSettings = !empty($this->aSettings) ? $this->aSettings : get_post_meta($this->couponID, 'wiloke_submission_coupon_settings', true);
	}

	public function isAvailable(){
		return true;
	}

	public function getDiscount($price){
		$this->couponType = $this->aSettings['coupon_type'];
		$couponAmount = absint($this->aSettings['coupon_amount']);

		if ( $this->couponType == 'amount_off' ){
			if ( abs($price) < abs($couponAmount) ){
				return $price;
			}

			return $couponAmount;
		}
		return ceil($price*$couponAmount/100);
	}

	public function getCouponDuration(){
		return $this->aSettings['coupon_duration'];
	}
}