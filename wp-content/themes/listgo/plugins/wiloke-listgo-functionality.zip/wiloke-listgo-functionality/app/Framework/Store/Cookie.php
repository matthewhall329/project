<?php
namespace WilokeListgoFunctionality\Framework\Store;


use WilokeListgoFunctionality\Framework\Helpers\GeneratePrefix;

class Cookie{
	public static function set($name, $value){
		if ( !headers_sent() ){
			setcookie(GeneratePrefix::generateKey($name), $value, 0, '/');
		}else{
			$_COOKIE[GeneratePrefix::generateKey($name)] = $value;
		}
	}

	public static function get($name){
		if ( !isset($_COOKIE[GeneratePrefix::generateKey($name)]) ){
			return false;
		}
		return $_COOKIE[GeneratePrefix::generateKey($name)];
	}

	public static function destroy($name=null){
		if ( !headers_sent() ){
			unset($_COOKIE[GeneratePrefix::generateKey($name)]);
		}else{
			setcookie(GeneratePrefix::generateKey($name), '', time() - 10000);
			setcookie(GeneratePrefix::generateKey($name), '', time() - 10000, '/', site_url());
		}
	}
}