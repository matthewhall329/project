<?php

namespace WilokeListgoFunctionality\Framework\Payment\DirectBankTransfer;

use Carbon\Carbon;
use WilokeListgoFunctionality\Framework\Helpers\Time;
use WilokeListgoFunctionality\Framework\UserPlan\GetUserPlan;
use WilokeListgoFunctionality\Framework\UserPlan\RemainingItemsInRecurringPaymentInterface;
use WilokeListgoFunctionality\Model\PaymentModel;
use WilokeListgoFunctionality\Model\PlanRelationshipModel;

class RemainingItemsInRecurringPayment extends GetUserPlan implements RemainingItemsInRecurringPaymentInterface {
	protected $userID;
	protected $planID;
	protected $sessionID;
	protected $unlimitedItems = 100000000000;

	/**
	 * @param array $aUserInfo: It contains userID and planID
	 */
	public function __construct(array $aUserInfo) {
		$this->setUserID($aUserInfo['userID']);
		$this->setPlanID($aUserInfo['planID']);
		$this->setSessionID($aUserInfo['sessionID']);
		$this->getUserPlan();
		$this->getPlanType();
		$this->getPlan();
		$this->getNextBillingDate();
		$this->getPlanSettings();
	}

	public function setUserID($userID){
		$this->userID = $userID;
	}

	public function setPlanID($planID){
		$this->planID = $planID;
	}

	public function setSessionID($sessionID){
		$this->sessionID = $sessionID;
	}

	/**
	 * Calculating the remaining item
	 *
	 * @return number $remainingItems
	 */
	public function remainingItems(){
		$status = PaymentModel::getSessionStatus($this->sessionID);

		if ( $status != 'succeeded' ){
			return 0;
		}

		$timestampNow = Time::timestampUTCNow();
		date_default_timezone_set('UTC');
		$nextBillingToDateFormat = date(DATE_ATOM, $this->nextBillingDate);

		if ( $timestampNow > $this->nextBillingDate ){
			return 0;
		}

		if ( empty($this->aPlanSettings['number_of_posts']) ){
			return $this->unlimitedItems;
		}

		$maximumAllowableItems = abs($this->aPlanSettings['number_of_posts']);

		$period = abs($this->aPlanSettings['regular_period']);

		$countItemsUsed = PlanRelationshipModel::countItemsUsedByUpBlock($nextBillingToDateFormat, $period, $this->userID, $this->sessionID, $this->planID);

		return $maximumAllowableItems - $countItemsUsed;
	}
}