<?php
namespace WilokeListgoFunctionality\Framework\Helpers;


class General {
	/**
	 * Get Client IP
	 * @since 1.0.1
	 */
	public static function clientIP(){
		if (isset($_SERVER['HTTP_CLIENT_IP'])) {
			$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
		}else if(isset($_SERVER['HTTP_X_FORWARDED_FOR'])){
			$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
		}else if(isset($_SERVER['HTTP_X_FORWARDED'])) {
			$ipaddress = $_SERVER['HTTP_X_FORWARDED'];
		}else if(isset($_SERVER['HTTP_FORWARDED_FOR'])) {
			$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
		}else if(isset($_SERVER['HTTP_FORWARDED'])){
			$ipaddress = $_SERVER['HTTP_FORWARDED'];
		}else if(isset($_SERVER['REMOTE_ADDR'])) {
			$ipaddress = $_SERVER['REMOTE_ADDR'];
		}else {
			$ipaddress = false;
		}
		return $ipaddress;
	}

	public static function detectPostType(){
		if ( !is_admin() ){
			return '';
		}

		if ( isset($_REQUEST['post']) ){
			return get_post_field('post_type', $_REQUEST['post']);
		}else if ( isset($_REQUEST['post_type']) ){
			return $_REQUEST['post_type'];
		}

		return '';
	}
}