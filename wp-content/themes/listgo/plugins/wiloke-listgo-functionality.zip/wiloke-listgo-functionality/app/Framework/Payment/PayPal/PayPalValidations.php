<?php
namespace WilokeListgoFunctionality\Framework\Payment\PayPal;


use WilokeListgoFunctionality\Framework\Store\Session;

trait PayPalValidations{
	function validateBeforeExecuting(){
		if ( !isset($_GET['token'])  ){
			return false;
		}
		$storeTokenPlanSession = wilokeRepository('sessionkeys:storeTokenPlanSession');
		$aStoreTokenPlan = Session::getSession($storeTokenPlanSession);
		if ( empty($aStoreTokenPlan) || !is_array($aStoreTokenPlan) ){
			return false;
		}

		if ( !array_key_exists($_GET['token'], $aStoreTokenPlan) ){
			return false;
		}

		Session::destroySession($storeTokenPlanSession);
		return true;
	}
}