<?php
namespace WilokeListgoFunctionality\Framework\Helpers;

use WilokeListgoFunctionality\Model\PaymentMetaModel;

class GetSettings{
	protected static $aOptions;

	public static function convertToRightKey($postID, $metaKey){
		if ( get_post_type($postID) == 'pricing' ){
			$metaKey = 'pricing_settings';
		}else if ( get_post_type($postID) == 'event-pricing' ){
			$metaKey = 'event_pricing_settings';
		}else if ( get_post_type($postID) == 'promotional-pricing' ){
			$metaKey = 'wiloke_submission_promotion';
		}

		return $metaKey;
	}


	/**
	 * We will use cache in the feature
	 *
	 * @param number $postID
	 * @param string $metaKey
	 *
	 * @return mixed
	 */
	public static function getPostMeta($postID, $metaKey=null){
		return get_post_meta($postID, self::convertToRightKey($postID, $metaKey), true);
	}

	/**
	 * We will use cache in the feature
	 *
	 * @param number $postID
	 * @param string $metaKey
	 *
	 * @return mixed
	 */
	public static function getAddListingSettings($postID){
		return get_post_meta($postID, 'pricing_settings', true);
	}

	/**
	 * Get User Meta
	 *
	 * @param number $userID
	 * @param string $metaKey
	 *
	 * @return mixed
	 */
	public static function getUserMeta($userID, $metaKey){
		return get_user_meta($userID, $metaKey, true);
	}

	/**
	 * Get Options
	 *
	 * @param string $optionsKey
	 *
	 * @return mixed
	 */
	public static function getOptions($optionsKey, $isFocus=false){
		if ( isset(self::$aOptions[$optionsKey]) && !$isFocus ){
			return self::$aOptions[$optionsKey];
		}

		$val = get_option($optionsKey);

		self::$aOptions[$optionsKey] = maybe_unserialize($val);

		return self::$aOptions[$optionsKey];
	}

	/**
	 * Get User Data
	 *
	 * @param string $userID
	 *
	 * @return object $oUseData
	 */
	public static function getUserData($userID){
		return get_userdata($userID);
	}

	/**
	 *
	 */
	public static function getWilokeSubmissionMeta($sessionID, $metaKey){
		$meta = PaymentMetaModel::get($sessionID, $metaKey);
		return maybe_unserialize($meta);
	}
}