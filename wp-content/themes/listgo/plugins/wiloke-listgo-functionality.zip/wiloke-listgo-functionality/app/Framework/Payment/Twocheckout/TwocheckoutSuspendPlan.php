<?php
namespace WilokeListgoFunctionality\Framework\Payment\Twocheckout;


use WilokeListgoFunctionality\Model\TwocheckoutModel;

class TwocheckoutSuspendPlan {
	use TwocheckoutConfiguration;

	protected $aUserPlanInfo;
	protected $planID;
	protected $subscriptionID;
	protected $subscriptionStatus;
	protected $sessionID;
	protected $userID;

	public function __construct($userID, array $aUserPlanInfo) {
		$this->aUserPlanInfo = $aUserPlanInfo;
		$this->init();
	}

	protected function init(){
		$this->setUserID($this->aUserPlanInfo['userID']);
		$this->setPlanID($this->aUserPlanInfo['planID']);
		$this->setSessionID($this->aUserPlanInfo['sessionID']);
		$this->setPlanType(get_post_type($this->planID));
		$this->getRecurringStatus();
	}

	public function setPlanID($planID){
		$this->planID = $planID;
		return $this;
	}

	public function setUserID($userID){
		$this->userID = $userID;
		return $this;
	}

	public function setAgreementID($agreementID){
		$this->agreementID = $agreementID;
		return $this;
	}

	public function setSessionID($sessionID){
		$this->sessionID = $sessionID;
		return $this;
	}

	public function setPlanType($planType){
		$this->planType = $planType;
		return $this;
	}

	protected function getRecurringStatus(){

	}


	public function execute(){
		if ( $this->subscriptionStatus == 'active' ){
			$this->setApiContext();

			$this->createFreeForeverCoupon();
			try{
				$oSubscription = \Stripe\Subscription::retrieve($this->subscriptionID);
				$oSubscription->coupon = wilokeRepository('app:stripe', true)->sub('suspendCoupon');
				$oSubscription->save();

				return array(
					'status'            => 'success',
					'isRealSuspended'   => true,
					'msg'               => esc_html__('The current plan has been switched to suspend status', 'wiloke')
				);

			}catch (\Exception $e){
				return array(
					'status' => 'error',
					'msg'    => $e->getMessage()
				);
			}
		}else{
			return array(
				'status' => 'success',
				'msg'    => esc_html__('The current plan status: ', 'wiloke') . $this->subscriptionStatus
			);
		}

	}

	protected function createFreeForeverCoupon(){
		// Set your secret key: remember to change this to your live secret key in production
		// See your keys here: https://dashboard.stripe.com/account/apikeys
		\Stripe\Stripe::setApiKey($this->oApiContext->secretKey);

		try{
			\Stripe\Coupon::retrieve(wilokeRepository('app:stripe', true)->sub('suspendCoupon'));
		}catch (\Exception $oE){
			try{
				\Stripe\Coupon::create(array(
					'id'            => wilokeRepository('app:stripe', true)->sub('suspendCoupon'),
					'duration'      => 'forever',
					'percent_off'   => 100,
				));

				return array(
					'status' => 'success',
					'msg'    => esc_html__('Free Forever Coupon has been created successfully', 'wiloke')
				);

			}catch (\Exception $oE){
				return array(
					'status' => 'error',
					'msg'    => esc_html__('We could not suspend the current plan', 'wiloke')
				);
			}

		}
	}
}