<?php
namespace WilokeListgoFunctionality\Framework\Payment\PayPal;

use WilokeListgoFunctionality\Framework\Helpers\Time;
use WilokeListgoFunctionality\Framework\Payment\Coupon;
use WilokeListgoFunctionality\Framework\Payment\PaymentMethodInterface;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use PayPal\Api\ChargeModel;
use PayPal\Api\Currency;
use PayPal\Api\MerchantPreferences;
use PayPal\Api\PaymentDefinition;
use PayPal\Api\Plan;
use PayPal\Api\Patch;
use PayPal\Api\PatchRequest;
use PayPal\Common\PayPalModel;
use PayPal\Exception\PayPalConnectionException;
use PayPal\Exception\PayPalConfigurationException;
use PayPal\Exception\PayPalInvalidCredentialException;
use PayPal\Exception\PayPalMissingCredentialException;

use PayPal\Api\Agreement;
use PayPal\Api\Payer;
use PayPal\Api\ShippingAddress;

use WilokeListgoFunctionality\Framework\Store\Session;
use WilokeListgoFunctionality\Model\PaymentMetaModel;
use WilokeListgoFunctionality\Model\UserModel;
use WilokeListgoFunctionality\Model\PaymentModel;

class PayPalRecurringPaymentMethod implements PaymentMethodInterface{
	use PayPalGenerateUrls;
	use PayPalSetup;

	public $gateway = 'paypal';
	protected $storeTokenPlanSession;
	protected $aConfiguration = array();
	protected $oReceipt;
	protected $oApiContext;
	protected $paymentDescription = 'AgreePayment'; // This description is very important if you are using recurring payment
	protected $thankyouUrl = null;
	protected $cancelUrl = null;
	public $token = null;
	private $planID = null;
	private $initTotal;

	public function getBillingType() {
		return wilokeRepository('app:billingTypes', true)->sub('recurring');
	}

	public function proceedPayment($oReceipt){
		$this->setup($oReceipt);
		$aResult = $this->createPlan();

		if ( $aResult['status'] == 'success' ){
			$aResult = $this->createBillingAgreement();
			return $aResult;
		}else{
			return $aResult;
		}
	}

	protected function parseTokenFromApprovalUrl($approvalUrl){
		$aParseData = explode('token=', $approvalUrl);
		$this->token = trim($aParseData[1]);
	}

	protected function storeTokenAndPlanId(){
		Session::setSession($this->storeTokenPlanSession, array(
			$this->token => $this->oReceipt->planID
		));
	}

	protected function createPlan(){
		// Create a new billing plan
		$plan = new Plan();
		$plan->setName($this->oReceipt->planName)
		     ->setDescription($this->paymentDescription)
		     ->setType('INFINITE');
		$this->initTotal = $this->oReceipt->total;

		if ( !empty($this->oReceipt->couponID) ){
			$instCoupon = new Coupon($this->oReceipt->couponID);
			$couponDuration = $instCoupon->getCouponDuration();

			if ( $couponDuration != 'once' ){
				$this->oReceipt->total = $instCoupon->getDiscount($this->oReceipt->total);
			}else{
				$trialPrice = $instCoupon->getDiscount($this->oReceipt->total);
				$this->initTotal = $trialPrice;
			}
		}

		// Set billing plan definitions
		$paymentDefinition = new PaymentDefinition();
		$paymentDefinition->setName($this->oReceipt->planName)
		                  ->setType('REGULAR')
		                  ->setFrequency('DAY')
		                  ->setFrequencyInterval($this->oReceipt->regularPeriod)
		                  ->setAmount(new Currency(array('value' => $this->oReceipt->total, 'currency' => $this->aConfiguration['currency_code'])));

		// Trial
		if ( isset($trialPrice) && !empty($trialPrice) ){
			$paymentTrialDefination = new PaymentDefinition();
			$paymentTrialDefination->setName('Trial Payments')
              ->setType('TRIAL')
              ->setFrequency('DAY')
              ->setFrequencyInterval($this->oReceipt->regularPeriod)
              ->setCycles(1)
              ->setAmount(new Currency(array('value' => $trialPrice, 'currency' => $this->aConfiguration['currency_code'])));
		}

		// Set merchant preferences
		$merchantPreferences = new MerchantPreferences();
		$merchantPreferences->setReturnUrl($this->thankyouUrl)
		                    ->setCancelUrl($this->cancelUrl)
		                    ->setAutoBillAmount('yes')
		                    ->setInitialFailAmountAction('CANCEL')
		                    ->setMaxFailAttempts($this->maxFailedPayments);
//							->setSetupFee(new Currency(array('value' => 1, 'currency' => $this->aConfiguration['currency_code'])));

		$plan->setPaymentDefinitions(array($paymentDefinition));
		$plan->setMerchantPreferences($merchantPreferences);

		//create plan
		try {
			$createdPlan = $plan->create($this->oApiContext);

			try {
				$patch = new Patch();
				$value = new PayPalModel('{"state":"ACTIVE"}');
				$patch->setOp('replace')
				      ->setPath('/')
				      ->setValue($value);
				$patchRequest = new PatchRequest();
				$patchRequest->addPatch($patch);
				$createdPlan->update($patchRequest, $this->oApiContext);
				$plan = Plan::get($createdPlan->getId(), $this->oApiContext);

				// Output plan id
				$this->planID = $plan->getId();

				return array(
					'status' => 'success',
					'msg'    => '',
					'planID' => $plan->getId()
				);
			} catch (PayPalConnectionException $ex) {
				return array(
					'code'   => $ex->getCode(),
					'status' => 'error',
					'msg'    => $ex->getMessage()
				);
			} catch (\Exception $ex) {
				return array(
					'status' => 'error',
					'msg'    => $ex->getMessage()
				);
			}
		} catch (PayPalConnectionException $ex) {
			return array(
				'code'   => $ex->getCode(),
				'status' => 'error',
				'msg'    => $ex->getMessage()
			);
		} catch (\Exception $ex) {
			return array(
				'status' => 'error',
				'msg'    => $ex->getMessage()
			);
		}
	}

	protected function createBillingAgreement(){
		// Create new agreement
		$instAgreement = new Agreement();
		$instAgreement->setName($this->paymentDescription)
		          ->setDescription($this->paymentDescription)
		          ->setStartDate(Time::iso8601StartDate());

		// Set plan id
		$plan = new Plan();
		$plan->setId($this->planID);
		$instAgreement->setPlan($plan);

		// Add payer type
		$payer = new Payer();
		$payer->setPaymentMethod('paypal');
		$instAgreement->setPayer($payer);

		// Adding shipping details
		if ( $instShippingAddress = $this->setShippingAddress() ){
			$instAgreement->setShippingAddress($instShippingAddress);
		}

		try {
			// Create agreement
			$instAgreement = $instAgreement->create($this->oApiContext);
			// Extract approval URL to redirect user

			$approvalUrl = $instAgreement->getApprovalLink();
			$this->parseTokenFromApprovalUrl($approvalUrl);

			// Insert wiloke_submission_transaction and wiloke_submission_paypal_recurring_payment before redirecting to PayPal
			$sessionID = PaymentModel::insert($this, $this->oReceipt);

			if ( empty($sessionID) ){
				return array(
					'status' => 'error',
					'msg'    => esc_html__('We could not create this session', 'wiloke')
				);
			}else{
				$this->storeTokenAndPlanId();
				return array(
					'status'    => 'success',
					'msg'       => esc_html__('Got Approval url', 'wiloke'),
					'next'      => $instAgreement->getApprovalLink(),
					'redirectTo'=> $instAgreement->getApprovalLink()
				);
			}
		} catch (PayPalConnectionException $ex) {
			return array(
				'code'   => $ex->getCode(),
				'status' => 'error',
				'msg'    => $ex->getMessage()
			);
		} catch (PayPalInvalidCredentialException $ex){
			return array(
				'code'   => $ex->getCode(),
				'status' => 'error',
				'msg'    => $ex->errorMessage()
			);
		} catch (\Exception $ex) {
			return array(
				'status' => 'error',
				'msg'    => $ex->getMessage()
			);
		}
	}
}