<?php
namespace WilokeListgoFunctionality\Framework\Payment;


use WilokeListgoFunctionality\Framework\Store\Session;
use WilokeListgoFunctionality\Model\InvoiceModel;
use WilokeListgoFunctionality\Model\PaymentModel;
use WilokeListgoFunctionality\Model\PlanRelationshipModel;
use WilokeListgoFunctionality\Model\UserModel;

class AdminManagement {
	public function __construct() {
		add_action('wp_ajax_wiloke_submission_delete_order', array($this, 'deleteSale'));
	}

	public function deleteSale(){
		if ( !current_user_can('administrator') || !isset($_POST['payment_ID']) || empty($_POST['payment_ID']) ){
			wp_send_json_error(
				array(
					'msg' => esc_html__('You do not have permission to access this page', 'wiloke')
				)
			);
		}

		$sessionID = trim($_POST['payment_ID']);

		$aSessionInfo = PlanRelationshipModel::getAllInfoWhereEqualToSessionID($sessionID);

		if ( empty($aSessionInfo) ){
			wp_send_json_error(
				array(
					'msg' => esc_html__('This session does not exists or you deleted it before', 'wiloke')
				)
			);
		}

		$planID = PlanRelationshipModel::getPlanIDWhereEqualToSessionID($sessionID);
		// Remove user plan
		UserModel::removeUserPlanByPlanID($aSessionInfo[0]['userID'], $planID);

		// Migrating all objects belong to this session to trash
		foreach($aSessionInfo as $aSession){
			wp_update_post(
				array(
					'ID' => $aSession['objectID'],
					'post_status' => 'trash',
					'post_type' => 'listing'
				)
			);

			delete_post_meta($aSession['objectID'], wilokeRepository('app:belongsToPlanID'));
		}

		// Finally, delete this session
		PlanRelationshipModel::deleteWhereSessionEqualTo($sessionID);
		PaymentModel::removeSessionBySessionID($sessionID);
		InvoiceModel::deleteWhereEqualToSession($sessionID);

		wp_send_json_success(
			array(
				'msg' => esc_html__('This session has been removed', 'wiloke')
			)
		);
	}
}