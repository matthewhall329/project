<?php
namespace WilokeListgoFunctionality\Framework\Helpers;


class GeneratePrefix{
	public static $prefix = 'wiloke_submission_';

	public static function generateKey($key){
		return self::$prefix . $key;
	}
}