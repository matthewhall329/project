<?php
namespace WilokeListgoFunctionality\Framework\Payment;


use WilokeListgoFunctionality\Framework\Helpers\GetSettings;

class Receipt{
	public $aInfo = array();
	public $thankyouUrl = null;
	public $cancelUrl   = null;
	public $planID      = null;
	public $aPlans    = array();
	public $planName;
	public $isMultiplePlan = false;
	public $couponID    = '';
	public $total       = 0;
	public $subTotal    = 0;
	public $amountTotal = 0;
	public $planKey = '';
	public $regularPeriod;

	protected $aPlanSettings = array();

	public function __construct($aInfo, $planKey='') {
		$this->aInfo = $aInfo;
		$this->setupPlan();
//		$this->setPlanID();
		$this->setCoupon();

		$this->setThankyouUrl();
		$this->setCancelUrl();
	}

	public function setupPlan(){
		if ( $this->aInfo['isFocusSetUp'] ){
			return false;
		}

		if ( isset($this->aInfo['aPlanIDs']) ){
			$this->setMultiplePlans();
		}else{
			$this->getPlanID();
			$this->planKey = empty($planKey) ? get_post_field('post_type', $this->planID) : $planKey;
			$this->aPlanSettings = GetSettings::getPostMeta($this->planID, $this->planKey);
			$this->total = $this->getPrice();
			$this->subTotal = $this->total;
			$this->amountTotal = $this->subTotal;
			$this->getPlanName();
			$this->setRegularPeriod();
		}
	}

	public function setToken($token){
		$this->aInfo['token'] = $token;
		return $this;
	}

	public function setThankyouUrl(){
		$this->thankyouUrl = isset($this->aInfo['thankyouUrl']) ? $this->aInfo['thankyouUrl'] : '';
		return $this;
	}

	public function setCancelUrl(){
		$this->cancelUrl = isset($this->aInfo['cancelUrl']) ? $this->aInfo['cancelUrl'] : '';
		return $this;
	}

	public function getPlanID(){
		$this->planID = isset($this->aInfo['planID']) ? abs(trim($this->aInfo['planID'])) : '';
		return $this;
	}

	public function getPrice(){
		return number_format(floatval(trim($this->aPlanSettings['price'])), 2);
	}

	public function setPlanID($planID){
		$this->planID = $planID;
		return $this;
	}

	public function setRegularPeriod(){
		$this->regularPeriod = isset($this->aPlanSettings['regular_period']) ? abs(trim($this->aPlanSettings['regular_period'])) : '';
		return $this;
	}

	public function setTotal($total){
		$this->total = $total;
		return $this;
	}

	public function setSubTotal($subTotal){
		$this->subTotal = $subTotal;
		return $this;
	}

	public function setAmountTotal($amountTotal){
		$this->amountTotal = $amountTotal;
		return $this;
	}

	public function setPlanName($planName){
		$this->planName = $planName;
		return $this;
	}

	public function setMultiplePlans(){
		$this->isMultiplePlan = true;

		foreach ( $this->aInfo['aPlanIDs'] as $planID ){
			$planKey = empty($planKey) ? get_post_field('post_type', $planID) : $planKey;
			$this->aPlanSettings = GetSettings::getPostMeta($planID, $planKey);
			$this->aPlans[$planID]['regular_period'] = isset($this->aPlanSettings['regular_period']) ? abs(trim($this->aPlanSettings['regular_period'])) : '';
			$this->aPlans[$planID]['planName'] = get_the_title($planID);
			$total = $this->getPrice();
			$this->aPlans[$planID]['total'] = $total;
			$this->subTotal += $total;
		}

		$this->subTotal = number_format($this->subTotal, 2);
		$this->amountTotal = $this->subTotal;
		return $this;
	}

	public function setCoupon(){
		$this->couponID = isset($this->aInfo['couponID']) ? trim($this->aInfo['couponID']) : '';
		return $this;
	}

	public function getPlanName(){
		$this->planName = get_the_title($this->aInfo['planID']);
		return $this;
	}
}