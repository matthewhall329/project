<?php
namespace WilokeListgoFunctionality\Framework\UserPlan;

use WilokeListgoFunctionality\Framework\Config\Repository;
use WilokeListgoFunctionality\Framework\Payment\DirectBankTransfer\RemainingItemsInNonRecurringPayment as RemainingItemsInNonRecurringDirectBankTransfer;
use WilokeListgoFunctionality\Framework\Payment\DirectBankTransfer\RemainingItemsInRecurringPayment as RemainingItemsInRecurringDirectBankTransfer;
use WilokeListgoFunctionality\Framework\Payment\PayPal\RemainingItemsInNonRecurringPayPal;
use WilokeListgoFunctionality\Framework\Payment\PayPal\RemainingItemsInRecurringPayPal;
use WilokeListgoFunctionality\Framework\Payment\Stripe\RemainingItemsInNonRecurringStripe;
use WilokeListgoFunctionality\Framework\Payment\Stripe\RemainingItemsInRecurringStripe;
use WilokeListgoFunctionality\Framework\Payment\Twocheckout\RemainingItemsInNonRecurringTwocheckout;
use WilokeListgoFunctionality\Framework\Payment\Twocheckout\RemainingItemsInRecurringTwocheckout;

class RemainingItemsFactory {
	protected $gateway = null;
	protected $billingType = null;
	protected $planID = null;
	protected $userID = null;
	protected $sessionID = null;
	protected $aUserInfo = array();

	/**
	 * Set Payment gateway
	 *
	 * @param string $gateway
	 *
	 * @return void
	 */
	public function setGateway($gateway){
		$this->gateway = $gateway;
	}

	/**
	 * Set Billing Type
	 *
	 * @param string $billingType: RecurringPayment or NonRecurringPayment
	 *
	 * @return void
	 */
	public function setBillingType($billingType){
		$this->billingType = $billingType;
	}

	/**
	 * Set plan ID
	 *
	 * @param number $planID
	 *
	 * @return void
	 */
	public function setPlanID($planID){
		$this->planID = abs($planID);
	}

	/**
	 * Set user ID
	 *
	 * @param number $userID
	 *
	 * @return void
	 */
	public function setUserID($userID){
		$this->userID = abs($userID);
	}

	/**
	 * Set sessionID
	 *
	 * @param number $sessionID
	 *
	 * @return void
	 */
	public function setSessionID($sessionID){
		$this->sessionID = abs($sessionID);
	}

	/**
	 * Set user info
	 *
	 * @param array $aUserInfo
	 *
	 * @return void
	 */
	public function updateUserInfo(){
		$this->aUserInfo['planID']      = $this->planID;
		$this->aUserInfo['userID']      = $this->userID;
		$this->aUserInfo['sessionID']   = $this->sessionID;
	}

	/**
	 * Set User Plan
	 *
	 * @param number $planID
	 * @param array $aPlanInfo
	 *
	 * @return mixed
	 */
	public function setUserPlan($planID, $aPlanInfo, $userID=null){
		if ( empty($aPlanInfo) ){
			return false;
		}

		$userID = empty($userID) ? get_current_user_id() : $userID;
		$this->setUserInfo = $aPlanInfo;

		$this->setBillingType($aPlanInfo['billingType']);
		$this->setPlanID($planID);
		$this->setGateway($aPlanInfo['gateway']);
		$this->setUserID($userID);
		$this->setSessionID($aPlanInfo['sessionID']);
		$this->updateUserInfo();
	}

	public function isRecurringPayment(){
		return $this->billingType == wilokeRepository('app:billingTypes', true)->sub('recurring');
	}

	public function determineInstance(){
		switch ($this->gateway){
			case 'paypal':
				if ( $this->isRecurringPayment() ){
					return new RemainingItemsInRecurringPayPal($this->aUserInfo);
				}else{
					return new RemainingItemsInNonRecurringPayPal($this->aUserInfo);
				}
				break;
			case 'stripe':
				if ( $this->isRecurringPayment() ){
					return new RemainingItemsInRecurringStripe($this->aUserInfo);
				}else{
					return new RemainingItemsInNonRecurringStripe($this->aUserInfo);
				}
				break;
			case '2checkout':
				if ( $this->isRecurringPayment() ){
					return new RemainingItemsInRecurringTwocheckout($this->aUserInfo);
				}else{
					return new RemainingItemsInNonRecurringTwocheckout($this->aUserInfo);
				}
				break;
			case 'banktransfer':
				if ( $this->isRecurringPayment() ){
					return new RemainingItemsInRecurringDirectBankTransfer($this->aUserInfo);
				}else{
					return new RemainingItemsInNonRecurringDirectBankTransfer($this->aUserInfo);
				}
				break;
			default:
				return apply_filters('wiloke-submission/app/Framework/UserPlan/RemainingItemsFactory', $this->gateway, $this->billingType, $this->aUserInfo);
				break;
		}
	}
}