<?php
namespace WilokeListgoFunctionality\Framework\Payment\Twocheckout;


use WilokeListgoFunctionality\Framework\Payment\PaymentMethodInterface;
use WilokeListgoFunctionality\Framework\Store\Session;
use WilokeListgoFunctionality\Model\InvoiceModel;
use WilokeListgoFunctionality\Model\PaymentMetaModel;
use WilokeListgoFunctionality\Model\PaymentModel;

class TwocheckoutNonRecurringPamentMethod implements PaymentMethodInterface {
	use TwocheckoutConfiguration;

	protected $sessionID;
	protected $userID;

	public function getBillingType() {
		return wilokeRepository('app:billingTypes', true)->sub('nonrecurring');
	}

	public function proceedPayment($oReceipt) {
		$this->setApiContext();
		$this->setReceipt($oReceipt);

		try {
			$aArgs = array(
				'merchantOrderId' => $this->oReceipt->planID,
				'token'      => $this->token,
				'currency'   => $this->aConfiguration['currency_code'],
				'billingAddr' => $this->getCardAddress(),
				'total' => $this->oReceipt->total
			);

			$aStatus = \Twocheckout_Charge::auth($aArgs);

			if ($aStatus['response']['responseCode'] == 'APPROVED') {
				// Recording this session
				$this->insertingNewSession();

				// Payment Meta Data
				$this->insertingNewPaymentMeta($aStatus);

				$postID = Session::getSession(wilokeRepository('sessionkeys:storePostID'), true);
				/**
				 * @hook PlanRelationship@updateSessionID 5
				 * @hook UserController@createUserPlan 10
				 */
				do_action('wiloke/wiloke-submission/payment/after_payment', array(
					'gateway'           => $this->gateway,
					'status'            => 'succeeded',
					'billingType'       => $this->getBillingType(),
					'sessionID'         => $this->sessionID,
					'planID'            => $this->oReceipt->planID,
					'planName'          => $this->oReceipt->planName,
					'postID'            => $postID,
					'planRelationshipID'=> Session::getSession(wilokeRepository('sessionkeys:storePlanRelationshipIDSessionID'), true)
				));
				Session::destroySession(wilokeRepository('sessionkeys:storePlanID'));

				InvoiceModel::insert(
					array(
						'sessionID'     => $this->sessionID,
						'regular_price' => $this->oReceipt->total,
						'currency'      => $this->aConfiguration['currency_code'],
						'message'       => $aStatus,
						'discount'      => 0
					)
				);

				return array(
					'status'     => 'success',
					'redirectTo' => get_permalink($postID),
					'msg'        => esc_html__('Congratulations! Your payment has been successfully', 'wiloke')
				);
			}else{
				return array(
					'status' => 'error',
					'msg'    => esc_html__('Unfortunately, Your payment has been failed. Response Status: ', 'wiloke') . $aStatus['response']['responseCode']
				);
			}
		} catch (\Twocheckout_Error $e) {
			return array(
				'msg'    => $e->getMessage(),
				'status' => 'error'
			);
		}
	}

	private function insertingNewSession(){
		$this->sessionID = PaymentModel::insert($this, $this->oReceipt, $this->userID, wilokeRepository('app:paymentStatus', true)->sub('succeeded'));
	}

	private function insertingNewPaymentMeta($aVal){
		PaymentMetaModel::set($this->sessionID, wilokeRepository('paymentKeys:info'), $aVal);
	}
}