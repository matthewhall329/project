<?php
namespace WilokeListgoFunctionality\Framework\Payment;


class Thankyou{
	public $aReceipt;
	public $oPayment;

	public function __construct(Receipt $aReceipt, PaymentMethodInterface $oPayment) {
		$this->aReceipt = $aReceipt;
		$this->oPayment = $oPayment;
	}

	public function generateUrl(){
		if ( isset($this->aReceipt['thankyou']) ){
			return $this->aReceipt['thankyou'];
		}

		return get_permalink(PaymentConfiguration::getField('thankyou'));
	}
}