<?php
namespace WilokeListgoFunctionality\Framework\Payment\FreePlan;


use Carbon\Carbon;
use WilokeListgoFunctionality\Framework\Helpers\GetSettings;

trait GenerateTransactionInfo {
	public function transactionInfo(){
		$oUserInfo = get_userdata($this->userID);

		return array(
			'coupon' => array(
				'ID'    => $this->oReceipt->couponID,
				'name'  => !empty($this->oReceipt->couponID) ? get_the_title($this->oReceipt->couponID) : '',
				'info'  => !empty($this->oReceipt->couponID) ? GetSettings::getPostMeta($this->oReceipt->couponID, get_post_type($this->oReceipt->couponID)) : ''
			),
			'plan'   => array(
				'ID'    => $this->oReceipt->planID,
				'name'  => get_the_title($this->oReceipt->planID),
				'type'  => get_post_type($this->oReceipt->planName),
				'info'  => GetSettings::getPostMeta($this->oReceipt->planID, get_post_type($this->oReceipt->planID))
			),
			'billingType' => $this->getBillingType(),
			'created_gmt_at'  => Carbon::now('UTC')->toAtomString(),
			'created_at' => current_time(DATE_ATOM),
			'sessionID'  => $this->sessionID,
			'userInfo'       => array(
				'ID'         => $this->userID,
				'email'      => $oUserInfo->user_email,
				'user_meta'  => $oUserInfo->user_meta,
			),
			'nextBillingDate'=>''
		);
	}
}