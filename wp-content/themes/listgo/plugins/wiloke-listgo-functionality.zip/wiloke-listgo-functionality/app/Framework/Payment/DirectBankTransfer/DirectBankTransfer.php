<?php
namespace WilokeListgoFunctionality\Framework\Payment\DirectBankTransfer;


use WilokeListgoFunctionality\Model\PaymentMetaModel;

class DirectBankTransfer {
	/**
	 * Get Last Invoice Info
	 *
	 * @param number $sessionID
	 * @return number $nextBillingDate
	 */
	public static function getNextBillingDate($sessionID){
		$nextBillingDate = PaymentMetaModel::get($sessionID, wilokeRepository('paymentKeys:nextBillingDate'));

		if ( empty($nextBillingDate) ){
			return 0;
		}

		return $nextBillingDate;
	}
}