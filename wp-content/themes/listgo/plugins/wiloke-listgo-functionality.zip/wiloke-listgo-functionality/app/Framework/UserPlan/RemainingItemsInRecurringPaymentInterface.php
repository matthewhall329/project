<?php

namespace WilokeListgoFunctionality\Framework\UserPlan;


interface RemainingItemsInRecurringPaymentInterface {
	public function setUserID($userID);

	public function setPlanID($planID);

	public function setSessionID($sessionID);

	public function getPlan();

	public function getDetailPaymentID();

	public function getNextBillingDate();

	public function getPlanType();

	public function getPlanSettings();
}