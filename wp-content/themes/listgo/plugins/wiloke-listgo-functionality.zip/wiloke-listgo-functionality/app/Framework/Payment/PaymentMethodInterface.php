<?php
namespace WilokeListgoFunctionality\Framework\Payment;

interface PaymentMethodInterface{
	public function proceedPayment($receipt);
	public function getBillingType();
}