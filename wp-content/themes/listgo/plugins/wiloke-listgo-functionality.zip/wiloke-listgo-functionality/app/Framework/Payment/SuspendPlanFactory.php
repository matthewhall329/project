<?php

namespace WilokeListgoFunctionality\Framework\Payment;


use WilokeListgoFunctionality\Framework\Payment\PayPal\PayPalSuspendPlan;
use WilokeListgoFunctionality\Framework\Payment\Stripe\StripeSuspendPlan;
use WilokeListgoFunctionality\Framework\Payment\Twocheckout\TwocheckoutStop;
use WilokeListgoFunctionality\Model\PaymentModel;

class SuspendPlanFactory {
	protected $gateway;
	protected $userID;
	protected $aUserPlanInfo;
	protected $oInstance;
	protected $aResult;

	public function setUserID($userID){
		$this->userID = $userID;
		return $this;
	}

	public function setUserPlanInfo($planID, $aInfo){
		$aInfo['planID'] = $planID;
		$this->aUserPlanInfo = $aInfo;
		$this->gateway = $this->aUserPlanInfo['gateway'];

		return $this;
	}

	public function execute(){
		switch ($this->gateway){
			case 'paypal':
				$this->oInstance = new PayPalSuspendPlan($this->userID, $this->aUserPlanInfo);
				$this->aResult   = $this->oInstance->execute();
				break;
			case 'stripe':
				$this->oInstance = new StripeSuspendPlan($this->userID, $this->aUserPlanInfo);
				$this->aResult = $this->oInstance->execute();
				break;
			case '2checkout':
				$this->oInstance = new TwocheckoutStop();
				$this->oInstance->setUserID($this->userID)
								->setUserInfo($this->aUserPlanInfo)
								->getSessionIDByUserInfo();

				$this->aResult = $this->oInstance->execute();
				break;
			default:
				if ( has_filter('wiloke-submisison/app/Framework/SuspendPlanFactory') ){
					return apply_filters('wiloke-submisison/app/Framework/SuspendPlanFactory', $this->userID, $this->gateway, $this->aUserPlanInfo);
				}
				break;
		}

		if ( empty($this->aResult) ){
			return array(
				'status' => 'success'
			);
		}

		if ( isset($this->aResult['isRealSuspended']) ){
			PaymentModel::updateToSuspendedStatusWhereEqualToSessionID($this->aUserPlanInfo['sessionID']);
		}

		return $this->aResult;
	}
}