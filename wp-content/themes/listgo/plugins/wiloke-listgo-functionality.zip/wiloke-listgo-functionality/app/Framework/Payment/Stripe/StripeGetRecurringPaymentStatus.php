<?php

namespace WilokeListgoFunctionality\Framework\Payment\Stripe;


use Stripe\Stripe;
use Stripe\Subscription;

class StripeGetRecurringPaymentStatus {
	use StripeConfiguration;

	protected $requestID;
	/**
	 * Set Request ID that returns from each complete payment. In this case, Request ID is your Stripe Subscription ID
	 *
	 * @param string $requestID
	 * @return void
	 */
	public function setRequestID($requestID) {
		$this->requestID = $requestID;
	}

	public function getStatus() {
		$this->setApiContext();
		try {
			$oSubscriptionInfo = Subscription::retrieve($this->requestID);

			if ( !empty($oSubscriptionInfo->discount) && ($oSubscriptionInfo->discount->coupon->id == wilokeRepository('app:stripe', true)->sub('suspendCoupon')) ){
				return wilokeRepository('app:paymentStatus', true)->sub('suspended');
			}

			return $oSubscriptionInfo->status;
		} catch (\Exception $ex) {
			return 'empty';
		}
	}
}