<?php
namespace WilokeListgoFunctionality\Framework\Helpers;


use WilokeListgoFunctionality\Framework\Config\Repository;

class FindPostTypeByPlanType{

	/**
	 * Finding the post type by the specified plan type
	 *
	 * @param string $planType
	 *
	 * @return string $postType
	 */
	public static function find($planType){
		return wilokeRepository('posttypeandplanrelationship:'.$planType);
	}
}