<?php
namespace WilokeListgoFunctionality\Framework\Payment\Twocheckout;


use WilokeListgoFunctionality\Framework\Helpers\Exception;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use WilokeListgoFunctionality\Model\UserModel;


trait TwocheckoutConfiguration{
	public $gateway = '2checkout';
	public $aConfiguration;
	public $oReceipt;
	private $oApiContext;
	public $token;
	public $aCardInfo;
	public $thankyouUrl;
	public $cancelUrl;

	private function setApiContext(){
		$this->aConfiguration = PaymentConfiguration::get();
		if ( empty($this->aConfiguration) ){
			Exception::error(esc_html__('The Wiloke Submission has not configured yet!', 'wiloke'));
		}

		$this->aConfiguration['payment_gateways'] = explode(',', $this->aConfiguration['payment_gateways']);
		if ( !in_array($this->gateway, $this->aConfiguration['payment_gateways']) ){
			Exception::error(esc_html__('The Twocheckout has not configured yet!', 'wiloke'));
		}

		if ( $this->aConfiguration['mode'] !== 'sandbox' ){
			\Twocheckout::privateKey($this->aConfiguration['2co_live_private_key']);
			\Twocheckout::sellerId($this->aConfiguration['2co_live_seller_id']);
			\Twocheckout::sandbox(false);
			\Twocheckout::verifySSL(true);  // this is set to true by default
		}else{
			\Twocheckout::privateKey($this->aConfiguration['2co_sandbox_private_key']);
			\Twocheckout::sellerId($this->aConfiguration['2co_sandbox_seller_id']);
			\Twocheckout::sandbox(true);
			\Twocheckout::verifySSL(false);
		}

		if ( defined('TWOCHECKOUT_ADMIN_USER') && defined('TWOCHECKOUT_ADMIN_PASSWORD') ){
			\Twocheckout::username(TWOCHECKOUT_ADMIN_USER);
			\Twocheckout::password(TWOCHECKOUT_ADMIN_PASSWORD);
		}

		$this->userID   = get_current_user_id();
	}

	protected function getCardInfo(){
		$this->aCardInfo = UserModel::getCardInfo($this->userID);
	}

	protected function getCardAddress(){
		$this->getCardInfo();

		return array(
			'name'          => $this->aCardInfo['card_name'],
			'addrLine1'     => $this->aCardInfo['card_address1'],
			'city'          => $this->aCardInfo['card_city'],
			'country'       => $this->aCardInfo['card_country'],
			'email'         => $this->aCardInfo['card_email'],
			'phoneNumber'   => $this->aCardInfo['card_phone']
		);
	}

	protected function setReceipt($oReceipt){
		$this->oReceipt = $oReceipt;
		$this->token    = $this->oReceipt->aInfo['token'];
	}

	protected function setUserID($userID){
		$this->userID = $userID;
	}
}