<?php
namespace WilokeListgoFunctionality\Framework\Payment\DirectBankTransfer;


use WilokeListgoFunctionality\Framework\Helpers\Exception;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;

trait Configuration {
	public $gateway = 'banktransfer';
	public $aConfiguration;
	public $oReceipt;
	private $oApiContext;
	public $token;
	public $userID;
	public $aBankDetails;
	protected $isFocus = false;

	private function setApiContext(){
		if ( $this->isFocus ){
			return true;
		}

		$this->aConfiguration = PaymentConfiguration::get();
		if ( empty($this->aConfiguration) ){
			Exception::error(esc_html__('The Wiloke Submission has not configured yet!', 'wiloke'));
		}
		$this->aConfiguration['payment_gateways'] = explode(',', $this->aConfiguration['payment_gateways']);
		if ( !in_array($this->gateway, $this->aConfiguration['payment_gateways']) ){
			Exception::error(esc_html__('Sorry, We do not support Direct Bank Transfer method', 'wiloke'));
		}

		$this->getBankAccounts();

		if ( empty($this->aBankDetails) ){
			Exception::error(esc_html__('Sorry, We do not support Direct Bank Transfer method', 'wiloke'));
		}
		$this->userID = get_current_user_id();
	}

	public function getBankAccounts(){
		$this->aBankDetails = PaymentConfiguration::getBankAccounts();
	}

	private function setReceipt($oReceipt){
		$this->oReceipt = $oReceipt;
		$this->token    = $this->oReceipt->aInfo['token'];
	}

	private function setUserID($userID){
		$this->userID = $userID;
	}
}