<?php
namespace WilokeListgoFunctionality\Framework\Payment\Twocheckout;


use WilokeListgoFunctionality\Framework\Helpers\DebugStatus;
use WilokeListgoFunctionality\Model\TwocheckoutModel;

class TwocheckoutStop {
	use TwocheckoutConfiguration;

	protected $saleID;
	protected $sessionID;
	protected $aUserPlanInfo;

	public function setUserID($userID) {
		$this->userID = $userID;
		return $this;
	}

	public function setUserInfo($aUserPlanInfo){
		$this->aUserPlanInfo = $aUserPlanInfo;
		return $this;
	}

	public function getSessionIDByUserInfo(){
		$this->setSessionID($this->aUserPlanInfo['sessionID']);
		$this->getSaleID();
		return $this;
	}

	public function setSessionID($sessionID){
		$this->sessionID = $sessionID;
	}

	public function getSaleID(){
		$this->saleID = TwocheckoutModel::getSaleID($this->sessionID);
	}

	public function setSaleID($saleID){
		$this->saleID = $saleID;
	}

	public function execute(){
		$this->setApiContext();

		try {
			$aStatus = \Twocheckout_Sale::stop(array(
				'sale_id' => $this->saleID
			));

			if ( ($aStatus['response_code'] == 'OK') && !empty($aStatus['response_message']) ){
				if ( isset($this->aConfiguration['2checkout_auto_refund']) && ($this->aConfiguration['2checkout_auto_refund'] == 'enable') ){
					$instTwocheckoutRefund = new TwocheckoutRefund();
					$instTwocheckoutRefund->getLineItemBySaleID($this->saleID)->execute();
				}
				return array(
					'status'        => 'success',
					'isRealStop'    => true,
					'msg'           => esc_html__('Your plan has been stopped successfully. Thank for using our service!', 'wiloke')
				);
			}else{
				return array(
					'status' => 'error',
					'msg'    => !DebugStatus::status('WILOKE_DEBUG') ?  esc_html__('OOps! We could not stop the current plan.', 'wiloke') : esc_html__('We could not stop the current plan because the API Updating is disabled. Please access to the 2checkout dashboad -> Account -> User Management to enable this feature', 'wiloke')
				);
			}
		} catch (\Twocheckout_Error $e) {
			return array(
				'status' => 'success',
				'msg'    => esc_html__('No recurring lineitems to stop.', 'wiloke')
			);
		}
	}
}
