<?php
namespace WilokeListgoFunctionality\Framework\Helpers;

use Carbon\Carbon;

class Time{
	public static $timezoneString;

	/*
	 * Return object $oNow
	 */
	public static function getAtomString(){
		return date(DATE_ATOM, current_time('timestamp'));
	}

	public static function getAtomUTCString(){
		return date(DATE_ATOM, current_time('timestamp', 1));
	}

	/*
	 * String To UTC Time
	 *
	 * @param number $timestamp
	 * @return string $date
	 */
	public static function toAtomUTC($timeStamp){
		$timeStamp = is_string($timeStamp) ? strtotime($timeStamp) : $timeStamp;
		date_default_timezone_set("UTC");
		return date(DATE_ATOM, $timeStamp);
	}

	public static function iso8601StartDate(){
		$startDate = date('c', current_time('timestamp'));
		$startDate = date('c', strtotime($startDate  . ' +1 day'));
		$startDate = str_replace('+00:00', 'Z', $startDate);
		return $startDate;
	}

	/**
	 * Get timestamp UTC now
	 */
	public static function timestampUTCNow(){
		return strtotime(Carbon::now('UTC')->toAtomString());
	}

	public static function convertDayToSeconds($day){
		return $day*24*60*60;
	}

	public static function convertSecondsToDay($seconds, $type='floor'){
		if ( $type == 'floor' ){
			return floor($seconds/(24*60*60));
		}else{
			return ceil($seconds/(24*60*60));
		}
	}
}