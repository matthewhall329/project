<?php
namespace WilokeListgoFunctionality\Framework\Payment\Twocheckout;



use Carbon\Carbon;
use WilokeListgoFunctionality\Framework\Payment\PaymentMethodInterface;
use WilokeListgoFunctionality\Framework\Store\Session;
use WilokeListgoFunctionality\Model\PaymentMetaModel;
use WilokeListgoFunctionality\Model\PaymentModel;
use WilokeListgoFunctionality\Model\TwocheckoutModel;

class TwocheckoutRecurringPaymentMethod implements PaymentMethodInterface {
	use TwocheckoutConfiguration;

	protected $userID;
	protected $sessionID;
	protected $nextBillingDate;

	public function getBillingType() {
		return wilokeRepository('app:billingTypes', true)->sub('recurring');
	}

	protected function convertPeriod($rawPeriod){
		$rawPeriod =  abs($rawPeriod);

		if ( $rawPeriod == 365 ){
			$regularPeriod = '1 Year';
			$this->nextBillingDate = Carbon::now('UTC')->addYear(1)->toAtomString();
		}else if ( $rawPeriod >= 30 ){
			$regularPeriod = floor($rawPeriod/30);
			$this->nextBillingDate = Carbon::now('UTC')->addMonth($regularPeriod)->toAtomString();
			$regularPeriod .=  $regularPeriod . ' Month';
		}else{
			$regularPeriod = floor($rawPeriod/7);
			$regularPeriod = $regularPeriod  < 1 ? 1 : $regularPeriod;
			$this->nextBillingDate = Carbon::now('UTC')->addWeek($regularPeriod)->toAtomString();
			$regularPeriod = $regularPeriod  . ' Week';
		}

		return $regularPeriod;
	}

	public function proceedPayment( $oReceipt ) {
		$this->setApiContext();
		$this->setReceipt($oReceipt);
		try {
			$aArgs = array(
				'merchantOrderId' => $this->oReceipt->planID,
				'token'      => $this->token,
				'currency'   => $this->aConfiguration['currency_code'],
				'billingAddr' => $this->getCardAddress(),
				'lineItems' => array(
					array(
						'type'          => 'product',
						'name'          => $this->oReceipt->planName,
						'price'         => $this->oReceipt->total,
						'tangible'      => 'N',
						'recurrence'    => $this->convertPeriod($this->oReceipt->regularPeriod),
						'duration'      => 'Forever',
						'quantity'      => 1,
						'productId'     => $this->oReceipt->planID,
						'description'   => $this->oReceipt->planName
					),
					array(
						'type'          => 'product1',
						'name'          => $this->oReceipt->planName,
						'price'         => $this->oReceipt->total,
						'tangible'      => 'N',
						'recurrence'    => $this->convertPeriod($this->oReceipt->regularPeriod),
						'duration'      => 'Forever',
						'quantity'      => 1,
						'productId'     => $this->oReceipt->planID,
						'description'   => $this->oReceipt->planName
					)
				)
			);

			$aStatus = \Twocheckout_Charge::auth($aArgs);
			if ($aStatus['response']['responseCode'] == 'APPROVED') {
				$this->insertingNewSession();
				$this->insertingNewPaymentMeta($aStatus);
				$this->insertingSaleID($aStatus['response']['orderNumber']);
				$this->insertingInvoiceID($aStatus['response']['transactionId']);

				$postID = Session::getSession(wilokeRepository('sessionkeys:storePostID'), true);
				/**
				 * @hook PlanRelationship@updateSessionID 5
				 * @hook UserController@createUserPlan 10
				 */
				do_action('wiloke/wiloke-submission/payment/after_payment', array(
					'gateway'           => $this->gateway,
					'nextBillingDate'   => $this->nextBillingDate,
					'status'            => 'succeeded',
					'billingType'       => $this->getBillingType(),
					'sessionID'         => $this->sessionID,
					'planID'            => $this->oReceipt->planID,
					'planName'          => $this->oReceipt->planName,
					'postID'            => $postID,
					'planRelationshipID'=> Session::getSession(wilokeRepository('sessionkeys:storePlanRelationshipIDSessionID'), true)
				));
				Session::destroySession(wilokeRepository('sessionkeys:storePlanID'));
				return array(
					'status'     => 'success',
					'redirectTo' => get_permalink($postID),
					'msg'        => esc_html__('Congratulations! Your payment has been successfully', 'wiloke')
				);
			}else{
				return array(
					'status' => 'error',
					'msg'    => esc_html__('Unfortunately, Your payment has been failed. Response Status: ', 'wiloke') . $aStatus['response']['responseCode']
				);
			}
		} catch (\Twocheckout_Error $e) {
			return array(
				'status' => 'error',
				'msg'    => $e->getMessage()
			);
		}
	}

	private function insertingNewSession(){
		$this->sessionID = PaymentModel::insert($this, $this->oReceipt, $this->userID, wilokeRepository('app:paymentStatus', true)->sub('succeeded'));
	}

	private function insertingNewPaymentMeta($aVal){
		PaymentMetaModel::set($this->sessionID, wilokeRepository('paymentKeys:info'), $aVal);
	}

	private function insertingSaleID($saleID){
		TwocheckoutModel::updateSaleID($this->sessionID, $saleID);
	}

	private function insertingInvoiceID($invoiceID){
		TwocheckoutModel::updateInvoiceID($this->sessionID, $invoiceID);
	}

}