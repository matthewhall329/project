<?php
namespace WilokeListgoFunctionality\Framework\Payment\PayPal;


use PayPal\Api\ShippingAddress;

trait PayPalSetup{
	public $maxFailedPayments;

	public function setup($oReceipt){
		$this->instPayPalConfiguration = PayPalConfiguration::setup();
		$this->aConfiguration = $this->instPayPalConfiguration->getConfiguration();
		$this->oApiContext = $this->instPayPalConfiguration->getApiContext();
		$this->oReceipt = $oReceipt;
		$this->storeTokenPlanSession = wilokeRepository('sessionkeys:storeTokenPlanSession');
		$this->maxFailedPayments = $this->aConfiguration['maxFailedPayments'];

		if ( empty($this->thankyouUrl()) ){
			throw new \Exception('Thank you page has not configured yet.', 'wiloke-submission');
		}

		if ( empty($this->cancelUrl()) ){
			throw new \Exception('Cancel page has not configured yet.', 'wiloke-submission');
		}
	}

	public function setShippingAddress(){
		$userID     = get_current_user_id();
		$aUserInfo  = \Wiloke::getUserMeta($userID);

		$shippingAddress = new ShippingAddress();
		$hasShippingAddressInfo = false;

		if ( isset($aUserInfo['meta']['wiloke_address']) && !empty($aUserInfo['meta']['wiloke_address']) ){
			$shippingAddress->setLine1($aUserInfo['meta']['wiloke_address']);
			$hasShippingAddressInfo = true;
		}

		if ( isset($aUserInfo['meta']['wiloke_city']) && !empty($aUserInfo['meta']['wiloke_city']) ){
			$shippingAddress->setCity($aUserInfo['meta']['wiloke_city']);
			$hasShippingAddressInfo = true;
		}

		if ( isset($aUserInfo['meta']['wiloke_state']) && !empty($aUserInfo['meta']['wiloke_state']) ){
			$shippingAddress->setCity($aUserInfo['meta']['wiloke_state']);
			$hasShippingAddressInfo = true;
		}

		if ( isset($aUserInfo['meta']['wiloke_country']) && !empty($aUserInfo['meta']['wiloke_country']) ){
			$shippingAddress->setPostalCode($aUserInfo['meta']['wiloke_country']);
			$hasShippingAddressInfo = true;
		}

		if ( isset($aUserInfo['meta']['wiloke_zipcode']) && !empty($aUserInfo['meta']['wiloke_zipcode']) ){
			$shippingAddress->setPostalCode($aUserInfo['meta']['wiloke_zipcode']);
			$hasShippingAddressInfo = true;
		}

		return $hasShippingAddressInfo ? $shippingAddress : false;
	}
}