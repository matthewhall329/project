<?php
namespace WilokeListgoFunctionality\Framework\Payment\Twocheckout;


use WilokeListgoFunctionality\Model\InvoiceModel;
use WilokeListgoFunctionality\Model\PaymentMetaModel;
use WilokeListgoFunctionality\Model\PaymentModel;
use WilokeListgoFunctionality\Model\TwocheckoutModel;
use WilokeListgoFunctionality\Model\UserModel;

class Webhook {
	use TwocheckoutConfiguration;

	protected $secretWord;
	public $aInstMessage;
	protected $nextBillingDate;
	protected $total;

	public function __construct($aInstMessage){
		$this->aInstMessage = $aInstMessage;
		$this->listener();
	}

	public function listener(){
		if ( !$this->validateNotification($this->aInstMessage['sale_id'], $this->aInstMessage['invoice_id'], $this->aInstMessage['md5_hash']) ){
			return false;
		}

		switch ($this->aInstMessage['message_type']){
			case 'RECURRING_STOPPED':
				$sessionID = TwocheckoutModel::getSessionIDBySaleID($this->aInstMessage['sale_id']);
				$sessionID = abs($sessionID);

				if ( !empty($sessionID) ){
					PaymentModel::updateToCancelledStatusWhereEqualToSessionID($sessionID);
					$aPaymentMeta = PaymentMetaModel::get($sessionID, wilokeRepository('paymentKeys:info'));

					if ( !isset($aPaymentMeta['nextBillingDate']) ){
						do_action('wiloke_submission/migrate-posts-to-expired-status', $sessionID);
					}else{
						$nextBillingDate = $aPaymentMeta['nextBillingDate'];
						$nextBillingDate = is_string($nextBillingDate) ? strtotime($nextBillingDate) : $aPaymentMeta['nextBillingDate'];
						$now = strtotime(current_time(DATE_ATOM, 1));

						if ( $now >= $nextBillingDate ){
							do_action('wiloke_submission/migrate-posts-to-expired-status', $sessionID);
							$planID = PaymentModel::getPlanIDWhereEqualToSessionID($sessionID);
							$userID = PaymentModel::getUserIDWhereEqualToSessionID($sessionID);
							UserModel::removeUserPlanByPlanID($userID, $planID);
							$aSaleIdInfo = \Twocheckout_Sale::retrieve(array(
								'sale_id' => TwocheckoutModel::getSaleID($sessionID)
							));
							PaymentMetaModel::patch($sessionID, wilokeRepository('app:paymentKeys', true)->sub('info'), $aSaleIdInfo);
						}
					}
				}
				break;
			case 'RECURRING_INSTALLMENT_FAILED':
				$sessionID = TwocheckoutModel::getSessionIDBySaleID($this->aInstMessage['sale_id']);
				$sessionID = abs($sessionID);
				if ( empty($sessionID) ){
					return false;
				}
				PaymentModel::updateToFailedStatusWhereEqualToSessionID($sessionID);
				$planID = PaymentModel::getPlanIDWhereEqualToSessionID($sessionID);
				$userID = PaymentModel::getUserIDWhereEqualToSessionID($sessionID);
				UserModel::removeUserPlanByPlanID($userID, $planID);
				do_action('wiloke_submission/migrate-posts-to-expired-status', $sessionID);
				break;

			case 'RECURRING_RESTARTED':
			case 'RECURRING_COMPLETE':
				$sessionID = PaymentModel::getPlanIDWhereEqualToSessionID($this->aInstMessage['sale_id']);
				$sessionID = abs($sessionID);
				if ( empty($sessionID) ){
					return false;
				}

				InvoiceModel::insert(
					array(
						'sessionID'     => $sessionID,
						'regular_price' => $this->getTotal(),
						'currency'      => $this->aInstMessage['list_currency'],
						'message'       => $this->aInstMessage,
						'discount'      => 0
					)
				);

				// After the subscription was expended successfully, We need to be re-publish all listings that belong to this session and change all listings
				// that are holding processing status to pending status.
				$planID = PaymentModel::getPlanIDWhereEqualToSessionID($sessionID);
				$userID = PaymentModel::getUserIDWhereEqualToSessionID($sessionID);

				$aSaleIdInfo = \Twocheckout_Sale::retrieve(array(
					'sale_id' => TwocheckoutModel::getSaleID($sessionID)
				));

				$instUserModel = new UserModel();
				$instUserModel->setUserID($userID)
				              ->setNextBillingDate($this->getNextBillingDate())
				              ->setPlanID($planID)
				              ->setSessionID($sessionID)
				              ->setGateway($this->gateway)
				              ->setBillingType(wilokeRepository('app:billingTypes', true)->sub('recurring'))
				              ->setUserPlan();

				PaymentMetaModel::patch($sessionID, wilokeRepository('app:paymentKeys', true)->sub('info'), $aSaleIdInfo);
				PaymentModel::updateToSucceededStatusWhereEqualToSessionID($sessionID);
				do_action('wiloke_submission/after-subscription-extended', array(
					'sessionID'         => $sessionID,
					'planID'            => $planID,
					'nextBillingDate'   => $this->getNextBillingDate()
				));

				do_action('wiloke_submission/after-subscription-extended-'.get_post_type($planID), array(
					'sessionID'         => $sessionID,
					'planID'            => $planID,
					'nextBillingDate'   => $this->getNextBillingDate()
				));
			break;
		}
	}

	public function getSellerID(){
		if ( $this->aConfiguration['mode'] == 'sandbox' ){
			return $this->aConfiguration['2co_sandbox_seller_id'];
		}

		return $this->aConfiguration['2co_live_seller_id'];
	}

	public function validateNotification($saleID, $invoiceID, $md5Hash){
		$this->setApiContext();

		$this->secretWord = $this->aConfiguration['2checkout_secret_word'];
		$stringToHash = strtoupper(md5($saleID . $this->getSellerID() . $invoiceID . $this->aConfiguration['2checkout_secret_word']));

		return ($stringToHash == $md5Hash);
	}

	public function getNextBillingDate(){
		if ( !empty($this->nextBillingDate) ){
			return $this->nextBillingDate;
		}

		foreach ($this->aInstMessage as $key => $val){
			if ( strpos($key, 'item_rec_date_next_') === false ){
				continue;
			}
			$this->nextBillingDate = $val;
		}

		return $this->nextBillingDate;
	}

	public function getTotal(){
		if ( !empty($this->total) ){
			return $this->total;
		}

		foreach ($this->aInstMessage as $key => $val){
			if ( strpos($key, 'item_usd_amount_') === false ){
				continue;
			}
			$this->total = $val;
		}

		return $this->total;
	}
}