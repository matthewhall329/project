<?php

namespace WilokeListgoFunctionality\Framework\UserPlan;


interface RemainingItemsInNonRecurringPaymentInterface {
	public function setUserID($userID);

	public function setPlanID($planID);

	public function setSessionID($sessionID);

	public function getPlan();

	public function getBilledDate();

	public function getPlanType();

	public function getPlanSettings();
}