<?php
namespace WilokeListgoFunctionality\Framework\Payment\Stripe;

use Braintree\Exception;
use WilokeListgoFunctionality\Model\StripeModel;
use WilokeListgoFunctionality\Submit\User as WilokeUser;

class StripeGenerateToken {
	use StripeConfiguration;

	protected $oToken;
	protected $oCustomer;

	public function generate(){
		$this->setApiContext();

		$aCardInfo  = WilokeUser::getCard();

		if ( empty($aCardInfo['card_name']) || empty($aCardInfo['cvv']) || empty($aCardInfo['expYear']) || empty($aCardInfo['expMonth']) || empty($aCardInfo['card_number']) || empty($aCardInfo['card_email']) ){
			if ( wp_doing_ajax() ){
				wp_send_json_error(
					array(
						'msg' => esc_html__('Please provide your card information', 'wiloke')
					)
				);
			}else{
				throw new Exception(esc_html__('Please provide your card information', 'wiloke'));
			}
		}

		try{
			$this->oToken = \Stripe\Token::create(array(
				'card' => array(
					'number'    => $aCardInfo['card_number'],
					'exp_month' => $aCardInfo['expMonth'],
					'exp_year'  => $aCardInfo['expYear'],
					'cvc'       => $aCardInfo['cvv']
				)
			));

			$this->oCustomer = \Stripe\Customer::create(array(
				'email'  => $aCardInfo['card_email'],
				'source' => $this->getTokenID()
			));

			StripeModel::updateCustomerID($this->oCustomer->id);
			StripeModel::updateSessionToken($this->getTokenID());

		}catch (\Exception $oE){

			if ( wp_doing_ajax() ){
				wp_send_json_error(
					array(
						'msg' => $oE->getMessage()
					)
				);
			}else{
				die($oE->getMessage());
			}
		}
	}

	public function getTokenID(){
		return $this->oToken->id;
	}

	public function getCustomerInfo(){
		return $this->oCustomer;
	}
}