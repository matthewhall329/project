<?php
namespace WilokeListgoFunctionality\Framework\Payment\FreePlan;

use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use WilokeListgoFunctionality\Framework\Payment\PaymentMethodInterface;
use WilokeListgoFunctionality\Framework\Payment\Receipt;
use WilokeListgoFunctionality\Framework\Store\Session;
use WilokeListgoFunctionality\Model\InvoiceModel;
use WilokeListgoFunctionality\Model\PaymentMetaModel;
use WilokeListgoFunctionality\Model\PaymentModel;

class FreePlan implements PaymentMethodInterface {
	use Configuration;
	use GenerateTransactionInfo;
	protected $storeTokenPlanSession;
	protected $sessionID;
	protected $aTransactionInfo;

	public function getBillingType(){
		return wilokeRepository('app:billingTypes', true)->sub('nonrecurring');
	}

	public function setupFreePlan(Receipt $oReceipt) {
		$this->proceedPayment($oReceipt);
	}

	public function proceedPayment($oReceipt) {
		$this->setApiContext();
		$this->setReceipt($oReceipt);

		// Once the session has been completed, We need to record to wiloke_subission_sessions table -> It will generate a sessionID
		$this->insertingNewSession();

		// Payment Meta Data
		$this->insertingNewPaymentMeta();
		/**
		 * @hook PlanRelationship@updateSessionID 5
		 * @hook UserController@createUserPlan 10
		 */
		do_action( 'wiloke/wiloke-submission/payment/after_payment', array(
			'gateway'            => $this->gateway,
			'status'             => wilokeRepository('app:paymentStatus', true)->sub('succeeded'),
			'billingType'        => $this->getBillingType(),
			'sessionID'          => $this->sessionID,
			'planID'             => $oReceipt->planID,
			'addListingMode'     => wilokeRepository('app:addListingMode', true)->sub('free'),
			'planName'           => $oReceipt->planName,
			'postID'             => Session::getSession( wilokeRepository( 'sessionkeys:storePostID' ), true ),
			'planRelationshipID' => Session::getSession( wilokeRepository( 'sessionkeys:storePlanRelationshipIDSessionID' ), true )
		) );

		Session::destroySession( wilokeRepository( 'sessionkeys:storePlanID' ) );
		InvoiceModel::insert(array(
			'sessionID'         => $this->sessionID,
			'regular_price'     => 0,
			'currency'          => PaymentConfiguration::getCurrency(),
			'message'           => $this->aTransactionInfo
		));

		return array(
			'status'    => 'success',
			'sessionID' => $this->sessionID,
			'msg'       => esc_html__( 'Congratulations! Your order has been created successfully', 'wiloke' )
		);
	}

	private function insertingNewSession(){
		$this->sessionID = PaymentModel::insert($this, $this->oReceipt, $this->userID, wilokeRepository('app:paymentStatus', true)->sub('succeeded'));
	}

	private function insertingNewPaymentMeta(){
		$this->aTransactionInfo = $this->transactionInfo();
		PaymentMetaModel::set($this->sessionID, wilokeRepository('paymentKeys:info'), $this->aTransactionInfo);
	}
}