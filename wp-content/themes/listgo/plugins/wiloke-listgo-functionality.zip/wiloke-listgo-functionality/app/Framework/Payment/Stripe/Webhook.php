<?php
namespace WilokeListgoFunctionality\Framework\Payment\Stripe;

use Stripe\Subscription;
use WilokeListgoFunctionality\Model\InvoiceModel;
use WilokeListgoFunctionality\Model\PaymentMetaModel;
use WilokeListgoFunctionality\Model\PaymentModel;
use WilokeListgoFunctionality\Model\StripeModel;
use WilokeListgoFunctionality\Model\UserModel;

class Webhook{
	use StripeConfiguration;

	public function __construct() {
		$this->listener();
	}

	public function listener(){
		$this->setApiContext();

		$rawdata = file_get_contents('php://input');
		if ( empty($rawdata) ){
			return '';
		}

		$oEventInfo = json_decode($rawdata);

		switch ($oEventInfo->type) {
			case 'charge.failed':
				$chargeID = $oEventInfo->data->object->id;
				$sessionID = StripeModel::getSessionIDWhereEqualToChargeID($chargeID);
				$sessionID = abs($sessionID);
				if ( empty($sessionID) ){
					return false;
				}

				InvoiceModel::insert(
					array(
						'sessionID'     => $sessionID,
						'regular_price' => '-'.$oEventInfo->data->object->amount,
						'currency'      => $oEventInfo->data->object->currency,
						'message'       => $oEventInfo,
						'discount'      => 0
					)
				);

				$planID = PaymentModel::getPlanIDWhereEqualToSessionID($sessionID);
				$userID = PaymentModel::getUserIDWhereEqualToSessionID($sessionID);
				UserModel::removeUserPlanByPlanID($userID, $planID);

				PaymentModel::updateToFailedStatusWhereEqualToSessionID($sessionID);
				$oCharge = \Stripe\Charge::retrieve($chargeID);
				PaymentMetaModel::patch($sessionID, $planID, $oCharge);

				do_action('wiloke_submission/migrate-posts-to-expired-status', $sessionID);
				do_action('wiloke_submission/migrate-posts-to-expired-status-'.get_post_type($planID), $sessionID);
				break;
			case 'invoice.payment_succeeded':
				$subscriptionID = $oEventInfo->data->object->subscription;
				$sessionID = StripeModel::getSessionIDWhereEqualToSubscriptionID($subscriptionID);
				$sessionID = abs($sessionID);
				if ( empty($sessionID) ){
					return false;
				}

				InvoiceModel::insert(
					array(
						'sessionID'     => $sessionID,
						'regular_price' => $oEventInfo->data->object->total,
						'currency'      => $oEventInfo->data->object->currency,
						'message'       => $oEventInfo,
						'discount'      => 0
					)
				);

				// After the subscription was expended successfully, We need to be re-publish all listings that belong to this session and change all listings
				// that are holding processing status to pending status.
				$planID = PaymentModel::getPlanIDWhereEqualToSessionID($sessionID);
				$userID = PaymentModel::getUserIDWhereEqualToSessionID($sessionID);

				$oSubscription = Subscription::retrieve($subscriptionID);

				$instUserModel = new UserModel();
				$instUserModel->setUserID($userID)
				              ->setNextBillingDate($oSubscription->current_period_end)
				              ->setPlanID($planID)
				              ->setSessionID($sessionID)
				              ->setGateway($this->gateway)
				              ->setBillingType(wilokeRepository('app:billingTypes', true)->sub('recurring'))
				              ->setUserPlan();

				PaymentMetaModel::patch($sessionID, wilokeRepository('app:paymentKeys', true)->sub('info'), $oSubscription);
				PaymentModel::updateToSucceededStatusWhereEqualToSessionID($sessionID);
				do_action('wiloke_submission/after-subscription-extended', array(
					'sessionID'         => $sessionID,
					'planID'            => $planID,
					'nextBillingDate'   => $oSubscription->current_period_end
				));

				do_action('wiloke_submission/after-subscription-extended-'.get_post_type($planID), array(
					'sessionID'         => $sessionID,
					'planID'            => $planID,
					'nextBillingDate'   => $oSubscription->current_period_end
				));
				break;
			case 'invoice.payment_failed':
				$subscriptionID = $oEventInfo->data->object->subscription;
				$sessionID = StripeModel::getSessionIDWhereEqualToSubscriptionID($subscriptionID);
				$sessionID = abs($sessionID);
				if ( empty($sessionID) ){
					return false;
				}

				InvoiceModel::insert(
					array(
						'sessionID'     => $sessionID,
						'regular_price' => '-'.$oEventInfo->data->object->total,
						'currency'      => $oEventInfo->data->object->currency,
						'message'       => $oEventInfo,
						'discount'      => 0
					)
				);

				PaymentModel::updateToFailedStatusWhereEqualToSessionID($sessionID);
				do_action('wiloke_submission/migrate-posts-to-expired-status', $sessionID);
				break;

			case 'customer.subscription.deleted':
				$subscriptionID = $oEventInfo->data->object->id;
				$sessionID = StripeModel::getSessionIDWhereEqualToSubscriptionID($subscriptionID);
				$sessionID = abs($sessionID);
				if ( empty($sessionID) ){
					return false;
				}

				PaymentModel::updateToCancelledStatusWhereEqualToSessionID($sessionID);
				$aPaymentMeta = PaymentMetaModel::get($sessionID, wilokeRepository('paymentKeys:info'));

				if ( !isset($aPaymentMeta['nextBillingDate']) ){
					do_action('wiloke_submission/migrate-posts-to-expired-status', $sessionID);
				}else{
					$nextBillingDate = $aPaymentMeta['nextBillingDate'];
					$nextBillingDate = is_string($nextBillingDate) ? strtotime($nextBillingDate) : $aPaymentMeta['nextBillingDate'];
					$now = strtotime(current_time(DATE_ATOM, 1));

					if ( $now >= $nextBillingDate ){
						do_action('wiloke_submission/migrate-posts-to-expired-status', $sessionID);

						$planID = PaymentModel::getPlanIDWhereEqualToSessionID($sessionID);
						$userID = PaymentModel::getUserIDWhereEqualToSessionID($sessionID);
						UserModel::removeUserPlanByPlanID($userID, $planID);
						$oSubscription = Subscription::retrieve($subscriptionID);
						PaymentMetaModel::patch($sessionID, wilokeRepository('app:paymentKeys', true)->sub('info'), $oSubscription);
					}
				}
				break;
		}
	}
}