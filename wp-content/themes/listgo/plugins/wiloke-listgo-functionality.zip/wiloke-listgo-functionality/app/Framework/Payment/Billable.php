<?php
namespace WilokeListgoFunctionality\Framework\Payment;

use WilokeListgoFunctionality\Framework\Helpers\GetSettings;

class Billable{
	protected $gateway;
	protected $planID;
	protected $freeAllowable;
	protected $aConfigs;

	public function __construct($aArgs) {
		$this->aConfigs = $aArgs;
		$this->gateway = $aArgs['gateway'];
		$this->isGatewaySupported();
		$this->freeAllowable($aArgs);
		$this->planID = $aArgs['planID'];
		$this->planIDExisting();
		$this->isFreePlan();
	}

	public function freeAllowable($aArgs){
		$this->freeAllowable = isset($aArgs['freeAllowable']) && $aArgs['freeAllowable'] ?  true : false;
	}

	public function isGatewaySupported(){
		$aGateways = PaymentConfiguration::getPaymentGateways();
		if ( empty($aGateways) ){
			if ( wp_doing_ajax() ){
				wp_send_json_error(
					array(
						'msg' => esc_html__('This gateway is not supported by the site', 'wiloke')
					)
				);
			}else{
				throw new \Exception(esc_html__('This gateway is not supported by the site', 'wiloke'));
			}
		}

		if ( !in_array($this->gateway, $aGateways) ){
			if ( wp_doing_ajax() ){
				wp_send_json_error(
					array(
						'msg' => esc_html__('This gateway is not supported by the site', 'wiloke')
					)
				);
			}else{
				throw new \Exception(esc_html__('This gateway is not supported by the site', 'wiloke'));
			}
		}
	}

	public function planIDExisting(){
		if ( !is_array($this->planID) ){
			$postStatus = get_post_status($this->planID);
			if ( $postStatus != 'publish' ){
				if ( wp_doing_ajax() ){
					wp_send_json_error(
						array(
							'msg' => esc_html__('The plan does not exist', 'wiloke')
						)
					);
				}else{
					throw new \Exception(esc_html__('The plan does not exist', 'wiloke'));
				}
			}
		}else{
			foreach ($this->planID as $planID){
				$postStatus = get_post_status($planID);
				if ( $postStatus != 'publish' ){
					if ( wp_doing_ajax() ){
						wp_send_json_error(
							array(
								'msg' => esc_html__('The plan does not exist', 'wiloke')
							)
						);
					}else{
						throw new \Exception(esc_html__('The plan does not exist', 'wiloke'));
					}
				}
			}
		}
	}

	public function isFreePlan(){
		if ( $this->freeAllowable || (isset($this->aConfigs['isIgnoreValidatePrice']) && $this->aConfigs['isIgnoreValidatePrice']) ){
			return true;
		}

		if ( !is_array($this->planID) ){
			$aPlanSettings = GetSettings::getPostMeta($this->planID, get_post_field('post_type', $this->planID));
			if ( empty($aPlanSettings['price']) ){
				if ( wp_doing_ajax() ){
					wp_send_json_error(
						array(
							'msg' => esc_html__('Regular price is required', 'wiloke')
						)
					);
				}else{
					throw new \Exception(esc_html__('Regular price is required', 'wiloke'));
				}
			}
		}else{
			foreach ($this->planID as $planID){
				$aPlanSettings = GetSettings::getPostMeta($planID, get_post_field('post_type', $planID));
				if ( empty($aPlanSettings['price']) ){
					if ( wp_doing_ajax() ){
						wp_send_json_error(
							array(
								'msg' => esc_html__('Regular price is required', 'wiloke')
							)
						);
					}else{
						throw new \Exception(esc_html__('Regular price is required', 'wiloke'));
					}
				}
			}
		}

	}
}