<?php
namespace WilokeListgoFunctionality\Framework\UserPlan;


interface PlanInfoInterface{
	/**
	 * @param number $planID
	 *
	 * @return array $aPlanInfo
	 */
	public function getPlanInfo($planID);
}