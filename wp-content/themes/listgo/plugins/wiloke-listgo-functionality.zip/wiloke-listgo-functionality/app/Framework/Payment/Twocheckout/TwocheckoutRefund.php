<?php
namespace WilokeListgoFunctionality\Framework\Payment\Twocheckout;


class TwocheckoutRefund {
	use TwocheckoutConfiguration;
	protected $requestID;
	public $descriptor;
	protected $lineItemID;

	public function __construct() {
		$this->setApiContext();
		$this->descriptor = esc_html__('wiloke-submission/app/Framework/Payment/Twocheckout/descriptor', 'Refund the current plan before changing to a new plan');
	}

	public function getLineItemBySaleID($saleID) {
		$aSaleDetails = \Twocheckout_Sale::retrieve(
			array(
				'sale_id' => $saleID
			)
		);

		if ( empty($aSaleDetails) ){
			return array(
				'status' => 'error',
				'msg' => esc_html__('The sale has already been refunded', 'wiloke')
			);
		}

		if ( !empty($aSale['sale']['recurring_decline']) ){
			return array(
				'status' => 'error',
				'msg' => esc_html__('The sale has already been declined', 'wiloke')
			);
		}

		if ( !isset($aSale['sale']['invoices']) || empty($aSale['sale']['invoices']) ){
			return array(
				'status' => 'error',
				'msg' => esc_html__('The are no invoices', 'wiloke')
			);
		}

		$aLastInvoice = end($aSale['sale']['invoices']);
		$aLastLineItem = end($aLastInvoice['lineitems']);
		$this->lineItemID = $aLastLineItem['billing']['lineitem_id'];

		return $this;
	}

	public function execute(){
		if ( empty($this->lineItemID) ){
			return false;
		}

		/*
		 * What does category means? https://www.2checkout.com/documentation/api/sales/refund-lineitem
		 */
		$params = array(
			'lineitem_id' => $this->lineItemID,
			'category'    => 10,
			'comment'     => $this->descriptor
		);
		try {
			$aStatus = \Twocheckout_Sale::refund($params);
			if ( $aStatus['response_code'] == 'OK' ){
				return array(
					'status' => 'success',
					'msg'    => esc_html__('The refund has been processed. Thank for using our service.', 'wiloke')
				);
			}else{
				return array(
					'status' => 'error',
					'msg'    => esc_html__('Something went wrong. We could not process this refund.', 'wiloke')
				);
			}
		} catch (\Twocheckout_Error $e) {
			return array(
				'status' => 'error',
				'msg' => $e->getMessage()
			);
		}
	}
}