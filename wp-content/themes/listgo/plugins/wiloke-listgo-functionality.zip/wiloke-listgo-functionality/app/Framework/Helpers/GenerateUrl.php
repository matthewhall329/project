<?php
namespace WilokeListgoFunctionality\Framework\Helpers;


class GenerateUrl{
	public static function url($url, $aParams){
		$queryParaMeter = http_build_query($aParams);
		if ( strpos($url, '?') !== false ){
			return $url . "&" . $queryParaMeter;
		}else{
			return $url . '?' . $queryParaMeter;
		}
	}
}