<?php
namespace WilokeListgoFunctionality\Framework\Payment\PayPal;


use WilokeListgoFunctionality\Framework\Helpers\DebugStatus;
use WilokeListgoFunctionality\Framework\Helpers\Upload;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;


class PayPalConfiguration{
	private $aConfiguration;
	private static $oInstance = null;
	private $oApiContext;

	public static function setup()
	{
		if ( self::$oInstance === null ){
			self::$oInstance = new self();
		}

		self::$oInstance->configuration();
		return self::$oInstance;
	}

	private function configuration(){
		$this->aConfiguration = PaymentConfiguration::get();
		if ( empty($this->aConfiguration) ){
			throw new \Exception('The PayPal has not configured yet!', 'wiloke');
		}

		$this->aConfiguration['payment_gateways'] = explode(',', $this->aConfiguration['payment_gateways']);
		if ( !in_array('paypal', $this->aConfiguration['payment_gateways']) ){
			throw new \Exception('The PayPal has not configured yet!', 'wiloke');
		}
		if ( $this->aConfiguration['mode'] == 'sandbox' ){
			$this->oApiContext = new \PayPal\Rest\ApiContext(
				new \PayPal\Auth\OAuthTokenCredential(
					$this->aConfiguration['paypal_sandbox_client_id'],
					$this->aConfiguration['paypal_sandbox_secret']
				)
			);

			if ( DebugStatus::status('WILOKE_IS_LOCALHOST') ){
				$this->oApiContext->setConfig(
					array(
						'mode' => 'sandbox',
						'http.CURLOPT_SSLVERSION'=>'CURL_SSLVERSION_TLSv1'
					)
				);
			}else{
				$this->oApiContext->setConfig(
					array(
						'mode'           => 'sandbox',
						'log.LogEnabled' => true,
						'log.LogLevel'   => 'DEBUG',
						'log.FileName'   => Upload::listgoFolder() . PaymentConfiguration::getField('paypal_logfilename')
					)
				);
			}
		}else{
			$this->oApiContext = new \PayPal\Rest\ApiContext(
				new \PayPal\Auth\OAuthTokenCredential(
					$this->aConfiguration['paypal_live_client_id'],
					$this->aConfiguration['paypal_live_secret']
				)
			);

			if ( DebugStatus::status('WILOKE_IS_LOCALHOST') ){
				$this->oApiContext->setConfig(
					array(
						'mode' => 'live',
						'http.CURLOPT_SSLVERSION'=>'CURL_SSLVERSION_TLSv1'
					)
				);
			}else{
				$this->oApiContext->setConfig(
					array(
						'mode' => 'live'
					)
				);
			}
		}
	}

	public function getConfiguration(){
		return $this->aConfiguration;
	}

	public function getApiContext(){
		return $this->oApiContext;
	}
}