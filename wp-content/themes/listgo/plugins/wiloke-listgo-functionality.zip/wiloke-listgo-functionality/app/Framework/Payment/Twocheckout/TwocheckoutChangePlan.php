<?php
namespace WilokeListgoFunctionality\Framework\Payment\Twocheckout;


use WilokeListgoFunctionality\Framework\Payment\Checkout;
use WilokeListgoFunctionality\Framework\Payment\Receipt;

class TwocheckoutChangePlan {
	protected $newPlanID;
	protected $newSessionID;
	protected $customerID;
	protected $aArgs;

	public function __construct($userID, $planID, $aArgs) {
		$this->userID = $userID;
		$this->newPlanID = $planID;
		$this->aArgs = $aArgs;
	}

	public function execute(){
		// If it's first time you use this plan, We will create a new billing plan
		$aData = array(
			'planID'    => $this->newPlanID,
			'couponID'  => '',
			'token'     => $this->aArgs['token']
		);

		$oReceipt       = new Receipt($aData);
		$oPayPalMethod  = new TwocheckoutRecurringPaymentMethod();
		$oCheckout      = new Checkout();

		/*
		 * Referring PayPalRecurringPayment.php to get more
		 */
		$aCheckAcceptPaymentStatus = $oCheckout->begin($oReceipt, $oPayPalMethod);

		return $aCheckAcceptPaymentStatus;
	}
}