<?php
namespace WilokeListgoFunctionality\CustomerPlan;

use WilokeListgoFunctionality\Model\UserModel;
use WilokeListgoFunctionality\Frontend\FrontendListingManagement;


class CustomerPlan{
	protected static $aConfigs = array();
	public static $getRPPDetailsResponse;
	protected static $aUserPaymentInfo = null;
	private static $customerStatus = null;
	private static $customerPayPalPlanKey = 'wiloke_submission_customer_paypal_plan';
	public static $myRemainListingsKey = 'wiloke_submission_my_remain_listings';
	private static $checkedMyPlanKey = 'wiloke_submission_checked_my_plan';
	private static $checkMyRemainOnFirstInit = 'wiloke_submission_checked_my_remain_on_first_init';
	private static $nonRecurringKey = 'NonRecurring';
	private static $recurringKey = 'RecurringPayPal';
	private static $freeKey = 'Free';
	private static $unlimitedKey = 'umlimited';
	private static $totalFreePosts = 10000000000000;
	private static $isTest = false;

	public function __construct() {
		add_action('wp_ajax_wiloke_submission_render_package_preview', array($this, 'renderPackagePreview'));
	}

	public function renderPackagePreview(){
		if ( empty($_GET['packageID']) ){
			wp_send_json_error(
				array(
					'msg' => esc_html__('Please select a package.', 'listgo')
				)
			);
		}

		if ( get_post_status($_GET['packageID']) !== 'publish' ){
			wp_send_json_error(
				array(
					'msg' => esc_html__('The package does not exist.', 'listgo')
				)
			);
		}

		ob_start();
		echo do_shortcode('[wiloke_pricing is_check_billing_type="no" specify_ids="'.esc_attr($_GET['packageID']).'"]');
		$content = ob_get_clean();
		wp_send_json_success(
			array(
				'msg' => $content
			)
		);
	}

	public static function getCustomerPlan(){
		$aLatestAddListingPlan = UserModel::getLatestPlanByPlanType('pricing');
		if ( empty($aLatestAddListingPlan) ){
			return false;
		}
		$aCustomerPlan = $aLatestAddListingPlan;
		$aCustomerPlan['packageID'] = $aLatestAddListingPlan['planID'];
	}

	public static function exceededMessage(){
		ob_start();
		if ( Payment::getBillingType() == 'None' ){
			$aInfo = array(
				'message' => sprintf( __('You have exceeded the number of listings for this plan. Please go to <a href="%s">Package Plan</a> and purchase a new plan to continue adding listing', 'wiloke'), esc_url(\WilokePublic::getPaymentField('package', true)) ),
				'icon' => 'icon_error-triangle_alt'
			);
		}else{
			$myAccount = \WilokePublic::getPaymentField('myaccount', true);
			$aInfo = array(
				'message' => sprintf( __('You have exceeded the number of listings for this plan. Fortunately, You can continue submitting by upgrading to higher plan. <a href="%s">Yes, I want to upgrade my plan.</a>', 'wiloke'), esc_url(\WilokePublic::addQueryToLink($myAccount, 'mode=my-billing')) ),
				'icon' => 'icon_error-triangle_alt'
			);
		}

		FrontendListingManagement::message($aInfo, 'danger');
		$content = ob_get_clean();
		return $content;
	}

	public static function suspendedMessage(){
		$myAccount = \WilokePublic::getPaymentField('myaccount', true);
		ob_start();
		$aInfo = array(
			'title'   => esc_html__('Whoops! There\'s an outstanding balance on your account', 'wiloke'),
			'message' => sprintf( __('We can not automatically deduct from your PayPal account, so to pay the balance you\'ll need make a payment through  PayPal in the Dashboard\'s Billing section: <a href="%s">Go to My Dashboard</a> Please let us know if you have any additional questions by contacting us at <a href="mail:%s">%s</a>', 'wiloke'),  esc_url(\WilokePublic::addQueryToLink($myAccount, 'mode=my-billing')), esc_attr(get_option('admin_email'))),
			'icon' => 'icon_error-triangle_alt'
		);
		FrontendListingManagement::message($aInfo, 'danger');
		$content = ob_get_clean();
		return $content;
	}

	public static function stillNotCompleteDirectBankTransferMessage(){
		ob_start();
		$aInfo = array(
			'message' => __('Please transfer your order recently to continue submitting. In case, you have already transferred to our bank account, please contact us to confirm your payment.', 'wiloke'),
			'icon' => 'icon_error-triangle_alt'
		);

		FrontendListingManagement::message($aInfo, 'danger');
		$content = ob_get_clean();
		return $content;
	}

	public static function planIsAvailableMessage(){
		ob_start();
		$aInfo = array(
			'title'   => esc_html__('Your subscription is still available now', 'wiloke'),
			'message' => sprintf( __('<a href="%s">Go to Add Listing page</a>', 'wiloke'),  esc_url(self::renderAddListingLink()))
		);
		FrontendListingManagement::message($aInfo, 'success');
		$content = ob_get_clean();
		return $content;
	}

	public static function selectPackageMessage(){
		ob_start();
		$aInfo = array(
			'title'   => esc_html__('You need to select one package before', 'wiloke'),
			'message' => sprintf( __('<a href="%s">Go to Add Pricing page</a>', 'wiloke'),  esc_url(\WilokePublic::getPaymentField('package')))
		);
		FrontendListingManagement::message($aInfo, 'success');
		$content = ob_get_clean();
		return $content;
	}

	public static function stopEditingMessage(){
		ob_start();
		$aInfo = array(
			'title'   => esc_html__('It is not yours listing.', 'wiloke'),
			'message' => esc_html__('You do not permission to access this page.', 'wiloke'),
			'icon' => 'icon_error-triangle_alt'
		);
		FrontendListingManagement::message($aInfo, 'danger');
		$content = ob_get_clean();
		return $content;
	}
}