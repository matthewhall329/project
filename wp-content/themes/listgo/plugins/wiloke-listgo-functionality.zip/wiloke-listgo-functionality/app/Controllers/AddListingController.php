<?php
namespace WilokeListgoFunctionality\Controllers;


use Carbon\Carbon;
use Symfony\Component\HttpKernel\HttpCache\Store;
use WilokeDesignAddListing\Framework\Helpers\Inc;
use WilokeListgoFunctionality\Framework\Config\Repository;
use WilokeListgoFunctionality\Framework\Helpers\AddListingHelpers;
use WilokeListgoFunctionality\Framework\Helpers\General;
use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
use WilokeListgoFunctionality\Framework\Payment\FreePlan;
use WilokeListgoFunctionality\Framework\Routing\RouteAfterItemInserted;
use WilokeListgoFunctionality\Framework\Helpers\DebugStatus;
use WilokeListgoFunctionality\Framework\Helpers\GenerateUrl;
use WilokeListgoFunctionality\Framework\Helpers\SetSettings;
use WilokeListgoFunctionality\Frontend\FrontendListingManagement;
use WilokeListgoFunctionality\Helpers\View;
use WilokeListgoFunctionality\Model\PaymentModel;
use WilokeListgoFunctionality\Model\PlanRelationshipModel;
use WilokeListgoFunctionality\Model\UserModel;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use WilokeListgoFunctionality\Framework\Store\Cookie;
use WilokeListgoFunctionality\Framework\Store\Session;
use WilokeListgoFunctionality\Submit\AddListing;
use WilokeListgoFunctionality\Submit\User as WilokeUser;
use WilokeListgoFunctionality\Submit\User;

class AddListingController extends Controller{
	protected $redirectTo = '/';
	protected $aRules     = array();
	protected $aData;
	protected $planID;
	protected $aPlanSettings;
	protected $userID;
	protected $listingID;
	protected $locationID;
	protected $isNewListing = false;
	protected $postAuthorID = 0;
	protected $thumbnailID;
	protected $placeID;
	protected $parentLocationID;
	protected $countryLocationID;
	protected $aParsePlaceInfo;
	protected $locationTax;
	protected $tagTax;
	protected $aCountry;
	protected $catTax;
	protected $isCreatedNewAccount = false;
	protected $administratorLevel1;
	public $aTermAllows = array('listing_location', 'listing_cat', 'listing_tag');
	protected $allowSize = 0;
	protected $fieldSettingsKey = 'wiloke_design_fields_settings';
	protected $designListingOptionsKey = 'wiloke_design_addlisting_page';
	protected $customFieldKeys = 'wiloke_listgo_my_custom_fields';

	public function __construct() {
		add_action('wiloke-submission/addlisting/guard', array($this, 'guard'));
		add_action('wp_ajax_wiloke_submission_new_preview_listing', array($this, 'newHandlePreview'));
		add_action('wp_ajax_nopriv_wiloke_submission_new_preview_listing', array($this, 'newHandlePreview'));
		add_action('wp_ajax_wiloke_submission_preview_listing', array($this, 'handlePreview'));
		add_action('wp_ajax_nopriv_wiloke_submission_preview_listing', array($this, 'handlePreview'));
		add_action('wp_ajax_wiloke_submission_submit_listing', array($this, 'handleSubmit'));
		add_action('wp_enqueue_scripts', array($this, 'enqueueScripts'));
		add_action('wp_ajax_wiloke_find_open_table_id', array($this, 'findOpenTableID'));
		add_action('wp_ajax_nopriv_wiloke_find_open_table_id', array($this, 'findOpenTableID'));
		add_action('ajax_query_attachments_args', array($this, 'mediaAccess'));
		add_action('wp_ajax_add_listing_fetch_term', array($this, 'fetchTerms'));
		add_action('wp_footer', array($this, 'confirmEditPopup'));
		add_action('wp_ajax_nopriv_wiloke_submission_insert_media', array($this, 'prepareInsertMedia'));
		add_action('wp_ajax_wiloke_submission_insert_media', array($this, 'prepareInsertMedia'));
		add_action('wp_ajax_wiloke_listgo_remove_listing', array($this, 'removeListing'));
		add_action('wiloke/listgo/wiloke-submission/addlisting', array($this, 'printAddListingBlock'));
		add_filter('wiloke_filter_metaboxes', array($this, 'registerMyCustomListingFields'), 10, 1);
		// add_action('init', array($this, 'testfat'));
	}

	public function registerMyCustomListingFields($aMetaBoxes){
		if ( General::detectPostType() != 'listing' ){
			return $aMetaBoxes;
		}

		$aFieldSettings = GetSettings::getOptions($this->fieldSettingsKey);
		if ( empty($aFieldSettings) ){
			return $aMetaBoxes;
		}
		$aCustomFieldCollection = array();

		foreach ( $aFieldSettings as $fieldID => $aFieldSetting ){
		    if ( !isset($aFieldSetting['isCustomField']) || !$aFieldSetting['isCustomField'] ){
		        continue;
            }

            switch ($aFieldSetting['type']){
                case 'select':
	                $aRawOptions = explode(',', $aFieldSetting['field']['options']);
	                $aOptions = array();
	                foreach ($aRawOptions as $field){
		                $field = trim($field);
		                $aOptions[$field] = $field;
	                }

                    if ( $aFieldSetting['field']['is_multiple_select'] == 'true' ){
	                    $aCustomFieldCollection[] = array(
		                    'type'         => 'multicheck',
		                    'id'           => $aFieldSetting['key'],
		                    'name'         => $aFieldSetting['title'],
		                    'default'      => '',
		                    'options'      => $aOptions
	                    );
                    }else{
	                    $aCustomFieldCollection[] = array(
		                    'type'         => 'select',
		                    'id'           => $aFieldSetting['key'],
		                    'name'         => $aFieldSetting['title'],
		                    'default'      => '',
		                    'options'      => $aOptions
	                    );
                    }

                    break;
	            case 'textarea':
		            $aCustomFieldCollection[] = array(
			            'type'         => 'textarea',
			            'id'           => $aFieldSetting['key'],
			            'name'         => $aFieldSetting['title']
		            );
		            break;
	            case 'text':
		            $aCustomFieldCollection[] = array(
			            'type'         => 'text',
			            'id'           => $aFieldSetting['key'],
			            'name'         => $aFieldSetting['title']
		            );
		            break;
	            case 'image':
		            $aCustomFieldCollection[] = array(
			            'type' => 'file',
			            'id'   => $aFieldSetting['key'],
			            'name' => $aFieldSetting['title']
		            );
		            break;
	            case 'gallery':
		            $aCustomFieldCollection[] = array(
			            'type'         => 'file_list',
			            'id'           => $aFieldSetting['key'],
			            'query_args'   => array('type' => 'image' ),
			            'preview_size' => array(50, 50),
			            'name'         => $aFieldSetting['title']
		            );
		            break;
            }
        }

		if ( isset($aCustomFieldCollection) && !empty($aCustomFieldCollection) ){
			$aMetaBoxes = array_merge($aMetaBoxes, array(
				$this->customFieldKeys  => array(
					'id'         => $this->customFieldKeys,
					'title'      => esc_html__( 'My Listing Custom Fields', 'listgo' ),
					'pages'      => array('listing'), // Post type
					'context'    => 'normal',
					'priority'   => 'low',
					'show_names' => true, // Show field names on the left
					'fields'     => $aCustomFieldCollection
				)
			));
		}
        return $aMetaBoxes;
    }

	public function printAddListingBlock(){
	    $aBlockAddListings = maybe_unserialize(get_option($this->designListingOptionsKey));
	    $aFieldsSettings = maybe_unserialize(get_option($this->fieldSettingsKey));

	    $postID = isset($_REQUEST['listing_id']) ? $_REQUEST['listing_id'] : '';
		$aPostMeta   = \Wiloke::getPostMetaCaching($postID, 'listing_settings');
		$aMyCustomFields   = \Wiloke::getPostMetaCaching($postID, $this->customFieldKeys);
		$aPackageSettings = AddListing::packageAllow();

	    foreach ($aBlockAddListings as $aBlock){
	        switch ($aBlock['blockType']){
		        case 'title_category_and_location_group':
			        View::inc('addlisting@title-categories-location', array(
				        'aFieldSettings'    => $aFieldsSettings['title_category_and_location_group'],
				        'aPackageSettings'  => $aPackageSettings,
				        'postID'            => $postID,
				        'aPostMeta'         => $aPostMeta,
				        'aMyCustomFields'   => $aMyCustomFields,
                        'aBlock'            => $aBlock
			        ));
			        break;
                default:
                    $fileName = str_replace('_', '-', $aBlock['blockType']);
			        View::inc('addlisting@'.$fileName, array(
				        'aBlock'           => $aBlock,
				        'aFieldSettings'   => $aFieldsSettings[$aBlock['blockKey']]['field'],
				        'aPackageSettings' => $aPackageSettings,
				        'postID'           => $postID,
				        'aPostMeta'        => $aPostMeta,
				        'aMyCustomFields'  => $aMyCustomFields
			        ));
			        break;
            }
        }

		View::inc('addlisting@submit', array(
			'aPackageSettings' => $aPackageSettings,
			'postID'           => $postID,
			'aPostMeta'        => $aPostMeta,
			'aMyCustomFields'  => $aMyCustomFields
		));
    }

	public static function checkAjaxSecurity($aData){
		if ( !isset($aData['security']) || !check_ajax_referer('wiloke-nonce', 'security', false) ){
			return false;
		}
		return true;
	}

	public function removeListing(){
		if ( !self::checkAjaxSecurity($_POST) || !isset($_POST['post_ID']) || empty($_POST['post_ID']) ){
			wp_send_json_error(
				esc_html__('You do not have permission to change the post status.', 'wiloke')
			);
		}

		$userID = get_current_user_id();
		$postAuthor = get_post_field('post_author', $_POST['post_ID']);
		if (absint($postAuthor) !== absint($userID) ){
			wp_send_json_error(
				esc_html__('You are not author of the post.', 'wiloke')
			);
		}

		wp_delete_post($_POST['post_ID']);
		wp_send_json_success();
	}

	/**
	 * Processing Insert Attachment
	 * @since 1.0
	 */
	protected function insertAttachment($aFile, $parentPostID=0){
		if ( ! function_exists( 'wp_handle_upload' ) ) {
			require_once( ABSPATH . 'wp-admin/includes/file.php' );
		}
		$upload_overrides = array('test_form' => false);
		$aMoveFile = wp_handle_upload($aFile, $upload_overrides );

		// Check the type of file. We'll use this as the 'post_mime_type'.
		$fileType = wp_check_filetype( basename($aMoveFile['file']), null );

		// Get the path to the upload directory.
		$wp_upload_dir = wp_upload_dir();
		// Prepare an array of post data for the attachment.
		$attachment = array(
			'guid'           => $wp_upload_dir['url'] . '/' . basename($aMoveFile['file']),
			'post_mime_type' => $fileType['type'],
			'post_title'     => preg_replace( '/\.[^.]+$/', '', basename($aMoveFile['file']) ),
			'post_content'   => '',
			'post_status'    => 'inherit',
			'post_author'    => get_current_user_id()
		);

		// Insert the attachment.
		$attachID = wp_insert_attachment($attachment, $aMoveFile['file'], $parentPostID);

		if ( empty($attachID) ){
			return new \WP_Error('broke', esc_html__('We regret to say that this file could not upload. The possible reason: Wrong file type or the file size is bigger than the allowance value', 'wiloke'));
		}

		// Make sure that this file is included, as wp_generate_attachment_metadata() depends on it.
		require_once(ABSPATH . 'wp-admin/includes/image.php');

		// Generate the metadata for the attachment, and update the database record.
		$aAttachData = wp_generate_attachment_metadata($attachID, $aMoveFile['file']);
		wp_update_attachment_metadata($attachID, $aAttachData);
		return $attachID;
	}

	/**
	 * Checking File
	 * @since 1.0
	 */
	protected function uploadImg($aFile){
		$aConditionals = array('image/jpeg', 'image/png', 'image/gif', 'image/jpg');
		if ( empty($aFile['error']) && ($aFile['size'] <= $this->allowSize) ){
			if ( in_array($aFile['type'], $aConditionals) ){
				$attachID = $this->insertAttachment($aFile);
				return $attachID;
			}
		}
	}

	/**
	 * Insert Media
	 * @since 1.0
	 */
	public function prepareInsertMedia(){
	    $aPlanSettings = GetSettings::getPostMeta(wilokeRepository('sessionkeys:storePlanID'), 'pricing_settings');

		$this->allowSize = ini_get('max_file_uploads');
		$this->allowSize = str_replace('M', '', $this->allowSize);
		$this->allowSize = absint($this->allowSize)*1024*1024;
		$fieldName = str_replace('_raw', '', $_GET['name']);

		if ( $_GET['type'] === 'single' ){
			if ( $fieldName != 'featured_image' && AddListingHelpers::isExceptThisCustomField($aPlanSettings, $fieldName) ){
				wp_send_json_error(
					array(
						'message' => esc_html__('Oops! The feature is not supported by this plan', 'wiloke')
					)
				);
			}

			$attachtID = $this->uploadImg($_FILES[$_GET['name']]);
			if ( is_wp_error($attachtID) ){
				wp_send_json_error(
					array(
						$_GET['where'] => $attachtID->get_error_message()
					)
				);
			}

			wp_send_json_success(array(
				'message' => $attachtID
			));
		}elseif($_GET['type'] == 'afc_single'){
			$aAFCImgs = $_FILES['acf'];
			$aFileUpload = array(
				'name'     => $aAFCImgs['name'][$_GET['name']],
				'type'     => $aAFCImgs['type'][$_GET['name']],
				'tmp_name' => $aAFCImgs['tmp_name'][$_GET['name']],
				'error'    => $aAFCImgs['error'][$_GET['name']],
				'size'     => $aAFCImgs['size'][$_GET['name']]
			);

			$attachID = $this->uploadImg($aFileUpload);
			if ( is_wp_error($attachID) || empty($attachID) ){
				wp_send_json_error(
					array(
						$_GET['where'] => esc_html__('Something went wrong', 'wiloke')
					)
				);
			}
			wp_send_json_success(array(
				'message' => $attachID
			));
		}else{
		    if ( $fieldName == 'gallery_settings' ){
		        if ( AddListingHelpers::isExceptThisField($aPlanSettings, 'gallery_settings') ){
			        wp_send_json_error(
				        array(
					        'message' => esc_html__('Oops! The feature is not supported by this plan', 'wiloke')
				        )
			        );
                }
            }else{
                if ( AddListingHelpers::isExceptThisCustomField($aPlanSettings, $fieldName) ){
	                wp_send_json_error(
		                array(
			                'message' => esc_html__('Oops! The feature is not supported by this plan', 'wiloke')
		                )
	                );
                }
            }

			$aFiles = $_FILES[$_GET['name']];
			foreach ( $aFiles['size'] as $key => $name ){
				$aFileUpload = array(
					'name'     => $aFiles['name'][$key],
					'type'     => $aFiles['type'][$key],
					'tmp_name' => $aFiles['tmp_name'][$key],
					'error'    => $aFiles['error'][$key],
					'size'     => $aFiles['size'][$key],
				);
				$attachID = $this->uploadImg($aFileUpload);
				if ( !is_wp_error($attachID) && !empty($attachID) ){
					$aAttachIDs[] = $attachID;
				}
			}

			if ( empty($aAttachIDs) ){
				wp_send_json_error(
					array(
						'message' => esc_html__('There are no files have been uploaded', 'wiloke')
					)
				);
			}else{
				wp_send_json_success(
					array(
						'message' => implode(',', $aAttachIDs)
					)
				);
			}
		}
	}

	public function confirmEditPopup(){
		if ( !is_page_template('wiloke-submission/addlisting.php') ){
			return '';
		}

		if ( !isset($_REQUEST['listing_id']) || empty($_REQUEST['listing_id']) ){
			return '';
		}

		?>
		<div id="wiloke-form-update-listing-wrapper" class="wil-modal wil-modal--fade">
			<div class="wil-modal__wrap">
				<div class="wil-modal__content">
					<div class="claim-form">
						<h2 class="claim-form-title"><?php esc_html_e('Update This Listing', 'wiloke'); ?></h2>
						<div class="claim-form-content">
							<form id="wiloke-form-confirm-update-listing" method="POST" class="form" action="#">
								<p><?php esc_html_e('This listing will be switched to hidden status temporary while reviewing. Do you want to continue?', 'wiloke'); ?></p>
								<button id="listgo-cancel-edit-listing" class="listgo-btn addlisting-popup__btn"><?php esc_html_e('Cancel', 'wiloke'); ?></button>
								<button id="listgo-continue-editing-listing" class="listgo-btn addlisting-popup__btn primary"><?php esc_html_e('Yes', 'wiloke'); ?></button>
							</form>
						</div>
						<div class="wil-modal__close"></div>
					</div>
				</div>
			</div>
			<div class="wil-modal__overlay"></div>
		</div>
		<?php
	}

	/**
	 * Fetch term
	 * @since 1.0
	 */
	public function fetchTerms(){
//		if ( !isset($_GET['term']) || empty($_GET['term']) || !isset($_GET['security']) || check_ajax_referer('wiloke-nonce', 'security', false) ){
//			wp_send_json_error();
//		}

		if ( !in_array($_GET['term'], $this->aTermAllows) ){
			wp_send_json_error();
		}

		$oTerms = get_terms( array(
			'taxonomy'  => $_GET['term'],
			'hide_empty' => false,
		));

		if ( empty($oTerms) || is_wp_error($oTerms) ){
			wp_send_json_error();
		}

		wp_send_json_success($oTerms);
	}

	/*
	 * User can only see her media / his media
	 */
	public function mediaAccess($aArgs){
		$userID = get_current_user_id();

		if ( !empty($userID) ){
			$aUserMeta = \Wiloke::getUserMeta($userID);
			if ( $aUserMeta['role'] === 'wiloke_submission' ){
				$aArgs['author'] = get_current_user_id();
			}
		}
		return $aArgs;
	}

	/**
	 * Add scripts to the add listing page
	 * @since 1.0
	 */
	public function enqueueScripts(){
		global $post;
		if ( is_page_template('wiloke-submission/addlisting.php') || ( isset($post->post_type) && ($post->post_type === 'listing') && ( ($post->post_status != 'publish') || ( $post->post_status == 'publish') && PaymentConfiguration::isAllowEditingPublishedPost() ) )
        ){
			wp_enqueue_script('backbone');
			wp_enqueue_script('underscore');
			wp_enqueue_media();
			wp_enqueue_script('jquery-select2', plugin_dir_url(dirname(__FILE__)) . '../public/asset/select2/js/select2.full.min.js', array('jquery'), WILOKE_LISTGO_FC_VERSION, true);
			wp_enqueue_style('jquery-select2', plugin_dir_url(dirname(__FILE__)) . '../public/asset/select2/css/select2.min.css', array(), WILOKE_LISTGO_FC_VERSION);

			if ( DebugStatus::status('WILOKE_TUNROFF_DESIGN_ADDLISTING_UC') ){
				wp_enqueue_script('addlisting', plugin_dir_url(dirname(__FILE__)) . '../public/source/js/addlisting.js', array('jquery'), WILOKE_LISTGO_FC_VERSION, true);
            }else{
				wp_enqueue_script('new-addlisting', plugin_dir_url(dirname(__FILE__)) . '../public/source/js/new-addlisting.js', array('jquery'), WILOKE_LISTGO_FC_VERSION, true);
            }

			wp_enqueue_style('addlisting', plugin_dir_url(dirname(__FILE__)) . '../public/source/css/addlisting.css', array(), WILOKE_LISTGO_FC_VERSION);

			if ( function_exists('su_query_asset') ){
				su_query_asset( 'css', array( 'simpleslider', 'farbtastic', 'magnific-popup', 'font-awesome' ) );
				su_query_asset( 'js', array( 'jquery', 'jquery-ui-core', 'jquery-ui-widget', 'jquery-ui-mouse', 'simpleslider', 'farbtastic', 'magnific-popup', 'qtip', 'jquery-hotkeys') );

				if ( !wp_script_is('su-generator', 'enqueued') )
				{
					wp_register_script( 'su-generator', WP_PLUGIN_URL . '/shortcodes-ultimate/assets/js/generator.js', array('magnific-popup', 'qtip' ), WILOKE_LISTGO_FC_VERSION, true );
					wp_enqueue_script('su-generator');
					wp_register_style( 'su-generator', WP_PLUGIN_URL . '/shortcodes-ultimate/assets/css/generator.css', array(), WILOKE_LISTGO_FC_VERSION);
					wp_enqueue_style('su-generator');
				}
			}
			wp_enqueue_script('wiloke-mapextend', get_template_directory_uri() . '/admin/source/js/mapextend.js', array('jquery'), WILOKE_LISTGO_FC_VERSION, true);

			if ( \WilokePublic::addLocationBy() === 'default' ){
				wp_enqueue_style('wiloke-mapextend', get_template_directory_uri() . '/admin/source/css/mapextend.css', array(), WILOKE_LISTGO_FC_VERSION);
			}

			wp_enqueue_script('wiloke-findtableid', get_template_directory_uri() . '/admin/source/js/findtableid.js', array('jquery'), WILOKE_LISTGO_FC_VERSION, true);
		}

		$aConfiguration = PaymentConfiguration::get();
		if ( isset($post->ID) && (($post->ID == $aConfiguration['checkout']) || ($post->ID == $aConfiguration['myaccount']))){
			wp_enqueue_script('wiloke-listgo-checkout', plugin_dir_url(dirname(__FILE__)) . '../public/source/js/checkout.js', array('jquery'), WILOKE_LISTGO_FC_VERSION, true );
        }
	}

	/**
	 * Determining author id by the listing id
	 */
	protected function determiningPostAuthorID(){
		if ( current_user_can('administrator') ){
			$this->postAuthorID = $this->userID;
			return true;
		}

		if ( empty($this->listingID) ){
			$this->postAuthorID = $this->userID;
		}else{
			$this->postAuthorID = get_post_field('post_author', $this->listingID);
		}
	}

	/**
	 * Verify authentication before adding a new listing
	 */
	public function guard($aInput){
//	    var_export(Session::getSession(wilokeRepository('sessionkeys:storePlanID')));die();
		$this->middleware(['role', 'planExists', 'ggRecaptcha', 'validateAddListing', 'addListingPlanPermission', 'isAvailableFreePlan', 'isPostAuthor'], array(
			'planID'        => trim(Session::getSession(wilokeRepository('sessionkeys:storePlanID'))),
			'postID'        => $this->listingID,
			'authorID'      => $this->userID,
			'ggCaptcha'     => trim($aInput['g-recaptcha-response']),
			'listingInfo'   => $this->aData,
            'aPlanSettings' => $this->aPlanSettings
		));
	}

	/**
	 * Rolling back. There are no mistake is acceptable.
	 *
	 */
	protected function rollingBack(){
		if ( !$this->isNewListing ){
			return false;
		}
		wp_delete_post($this->listingID, true);
		delete_post_thumbnail($this->thumbnailID);
		wp_delete_attachment($this->aData['featured_image'], true);

		if ( !empty($this->aData['listing_gallery']) ){
			$aGalleryIDs = array_map('abs', explode(',', $this->aData['listing_gallery']));
			foreach ( $aGalleryIDs as $galleryID ){
				wp_delete_attachment($galleryID, true);
			}
		}
	}

	public function findOpenTableID(){
		$restaurant = html_entity_decode(addslashes($_POST['term']));
		// Send API Call using WP's HTTP API
		$aResponse = wp_remote_get('https://opentable.herokuapp.com/api/restaurants?name=' . $restaurant);

		if ( is_wp_error($aResponse)  ){
			wp_send_json_error(
				array(
					'msg' => esc_html__('We found no table what you are looking for. Please try with another keywords', 'wiloke')
				)
			);
		}else{
			wp_send_json_success(
				array(
					'data' => $aResponse['body']
				)
			);
		}
	}

	/**
	 *
	 * @param array $aUserPlan
	 * @return number
	 */
	protected function insertPlanRelationShip($aUserPlan){
		return PlanRelationshipModel::insert(
			array(
				'planID'    => $this->planID,
				'objectID'  => $this->listingID,
				'userID'    => $this->userID,
				'sessionID' => DebugStatus::status('WILOKE_SUBMISSION_THROUGH_ALL') || empty($aUserPlan) || (float)$aUserPlan['remainingItems'] <= 0 ? 0 : abs($aUserPlan['sessionID'])
			)
		);
	}

	/**
	 * Determining whether the listing is an expired Listing
	 *
	 * @return bool
	 */
	public function needTobeAddedToPlanRelationship(){
//		if ( $this->isNewListing ){
//			return true;
//		}

        $postStatus = get_post_status($this->listingID);

		if ( $postStatus == 'publish' || $postStatus == 'pending' ){
			return false;
		}

		return true;
	}


	/**
	 * Determining new listing status based on Listing Status
	 *
	 * @return string $newStatus;
	 */
	public function determiningNewListingStatus(){
		$listingStatus = get_post_status($this->listingID);
		if ( empty($listingStatus) ){
			return 'processing';
		}

		return $listingStatus;
	}

	protected function handleClaimListing($aUserPlan, $listingStatus){
		$belongToPlanID = GetSettings::getPostMeta($this->listingID, wilokeRepository('app:belongsToPlanID'));
		$aUserPlanIDs 	= UserModel::getDetailPlan($belongToPlanID);
		
		if ( !empty($aUserPlanIDs) ){
			if ( PaymentConfiguration::getField('published_listing_editable') == 'allow_need_review' ){
		        return 'pending';
            }
			return 'publish';
		}

		if ( !empty($aUserPlan['remainingItems']) ){
			$aWilokeSubmissionSettings = PaymentConfiguration::get();
			if (  isset($aWilokeSubmissionSettings['approved_method']) && ($aWilokeSubmissionSettings['approved_method'] == 'auto_approved_after_payment') ){
				return 'publish';
			}

			return 'pending';
		}

		return 'processing';
	}

	public function determiningSubmitListingStatus($aUserPlan){
	    if ( current_user_can('administrator') && !DebugStatus::status('WILOKE_SUBMISSION_CHECK_EVEN_ADMIN') ){
	        return 'publish';
        }

		$listingStatus = get_post_status($this->listingID);
		
		$aClaimInfo = GetSettings::getPostMeta($this->listingID, 'listing_claim');
		if ( DebugStatus::status('WILOKE_TURNON_VERIFY_CLAIM') ){
			if ( $aClaimInfo['status'] == 'claimed' ){
				return $this->handleClaimListing($aUserPlan, $listingStatus);
			}
		}else{
			if ( get_post_status($this->listingID) == 'publish' && $aClaimInfo['status'] == 'claimed' ){
				return 'publish';
			}
		}

		if ( $listingStatus == 'publish' ){
		    if ( PaymentConfiguration::getField('published_listing_editable') == 'allow_need_review' ){
		        return 'pending';
            }

            return 'publish';
        }

		if ( !empty($aUserPlan['remainingItems']) ){
			$aWilokeSubmissionSettings = PaymentConfiguration::get();
			if (  isset($aWilokeSubmissionSettings['approved_method']) && ($aWilokeSubmissionSettings['approved_method'] == 'auto_approved_after_payment') ){
				return 'publish';
			}

			if ( $listingStatus == 'expired' ){
				return 'renew';
			}
			return 'pending';
		}else{
			
			if ( PaymentConfiguration::isFreeAddListingMode() || empty($this->aPlanSettings['price']) ){
				if (  isset($aWilokeSubmissionSettings['approved_method']) && ($aWilokeSubmissionSettings['approved_method'] == 'auto_approved_after_payment') ){
					return 'publish';
				}else{
					return 'pending';
                }
			}

			return $listingStatus;
		}
	}

	protected function verifyUser(){
	    global $wiloke;
		if ( !is_user_logged_in() ){
			if ( isset($this->aData['createaccount']) && ($this->aData['createaccount'] === 'on') ){
				$aVerifyEmail = WilokeUser::verifyEmail($this->aData['wiloke_reg_email']);
				if ( !$aVerifyEmail['success'] ){
					wp_send_json_error(array(
						'wiloke-reg-invalid-email' => $aVerifyEmail['message']
					));
				}

				if ( isset($wiloke->aThemeOptions['toggle_google_recaptcha']) && ($wiloke->aThemeOptions['toggle_google_recaptcha'] == 'enable') ){
					$aVerifiedreCaptcha = WilokeUser::verifyGooglereCaptcha($this->aData['g-recaptcha-response']);
					if ( $aVerifiedreCaptcha['status'] == 'error' ){
						wp_send_json_error(array(
							'reject' => $aVerifiedreCaptcha['message']
						));
					}
					unset($this->aData['g-recaptcha-response']);
				}

				$aResult = WilokeUser::createUserByEmail($this->aData['wiloke_reg_email'], $this->aData['wiloke_reg_password']);

				if ( !$aResult['success'] ){
					wp_send_json_error(array(
						'wiloke-reg-invalid-email' => $aResult['message']
					));
				}else{
					$this->userID = $aResult['message'];
					$this->isCreatedNewAccount = true;
				}
			}else{
				$aResult = WilokeUser::signOn($this->aData['wiloke_user_login'], $this->aData['wiloke_my_password']);
				if ( $aResult['success'] === false ){
					wp_send_json_error(array(
						'wiloke-signup-failured' => $aResult['message']
					));
				}else{
					$this->userID = absint($aResult['message']);

					if ( GetSettings::getUserMeta($this->userID, User::$pendingStatus) ){
						wp_send_json_error(array(
							'reject' => esc_html__('You have to confirm your account before continuing', 'wiloke')
						));
					}
				}
			}

			Session::setSession(wilokeRepository('sessionkeys:storePlanID'), $this->aData['package_id']);
		}else{
			$this->userID  = get_current_user_id();
			if ( GetSettings::getUserMeta($this->userID, User::$pendingStatus) ){
				wp_send_json_error(array(
					'reject' => esc_html__('You have to confirm your account before continuing', 'wiloke')
				));
			}
		}
    }

	public function handleSubmit(){
		$this->listingID = trim($_POST['listing_id']);
		$this->planID    = GetSettings::getPostMeta($this->listingID, wilokeRepository('app:belongsToPlanID'));
		$this->aPlanSettings = GetSettings::getPostMeta($this->planID, get_post_type($this->planID));
		
		$this->postAuthorID = get_post_field('post_author', $this->listingID);

		$this->middleware(['isPostAuthor', 'editListingPendingAllowable'], array(
			'postID'    => $this->listingID,
			'authorID'  => $this->postAuthorID
		));

		$aUserPlan = UserModel::getUserDetailPlan($this->postAuthorID, $this->planID);

		/**
		 * Re-count remaining items of the user
		 */
		if ( !empty($aUserPlan) && $this->needTobeAddedToPlanRelationship() ){
			UserModel::updateUserRemainingItemsByPlanID($this->postAuthorID, $this->planID);
		}

		$postStatus = $this->determiningSubmitListingStatus($aUserPlan);
		wp_update_post(
			array(
				'post_type'	    => 'listing',
				'ID'            => $this->listingID,
				'post_status'   => $postStatus,
				'post_date_gmt' => Carbon::now('UTC')->toAtomString()
			)
		);

		if ( $this->aPlanSettings['toggle_add_feature_listing'] == 'enable' ){
			update_post_meta($this->listingID, 'wiloke_listgo_toggle_highlight', true);
		}else{
			delete_post_meta($this->listingID, 'wiloke_listgo_toggle_highlight');
		}

		if ( $postStatus == 'pending' ){
			do_action('wiloke-submission/mail', array(
				'type'     => wilokeRepository('mailstatus:type', true)->sub('submittedPost'),
				'listingID'=> $this->listingID
			));
        }else if ( $postStatus == 'publish' ){
			do_action('wiloke-submission/mail', array(
				'type'     => wilokeRepository('mailstatus:type', true)->sub('postApproved'),
				'listingID'=> $this->listingID
			));

			$aWilokeSubmissionSettings = PaymentConfiguration::get();
			
			wp_send_json_success(
				array(
					'msg'           => esc_html__('Congratulations! Your submission has been successfully!', 'wiloke'),
					'redirectTo'    => get_permalink($aWilokeSubmissionSettings['thankyou']),
					'isRedirect'    => true
				)
			);
        }

		$oNextStep = $this->nextStepAfterInsertingListing();
		
		if ( !$oNextStep->isCheckout ){
			Session::destroySession(wilokeRepository('sessionkeys:storePlanID'));
		}else{
		    if ( PaymentConfiguration::isFreeAddListingMode() || empty($this->aPlanSettings['price']) ){
                Session::setSession(wilokeRepository('sessionkeys:startFreePlan'), true);
                /*
                 * @hooked FreePlanController@setupFreePlan
                 */
                do_action('wiloke-submission/setup-free-plan', array(
                    'thankyouUrl' => get_permalink(PaymentConfiguration::getField('thankyou')),
                    'aUserPlan'   => $aUserPlan
                ));
            }
        }

		wp_send_json_success(
			array(
				'msg'           => esc_html__('Congratulations! Your submission has been successfully!', 'wiloke'),
				'redirectTo'    => $oNextStep->redirectTo,
				'isRedirect'    => true
			)
		);
	}

	protected function checkRequiredField($aFieldSettings, $fieldName){
		if ( isset($aFieldSettings['field']['isRequired']) && ($aFieldSettings['field']['isRequired'] !== 'false') ){
		    if ( is_array($fieldName) ){
                foreach ($fieldName as $subField => $parent){
	                if ( !isset($this->aData[$parent][$subField]) || empty($this->aData[$parent][$subField]) ){
		                wp_send_json_error(array(
		                	'isCreatedNewAccount' => $this->isCreatedNewAccount,
			                $aFieldSettings['key'] => sprintf(__('The <strong>%s</strong> setting is required', 'wiloke'), $aFieldSettings['title'])
		                ));
	                }
                }
            }else{
			    if ( !isset($this->aData[$fieldName]) || empty($this->aData[$fieldName]) ){
				    wp_send_json_error(array(
				    	'isCreatedNewAccount' => $this->isCreatedNewAccount,
					    $aFieldSettings['key'] => sprintf(__('The <strong>%s</strong> setting is required', 'wiloke'), $aFieldSettings['title'])
				    ));
			    }
            }
		}

		return true;
    }

    protected function verifyHour($hour){
	    if ( $hour > 12 ){
		    wp_send_json_error(
			    array(
				    'reject' => esc_html__('The hour must be smaller than or equal to 12', 'wiloke')
			    )
		    );
        }

	    return true;
    }

	protected function verifyMinutes($minutes){
		if ( $minutes > 60 ){
			wp_send_json_error(
				array(
					'reject' => esc_html__('The hour must be smaller than or equal to 60', 'wiloke')
				)
			);
        }
		return true;
	}

	protected function sanitizeData($val, $type=''){
	    if ( empty($val) ){
	        return '';
        }

        switch ($type){
            case 'array':
	            $val = array_map('sanitize_text_field', $val);
                break;
            case 'gallery':
	            $val = array_map('absint', $val);
                break;
            default:
                $val = sanitize_text_field($val);
                break;
        }

        return $val;
    }

    protected function saveImage($imgID){
	    wp_update_post(
		    array(
			    'ID' => $imgID,
			    'post_author' => $this->userID
		    )
	    );

	    return wp_get_attachment_image_url($imgID);
    }

    protected function saveGalleries($aGalleries){
	    $aImages = array();
	    foreach ( $aGalleries as $galleryID ){
		    if ( !empty($galleryID) ){
			    $aImages[$galleryID] = $this->saveImage($galleryID);
		    }
	    }
        return $aImages;
    }

	public function newHandlePreview(){
		parse_str($_POST['data'], $this->aData);

		$this->verifyUser();
		$this->planID  = trim(Session::getSession(wilokeRepository('sessionkeys:storePlanID')));
		$this->aData['content'] = $_POST['content'];
		$this->aData['planID']  = $this->planID;
		$this->aData['acfData'] = $_POST['acfData'];
		$this->listingID        = isset($this->aData['listing_id']) && is_user_logged_in() ? $this->aData['listing_id'] : '';
		$this->aPlanSettings    = GetSettings::getPostMeta($this->planID, get_post_type($this->planID));
		$this->determiningPostAuthorID();

		do_action('wiloke-submission/top_level');
		do_action('wiloke-submission/addlisting/guard', $this->aData);

		$this->locationTax = wilokeRepository('app:listing_location_tax');
		$this->catTax = wilokeRepository('app:listing_cat_tax');
		$this->tagTax = wilokeRepository('app:listing_tag_tax');

		$aFieldsSettings = GetSettings::getOptions($this->fieldSettingsKey);

		/**
		 * If the user plan has already been emptied, We should remove it.
		 */
		$aUserPlan = UserModel::getUserDetailPlan($this->userID, $this->planID);
		$isRemovedPlan = false;
		if ( !PaymentConfiguration::isFreeAddListingMode() && isset($aUserPlan['addListingMode']) && ($aUserPlan['addListingMode'] == wilokeRepository('app:addListingMode', true)->sub('free')) ){
			UserModel::removeUserPlanByPlanID(get_current_user_id(), $this->planID);
			$isRemovedPlan = true;
		}

		if ( !$isRemovedPlan && isset($aUserPlan['remainingItems']) && empty($aUserPlan['remainingItems']) ) {
			UserModel::removeUserPlanByPlanID($this->userID, $this->planID);
			$aUserPlan = array();
		}
		$isSetLocationByGoogleMap = true;

		// Inserting new post
		$aListingInfo = array(
            'post_title'    => 'No Title',
			'post_type'     => 'listing',
			'post_status'   => $this->determiningNewListingStatus()
		);
		
		foreach ($aFieldsSettings as $fieldName => $aFieldSettings){
		    if ( isset($aFieldSettings['toggle']) && $aFieldsSettings['toggle'] == 'false' ){
		        continue;
            }

		    switch ( $fieldName):
			    case 'listing_facebook_fanpage':
				    if ( !isset($this->aPlanSettings['toggle_facebook_fanpage']) || ($this->aPlanSettings['toggle_facebook_fanpage'] == 'enable') ){
					    $facebookSource = $this->aData['listing_facebook_fanpage'];
				    }
				    break;
                case 'listing_timekit':
	                if ( !isset($this->aPlanSettings['toggle_timekit']) || ($this->aPlanSettings['toggle_timekit'] == 'enable') ){
		                foreach ($this->aData['listing_timekit'] as $key => $val){
			                $aTimekit[sanitize_text_field($key)] = sanitize_text_field($val);
		                }
	                }
                    break;
			    case 'business_hours':
			        if ( isset($this->aData['toggle_business_hours']) && $this->aData['toggle_business_hours'] == 'enable' ){
			            $toggleBusinessHours = 'enable';
			            for ( $i = 0; $i < 7; $i++ ){
			                $hour = (int)$this->aData['listgo_bh'][$i]['start_hour'];
				            $this->verifyHour($hour);
			                $aBusinessHours[$i]['start_hour'] = $hour;
			                $minutes = (int)$this->aData['listgo_bh'][$i]['start_minutes'];
				            $this->verifyMinutes($minutes);
			                $aBusinessHours[$i]['start_minutes'] = $minutes;
			                $aBusinessHours[$i]['start_format'] = sanitize_text_field($this->aData['listgo_bh'][$i]['start_format']);

				            $hour = (int)$this->aData['listgo_bh'][$i]['close_hour'];
				            $this->verifyHour($hour);
				            $aBusinessHours[$i]['close_hour'] = $hour;
				            $minutes = (int)$this->aData['listgo_bh'][$i]['close_minutes'];
				            $this->verifyMinutes($minutes);
				            $aBusinessHours[$i]['close_minutes'] = $minutes;
				            $aBusinessHours[$i]['close_format'] = sanitize_text_field($this->aData['listgo_bh'][$i]['close_format']);

				            if ( isset($this->aData['listgo_bh'][$i]['closed']) && !empty($this->aData['listgo_bh'][$i]['closed']) ){
					            $aBusinessHours[$i]['closed'] = 1;
                            }else{
					            $aBusinessHours[$i]['closed'] = 0;
                            }
                        }
                    }else{
				        $toggleBusinessHours = 'disable';
                    }
			        break;
                case 'price_segment':
                    if ( $aFieldSettings['field']['isRequired'] == 'true' ){
	                    $this->checkRequiredField($aFieldSettings, array(
		                    'price_from' => 'listing_price',
		                    'price_to' => 'listing_price'
                        ));
                	}

                    if ( !empty($this->aData['listing_price']['price_segment']) && floatval($this->aData['listing_price']['price_from']) >= $this->aData['listing_price']['price_to']  ){
                        wp_send_json_error(
                            array(
                                'reject' => esc_html__('The "Price From" value must be smaller than the "Price To"', 'wiloke')
                            )
                        );
                    }
					

                    $aPriceSegmentation['price_segment'] = sanitize_text_field($this->aData['listing_price']['price_segment']);
                    $aPriceSegmentation['price_from'] = sanitize_text_field($this->aData['listing_price']['price_from']);
	                $aPriceSegmentation['price_to'] = sanitize_text_field($this->aData['listing_price']['price_to']);
                    
                    break;
                case 'title_category_and_location_group':
                    foreach ($aFieldSettings as $fieldKey => $aField){
                        if ( !isset($aField['toggle']) || $aField['toggle'] == 'false' ){
                            continue;
                        }

                        $aSubFieldSettings['field'] = $aField;
                        $aSubFieldSettings['title'] = $aField['title'];

                        $realFieldKey = $fieldKey;
                        if ( $fieldKey == 'google_address' ){
                            $realFieldKey = 'listing_latlng';
                        }
                        $this->checkRequiredField($aSubFieldSettings, $realFieldKey);

                        switch ($fieldKey){
                            case 'listing_title':
                                $aListingInfo['post_title'] = sanitize_text_field($this->aData[$fieldKey]);
                                break;
                            case 'listing_cats':
                                $aListingCats = $this->aData['listing_cats'];

                                foreach ( $aListingCats as $key => $termID  ){
                                    $termID = absint($termID);
                                    if ( !term_exists($termID, $this->catTax) ){
                                        unset($aListingCats[$termID]);
                                    }else{
                                        $aListingCats[$key] = absint($termID);
                                    }
                                }
	                            if ( !empty($aListingCats) && !empty($aField['maximumSelection']) ){
		                            $aListingCats = array_slice($aListingCats, 0, $aFieldSettings['maximumSelection']);
	                            }
                                break;
                            case 'listing_location':
                                $aListingLocation = absint($this->aData['listing_location']);
                                break;
                            case 'google_address':
                                $aListingSettings['map']['latlong']     = sanitize_text_field($this->aData['listing_latlng']);
                                $aListingSettings['map']['location']    = sanitize_text_field($this->aData['listing_address']);

                                if ( $aFieldSettings['listing_location']['toggle'] != 'false' ){
                                    $isSetLocationByGoogleMap = false;
                                }
                                break;
                        }
                    }
                break;
                case 'listing_content':
	                $this->checkRequiredField($aFieldSettings, 'content');
	                $aListingInfo['post_content'] = $this->aData['content'];
                    break;
                case 'listing_information':
                    $aListingSettings['phone_number']    = sanitize_text_field($this->aData['listing_phonenumber']);
                    $aListingSettings['website']  = sanitize_text_field($this->aData['listing_website']);
                    $aListingSettings['contact_email']  = sanitize_text_field($this->aData['contact_email']);

                    $aSocialNetworks = array();
                    foreach (wilokeRepository('addlisting:social_networks') as $social){
                        if ( !AddListingHelpers::isExceptThisSocial($this->aPlanSettings, $social) ){
	                        $aSocialNetworks[$social] = sanitize_text_field($this->aData['listing']['social'][$social]);
                        }
                    }
	                break;
			    case 'listing_tags':
				    $this->checkRequiredField($aFieldSettings, $fieldName);
                    if ( $aFieldSettings['field']['mode'] == 'admin' ){
                        $aListingTags = $this->aData['listing_tags'];
	                    $aListingTags = array_map('absint', $aListingTags);
                    }else{
	                    $aListingTags = explode(',', $this->aData['listing_tags']);
                        foreach ($aListingTags as $key => $tag){
                            if ( empty($tag) ){
                                continue;
                            }
	                        $aListingTags[$key] = sanitize_text_field($tag);
                        }
                    }

                    if ( !empty($aListingTags) && !empty($aFieldSettings['field']['maximumSelection']) ){
	                    $aListingTags = array_slice($aListingTags, 0, $aFieldSettings['field']['maximumSelection']);
                    }
				    break;
                case 'gallery_settings':
                    if ( !AddListingHelpers::isExceptThisField($this->aPlanSettings, 'toggle_allow_add_gallery') ){
	                    $this->checkRequiredField($aFieldSettings, 'gallery_settings');

	                    $aGalleries = explode(',', $this->aData['gallery_settings']);
	                    $aGalleries = array_map('absint', $aGalleries);
                    }
                    break;
                case 'open_table':
	                if ( !AddListingHelpers::isExceptThisField($this->aPlanSettings, 'toggle_open_table') ) {
		                $aOpenTableData = array();
		                foreach ( $this->aData['listing_open_table_settings'] as $key => $val ) {
			                $aOpenTableData[ sanitize_text_field( $key ) ] = sanitize_text_field( $val );
		                }
	                }
	                break;
			    case 'advanced_custom_field':
			        //passed
				    break;
			    case 'featured_image':
				    $this->checkRequiredField($aFieldSettings, $fieldName);
				    $thumbnailID = absint( $this->aData[ $fieldName ] );
				    break;
			    case 'listing_style':
				    if ( !AddListingHelpers::isExceptThisField($this->aPlanSettings, 'toggle_listing_template') ) {
					    $this->checkRequiredField($aFieldSettings, $fieldName);
					    $listingStyle = sanitize_text_field( $this->aData[ $fieldName ] );
				    }
				    break;
                case 'listing_coupon':
	                if ( !AddListingHelpers::isExceptThisField($this->aPlanSettings, 'toggle_coupon') ) {
		                $this->checkRequiredField($aFieldSettings, $fieldName);
		                $aCoupon = array();
		                foreach ( $this->aData['listing_coupon'] as $key => $val ) {
			                $aCoupon[ sanitize_text_field( $key ) ] = sanitize_text_field( $val );
		                }
	                }
                    break;
                default:
	                if ( !AddListingHelpers::isExceptThisCustomField($this->aPlanSettings, $aFieldSettings['key']) ){
		                if ( $aFieldSettings['type'] == 'select' && $aFieldSettings['field']['is_multiple_select'] == 'true' ){
			                $this->checkRequiredField($aFieldSettings, array(
				                $fieldName
			                ));
			                $aCustomFields[$aFieldSettings['key']] = $this->sanitizeData($this->aData[$aFieldSettings['key']], 'array');
		                }elseif($aFieldSettings['type'] == 'gallery'){
			                $this->checkRequiredField($aFieldSettings, array(
				                $fieldName
			                ));
			                $galleryIDs = $this->aData[$aFieldSettings['key']];
			                if ( !empty($galleryIDs) ){
				                $aGalleryIDs = explode(',', $galleryIDs);
				                $aGalleryIDs = $this->sanitizeData($aGalleryIDs, 'gallery');
				                $aCustomFields[$aFieldSettings['key']] = $this->saveGalleries($aGalleryIDs);
			                }else{
				                $aCustomFields[$aFieldSettings['key']] = '';
			                }
		                }else{
			                $this->checkRequiredField($aFieldSettings, $aFieldSettings['key']);
			                $val = $this->aData[$aFieldSettings['key']];
			                $val = $this->sanitizeData($val);

			                if ( $aFieldSettings['type'] == 'image' ){
				                $aCustomFields[$aFieldSettings['key'].'_id'] = $val;
				                $aCustomFields[$aFieldSettings['key']] = $this->saveImage($val);
			                }else{
				                $aCustomFields[$aFieldSettings['key']] = $val;
			                }
		                }
	                }
			    break;
            endswitch;
        }

		if ( !empty($this->listingID) ){
			if ( DebugStatus::status('WILOKE_TURNON_VERIFY_CLAIM') ){
				$aClaimInfo = GetSettings::getPostMeta($this->listingID, 'listing_claim');

				if ( $aClaimInfo['status'] == 'claimed' ){
					$aListingInfo['post_status'] = 'processing';
				}
			}
			$aListingInfo['ID'] = $this->listingID;
			wp_update_post($aListingInfo);
		}else{
			$this->isNewListing = true;
			$this->listingID = wp_insert_post($aListingInfo);
			$aListingInfo['ID'] = $this->listingID;
		}

		if ( empty($this->listingID) || is_wp_error($this->listingID) ){
			wp_send_json_success(
				array(
					'msg' => esc_html__('Whoops! We could not insert a new listing.', 'wiloke')
				)
			);
		}

		if ( isset($toggleBusinessHours) ){
			update_post_meta($this->listingID, 'wiloke_toggle_business_hours', $toggleBusinessHours);
			if ( $toggleBusinessHours == 'enable' ){
				update_post_meta($this->listingID, 'wiloke_listgo_business_hours', $aBusinessHours);
            }
        }

        if ( isset($thumbnailID) ){
		    if ( !empty($thumbnailID) ){
			    wp_update_post(
				    array(
					    'ID'            => $thumbnailID,
					    'post_author'   => $this->userID
				    )
			    );
			    set_post_thumbnail($this->listingID, $thumbnailID);
            }else{
		        delete_post_thumbnail($this->listingID);
            }
        }

        if ( isset($aPriceSegmentation) ){
            update_post_meta($this->listingID, 'listing_price', $aPriceSegmentation);
        }

		if ( isset($listingStyle) ){
			update_post_meta($this->listingID, '_wp_page_template', $listingStyle);
		}

        if ( isset($aListingCats) ){
	        wp_set_post_terms($this->listingID, $aListingCats, $this->catTax, false);
        }

		if ( isset($aListingTags) && !empty($aListingTags) ){
			wp_set_post_terms($this->listingID, $aListingTags, $this->tagTax, false);
		}

        if( $isSetLocationByGoogleMap ){
	        $this->setLocationByGoogleAddress();
        }else{
			wp_set_post_terms($this->listingID, $aListingLocation, $this->locationTax, false);
        }

        if ( isset($aListingSettings) ){
	        update_post_meta($this->listingID, 'listing_settings', $aListingSettings);
        }

        if ( isset($aSocialNetworks) ){
	        update_post_meta($this->listingID, 'listing_social_media', $aSocialNetworks);
        }

		if ( isset($aOpenTableData) ){
			update_post_meta($this->listingID, 'listing_open_table_settings', $aOpenTableData);
		}

		if ( isset($facebookSource) ){
			update_post_meta($this->listingID, 'listing_facebook_fanpage', $facebookSource);
		}

		if ( isset($aCoupon) ){
			update_post_meta($this->listingID, 'listing_coupon', $aCoupon);
        }

        if ( isset($aTimekit) ){
	        update_post_meta($this->listingID, 'listing_timekit', $aTimekit);
        }

        if ( isset($aGalleries) ){
            if ( !empty($aGalleries) ){
                $aListOfImages['gallery'] = $this->saveGalleries($aGalleries);
	            update_post_meta($this->listingID, 'gallery_settings', $aListOfImages);
            }else{
	            delete_post_meta($this->listingID, 'gallery_settings');
            }
        }

        if ( isset($aCustomFields) ){
            update_post_meta($this->listingID, $this->customFieldKeys, $aCustomFields);
        }

        $this->setACFCustomFields();

		$planRelationshipID = $this->insertPlanRelationShip($aUserPlan);
		if ( !$planRelationshipID ){
			$this->rollingBack();
			wp_send_json_error(
				array(
					'msg' => DebugStatus::status('WILOKE_DEBUG') ? esc_html__('We could not insert values to Plan Relationship table', 'wiloke') : esc_html__('Something went wrong', 'wiloke')
				)
			);
		}

		Session::setSession(wilokeRepository('sessionkeys:storePlanRelationshipIDSessionID'), $planRelationshipID);
		Session::setSession(wilokeRepository('sessionkeys:storePostID'), $this->listingID);

		/**
		 * Listing belongs to
		 */
		$this->listingBelongsTo();

		do_action('wiloke-submission/mail', array(
			'type'     => wilokeRepository('mailstatus:type', true)->sub('submittedPost'),
			'aInfo'    => $aListingInfo,
			'act'      => 'submitted',
			'listingID'=> $this->listingID
		));

		$oUserMeta = get_userdata($this->userID);
		if ( !empty($oUserMeta->roles) && in_array('wiloke_submission', $oUserMeta->roles) ){
			update_post_meta($this->listingID, 'listing_claim', array('status'=>'claimed'));
        }
        
		wp_send_json_success(array('next'=>get_permalink($this->listingID)));
	}

	public function handlePreview(){
		parse_str($_POST['data'], $this->aData);

		$this->verifyUser();
		$this->planID  = trim(Session::getSession(wilokeRepository('sessionkeys:storePlanID')));
		$this->aData['content'] = $_POST['content'];
		$this->aData['planID']  = $this->planID;
		$this->aData['acfData'] = $_POST['acfData'];
		$this->listingID        = isset($this->aData['listing_id']) && is_user_logged_in() ? $this->aData['listing_id'] : '';
        $this->aPlanSettings    = GetSettings::getPostMeta($this->planID, get_post_type($this->planID));
		$this->determiningPostAuthorID();

		do_action('wiloke-submission/top_level');
		do_action('wiloke-submission/addlisting/guard', $this->aData);

		$this->locationTax = wilokeRepository('app:listing_location_tax');
		$this->catTax = wilokeRepository('app:listing_cat_tax');
		$this->tagTax = wilokeRepository('app:listing_tag_tax');
        
		/**
		 * If the user plan has already been emptied, We should remove it.
		 */
		$aUserPlan = UserModel::getUserDetailPlan($this->userID, $this->planID);
		$isRemovedPlan = false;
		if ( !PaymentConfiguration::isFreeAddListingMode() && isset($aUserPlan['addListingMode']) && ($aUserPlan['addListingMode'] == wilokeRepository('app:addListingMode', true)->sub('free')) ){
			UserModel::removeUserPlanByPlanID(get_current_user_id(), $this->planID);
			$isRemovedPlan = true;
		}

		if ( !$isRemovedPlan && isset($aUserPlan['remainingItems']) && empty($aUserPlan['remainingItems']) ) {
			UserModel::removeUserPlanByPlanID($this->userID, $this->planID);
			$aUserPlan = array();
		}

		// Inserting new post
		$aInfo = array(
			'post_type'     => 'listing',
			'post_status'   => $this->determiningNewListingStatus(),
			'post_title'    => $this->aData['listing_title'],
			'post_content'  => $this->aData['content']
		);

		if ( !empty($this->listingID) ){
			$aInfo['ID'] = $this->listingID;
			wp_update_post($aInfo);
		}else{
			$this->isNewListing = true;
			$this->listingID = wp_insert_post($aInfo);
			$aInfo['ID'] = $this->listingID;
		}

		if ( empty($this->listingID) || is_wp_error($this->listingID) ){
			wp_send_json_success(
				array(
					'msg' => esc_html__('Whoops! We could not insert a new listing.', 'wiloke')
				)
			);
		}

		$this->setPostThumbnail();
		$this->setListingLocation();
		$this->setListingCategories();
		$this->setListingTag();
		$this->setPostMeta();
		$this->setACFCustomFields();

		$planRelationshipID = $this->insertPlanRelationShip($aUserPlan);
		if ( !$planRelationshipID ){
			$this->rollingBack();
			wp_send_json_error(
				array(
					'msg' => DebugStatus::status('WILOKE_DEBUG') ? esc_html__('We could not insert values to Plan Relationship table', 'wiloke') : esc_html__('Something went wrong', 'wiloke')
				)
			);
		}

		Session::setSession(wilokeRepository('sessionkeys:storePlanRelationshipIDSessionID'), $planRelationshipID);
		Session::setSession(wilokeRepository('sessionkeys:storePostID'), $this->listingID);

		/**
		 * Listing belongs to
		 */
		$this->listingBelongsTo();

		do_action('wiloke-submission/mail', array(
			'type'     => wilokeRepository('mailstatus:type', true)->sub('submittedPost'),
			'aInfo'    => $aInfo,
			'act'      => 'submitted',
            'listingID'=> $this->listingID
		));

		wp_send_json_success(array('next'=>get_permalink($this->listingID)));
	}

	protected function setPostMeta(){
		$aListingSettings['map']['location']  = $this->aData['listing_address'];
		$aListingSettings['map']['latlong']   = $this->aData['listing_latlng'];
		$aListingSettings['phone_number']     = $this->aData['listing_phonenumber'];
		$aListingSettings['website']          = $this->aData['listing_website'];

		update_post_meta($this->listingID, 'listing_settings', $aListingSettings);
		update_post_meta($this->listingID, 'listgo_listing_latlong', $aListingSettings['map']['latlong']);

		if ( !isset($aPackageSettings['toggle_allow_add_gallery']) || ($aPackageSettings['toggle_allow_add_gallery']  === 'enable') ){
			if ( isset($this->aData['listing_gallery']) && !empty($this->aData['listing_gallery']) ){
				$aGallery = array_map('absint', explode(',', $this->aData['listing_gallery']));
				$aImages = array();
				foreach ( $aGallery as $galleryID ){
					if ( !empty($galleryID) ){
						$aImages[$galleryID] = wp_get_attachment_image_url($galleryID);
						wp_update_post(
							array(
								'ID' => $galleryID,
								'post_author' => $this->userID
							)
						);
					}
				}
				$aListOfImages['gallery'] = $aImages;
				update_post_meta($this->listingID, 'gallery_settings', $aListOfImages);
			}else{
				update_post_meta($this->listingID, 'gallery_settings', false);
			}
		}

		if ( isset($aPackageSettings['toggle_listing_template']) && ($aPackageSettings['toggle_listing_template'] == 'enable') ){
		    update_post_meta($this->listingID, '_wp_page_template', $this->aData['listing_style']);
        }

		if ( isset($aPricingSettings['toggle_open_table']) && ($aPricingSettings['toggle_open_table'] == 'enable') ){
			if ( isset($this->aData['listing_open_table_settings']) ){
				$aOpenTableData = array();
				foreach ($this->aData['listing_open_table_settings'] as $key => $val){
					$aOpenTableData[sanitize_text_field($key)] =  sanitize_text_field($val);
				}
				update_post_meta($this->listingID, 'listing_open_table_settings', $aOpenTableData);
			}
		}

		$listingPrice = isset($this->aData['listing_price']) ? $this->aData['listing_price'] : '';
		update_post_meta($this->listingID, 'listing_price', $listingPrice);
		update_post_meta($this->listingID, 'listing_social_media', $this->aData['listing']['social']);

		$toggleBSH = isset($this->aData['toggle_business_hours']) ? $this->aData['toggle_business_hours'] : 'disable';
		update_post_meta($this->listingID, 'wiloke_toggle_business_hours', $toggleBSH);

		$aBusinessHours = apply_filters('wiloke/wiloke-listgo-functionality/app/submit/addlisting', $this->aData['listgo_bh']);
		update_post_meta($this->listingID, 'wiloke_listgo_business_hours', $aBusinessHours);

	}

	/**
	 * Creating Location based on Google Auto Complete
	 *
	 */
	protected function maybeTermParentExisting(){
		$oParent = get_term_by('slug', $this->convertNameToSlug($this->administratorLevel1['long_name']), 'listing_location');
		if ( !empty($oParent) && !is_wp_error($oParent) ){
			$this->parentLocationID = $oParent->term_id;
			return true;
		}

		$oParent = get_term_by('slug', $this->convertNameToSlug($this->administratorLevel1['long_name'], true), 'listing_location');
		if ( !empty($oParent) && !is_wp_error($oParent) ){
			$this->parentLocationID = $oParent->term_id;
			return true;
		}

		$oParent = get_term_by('slug', $this->convertNameToSlug($this->administratorLevel1['short_name']), 'listing_location');
		if ( !empty($oParent) && !is_wp_error($oParent) ){
			$this->parentLocationID = $oParent->term_id;
			return true;
		}

		$oParent = get_term_by('slug', $this->convertNameToSlug($this->administratorLevel1['short_name'], true), 'listing_location');
		if ( !empty($oParent) && !is_wp_error($oParent) ){
			$this->parentLocationID = $oParent->term_id;
			return true;
		}

		$aParent = $this->findLocationByPlaceID($this->administratorLevel1['long_name']);

		if ( $aParent ){
			$this->parentLocationID = $oParent['term_id'];
			return true;
		}

		return false;
	}

	protected function maybeTermCountryExisting(){
		$oParent = get_term_by('slug', $this->convertNameToSlug($this->aCountry['long_name']), $this->locationTax);
		if ( !empty($oParent) && !is_wp_error($oParent) ){
			$this->countryLocationID = $oParent->term_id;
			return true;
		}

		$oParent = get_term_by('slug', $this->convertNameToSlug($this->aCountry['long_name'], true), $this->locationTax);
		if ( !empty($oParent) && !is_wp_error($oParent) ){
			$this->countryLocationID = $oParent->term_id;
			return true;
		}

		$oParent = get_term_by('slug', $this->convertNameToSlug($this->aCountry['short_name']), $this->locationTax);
		if ( !empty($oParent) && !is_wp_error($oParent) ){
			$this->countryLocationID = $oParent->term_id;
			return true;
		}

		$oParent = get_term_by('slug', $this->convertNameToSlug($this->aCountry['short_name'], true), $this->locationTax);
		if ( !empty($oParent) && !is_wp_error($oParent) ){
			$this->countryLocationID = $oParent->term_id;
			return true;
		}

		$aParent = $this->findLocationByPlaceID($this->aCountry['long_name']);

		if ( $aParent ){
			$this->countryLocationID = $oParent['term_id'];
			return true;
		}

		return false;
	}

	protected function findLocationByPlaceID($name){
		global $wiloke;
		$url = 'https://maps.googleapis.com/maps/api/place/autocomplete/json?input='.$name.'&types=geocode&key='.$wiloke->aThemeOptions['general_map_api'];

		$aPlaceInfo = wp_remote_get(esc_url_raw($url));

		if ( is_wp_error($aPlaceInfo) ){
			return false;
		}

		$aPlaceInfo = wp_remote_retrieve_body( $aPlaceInfo );
		$aPlaceInfo = json_decode($aPlaceInfo, true);

		if ( !isset($aPlaceInfo['predictions']) || empty($aPlaceInfo['predictions']) ) {
			return false;
		}

		$aTerms = get_terms(array(
			'taxonomy'   => 'listing_location',
			'hide_empty' => false,
			'meta_query' => array(
				array(
					'key'       => 'wiloke_listing_location_place_id',
					'value'     => $aPlaceInfo['predictions'][0]['place_id'],
					'compare'   => '='
				)
			)
		));

		if ( empty($aTerms) || is_wp_error($aTerms) ){
			return false;
		}

		return array(
			'term'      => $aTerms[0],
			'term_id'   => $aTerms[0]->term_id,
			'place_id'  => $aPlaceInfo['body']['predictions'][0]['place_id']
		);
	}

	protected function detectCountry($aData){
		$total = count($aData);

		for ( $order = absint($total - 2); $order >= 0; $order-- ){
			if ( $aData[$order]['types'][0] === 'country' ){
				$this->aCountry = $aData[$order];
				break;
			}
		}
	}

	protected function convertNameToSlug($slug, $isReplaceDash=false){
		$slug = sanitize_title($slug);
		return $isReplaceDash ? str_replace('-', '', $slug) : $slug;
	}

	protected function findLocationByName($aName){
		$aLocation = get_term_by('slug', $this->convertNameToSlug($aName['long_name']), $this->locationTax);
		if ( !empty($aLocation) && !is_wp_error($aLocation) ){
			return $aLocation;
		}

		$aLocation = get_term_by('slug', $this->convertNameToSlug($aName['long_name'], true), $this->locationTax);
		if ( !empty($aLocation) && !is_wp_error($aLocation) ){
			return $aLocation;
		}

		$aLocation = get_term_by('slug', $this->convertNameToSlug($aName['short_name']), $this->locationTax);
		if ( !empty($aLocation) && !is_wp_error($aLocation) ){
			return $aLocation;
		}

		$aLocation = get_term_by('slug', $this->convertNameToSlug($aName['short_name'], true), $this->locationTax);
		if ( !empty($aLocation) && !is_wp_error($aLocation) ){
			return $aLocation;
		}

		return false;
	}

	protected function parseLocationCategoryName(){
		if ( $this->aParsePlaceInfo['address_components'][0]['types'][0] === 'administrative_area_level_2' ){
			return $this->aParsePlaceInfo['address_components'][0];
		}else{
			foreach ( $this->aParsePlaceInfo['address_components'] as $key => $aPolitical ){
				if ( $aPolitical['types'][0] === 'administrative_area_level_2' ){
				    $next = abs($key)+1;
				    if ( isset($this->aParsePlaceInfo['address_components'][$next]['types'][0]) && ($this->aParsePlaceInfo['address_components'][$next]['types'][0] == 'administrative_area_level_1') ){
					    $this->administratorLevel1 = $this->aParsePlaceInfo['address_components'][$next];
                    }
					return $aPolitical;
				}

				if($aPolitical['types'][0] === 'administrative_area_level_1'){
					$this->administratorLevel1 = $aPolitical;
				}
			}
		}

		if ( !empty($this->administratorLevel1) ){
			return $this->administratorLevel1;
		}

		$total = count($this->aParsePlaceInfo['address_components']);
		if ( $total < 3 ){
			return $this->aParsePlaceInfo['address_components'][0];
		}else{
			return $this->aParsePlaceInfo['address_components'][$total-2];
		}
	}

	protected function getTimeZoneByGoogleAPI($latLng){
		global $wiloke;
		$aTimeZone = wp_remote_get(esc_url_raw('https://maps.googleapis.com/maps/api/timezone/json?location='.$latLng.'&timestamp='.time().'&key='.$wiloke->aThemeOptions['general_map_api']));
		if ( is_wp_error($aTimeZone)  ){
			return '';
		}else{
			$oTimeZone = json_decode($aTimeZone['body']);
			return $oTimeZone->timeZoneId;
		}
	}

	protected function insertNewTerm($name){
		if ( empty($this->parentLocationID) && !empty($this->administratorLevel1) ){
			$aNewTerm = wp_insert_term( $this->administratorLevel1['long_name'], $this->locationTax, array(
				'parent' => $this->countryLocationID
			));
			$this->parentLocationID = $aNewTerm['term_id'];
		}

		$aNewTerm = wp_insert_term( $name, $this->locationTax, array(
			'parent' => $this->parentLocationID
		));
		$this->locationID = $aNewTerm['term_id'];

		\Wiloke::updateOption('_wiloke_cat_settings_'.$this->locationID, array(
			'placeid' => $this->placeID,
			'timezone'=> $this->getTimeZoneByGoogleAPI($this->aData['listing_latlng'])
		));

		update_term_meta($this->locationID, 'wiloke_listing_location_place_id', $this->placeID);
	}

	protected function setLocationByGoogleAddress(){
		$this->aParsePlaceInfo = base64_decode($this->aData['listing_place_information']);
		$this->aParsePlaceInfo = json_decode($this->aParsePlaceInfo, true);
		$aLocation = $this->parseLocationCategoryName();

		if ( !empty($this->administratorLevel1) && $this->administratorLevel1['long_name'] == $aLocation['long_name'] ){
			$this->administratorLevel1 = null;
		}

		$oLocationExist = $this->findLocationByName($aLocation);

		$this->aCountry = end($this->aParsePlaceInfo['address_components']);
		if ( $this->aCountry['types'][0] !== 'country' ){
			$this->detectCountry($this->aParsePlaceInfo['address_components']);
		}

		if ( !$oLocationExist ){
			$oLocationExist = $this->findLocationByPlaceID($aLocation['long_name']);
			if ( !$oLocationExist ){
				if ( !empty($this->administratorLevel1) ){
					$this->maybeTermParentExisting();
				}

				if ( !empty($this->aCountry) ){
					$this->maybeTermCountryExisting();
				}

				if ( !empty($aLocation['long_name']) ){
					$this->insertNewTerm($aLocation['long_name']);
				}
			}else{
				$this->aLocation  = $oLocationExist['term'];
				$this->locationID = $oLocationExist['term_id'];
				$this->placeID    = $oLocationExist['place_id'];
			}
		}else{
			$this->oLocation = $oLocationExist;
			$this->locationID = $oLocationExist->term_id;
		}

		if ( !empty($this->locationID) ){
			wp_set_post_terms($this->listingID, $this->locationID, $this->locationTax);
		}
	}

	protected function setListingLocation(){
		$aThemeOptions = GetSettings::getOptions(wilokeRepository('app:themeoptions'));

		if ( $aThemeOptions['add_listing_select_location_type'] == 'default' ){
			wp_set_post_terms($this->listingID, $this->aData['listing_location'], $this->locationTax, true);
		}else{
            $this->setLocationByGoogleAddress();
		}
	}

	protected function setACFCustomFields(){
		if ( empty($this->aData['acfData']) ){
			return true;
		}
		$aPackageSettings = \Wiloke::getPostMetaCaching($this->planID, 'pricing_settings');

		if ( !isset($aPackageSettings['afc_custom_field']) || empty($aPackageSettings['afc_custom_field']) ){
			return false;
		}

		$aACFPostTypes = array('acf', 'acf-field-group');
		$postType = get_post_field('post_type', $aPackageSettings['afc_custom_field']);
		if ( !in_array($postType, $aACFPostTypes) || (get_post_field('post_status', $aPackageSettings['afc_custom_field']) != 'publish') ){
			return false;
		}

		$aCustomFields = json_decode(stripslashes($this->aData['acfData']), true);

		$this->listingID = abs($this->listingID);

		foreach ( $aCustomFields as $key => $val ){
			update_field($key, $val, $this->listingID);
		}
	}

	/* End / Creating new Location based on Google Auto Complete */
	protected function setListingTag(){
	    global $wiloke;
		if ( !empty($this->aData['listing_tags']) ){
		    if ( $wiloke->aThemeOptions['add_listing_select_tag_type'] == 'add_by_user' ){
			    wp_set_post_terms($this->listingID, $this->aData['listing_tags'], $this->tagTax, false);
            }else{
			    $this->aData['listing_tags'] = array_map('absint', $this->aData['listing_tags']);
			    wp_set_post_terms($this->listingID, $this->aData['listing_tags'], $this->tagTax, true);
            }
		}
	}

	protected function setListingCategories(){
		$aListingCats = $this->aData['listing_cats'];

		foreach ( $aListingCats as $key => $termID  ){
			$termID = absint($termID);
			if ( !term_exists($termID, $this->catTax) ){
				unset($aListingCats[$termID]);
			}else{
				$aListingCats[$key] = absint($termID);
			}
		}

		wp_set_post_terms($this->listingID, $aListingCats, $this->catTax, true);
	}

	/**
	 *  Set post Thumbnail
	 *
	 * @return bool
	 */
	protected function setPostThumbnail(){
		if ( !empty($this->aData['featured_image']) ){
			$this->thumbnailID = get_post_thumbnail_id($this->listingID);

			if ( $this->thumbnailID == $this->aData['featured_image'] ){
				return false;
			}
			$this->thumbnailID = set_post_thumbnail($this->listingID, $this->aData['featured_image']);
			return true;
		}
	}

	/**
	 * Listing belongs to
	 *
	 * Updating all information of where listing belongs to
	 *
	 * @return void
	 */
	protected function listingBelongsTo(){
		SetSettings::setPostMeta($this->listingID, wilokeRepository('app:belongsToPlanID'), $this->planID);
	}

	/**
	 * Determine the page url need to be gone after inserting listing
	 *
	 * @return $oResponse
	 */
	protected function nextStepAfterInsertingListing(){
		$isFreeMode = PaymentConfiguration::isFreeAddListingMode();

		if ( !$isFreeMode ){
            $isFreeMode = empty($this->aPlanSettings['price']) ?  true : false;
        }
        
		$instRouteAfterItemInserted = new RouteAfterItemInserted();
		$instRouteAfterItemInserted->isFreeAddItem($isFreeMode)
			->setPlanID($this->planID)
			->setPostID($this->listingID)
			->setUserID($this->userID);

		$oResponse = $instRouteAfterItemInserted->response();

		return $oResponse;
	}


	/**
	 * Sanitize data before updating
	 *
	 * @param mixed $val
	 * @param string $cb Callback function
	 *
	 * @return mixed $sanitizedVal
	 */
	protected function sanitize($val, $cb){
		$sanitizedVal = null;

		if ( is_array($val) ){
			foreach ($val as $k => $v){
				$sanitizedVal[$k] = $cb($v);
			}
		}else{
			$sanitizedVal = $cb($val);
		}

		return $sanitizedVal;
	}

	/**
	 * Add Listing Controller
	 */
	public static function addListingController(){
	    if ( is_user_logged_in() ){
	        if ( GetSettings::getUserMeta(get_current_user_id(), User::$pendingStatus) ){
		        ob_start();
		        FrontendListingManagement::message(array(
			        'message' => esc_html__('Please confirm your account before continuing.', 'wiloke')
		        ), 'danger');
		        $content = ob_get_contents();
		        ob_end_clean();
		        return $content;
            }
        }

		if ( !isset($_REQUEST['package_id']) || empty($_REQUEST['package_id']) || (get_post_status($_REQUEST['package_id']) != 'publish') ){
			ob_start();
			FrontendListingManagement::message(array(
				'message' => esc_html__('Please select a plan before adding your listing.', 'wiloke')
			), 'danger');
			$content = ob_get_contents();
			ob_end_clean();
			return $content;
		}

		$aUserPlanInfo = UserModel::getDetailPlan($_GET['package_id']);
		Session::setSession(wilokeRepository('sessionkeys:storePlanID'), $_GET['package_id']);
		if ( DebugStatus::status('WILOKE_SUBMISSION_THROUGH_ALL') ){
			return true;
		}

		if ( !DebugStatus::status('WILOKE_SUBMISSION_CHECK_EVEN_ADMIN') && current_user_can('administrator') ){
			return true;
		}

		if ( empty($aUserPlanInfo) ){
			return true;
		}

		if ( isset($_GET['listing_id']) && (get_post_field('post_author', $_GET['listing_id']) != get_current_user_id()) ){
			ob_start();
			FrontendListingManagement::message(array(
				'message' => esc_html__('You do not have permission to access this page.', 'wiloke')
			), 'danger');
			$content = ob_get_contents();
			ob_end_clean();
			Session::destroySession(wilokeRepository('sessionkeys:storePlanID'));
			return $content;
		}

		if ( PaymentConfiguration::isNonRecurringPayment() ){
			if ( $aUserPlanInfo['gateway'] ==  'banktransfer' ){
				$status = PaymentModel::getSessionStatus($aUserPlanInfo['sessionID']);
				if ( $status != wilokeRepository('app:paymentStatus', true)->sub('succeeded') ){
					ob_start();
					FrontendListingManagement::message(array(
						'message' => esc_html__('Please transfer your order recently to continue submitting. In case, you have already transferred to our bank account, please contact us to confirm your payment.', 'wiloke')
					), 'danger');
					$content = ob_get_contents();
					ob_end_clean();
					Session::destroySession(wilokeRepository('sessionkeys:storePlanID'));
					return $content;
				}
			}
			return true;
		}else{
			if ( $aUserPlanInfo['gateway'] ==  'banktransfer' ){
				$status = PaymentModel::getSessionStatus($aUserPlanInfo['sessionID']);
				if ( $status != wilokeRepository('app:paymentStatus', true)->sub('succeeded') ){
					ob_start();
					FrontendListingManagement::message(array(
						'message' => esc_html__('Please transfer your order recently to continue submitting. In case, you have already transferred to our bank account, please contact us to confirm your payment.', 'wiloke')
					), 'danger');
					$content = ob_get_contents();
					ob_end_clean();
					Session::destroySession(wilokeRepository('sessionkeys:storePlanID'));
					return $content;
				}
			}

			if ( empty($aUserPlanInfo['remainingItems']) ){
				$myAccount = \WilokePublic::getPaymentField('myaccount', true);
				$aInfo = array(
					'message' => sprintf( __('You have exceeded the number of listings for this plan. Fortunately, You can continue submitting by upgrading to higher plan. <a href="%s">Yes, I want to upgrade my plan.</a>', 'wiloke'), esc_url(\WilokePublic::addQueryToLink($myAccount, 'mode=my-billing')) ),
					'icon' => 'icon_error-triangle_alt'
				);
				ob_start();
				FrontendListingManagement::message($aInfo, 'danger');
				$content = ob_get_contents();
				ob_end_clean();
				Session::destroySession(wilokeRepository('sessionkeys:storePlanID'));
				return $content;
			}
			return true;
		}
	}
}