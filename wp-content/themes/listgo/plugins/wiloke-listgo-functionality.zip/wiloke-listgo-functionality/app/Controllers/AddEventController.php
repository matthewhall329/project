<?php
namespace WilokeListgoFunctionality\Controllers;


use Stripe\Card;
use WilokeListgoFunctionality\Framework\Helpers\DebugStatus;
use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
use WilokeListgoFunctionality\Framework\Helpers\SetSettings;
use WilokeListgoFunctionality\Framework\Helpers\Time;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use WilokeListgoFunctionality\Framework\Store\Session;
use WilokeListgoFunctionality\Model\PlanRelationshipModel;
use WilokeListgoFunctionality\Model\UserModel;

class AddEventController extends Controller {
	protected $eventPlanID;
	protected $eventID;
	protected $listingID;
	protected $userID;
	protected $aAtts;
	protected $aUserEventPlan;
	protected $eventSettingsKey  = 'event_settings';
	protected $postStatus;
	protected $postType='event';
	protected $aEventPlanSettings;
	protected $expiryPeriod=1800;
	protected $isNewListing = true;
    protected $token;

	public function __construct() {
		add_action('wp_ajax_wiloke_submission_add_event', array($this, 'addEvent'));
		add_action('wiloke/wiloke-submission/payment/after_payment', array($this, 'updateEventStatus'), 10);
		add_action('wiloke/wiloke-submission/payment/after_payment', array($this, 'addOfferEventPlan'), 10);
		add_action('updated_post_meta', array($this, 'updateEventParent'), 10, 4);
		add_action('wp_ajax_wiloke_listgo_delete_event', array($this, 'deleteEvent'), 10, 4);
	}

	public function deleteEvent(){
		if ( !isset($_POST['eventID']) || empty($_POST['eventID']) ){
			wp_send_json_error();
		}

		if ( get_post_type($_POST['eventID']) !== $this->postType ){
			wp_send_json_error();
		}

		if ( !current_user_can('administrator') ){
			if ( get_post_field('post_author', $_POST['eventID']) != get_current_user_id() ){
				wp_send_json_error();
			}
		}

		wp_delete_post($_POST['eventID']);
	}

	public function addOfferEventPlan($aData){
		if ( $aData['status'] !== 'succeeded' ){
			return false;
		}

		if (  get_post_type($aData['planID']) != 'pricing' ){
			return false;
		}

		$aPlanSettings = GetSettings::getPostMeta($aData['planID'], 'pricing_settings');
		if ( !isset($aPlanSettings['event_pricing_package']) || empty($aPlanSettings['event_pricing_package']) ){
			return false;
		}

		$instUserModel = new UserModel;
		$instUserModel->setUserID(get_current_user_id());
		$instUserModel->setGateway($aData['gateway']);
		$instUserModel->setSessionID($aData['sessionID']);
		$instUserModel->setBillingType($aData['billingType']);
		$instUserModel->setPlanID($aPlanSettings['event_pricing_package']);

		$instUserModel->setEventPlan();
	}

	public function updateEventParent($metaID, $objectID, $metaKey, $metaValue){
        if ( $metaKey !== 'event_settings' ){
            return false;
        }

		wp_update_post(
			array(
				'ID' => $objectID,
				'post_parent' => $metaValue['belongs_to']
			)
		);
    }

	protected function eventExpirationEdit(){
		if ( current_user_can('edit_theme_options') ){
			return false;
		}

		$eventCreatedAtGMT = strtotime(get_post_field('post_date_gmt', $this->eventID));
		$nowUTC = Time::timestampUTCNow();
		if ( intval($nowUTC - $eventCreatedAtGMT) >= $this->expiryPeriod  ){
			return true;
		}

		return false;
	}

	/*
	 * Generate Event Content
	 *
	 */
	public function renderEvent(){
		$this->aEventPlanSettings = GetSettings::getPostMeta($this->eventID, $this->eventSettingsKey);
		ob_start();
		?>
		<div id="event-<?php echo esc_attr($this->eventID); ?>" class="listing-single__event">
			<?php if ( has_post_thumbnail($this->eventID) ) : ?>
				<div class="listing-single__event-media">
					<?php echo get_the_post_thumbnail($this->eventID, 'large'); ?>
				</div>
			<?php endif; ?>

			<h2 class="listing-single__event-title"><?php echo get_the_title($this->eventID); ?></h2>

			<div class="listing-event__start">
				<table class="listing-event__table">
					<thead>
					<tr>
						<th><?php esc_html_e('Address', 'wiloke'); ?></th>
						<th><?php esc_html_e('From', 'wiloke'); ?></th>
						<th><?php esc_html_e('To', 'wiloke'); ?></th>
					</tr>
					</thead>
					<tr>
						<td class="listing-event__address" title="Address">
							<p>
								<i class="color-yelow icon_pin_alt"></i> <?php echo esc_html_e($this->aEventPlanSettings['place_detail']); ?>
							</p>
						</td>
						<td class="listing-event__from" title="<?php esc_html_e('Events starts', 'wiloke'); ?>">
							<p>
								<?php if ( !empty($this->aEventPlanSettings['start_at']) ) : ?>
									<i class="color-green icon_clock_alt"></i> <?php echo esc_html($this->aEventPlanSettings['start_at']); ?> <br>
								<?php endif; ?>
								<?php if ( !empty($this->aEventPlanSettings['start_on']) ) : ?>
									<i class="color-green icon_table"></i> <?php echo esc_html($this->aEventPlanSettings['start_on']); ?>
								<?php endif; ?>
							</p>
						</td>
						<td class="listing-event__to"  title="<?php esc_html_e('Events closes', 'wiloke'); ?>">
							<p>
								<?php if ( !empty($this->aEventPlanSettings['end_at']) ) : ?>
									<i class="color-red icon_clock_alt"></i> <?php echo esc_html($this->aEventPlanSettings['end_at']); ?> <br>
								<?php endif; ?>
								<?php if ( !empty($this->aEventPlanSettings['end_on']) ) : ?>
									<i class="color-red icon_table"></i> <?php echo esc_html($this->aEventPlanSettings['end_on']); ?>
								<?php endif; ?>
							</p>
						</td>
					</tr>
				</table>
			</div>

			<div class="listing-single__event-content">
				<?php echo get_post_field('post_content', $this->eventID); ?>
			</div>

			<?php if ( current_user_can('edit_theme_options') || (get_post_field('post_author', $this->eventID) == get_current_user_id()) ) : ?>
				<div class="listing-single__event-actions">
					<?php
					$expiredEditing = $this->eventExpirationEdit();
					if ( !$expiredEditing && !current_user_can('edit_theme_options') ) :
						?>
						<div class="listing-single__event-msg">
							<?php esc_html_e('This event can not be edited after', 'wiloke'); ?>
							<span class="listing-single__event-countdown-edit">
                        <span class="listing-single__event-countdown-edit-label"><?php esc_html_e('Countdown:', 'wiloke'); ?></span>
                        <span id="listgo-countdown-editing-period-<?php echo esc_attr($this->eventID); ?>" class="listing-single__event-countdown-edit-time" data-created="<?php echo esc_attr(get_post_field('post_date', $this->eventID)); ?>"><?php echo esc_attr('30:00'); ?></span> <?php esc_html_e(' minutes', 'wiloke'); ?>
                    </span>
						</div>
					<?php endif; ?>
					<div class="pull-right">
						<?php if ( !$expiredEditing ) : ?>
							<a id="listgo-edit-event-<?php echo esc_attr($this->eventID); ?>" class="listing-single__event-edit" data-id="<?php echo esc_attr($this->eventID); ?>" href="#"><i class="icon_pencil"></i> <span><?php esc_html_e('Edit', 'listgo'); ?></span></a>
						<?php endif; ?>
						<a id="listgo-delete-event-<?php echo esc_attr($this->eventID); ?>" class="listing-single__event-remove" data-id="<?php echo esc_attr($this->eventID); ?>" href="#"><i class="icon_close"></i> <span><?php esc_html_e('Remove', 'listgo'); ?></span></a>
					</div>
				</div>
			<?php endif; ?>
		</div>
		<?php
		$content = ob_get_contents();
		ob_end_clean();
		return $content;
	}

	/**
	 * After the payment succeeded, we will update the event status
	 *
	 * @param array $aAfterPaymentInfo
	 * @return bool
	 */
	public function updateEventStatus($aAfterPaymentInfo){
		if ( !isset($aAfterPaymentInfo['planID']) || empty($aAfterPaymentInfo['planID']) || is_array($aAfterPaymentInfo['planID'])){
			return false;
		}

		if ( get_post_type($aAfterPaymentInfo['planID']) != $this->postType ){
			return false;
		}

		wp_update_post(
			array(
				'ID' => $aAfterPaymentInfo['eventID'],
				'post_status' => 'publish'
			)
		);
	}

	protected function parseEventData($aRawData){
		$aEventSettings = json_decode(urldecode(base64_decode($aRawData['data'])), true);
		$aParsedData = array();
		foreach ( $aEventSettings as $aField ){
			$name = strip_tags($aField['name']);
			$aParsedData[$name] = sanitize_text_field($aField['value']);
		}
		$aParsedData['event_content'] = wp_kses_post($aRawData['event_content']);

		$this->aAtts = $aParsedData;
	}

	/**
	 * Determining whether the listing is an expired Listing
	 *
	 * @return bool
	 */
	public function needTobeAddedToPlanRelationship(){
		if ( !empty($this->eventID) ){
			$this->isNewListing = false;
			return $this->isNewListing;
		}

		if ( $this->postStatus != 'publish' ){
			$this->isNewListing = false;
			return $this->isNewListing;
		}

		$this->isNewListing = true;

		return $this->isNewListing;
	}

	public function addEvent(){
		$this->userID = get_current_user_id();
		$this->eventID = isset($_POST['eventID']) ? trim($_POST['eventID']) : '';
		$this->eventPlanID = isset($_POST['eventPlanID']) ? trim($_POST['eventPlanID']) : '';
		$this->listingID = trim($_POST['listingID']);
		$this->token = trim($_POST['token']);

		$this->middleware(['isPostAuthor', 'isEventExpired'], array(
			'postID'        => $this->listingID,
			'eventID'       => $this->eventID,
			'eventPlanID'   => $this->eventPlanID
		));

		$this->parseEventData($_POST);

		$this->middleware(['validateEventsAtts'], $this->aAtts);

		if ( !empty($this->eventID) ){
			// It's update event session
			wp_update_post(
				array(
					'ID'           => $this->eventID,
					'post_title'   => $this->aAtts['event_title'],
					'post_content' => $this->aAtts['event_content']
				)
			);
			$this->setFeatureImage();
			$this->setEventMetaValues();

			wp_send_json_success(
				array(
					'eventID'   => $this->eventID,
					'msg'       => $this->renderEvent()
				)
			);
		}else{
			$this->aUserEventPlan = UserModel::getUserEventPlan($this->userID);

            $this->middleware(['validateBankTransferStatus'], array(
                'aUserPlan' => $this->aUserEventPlan
            ));
			// it's insert a new event session
			$this->eventID = wp_insert_post(
				array(
					'ID'           => $this->eventID,
					'post_type'    => $this->postType,
					'post_title'   => $this->aAtts['event_title'],
					'post_content' => $this->aAtts['event_content'],
					'post_status'  => $this->detectingEventStatus(),
                    'post_date_gmt'=> Time::getAtomUTCString()
				)
			);

			$this->setEventMetaValues();
			$this->insertPlanRelationShip();
			$this->listingBelongsTo();
			$this->updateParentOfEvent();

			if ( $this->postStatus != 'publish' ){
				Session::setSession(wilokeRepository('sessionkeys:storePostID'), $this->eventID);
				Session::setSession(wilokeRepository('sessionkeys:storePlanID'), $this->eventPlanID);
				Session::setSession(wilokeRepository('sessionkeys:planType'), 'event');

				$this->aAtts['redirectTo'] = get_permalink($this->listingID);
				$this->aAtts['planID']  = $this->eventPlanID;
				$this->aAtts['thankyouUrl']  = get_permalink($this->listingID);
				$this->aAtts['token'] = $this->token;
				PaymentConfiguration::$isFocusNonRecurring = true;
				do_action('wiloke_submission/purchase-event-plan-with-'.$this->aAtts['event_payment_method'], $this->aAtts);
			}else{
				if (current_user_can('administrator') && !DebugStatus::status('WILOKE_SUBMISSION_CHECK_EVEN_ADMIN')){
					wp_send_json_success(
						array(
							'eventID'	=> null,
							'msg'       => $this->renderEvent()
						)
					);
				}

				UserModel::updateUserRemainingItemsByPlanID($this->userID, $this->eventPlanID);
				wp_send_json_success(
					array(
						'eventID'	=> null,
						'msg'       => $this->renderEvent(),
						'remaining' => abs($this->aUserEventPlan['remainingItems']) - 1
					)
				);
			}
		}
	}

	/**
	 * Listing belongs to
	 *
	 * Updating all information of where listing belongs to
	 *
	 * @return void
	 */
	protected function listingBelongsTo(){
		SetSettings::setPostMeta($this->eventID, wilokeRepository('app:belongsToPlanID'), $this->eventPlanID);
	}

	/**
	 * An event is a child of a listing
     *
	 */
	protected function updateParentOfEvent(){
	    wp_update_post(
	        array(
                'ID' => $this->eventID,
                'post_parent' => $this->listingID
            )
        );
    }

	/**
	 *
	 * @return number
	 */
	protected function insertPlanRelationShip(){
		$relationshipID = PlanRelationshipModel::insert(
			array(
				'planID'    => $this->eventPlanID,
				'objectID'  => $this->eventID,
				'userID'    => $this->userID,
				'sessionID' => empty($this->aUserEventPlan) || abs($this->aUserEventPlan['remainingItems']) <= 0 ? 0 : abs($this->aUserEventPlan['sessionID'])
			)
		);

		Session::setSession(wilokeRepository('sessionkeys:storePlanRelationshipIDSessionID'), $relationshipID);
		return $relationshipID;
	}


	protected function setFeatureImage(){
		if ( isset($this->aAtts['event_featured_image']) && !empty($this->aAtts['event_featured_image']) ){
			set_post_thumbnail($this->eventID, $this->aAtts['event_featured_image']);
		}
	}

	protected function convertEventDateToTimestamp($date, $hour){
		if ( empty($hour) ){
			$timestamp = strtotime(trim($date));
		}else{
			$timestamp = strtotime(trim($date) . ' +'.$hour);
		}
		return $timestamp;
    }

	protected function setEventMetaValues(){
		unset($this->aAtts['event_title']);
		unset($this->aAtts['event_content']);
		unset($this->aAtts['event_featured_image']);
		$this->aAtts['belongs_to'] = $this->listingID;

		SetSettings::setPostMeta($this->eventID, $this->eventSettingsKey, $this->aAtts);

		if ( current_user_can('edit_theme_options') ){
			$showEventOnCarouselStatus = $showEventOnListStatus = $showEventOnWidget = 'enable';
		}else{
			$showEventOnCarouselStatus 	= get_post_meta($this->eventPlanID, wilokeRepository('eventsettings:toggleEventOnCarousel'), true);
			$showEventOnListStatus 	= get_post_meta($this->eventPlanID, wilokeRepository('eventsettings:toggleEventOnListing'), true);
			$showEventOnWidget 		= get_post_meta($this->eventPlanID, wilokeRepository('eventsettings:toggleEventOnWidget'), true);
		}

		$started = $this->convertEventDateToTimestamp($this->aAtts['start_on'], $this->aAtts['start_at']);
		$ended   = $this->convertEventDateToTimestamp($this->aAtts['end_at'], $this->aAtts['end_on']);

		SetSettings::setPostMeta($this->eventID, wilokeRepository('eventsettings:eventStart'), $started);
		SetSettings::setPostMeta($this->eventID, wilokeRepository('eventsettings:eventEnded'), $ended);

		update_post_meta($this->eventID, wilokeRepository('eventsettings:toggleEventOnCarousel'), $showEventOnCarouselStatus);
		update_post_meta($this->eventID, wilokeRepository('eventsettings:toggleEventOnListing'), $showEventOnListStatus);
		update_post_meta($this->eventID, wilokeRepository('eventsettings:toggleEventOnWidget'), $showEventOnWidget);
	}

	protected function detectingEventStatus(){
		if ( !empty($this->eventID) ){
			return get_post_status($this->eventID);
		}

		if (current_user_can('administrator') && !DebugStatus::status('WILOKE_SUBMISSION_CHECK_EVEN_ADMIN')){
			$this->postStatus = 'publish';
			return $this->postStatus;
		}

		if ( empty($this->aUserEventPlan) || ($this->aUserEventPlan['remainingItems'] <= 0)  ){
			$this->middleware(['validateEventPlan'], array(
				'eventPlanID'   => $this->eventPlanID
			));

			$this->postStatus = 'draft';
			return $this->postStatus;
		}

		$this->eventPlanID =$this->aUserEventPlan['planID'];
		$this->postStatus = 'publish';
		return $this->postStatus;
	}
}