<?php
namespace WilokeListgoFunctionality\Controllers;


class Kernel extends Controller {
	public function __construct() {
		add_action('wiloke-submission/top_level', array($this, 'guard'));
	}

	public function guard(){
		$this->middleware(['userBanned']);
	}
}