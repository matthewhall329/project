<?php
namespace WilokeListgoFunctionality\Controllers;


use WilokeListgoFunctionality\Framework\Helpers\DebugStatus;
use WilokeListgoFunctionality\Framework\Helpers\GenerateUrl;
use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
use WilokeListgoFunctionality\Framework\Store\Cookie;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use WilokeListgoFunctionality\Model\UserModel;
use WilokeListgoFunctionality\Submit\User;

class AddListingBtnUrlController {
	protected static $aUserPlansInCookie;
	protected $planKey = 'pricing';

	public function __construct() {
		add_filter('wiloke-submission/add-listing-btn-url', array($this, 'getAddListingBtnUrl'));
		add_filter('wiloke-submission/edit-listing-btn-url', array($this, 'getEditListingUrl'), 10, 1);
		add_filter('wiloke/listgo/planUrl', array($this, 'getPlanUrl'), 10, 2);
	}

	public function getPlanUrl($planID, $listingID){
		$addListingUrl = get_permalink(PaymentConfiguration::getField('addlisting'));

		if ( !empty($listingID) ){
			return GenerateUrl::url($addListingUrl, array(
				'package_id' => $planID,
				'listing_id' => $listingID
			));
        }else{
			return GenerateUrl::url($addListingUrl, array(
				'package_id' => $planID
			));
        }
    }

	public static function getUserPlansInCookie(){
		self::$aUserPlansInCookie = maybe_unserialize(stripslashes(Cookie::get(wilokeRepository('cookiekeys:userPlanCookie'))));
		return self::$aUserPlansInCookie;
	}

	public static function getEditListingUrl($postID){
		$aUserPlans = UserModel::getPlansByUserID(get_current_user_id());
		$aWilokeSettings = PaymentConfiguration::get();
		

		if ( !DebugStatus::status('WILOKE_TURNON_VERIFY_CLAIM') ){
			$aClaimInfo = GetSettings::getPostMeta($postID, 'listing_claim');
			if ( get_post_status($postID) == 'publish' && $aClaimInfo['status'] == 'claimed' ){
				return GenerateUrl::url(get_permalink($aWilokeSettings['addlisting']), array(
					'listing_id' => $postID
				));
			}
		}

		if ( get_post_type($postID) == 'listing' && isset($aUserPlans['pricing']) && !PaymentConfiguration::isNonRecurringPayment() ){
			$aLastPlan 	= end($aUserPlans['pricing']);
			$planID 	= $aLastPlan['planID'];
		}else{
			$planID = GetSettings::getPostMeta($postID, wilokeRepository('app:belongsToPlanID'));
		}

		if ( PaymentConfiguration::isFreeAddListingMode() || PaymentConfiguration::isPlanExists($planID) ){
			return GenerateUrl::url(get_permalink($aWilokeSettings['addlisting']), array(
				'package_id' => empty($planID) ? PaymentConfiguration::getFreePlan() : $planID,
				'listing_id' => $postID
			));
		}

		return GenerateUrl::url(get_permalink($aWilokeSettings['package']), array(
			'listing_id' => $postID
		));
    }

	public static function quickAddListingBtn(){
		if ( !class_exists('WilokeListgoFunctionality\Shortcodes\Shortcodes') ){
			return false;
		}

		if ( is_user_logged_in() ){
			if ( !current_user_can('edit_theme_options') && \WilokePublic::$oUserInfo->role !== 'wiloke_submission' ){
				return '';
			}
		}

		global $wiloke;
		$toggle = \WilokePublic::getPaymentField('toggle');
		if ( empty($toggle) || $toggle === 'disable' ){
			return false;
		}
		$additionalClass = $wiloke->aThemeOptions['toggle_add_listing_btn_on_mobile'] == 'enable' ? 'add-listing-enable-on-mobile' : 'add-listing-disable-on-mobile';
		?>
		<div class="header__add-listing <?php echo esc_attr($additionalClass); ?>">
			<div class="tb">
				<div class="tb__cell">
					<a href="<?php echo esc_url(apply_filters('wiloke-submission/add-listing-btn-url', '')); ?>"><span><?php esc_html_e('+ Add Listing', 'wiloke'); ?></span></a>
				</div>
			</div>
		</div>
		<?php
	}


	/**
	 * Control Add listing btn url
	 *
	 */
	public function getAddListingBtnUrl(){
		$aWilokeSettings = PaymentConfiguration::get();

		if ( PaymentConfiguration::isFreeAddListingMode() ){
			$aCustomerPlan = PaymentConfiguration::getCustomerPlans();
			return GenerateUrl::url(get_permalink($aWilokeSettings['addlisting']), array(
				'package_id' => end($aCustomerPlan)
			));
		}

		$addListingBtnUrl = get_permalink($aWilokeSettings['package']);

		if ( DebugStatus::status('WILOKE_SUBMISSION_THROUGH_ALL') ){
			return $addListingBtnUrl;
		}

		$aUserLatestPlan = UserModel::getLatestPlanByPlanType($this->planKey);

		if ( !$aUserLatestPlan ){
			return $addListingBtnUrl;
		}

		if ( !PaymentConfiguration::isFreeAddListingMode() && isset($aUserLatestPlan['addListingMode']) && ($aUserLatestPlan['addListingMode'] == wilokeRepository('app:addListingMode', true)->sub('free')) ){
			UserModel::removeUserPlanByPlanID(get_current_user_id(), $aUserLatestPlan['planID']);
			return $addListingBtnUrl;
		}

		if ( empty($aUserLatestPlan['remainingItems']) ){
			return $addListingBtnUrl;
		}

		return GenerateUrl::url(get_permalink($aWilokeSettings['addlisting']), array(
			'package_id' => $aUserLatestPlan['planID']
		));
	}
}