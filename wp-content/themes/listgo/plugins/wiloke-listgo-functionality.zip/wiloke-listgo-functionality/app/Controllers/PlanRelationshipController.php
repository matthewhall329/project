<?php
namespace WilokeListgoFunctionality\Controllers;


use Carbon\Carbon;
use WilokeListgoFunctionality\Framework\Helpers\Time;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use WilokeListgoFunctionality\Model\PlanRelationshipModel;

class PlanRelationshipController extends Controller {
	public function __construct() {
		add_action('wiloke/wiloke-submission/payment/after_payment', array($this, 'updateSessionID'), 5);
	}

	/*
	 * Updating sessionID column in Plan Relationship table after the payment has been succeeded
	 *
	 * @param array $aPaymentResponse
	 */
	public function updateSessionID($aPaymentResponse){
		if ( ($aPaymentResponse['status'] != 'succeeded') && ($aPaymentResponse['gateway'] != 'banktransfer') ){
			return false;
		}

		$this->middleware(['isUserLoggedIn']);

		PlanRelationshipModel::updateEmptySessionID($aPaymentResponse['sessionID'], array(
			'value' => array(
				'planID' => $aPaymentResponse['planID'],
				'userID' => isset($aPaymentResponse['userID']) && !empty($aPaymentResponse['userID']) ? abs($aPaymentResponse['userID']) : get_current_user_id(),
				'ID'     => $aPaymentResponse['planRelationshipID']
			),
			'format' => array(
				'%d',
				'%d',
				'%d'
			)
		));

		if ( !empty($aPaymentResponse['postID']) ){
			if ( $aPaymentResponse['gateway'] != 'banktransfer' ){
				$postStatus = get_post_status($aPaymentResponse['postID']);
				$postType   = get_post_field('post_type', $aPaymentResponse['postID']);

				if ( $postType == 'event' || (PaymentConfiguration::getField('approved_method') != 'manual_review') ){
					$newPostStatus = 'publish';
				}else{
					if ( $postStatus == 'expired' ){
						$newPostStatus = 'renew';
					}else{
						$newPostStatus = 'pending';
					}
				}

				wp_update_post(
					array(
						'ID'            => $aPaymentResponse['postID'],
						'post_status'   => $newPostStatus
					)
				);
			}else{
				wp_update_post(
					array(
						'ID'             => $aPaymentResponse['postID'],
						'post_date_gmt'  => Time::getAtomUTCString()
					)
				);
			}

		}
	}
}