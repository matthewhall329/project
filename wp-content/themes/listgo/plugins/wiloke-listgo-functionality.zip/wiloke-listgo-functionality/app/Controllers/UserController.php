<?php
namespace WilokeListgoFunctionality\Controllers;


use WilokeListgoFunctionality\Framework\Config\Repository;
use WilokeListgoFunctionality\Framework\Helpers\GeneratePrefix;
use WilokeListgoFunctionality\Framework\Helpers\GenerateUrl;
use WilokeListgoFunctionality\Framework\Store\Session;
use WilokeListgoFunctionality\Framework\Store\Cookie;
use WilokeListgoFunctionality\Model\UserModel;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use WilokeListgoPromotion\Register\RegisterPromotionPricing;

class UserController{
	public function __construct() {
		add_action('wp_login', array(__CLASS__, 'setupUserPlanToCookie'), 10, 2);
		add_action('wiloke-submission/update-user-plan-cookie', array(__CLASS__, 'updateUserPlanCookie'), 10, 1);
		add_action('wiloke-submission/app/model/usermodel/updateUserRemainingItemsByPlanID', array(__CLASS__, 'updateUserPlanCookieByUserID'), 10, 1);
		add_action('wp_ajax_wiloke_submission_detect_timezone', array($this, 'detectUserTimeZone'));
		add_action('wiloke/wiloke-submission/payment/after_payment', array($this, 'createUserPlan'), 10);

		add_action('wiloke/wiloke-submission/manually-add-order', array($this, 'createUserPlan'), 10);
		add_action('wiloke_submission/after-orderstatus-changed-pricing', array($this, 'updateRemainingItems'), 10);
	}

	public function updateRemainingItems($aData){
		if ( $aData['newStatus'] != wilokeRepository('app:paymentStatus', true)->sub('succeeded') ){
			return false;
		}

		UserModel::updateUserRemainingItemsByPlanID($aData['userID'], $aData['planID']);
	}

	/**
	 * Creating a new user plan. $aPaymentStatus is the result of each payment
	 *
	 * @param array $aPaymentResponse
	 * @return bool
	 */
	public function createUserPlan($aPaymentResponse){
		if ( class_exists('WilokeListgoPromotion\Register\RegisterPromotionPricing') && isset($aPaymentResponse['planID']) && get_post_type($aPaymentResponse['planID']) == RegisterPromotionPricing::$postType ){
			return false;
		}

		if ( ($aPaymentResponse['gateway'] != 'banktransfer') ){
			if ( $aPaymentResponse['status'] != 'succeeded' ){
				return false;
			}

			if ( !PaymentConfiguration::isNonRecurringPayment($aPaymentResponse['billingType']) ){
				if ( !isset($aPaymentResponse['nextBillingDate']) || empty($aPaymentResponse['nextBillingDate']) ){
					if( wp_doing_ajax() ){
						wp_send_json_error(
							array(
								'msg' => new NotFoundHttpException( esc_html__('nextBillingDate value is required', 'wiloke') )
							)
						);
					}else{
						throw new NotFoundHttpException( esc_html__('nextBillingDate value is required', 'wiloke') );
					}
				}
			}
		}
		$aPaymentResponse['nextBillingDate'] = isset($aPaymentResponse['nextBillingDate']) && !empty($aPaymentResponse['nextBillingDate']) ? $aPaymentResponse['nextBillingDate'] : '';
		$aPaymentResponse['userID'] = isset($aPaymentResponse['userID']) && !empty($aPaymentResponse['userID']) ? $aPaymentResponse['userID'] : get_current_user_id();

		$instUserModel = new UserModel();
		$instUserModel->setUserID($aPaymentResponse['userID'])
		              ->setNextBillingDate($aPaymentResponse['nextBillingDate'])
		              ->setPlanID($aPaymentResponse['planID'])
		              ->setSessionID($aPaymentResponse['sessionID'])
		              ->setGateway($aPaymentResponse['gateway'])
		              ->setBillingType($aPaymentResponse['billingType']);

		if ( isset($aPaymentResponse['addListingMode']) ){
			$instUserModel->setAddListingMode($aPaymentResponse['addListingMode']);
		}
		$instUserModel->setUserPlan();

		return true;
	}

	public function detectUserTimeZone(){
		Session::setSession(GeneratePrefix::generateKey('user_timezone'), $_POST['timezone']);
	}

	public function enqueueScripts(){
		wp_enqueue_script('jstimezonedetect', 'http://cdnjs.cloudflare.com/ajax/libs/jstimezonedetect/1.0.4/jstz.min.js', array('jquery'), WILOKESUBMISSION_VERSION, true);
		wp_enqueue_script('wiloke-submission-global', WILOKESUBMISSION_PUBLIC_SCRIPTS_URL . 'js/wiloke-submission-frontend-global.js', array('jquery'), WILOKESUBMISSION_VERSION);
	}

	/**
	 * Once user is logged in your website, We will put all
	 *
	 */
	public static function setupUserPlanToCookie($userLogin, $oUser){
		$userPlans = UserModel::getPlansByUserID($oUser->ID);
		$aUserPlans = maybe_serialize($userPlans);
		Cookie::set(wilokeRepository('cookiekeys:userPlanCookie'), $aUserPlans);
	}

	public static function updateUserPlanCookie($oUser){
		Cookie::destroy(wilokeRepository('cookiekeys:userPlanCookie'));
		$userPlans = UserModel::getPlansByUserID($oUser->ID);
		$userPlans = maybe_serialize($userPlans);
		if ( !empty($userPlans) ){
			Cookie::set(wilokeRepository('cookiekeys:userPlanCookie'), $userPlans);
		}
	}

	public static function updateUserPlanCookieByUserID($userID){
		Cookie::destroy(wilokeRepository('cookiekeys:userPlanCookie'));
		$userPlans = UserModel::getPlansByUserID($userID);

		$userPlans = maybe_serialize($userPlans);

		if ( !empty($userPlans) ){
			Cookie::set(wilokeRepository('cookiekeys:userPlanCookie'), $userPlans);
		}
	}

	public static function getUserPlansCookie(){
		return maybe_unserialize(stripslashes(Cookie::get(wilokeRepository('cookiekeys:userPlanCookie'))));
	}
}