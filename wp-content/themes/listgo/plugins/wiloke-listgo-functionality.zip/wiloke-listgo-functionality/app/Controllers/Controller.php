<?php
namespace WilokeListgoFunctionality\Controllers;


use WilokeListgoFunctionality\Framework\Routing\Controller as BaseController;

class Controller extends BaseController{
	public function __construct() {

	}
}