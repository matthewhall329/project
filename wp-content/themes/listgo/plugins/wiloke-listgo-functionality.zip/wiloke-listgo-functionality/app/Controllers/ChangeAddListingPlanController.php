<?php
namespace WilokeListgoFunctionality\Controllers;


use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
use WilokeListgoFunctionality\Framework\Payment\Billable;
use WilokeListgoFunctionality\Framework\Payment\ChangePlanFactory;
use WilokeListgoFunctionality\Framework\Payment\PayPal\ChangePlan;
use WilokeListgoFunctionality\Framework\Payment\SuspendPlanFactory;
use WilokeListgoFunctionality\Model\UserModel;

class ChangeAddListingPlanController extends Controller {
	protected $gateway;
	protected $newPlanID;
	protected $aNewPlanSettings;
	protected $currentPlanID;
	protected $userID;
	protected $aCurrentUserPlanInfo;

	public function __construct() {
		add_action('wp_ajax_wiloke_submission_change_add_listing_plan', array($this, 'changePlan'));
		add_action('wiloke-submissison/changePlan/guard', array($this, 'guard'));
	}

	public function guard(){
		$this->middleware(['role', 'planExists', 'avoidChangeToCurrentPlan', 'avoidDowngradeToFreePlan', 'outStandingBalance'], array(
			'planID'            => $this->newPlanID,
			'aNewPlanSettings'  => $this->aNewPlanSettings,
			'userID'            => $this->userID,
			'aCurrentPlanInfo'  => $this->aCurrentUserPlanInfo
		));
	}

	public function changePlan(){
		$this->newPlanID  = trim($_POST['planID']);
		$this->gateway = trim($_POST['gateway']);

		$this->aNewPlanSettings = GetSettings::getPostMeta($this->newPlanID, get_post_type($this->newPlanID));
		$this->userID  = get_current_user_id();
		$this->getCurrentPlan();

		new Billable(array(
			'gateway' => $this->gateway,
			'planID'  => $this->newPlanID,
			'freeAllowable' => true
		));

		do_action('wiloke-submission/top_level');
		do_action('wiloke-submissison/changePlan/guard');

		// Suspend or cancel the current status
		$instSuspendPlanFactory = new SuspendPlanFactory();
		$aSuspendStatus = $instSuspendPlanFactory->setUserID($this->currentPlanID)->setUserPlanInfo($this->currentPlanID, $this->aCurrentUserPlanInfo)->execute();

		if ( $aSuspendStatus['status'] == 'error'  ){
			wp_send_json_error($aSuspendStatus);
		}

		// Changing to the new plan
		$instChangePlanFactory = new ChangePlanFactory();
		$instChangePlan = $instChangePlanFactory->setPlanID($this->newPlanID)->setUserID($this->userID)->setGateway($this->gateway)->setArgs($_POST)->determineInstance();
		$aStatus = $instChangePlan->execute();

		if ( $aStatus['status'] == 'success' ){
			wp_send_json_success(
				$aStatus
			);
		}else{
			wp_send_json_error($aStatus);
		}
	}

	/**
	 * Get Current Plan.
	 *
	 */
	protected function getCurrentPlan(){
		$aCurrentPlan = UserModel::getPlansByPlanType(get_post_type($this->newPlanID));
		if ( empty($aCurrentPlan) ){
			$this->aCurrentUserPlanInfo = false;
		}else{
			$aPlanID  = array_keys($aCurrentPlan);
			$this->currentPlanID = end($aPlanID);
			$this->aCurrentUserPlanInfo  = $aCurrentPlan[$this->currentPlanID];
		}
	}
}