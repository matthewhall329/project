<?php
namespace WilokeListgoFunctionality\Controllers;


use Carbon\Carbon;
use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
use WilokeListgoFunctionality\Model\DirectBankTransferModel;
use WilokeListgoFunctionality\Model\InvoiceModel;
use WilokeListgoFunctionality\Model\PaymentMetaModel;
use WilokeListgoFunctionality\Model\PaymentModel;
use WilokeListgoFunctionality\Model\PlanRelationshipModel;
use WilokeListgoFunctionality\Model\UserModel;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;

class SessionController extends Controller {
	protected $aInput;

	public function __construct() {
		add_action('wp_ajax_wiloke_submission_update_session', array($this, 'updateSession'));
		add_action('wp_ajax_wiloke_submission_change_order_status', array($this, 'changeOrderStatus'));
		add_action('wp_ajax_wiloke_submission_charge_next_billing_date', array($this, 'chargeNextBillingDate'));
		add_action('wp_ajax_wiloke_submission_change_plan', array($this, 'changePlan'));
	}

	public function changePlan(){
		$this->aInput = $_POST;

		$this->middleware(['UpdateSessionPermission']);
		$this->validate($this->aInput, array(
			'sessionID' => 'required'
		));

		if ($this->aInput['currentPlanID'] == $this->aInput['newPlanID']){
			wp_send_json_error(
				array(
					'msg' => esc_html__('The new plan must be different from the current plan.', 'wiloke')
				)
			);
		}

		$planStatus = get_post_status($this->aInput['newPlanID']);

		if ( $planStatus != 'publish' ){
			wp_send_json_error(
				array(
					'msg' => esc_html__('This plan does not exists.', 'wiloke')
				)
			);
		}

		/*
		 * @hooked PostsManagementController@updatePostsBelongTo
		 */
		do_action('wiloke_submission/after-plan-changed', array(
			'sessionID'     => $this->aInput['sessionID'],
			'currentPlanID' => $this->aInput['currentPlanID'],
			'newPlanID'     => $this->aInput['newPlanID']
		));

		do_action('wiloke_submission/after-plan-changed-'.get_post_type($this->aInput['newPlanID']), array(
			'sessionID'     => $this->aInput['sessionID'],
			'currentPlanID' => $this->aInput['currentPlanID'],
			'newPlanID'     => $this->aInput['newPlanID']
		));

		UserModel::updateUserNewPlanWhereEqualToPlanID($this->aInput['userID'], $this->aInput['currentPlanID'], $this->aInput['newPlanID']);
		PlanRelationshipModel::updateNewPlanWhereEqualToSessionIDAndPlanID($this->aInput['newPlanID'], $this->aInput['sessionID'], $this->aInput['currentPlanID']);

		if ( $this->aInput['gateway'] == 'banktransfer' ){
			DirectBankTransferModel::updateNewPlanInfo($this->aInput['newPlanID'], $this->aInput['sessionID']);
		}

		wp_send_json_success(
			array(
				'msg' => esc_html__('Congratulations! The new plan has been updated successfully.', 'wiloke')
			)
		);
	}

	public function chargeNextBillingDate(){
		$this->middleware(['UpdateSessionPermission']);
		$this->parseValues();
		$this->validate($this->aInput, array(
			'sessionID' => 'required'
		));

		$aPaymentMeta = PaymentMetaModel::get($this->aInput['sessionID'], wilokeRepository('paymentKeys:info'));
		$planStatus = get_post_type($this->aInput['planID']);
		if ( $planStatus == 'publish' ){
			$aPlanSettings  = GetSettings::getPostMeta($this->aInput['planID'], $planStatus);
		}else{
			$aPlanSettings  = $aPaymentMeta['plan']['info'];
		}

		if ( empty($aPaymentMeta['nextBillingDate']) ){
			$createdAt = PaymentModel::getCreatedDate($this->aInput['sessionID']);
			$aPaymentMeta['nextBillingDate'] = strtotime(date(DATE_ATOM, strtotime($createdAt)) . ' + ' . $aPlanSettings['regular_period'] . ' days');
		}else{
			$aPaymentMeta['nextBillingDate'] = strtotime(date(DATE_ATOM, $aPaymentMeta['nextBillingDate']) . ' + ' . $aPlanSettings['regular_period'] . ' days');
		}

		PaymentModel::updateToSucceededStatusWhereEqualToSessionID($this->aInput['sessionID']);
		PaymentMetaModel::update($this->aInput['sessionID'], wilokeRepository('paymentKeys:info'), $aPaymentMeta);
		PaymentMetaModel::set($this->aInput['sessionID'], wilokeRepository('paymentKeys:nextBillingDate'), $aPaymentMeta['nextBillingDate']);
		if ( !UserModel::getUserDetailPlan($this->aInput['userID'], $this->aInput['planID']) ){
			$instUserModel = new UserModel();
			$instUserModel->setUserID($this->aInput['userID'])
			              ->setNextBillingDate($aPaymentMeta['nextBillingDate'])
			              ->setPlanID($this->aInput['planID'])
			              ->setSessionID($this->aInput['sessionID'])
			              ->setGateway($this->aInput['gateway'])
			              ->setBillingType($this->aInput['billingType']);
			if ( isset($this->aInput['addListingMode']) ){
				$instUserModel->setAddListingMode($this->aInput['addListingMode']);
			}
			$instUserModel->setUserPlan();
		}else{
			UserModel::updateUserNextBillingDateWhereEqualToPlanID($this->aInput['userID'], $this->aInput['planID'], $aPaymentMeta['nextBillingDate']);
			UserModel::updateUserRemainingItemsByPlanID($this->aInput['userID'], $this->aInput['planID']);
		}

		/*
		 * @hooked PostsManagementController@updatePostStatusAfterSubscriptionExtended
		 */
		do_action('wiloke_submission/after-subscription-extended', array(
			'sessionID'         => $this->aInput['sessionID'],
			'planID'            => $this->aInput['planID'],
			'nextBillingDate'   => $aPaymentMeta['nextBillingDate']
		));

		do_action('wiloke_submission/after-subscription-extended-'.get_post_type($this->aInput['planID']), array(
			'sessionID'         => $this->aInput['sessionID'],
			'planID'            => $this->aInput['planID'],
			'nextBillingDate'   => $aPaymentMeta['nextBillingDate']
		));

		$this->createNewInvoice();
		wp_send_json_success(
			array(
				'msg' => esc_html__('Congratulations! The subscription has been extended successfully.', 'wiloke')
			)
		);
	}

	public function changeOrderStatus(){
		$this->middleware(['UpdateSessionPermission']);
		$this->aInput = $_POST;
		$this->validate($this->aInput, array(
			'sessionID' => 'required'
		));

		if ($this->aInput['currentStatus'] == $this->aInput['newStatus']){
			wp_send_json_error(
				array(
					'msg' => esc_html__('The new status must be different from the current status', 'wiloke')
				)
			);
		}

		$status = true;
		switch ($this->aInput['newStatus']){
			case 'canceled':
				$status = PaymentModel::updateToCancelledStatusWhereEqualToSessionID($this->aInput['sessionID']);
				break;
			case 'suspended':
				$status = PaymentModel::updateToSuspendedStatusWhereEqualToSessionID($this->aInput['sessionID']);
				break;
			case 'succeeded':
			case 'completed':
				$status = PaymentModel::updateToSucceededStatusWhereEqualToSessionID($this->aInput['sessionID']);
				break;
			case 'failed':
				$status = PaymentModel::updateToFailedStatusWhereEqualToSessionID($this->aInput['sessionID']);
				break;
			case 'processing':
				$status = PaymentModel::updateToProcessingStatusWhereEqualToSessionID($this->aInput['sessionID']);
				break;
			default:
				wp_send_json_error(
					array(
						'msg' => esc_html__('Whoops! It seems this status does not exists.', 'wiloke')
					)
				);
				break;
		}

		if ( !$status ){
			wp_send_json_error(
				array(
					'msg' => esc_html__('We could not update Payment Status.', 'wiloke')
				)
			);
		}

		/*
		 * @hooked PostsManagementController@updatePostsStatusAfterOrderStatusChanged
		 */
		do_action('wiloke_submission/after-orderstatus-changed', array(
			'userID'        => $this->aInput['userID'],
			'sessionID'     => $this->aInput['sessionID'],
			'planID'        => $this->aInput['planID'],
			'newStatus'     => $this->aInput['newStatus'],
			'gateway'       => $this->aInput['gateway'],
			'billingType'   => $this->aInput['billing_type']
		));

		/*
		 * @hooked PostsManagementController@updateListingStatusAfterOrderStatusChanged
		 */
		do_action('wiloke_submission/after-orderstatus-changed-'.get_post_type($this->aInput['planID']), array(
			'userID'        => $this->aInput['userID'],
			'sessionID'     => $this->aInput['sessionID'],
			'planID'        => $this->aInput['planID'],
			'newStatus'     => $this->aInput['newStatus'],
			'gateway'       => $this->aInput['gateway'],
			'billingType'   => $this->aInput['billing_type']
		));

		$this->aInput['order_status'] = $this->aInput['newStatus'];
		$this->updateInvoice();
		wp_send_json_success(
			array(
				'msg' => esc_html__('Congratulations! The order status has been changed successfully.', 'wiloke')
			)
		);
	}

	public function updateSession(){
		$this->middleware(['UpdateSessionPermission']);
		$this->parseValues();
		$this->validate($this->aInput, array(
			'sessionID' => 'required'
		));
		$this->updateInvoice();

		PaymentModel::updateWhereEqualToID(
			array(
				'value' => array(
					'planID'    => $this->aInput['planID'],
					'status'    => $this->aInput['order_status']
				),
				'format' => array(
					'%d',
					'%s'
				)
			),
			$this->aInput['sessionID']
		);

		/*
		 * @hooked PostsManagementController@updatePostsStatus
		 */
		do_action('wiloke_submission/after-changing-session-status', array(
			'sessionID' => $this->aInput['sessionID'],
			'planID'    => $this->aInput['planID'],
			'status'    => $this->aInput['order_status']
		));


		do_action('wiloke_submission/after-changing-session-status-'.get_post_type($this->aInput['planID']), array(
			'sessionID' => $this->aInput['sessionID'],
			'planID'    => $this->aInput['planID'],
			'status'    => $this->aInput['order_status']
		));

		wp_send_json_success(
			array(
				'msg' => esc_html__('Congratulations! The session has been updated successfully', 'wiloke')
			)
		);
	}

	protected function updateInvoice(){
		if ( ($this->aInput['gateway'] == 'banktransfer') && ($this->aInput['billing_type'] == wilokeRepository('app:billingTypes', true)->sub('nonrecurring')) ){
			if ( $this->aInput['order_status'] == wilokeRepository('app:paymentStatus', true)->sub('succeeded') ){
				$aPaymentMeta = PaymentMetaModel::get($this->aInput['sessionID'], wilokeRepository('paymentKeys:info'));
				if ( $invoiceID = InvoiceModel::getIDWhereEqualToSessionID($this->aInput['sessionID']) ){
					InvoiceModel::update($invoiceID, $this->aInput['sessionID'], $aPaymentMeta);
				}else{
					InvoiceModel::insert(array(
						'sessionID'     => $this->aInput['sessionID'],
						'regular_price' => abs($aPaymentMeta['plan']['info']['price']),
						'currency'      => PaymentConfiguration::getCurrency(),
						'message'       => $aPaymentMeta
					));
				}
			}else{
				InvoiceModel::deleteWhereEqualToSession($this->aInput['sessionID']);
			}
		}
	}

	protected function createNewInvoice(){
		if ( ($this->aInput['gateway'] == 'banktransfer') && ($this->aInput['billing_type'] == wilokeRepository('app:billingTypes', true)->sub('recurring')) ){
			$aPaymentMeta = PaymentMetaModel::get($this->aInput['sessionID'], wilokeRepository('paymentKeys:info'));
			InvoiceModel::insert(array(
				'sessionID'         => $this->aInput['sessionID'],
				'regular_price'     => abs($aPaymentMeta['plan']['info']['price']),
				'currency'          => PaymentConfiguration::getCurrency(),
				'message'           => $aPaymentMeta
			));
		}
	}

	protected function parseValues(){
		foreach ($_POST['data'] as $aData){
			$this->aInput[$aData['name']] = $aData['value'];
		}
	}
}