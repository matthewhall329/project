<?php
namespace WilokeListgoFunctionality\Controllers;


use WilokeListgoFunctionality\Framework\Payment\Billable;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use WilokeListgoFunctionality\Framework\Payment\Stripe\StripeGenerateToken;
use WilokeListgoFunctionality\Framework\Payment\Stripe\StripeNonRecurringPaymentMethod;
use WilokeListgoFunctionality\Framework\Payment\Checkout;
use WilokeListgoFunctionality\Framework\Payment\Receipt;
use WilokeListgoFunctionality\Framework\Payment\Stripe\StripeRecurringPaymentMethod;
use WilokeListgoFunctionality\Framework\Payment\Stripe\Webhook;
use WilokeListgoFunctionality\Framework\Store\Session;
use WilokeListgoFunctionality\Model\StripeModel;

class StripeController extends Controller {
	public $nonRecurringPaymentKey = 'NonRecurringPayment';
	public $recurringPaymentKey = 'RecurringPayment';
	public $gateway = 'stripe';

	public function __construct() {
		add_action('wp_ajax_wiloke_submission_pay_with_stripe', array($this, 'preparePayment'));
		add_action('wiloke_submission/purchase-event-plan-with-stripe', array($this, 'buyEventPlan'));
		add_action('init', array($this, 'listenEvents'));
	}

	public function listenEvents(){
		if ( !isset($_REQUEST['wiloke-submission-listen']) || ($_REQUEST['wiloke-submission-listen'] != $this->gateway) ){
			return false;
		}

		new Webhook();
	}

	public function preparePayment($aData=array()){
		// Authentication
		new Billable(array(
			'gateway' => $this->gateway,
			'planID'  => Session::getSession(wilokeRepository('sessionkeys:storePlanID'))
		));

		$aData = empty($aData) ? $_POST['aData'] : $aData;
		$aData['planID'] = Session::getSession(wilokeRepository('sessionkeys:storePlanID'));

		$instReceipt = new Receipt($aData);
		if ( PaymentConfiguration::isNonRecurringPayment() ){
			$instPaymentMethod = new StripeNonRecurringPaymentMethod();
		}else{
			$instPaymentMethod = new StripeRecurringPaymentMethod();
		}
		if ( !isset($_POST['redirectTo']) ){
			$instPaymentMethod->thankyouUrl = PaymentConfiguration::thankyouUrl();
		}

		$oCheckout = new Checkout();
		$aPaymentStatus = $oCheckout->begin($instReceipt, $instPaymentMethod);
		
		if ( $aPaymentStatus['status'] == 'success' ){
			$aPaymentStatus['redirectTo'] = $instPaymentMethod->thankyouUrl;
			wp_send_json_success($aPaymentStatus);
		}else{
			wp_send_json_error($aPaymentStatus);
		}
	}

	public function buyEventPlan($aData=array()){
		$aData = empty($aData) ? $_POST['aData'] : $aData;

		// Authentication
		new Billable(array(
			'gateway' => $this->gateway,
			'planID'  => Session::getSession(wilokeRepository('sessionkeys:storePlanID'))
		));

		$aData['planID'] = Session::getSession(wilokeRepository('sessionkeys:storePlanID'));
		$instReceipt = new Receipt($aData);

		$customerID = StripeModel::getCustomerID(get_current_user_id());
		
		$oStripeMethod = new StripeNonRecurringPaymentMethod();
		$oStripeMethod->thankyouUrl = $aData['redirectTo'];

		if ( empty($customerID) ){
			$aPaymentStatus = $oStripeMethod->proceedWithSingleToken($instReceipt);
		}else{
			$aPaymentStatus = $oStripeMethod->proceedPayment($instReceipt);
		}

		if ( $aPaymentStatus['status'] == 'success' ){
			$aPaymentStatus['redirectTo'] = $oStripeMethod->thankyouUrl;
			wp_send_json_success($aPaymentStatus);
		}else{
			wp_send_json_error($aPaymentStatus);
		}
	}
}