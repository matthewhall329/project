<?php
namespace WilokeListgoFunctionality\Controllers;

use WilokeListgoFunctionality\Framework\Payment\Billable;
use WilokeListgoFunctionality\Framework\Payment\Checkout;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use WilokeListgoFunctionality\Framework\Payment\PayPal\PayPalChangePlan;
use WilokeListgoFunctionality\Framework\Payment\PayPal\PayPalRecurringPaymentMethod;
use WilokeListgoFunctionality\Framework\Payment\PayPal\PaypalUpdateBillingAgreement;
use WilokeListgoFunctionality\Framework\Payment\PayPal\Webhook;
use WilokeListgoFunctionality\Framework\Payment\Receipt;
use WilokeListgoFunctionality\Framework\Payment\PayPal\PayPalNonRecurringPaymentMethod;
use WilokeListgoFunctionality\Framework\Payment\PayPal\PayPalExecuteNonRecurringPayment;
use WilokeListgoFunctionality\Framework\Payment\PayPal\PayPalExecuteRecurringPayment;
use WilokeListgoFunctionality\Framework\Store\Session;

class PayPalController extends Controller {
	public $nonRecurringPaymentKey = 'NonRecurringPayment';
	public $recurringPaymentKey = 'RecurringPayment';
	public $gateway = 'paypal';

	public function __construct() {
		add_action('init', array($this, 'listenEvents'));
		add_action('wp_ajax_wiloke_submission_pay_with_paypal', array($this, 'preparePayment'));
		add_action('wp_ajax_nopriv_wiloke_submission_pay_with_paypal', array($this, 'preparePayment'));
		add_action('init', array($this, 'paymentExecution'), 1);
//		add_action('wp_ajax_wiloke_buy_event_plan_with_paypal', array($this, 'buyEventPlan'));
		add_action('wiloke_submission/purchase-event-plan-with-paypal', array($this, 'buyEventPlan'));
	}

	public function listenEvents(){
		if ( !isset($_REQUEST['wiloke-submission-listen']) || ($_REQUEST['wiloke-submission-listen'] != $this->gateway) ){
			return false;
		}

		new Webhook();
	}

	public function updatePayPal(){
		$instPayPal = new PaypalUpdateBillingAgreement();
		$instPayPal->test($_POST['agreementID']);
	}

	public function paymentExecution(){
		if ( !isset($_REQUEST['billingType']) ){
			return false;
		}

		new Billable(
			array(
				'gateway' => $this->gateway,
				'planID'  => $_REQUEST['planID'],
				'isIgnoreValidatePrice'=>true
			)
		);

		if ( trim(strtolower($_GET['billingType'])) == strtolower(wilokeRepository('app:billingTypes', true)->sub('recurring')) ){
			$this->withRecurringPayment();
		}else{
			$this->withNonRecurringPayment();
		}
	}

	public function withNonRecurringPayment(){
		$oPayPalMethod = new PayPalExecuteNonRecurringPayment();
		$oPayPalMethod->executePayment();
	}

	public function withRecurringPayment(){
		$oPayPalMethod = new PayPalExecuteRecurringPayment();
		$oPayPalMethod->executePayment();
	}

	public function preparePayment($aData=array()){
		// Authentication
		new Billable(array(
			'gateway' => $this->gateway,
			'planID'  => Session::getSession(wilokeRepository('sessionkeys:storePlanID'))
		));
		$aData = empty($aData) ? $_POST : $aData;
		$aData['planID'] = Session::getSession(wilokeRepository('sessionkeys:storePlanID'));

		$oReceipt = new Receipt($aData);
		if ( PaymentConfiguration::isNonRecurringPayment() ){
			$oPayPalMethod = new PayPalNonRecurringPaymentMethod();
		}else{
			$oPayPalMethod = new PayPalRecurringPaymentMethod();
		}

		$oCheckout = new Checkout();
		$aCheckAcceptPaymentStatus = $oCheckout->begin($oReceipt, $oPayPalMethod);

		if ( $aCheckAcceptPaymentStatus['status'] == 'success' ){
			wp_send_json_success($aCheckAcceptPaymentStatus);
		}else{
			wp_send_json_error($aCheckAcceptPaymentStatus);
		}
	}

	public function buyEventPlan(){
		// Authentication
		new Billable(array(
			'gateway' => $this->gateway,
			'planID'  => $_POST['eventPlanID']
		));

		$aData = $_POST['aData'];
		$aData['planID'] = $_POST['eventPlanID'];

		$instReceipt = new Receipt($aData);

		$oPayPalMethod = new PayPalNonRecurringPaymentMethod();
		$oCheckout = new Checkout();
		$aPaymentStatus = $oCheckout->begin($instReceipt, $oPayPalMethod);

		if ( $aPaymentStatus['status'] == 'success' ){
			wp_send_json_success($aPaymentStatus);
		}else{
			wp_send_json_error($aPaymentStatus);
		}
	}
}