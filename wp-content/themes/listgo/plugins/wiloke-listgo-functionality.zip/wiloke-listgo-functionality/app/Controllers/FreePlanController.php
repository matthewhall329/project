<?php
namespace WilokeListgoFunctionality\Controllers;


use WilokeListgoFunctionality\Framework\Payment\DirectBankTransfer\Configuration;
use WilokeListgoFunctionality\Framework\Payment\DirectBankTransfer\Token;
use WilokeListgoFunctionality\Framework\Payment\FreePlan\FreePlan;
use WilokeListgoFunctionality\Framework\Payment\Receipt;
use WilokeListgoFunctionality\Framework\Store\Session;


class FreePlanController extends Controller {
	use Configuration;

	public $nonRecurringPaymentKey = 'NonRecurringPayment';

	public function __construct() {
		add_action('wiloke-submission/setup-free-plan', array($this, 'setupFreePlan'));
	}

	public function setupFreePlan($aData){
		if ( !Session::getSession(wilokeRepository('sessionkeys:startFreePlan'), true) ){
			wp_send_json_error(array(
				'msg' => esc_html__('You do not have permission to access this page', 'wiloke')
			));
		}

		// if ( isset($aData['aUserPlan']['sessionID']) && !empty($aData['aUserPlan']['sessionID']) ){
		// 	Session::destroySession(wilokeRepository('sessionkeys:storePlanID'));
		// 	wp_send_json_success(array(
		// 		'redirectTo' => urlencode($aData['thankyouUrl'])
		// 	));
		// }

		$aData['planID'] = Session::getSession(wilokeRepository('sessionkeys:storePlanID'));

		if ( empty($aData['planID']) ){
			wp_send_json_error(
				array(
					'msg' => esc_html__('Unauthentication', 'wiloke')
				)
			);
		}

		$aData['token'] = Token::generateToken();
		$instReceipt    = new Receipt($aData);
		$oPaymentMethod = new FreePlan();
		$oPaymentMethod->setupFreePlan($instReceipt);

		wp_send_json_success(array(
			'redirectTo' => urlencode($instReceipt->thankyouUrl)
		));
	}
}