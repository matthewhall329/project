<?php
namespace WilokeListgoFunctionality\Controllers;


use WilokeListgoFunctionality\Framework\Payment\Billable;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use WilokeListgoFunctionality\Framework\Payment\Checkout;
use WilokeListgoFunctionality\Framework\Payment\Receipt;
use WilokeListgoFunctionality\Framework\Payment\Twocheckout\TwocheckoutNonRecurringPamentMethod;
use WilokeListgoFunctionality\Framework\Payment\Twocheckout\TwocheckoutRecurringPaymentMethod;
use WilokeListgoFunctionality\Framework\Payment\Twocheckout\Webhook;
use WilokeListgoFunctionality\Framework\Store\Session;
use WilokeListgoFunctionality\Model\UserModel;

class TwocheckoutController extends Controller {
	public $nonRecurringPaymentKey = 'NonRecurringPayment';
	public $recurringPaymentKey = 'RecurringPayment';
	public $gateway = '2checkout';
	protected $aCardInfo;

	public function __construct() {
		add_action('init', array($this, 'listenEvents'));
		add_action('wp_ajax_wiloke_submission_pay_with_2checkout', array($this, 'preparePayment'));
		add_action('wiloke_submission/purchase-event-plan-with-2checkout', array($this, 'buyEventPlan'));
	}

	/*
	 * Listening events from 2checkout server
	 */
	public function listenEvents(){
		if ( !isset($_REQUEST['wiloke-submission-listener']) || (strtolower($_REQUEST['wiloke-submission-listener']) !== $this->gateway) ){
			return false;
		}

		if ( !isset($_POST['message_type']) || empty($_POST['message_type']) ) {
			return false;
		}
		new Webhook($_POST);
	}

	public function getCardInfo(){
		if ( empty($this->aCardInfo) ){
			return false;
		}

		$aParseInfo = array();

		foreach ( $this->aCardInfo as $aData ){
			$aParseInfo[$aData['name']] = trim(sanitize_text_field($aData['value']));
		}

		UserModel::saveCardInfo($aParseInfo);
	}

	public function preparePayment($aData=array()){
		// Authentication
		new Billable(array(
			'gateway' => $this->gateway,
			'planID'  => Session::getSession(wilokeRepository('sessionkeys:storePlanID'))
		));

		$aData = empty($aData) ? $_POST : $aData;
		$aData['planID'] = Session::getSession(wilokeRepository('sessionkeys:storePlanID'));
		$instReceipt = new Receipt($aData);

		// Card Information
		$this->aCardInfo = $_POST['formData'];
		$this->getCardInfo();

		if ( PaymentConfiguration::isNonRecurringPayment() ){
			$instPaymentMethod = new TwocheckoutNonRecurringPamentMethod();
		}else{
			$instPaymentMethod = new TwocheckoutRecurringPaymentMethod();
		}

		if ( !isset($_POST['redirectTo']) ){
			$instPaymentMethod->thankyouUrl = PaymentConfiguration::thankyouUrl();
		}

		$oCheckout = new Checkout();
		$aPaymentStatus = $oCheckout->begin($instReceipt, $instPaymentMethod);

		if ( $aPaymentStatus['status'] == 'success' ){
			$aPaymentStatus['redirectTo'] = $instPaymentMethod->thankyouUrl;
			wp_send_json_success($aPaymentStatus);
		}else{
			wp_send_json_error($aPaymentStatus);
		}
	}

	public function buyEventPlan($aData){
		// Authentication
		new Billable(array(
			'gateway' => $this->gateway,
			'planID'  => Session::getSession(wilokeRepository('sessionkeys:storePlanID'))
		));

		$instReceipt = new Receipt($aData);
		$aData['planID'] = Session::getSession(wilokeRepository('sessionkeys:storePlanID'));
		// Card Information

		$instPaymentMethod = new TwocheckoutNonRecurringPamentMethod();

		$instPaymentMethod->thankyouUrl = $aData['redirectTo'];

		$oCheckout = new Checkout();
		$aPaymentStatus = $oCheckout->begin($instReceipt, $instPaymentMethod);

		if ( $aPaymentStatus['status'] == 'success' ){
			$aPaymentStatus['redirectTo'] = $instPaymentMethod->thankyouUrl;
			wp_send_json_success($aPaymentStatus);
		}else{
			wp_send_json_error($aPaymentStatus);
		}
	}
}