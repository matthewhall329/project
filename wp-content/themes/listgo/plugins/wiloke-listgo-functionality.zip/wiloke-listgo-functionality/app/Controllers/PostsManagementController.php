<?php
namespace WilokeListgoFunctionality\Controllers;


use Stripe\Plan;
use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
use WilokeListgoFunctionality\Framework\Helpers\SetSettings;
use WilokeListgoFunctionality\Framework\Helpers\Time;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use WilokeListgoFunctionality\Model\EventModel;
use WilokeListgoFunctionality\Model\PaymentMetaModel;
use WilokeListgoFunctionality\Model\PaymentModel;
use WilokeListgoFunctionality\Model\PlanRelationshipModel;
use WilokeListgoFunctionality\Model\PostsModel;

class PostsManagementController extends Controller {
	public $postType = 'pricing';

	public function __construct() {
		add_action('wiloke_submission/after-changing-session-status', array($this, 'updatePostsStatus'));
		add_action('wiloke_submission/after-subscription-extended', array($this, 'updatePostStatusAfterSubscriptionExtended'));
		add_action('wiloke_submission/after-plan-changed', array($this, 'updatePostsBelongTo'));
		add_action('wiloke_submission/after-orderstatus-changed-pricing', array($this, 'updateListingStatusAfterOrderStatusChanged'));
		add_action('wiloke_submission/after-orderstatus-changed-event-pricing', array($this, 'updateEventStatusAfterOrderStatusChanged'));
		add_action('wiloke_submission/after-paid-recurring-payment', array($this, 'updatePostStatusAfterRecurringPaymentPaid'));
		add_action('wiloke_submission/migrate-posts-to-expired-status', array($this, 'moveAllPostsBelongToSessionIDToExpiredStatus'));
		add_filter('cron_schedules', array($this, 'registerCronShedules'));
		add_action('wiloke-submission/wiloke_check_posts_status', array($this, 'robotCheckNonRecurringPostsStatus'));
		add_action('wiloke-submission/wiloke_check_posts_status', array($this, 'robotCheckRecurringPostsStatus'));
		add_action('wiloke-submission/wiloke_check_posts_status', array($this, 'robotRemoveEventDraft'));
		
		add_action('wiloke-submission/wiloke_check_posts_status', array($this, 'robotMigrateExpiredEvents'));
		// add_action('wiloke-submission/wiloke_check_posts_status', array($this, 'robotMigrateExpiredEvents'));

		$this->registerCheckPostsStatusEvent();
	}

	protected function isListingPostType($postID){
		if ( get_post_type($postID) !== 'listing' ){
			return false;
		}

		return true;
	}

	public function robotMigrateExpiredEvents(){
		$aExpiredEvents = EventModel::getExpiredEvents();
		if ( empty($aExpiredEvents) ){
			return false;
		}

		foreach ($aExpiredEvents as $eventID){
			wp_update_post(
				array(
					'ID' => $eventID,
					'post_status' => 'draft'
				)
			);
		}

		do_action('wiloke-submission/mail', array(
			'type'      => wilokeRepository('mailstatus:type', true)->sub('expiredEvents'),
			'target'    => $aExpiredEvents
		));
	}

	public function robotRemoveEventDraft(){
		$aRawEvents = EventModel::getDraftEvents();
		if ( empty($aRawEvents) ){
			return $aRawEvents;
		}

		$aEvents = array();
		foreach ( $aRawEvents as $aEvent ){
			wp_delete_post($aEvent['ID']);
			$aEvents[] = $aEvent['ID'];
		}

		do_action('wiloke-submission/mail', array(
			'type'      => wilokeRepository('mailstatus:type', true)->sub('deletedEvents'),
			'target'    => $aEvents
		));
	}

	public function registerCronShedules($aShecules){
		$aShecules['wiloke_for_times_per_day'] = array(
			'interval' => 21600,
			'display'  => esc_html__('For Times Per Day', 'wiloke')
		);

		return $aShecules;
	}

	public static function unregisterCheckPostsStatusEvent(){
		wp_clear_scheduled_hook('wiloke-submission/wiloke_check_posts_status');
	}

	public static function registerCheckPostsStatusEvent(){
		if ( !wp_next_scheduled ( 'wiloke-submission/wiloke_check_posts_status' ) ) {
			wp_schedule_event(time(), 'wiloke_for_times_per_day', 'wiloke-submission/wiloke_check_posts_status');
		}
	}

	public function robotCheckNonRecurringPostsStatus(){
		$oPosts = PlanRelationshipModel::getNonRecurringPublishPosts();

		if ( empty($oPosts) ){
			return false;
		}

		$aExpiryPosts   = array();
		$aPlanSettings  = array();
		$now = Time::timestampUTCNow();

		foreach ($oPosts as $oPost){
			if ( get_post_type($oPost->planID) != $this->postType ){
				continue;
			}

			if ( $oPost->status != wilokeRepository('app:paymentStatus', true)->sub('succeeded') ){
				$aExpiryPosts[] = $oPost->objectID;
			}else{
				if ( !isset($aPlanSettings[$oPost->planID]) ){
					$aPlanSettings[$oPost->planID] = GetSettings::getPostMeta($oPost->planID, get_post_type($oPost->planID));
				}

				if ( empty($aPlanSettings[$oPost->planID]['duration']) ){
					continue;
				}

				$duration = '+' . abs($aPlanSettings[$oPost->planID]['duration']) . ' days';
				$endedAt = strtotime($duration, strtotime($oPost->created_at_gmt));
				
				if ( $now > $endedAt ){
					$aExpiryPosts[] = $oPost->objectID;
				}
			}
		}
		
		if ( !empty($aExpiryPosts) ){
			PostsModel::updatePostsStatus($aExpiryPosts, 'expired');

			do_action('wiloke-submission/mail', array(
				'type'      => wilokeRepository('mailstatus:type', true)->sub('postExpired'),
				'target'    => $aExpiryPosts
			));
		}
	}

	public function robotCheckRecurringPostsStatus(){
		$aSessions = PaymentModel::getAllActivationsAccountInfo();

		if ( empty($aSessions) ){
			return false;
		}

		$now = Time::timestampUTCNow();
		$aSessionExpired = array();
		foreach ($aSessions as $oSession){
			$nextBillingDate = PaymentMetaModel::get($oSession->ID, wilokeRepository('paymentKeys:nextBillingDate'));
			if ( $nextBillingDate <= $now ){
				PaymentModel::updateToCancelledStatusWhereEqualToSessionID($oSession->ID);
				$this->moveAllPostsBelongToSessionIDToExpiredStatus($oSession->ID);
				$aSessionExpired[] = $oSession->ID;
			}
		}

		if ( !empty($aSessionExpired) ){
			do_action('wiloke-submission/mail', array(
				'type'      => wilokeRepository('mailstatus:type', true)->sub('sessionExpired'),
				'target'    => $aSessionExpired
			));
		}
	}

	/**
	 * After the sale/subscription status has been changed, We need to update listing belongs to
	 *
	 * @param array $aInfo
	 * @return bool
	 */
	public function updateEventStatusAfterOrderStatusChanged($aInfo){
		$aPostIDs = PlanRelationshipModel::getObjectIDWhereEqualToSessionIDAndPlanID($aInfo['sessionID'], $aInfo['planID']);
		if ( empty($aPostIDs) ){
			return false;
		}

		foreach ( $aPostIDs as $aPost ){
			switch ($aInfo['newStatus']){
				case 'canceled':
				case 'suspended':
				case 'processing':
				case 'failed':
				case 'refunded':
					wp_update_post(
						array(
							'ID' => $aPost['objectID'],
							'post_status' => 'draft'
						)
					);
					break;
				case 'succeeded':
				case 'completed':
					wp_update_post(
						array(
							'ID'          => $aPost['objectID'],
							'post_status' => 'publish'
						)
					);
					break;
			}
		}
	}

	public function updateListingStatusAfterOrderStatusChanged($aInfo){
		$aPostIDs = PlanRelationshipModel::getObjectIDWhereEqualToSessionIDAndPlanID($aInfo['sessionID'], $aInfo['planID']);

		if ( empty($aPostIDs) ){
			return false;
		}

		$aWilokeSubmissionSettings = PaymentConfiguration::get();

		foreach ( $aPostIDs as $aPost ){
			switch ($aInfo['newStatus']){
				case 'canceled':
					wp_update_post(
						array(
							'ID' => $aPost['objectID'],
							'post_status' => 'processing'
						)
					);
					break;
				case 'suspended':
					wp_update_post(
						array(
							'ID' => $aPost['objectID'],
							'post_status' => 'processing'
						)
					);
					break;
				case 'succeeded':
				case 'completed':
					$postStatus = get_post_status($aPost['objectID']);

					if ( ($aWilokeSubmissionSettings['approved_method'] != 'manual_review') ){
						if ( $postStatus == 'processing' || $postStatus == 'expired' ){
							wp_update_post(
								array(
									'ID'          => $aPost['objectID'],
									'post_status' => 'publish'
								)
							);
						}
					}else{
						if ( $postStatus == 'processing' || $postStatus == 'expired' ){
							wp_update_post(
								array(
									'ID'          => $aPost['objectID'],
									'post_status' => 'pending'
								)
							);
						}elseif($postStatus == 'expired'){
							wp_update_post(
								array(
									'ID'          => $aPost['objectID'],
									'post_status' => 'renew'
								)
							);
						}
					}
					break;
				case 'processing':
					wp_update_post(
						array(
							'ID' => $aPost['objectID'],
							'post_status' => 'processing'
						)
					);
					break;
			}
		}
	}

	/**
	 * After the plan has been changed, We need to update listing belongs to
	 *
	 * @param array $aInfo
	 * @return bool
	 */
	public function updatePostsBelongTo($aInfo){
		$aPostIDs = PlanRelationshipModel::getObjectIDWhereEqualToSessionIDAndPlanID($aInfo['sessionID'], $aInfo['currentPlanID']);
		if ( empty($aPostIDs) ){
			return false;
		}

		foreach ( $aPostIDs as $aPost ){
			SetSettings::setPostMeta($aPost['objectID'], wilokeRepository('app:belongsToPlanID'), $aInfo['newPlanID']);
		}
	}

	/**
	 * After the subscription has been extended, We should renew all the expiry listings and change all processing status to pending status
	 *
	 * @param array $aInfo
	 * @return bool
	 */
	public function updatePostStatusAfterSubscriptionExtended($aInfo){
		$aPostIDs = PlanRelationshipModel::getObjectIDsCreatedBefore($aInfo['sessionID'], $aInfo['nextBillingDate']);

		if ( empty($aPostIDs) ){
			return false;
		}

		foreach ( $aPostIDs as $aPost ){
			$postStatus = get_post_status($aPost['objectID']);
			SetSettings::setPostMeta($aPost['objectID'], wilokeRepository('app:belongsToPlanID'), $aInfo['planID']);
			if ( $postStatus == 'expired' ){
				wp_update_post(
					array(
						'ID'            => $aPost['objectID'],
						'post_status'   => 'publish'
					)
				);
			}else if ( $postStatus == 'processing' ){
				wp_update_post(
					array(
						'ID'            => $aPost['objectID'],
						'post_status'   => PaymentConfiguration::newPostStatus()
					)
				);
			}
		}
	}

	/**
	 * After the customer transferred the funds, All posts that belongs to this plan will be automatically updated
	 *
	 * @param array $aInfo
	 * @return bool
	 */
	public function updatePostsStatus($aInfo){
		$aPostIDs = PlanRelationshipModel::getObjectIDWhereEqualToSessionIDAndPlanID($aInfo['sessionID'], $aInfo['planID']);
		if ( empty($aPostIDs) ){
			return false;
		}

		if ( $aInfo['status'] == wilokeRepository('app:paymentStatus', true)->sub('succeeded') ){
			$newPostStatus = PaymentConfiguration::newPostStatus();
		}elseif($aInfo['status'] == wilokeRepository('app:paymentStatus', true)->sub('failed') || $aInfo['status'] == wilokeRepository('app:paymentStatus', true)->sub('canceled')){
			$newPostStatus = 'processing';
		}else{
			return false;
		}

		foreach ($aPostIDs as $aPost){
			if( get_post_type($aPost['objectID']) == 'event' ){
				wp_update_post(
					array(
						'ID'            => $aPost['objectID'],
						'post_status'   => 'publish'
					)
				);
			}else{
				$currentPostType = get_post_status($aPost['objectID']);
				if ( $currentPostType == 'expired' || $currentPostType == 'processing' || $currentPostType == 'pending' ){
					wp_update_post(
						array(
							'ID'            => $aPost['objectID'],
							'post_status'   => $newPostStatus
						)
					);
				}
			}
		}

		return true;
	}

	/**
	 * Move all posts to expired status
	 *
	 * @param number $sessionID
	 * @return bool
	 */
	public function moveAllPostsBelongToSessionIDToExpiredStatus($sessionID){
		$aRawPosts = PlanRelationshipModel::getObjectIDsWhereEqualToSessionID($sessionID);
		if ( empty($aRawPosts) ){
			return false;
		}

		$aPosts = array();

		foreach ($aRawPosts as $aPost){
			$aPosts[] = absint($aPost['objectID']);
		}

		PostsModel::updatePostsStatus($aPosts, 'expired');
	}
}