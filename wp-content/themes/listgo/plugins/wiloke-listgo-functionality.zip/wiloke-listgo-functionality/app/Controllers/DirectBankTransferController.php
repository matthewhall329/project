<?php
namespace WilokeListgoFunctionality\Controllers;


use WilokeListgoFunctionality\Framework\Helpers\GenerateUrl;
use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
use WilokeListgoFunctionality\Framework\Helpers\Render;
use WilokeListgoFunctionality\Framework\Payment\Billable;
use WilokeListgoFunctionality\Framework\Payment\DirectBankTransfer\Configuration;
use WilokeListgoFunctionality\Framework\Payment\DirectBankTransfer\NonRecurringPaymentMethod;
use WilokeListgoFunctionality\Framework\Payment\DirectBankTransfer\RecurringPaymentMethod;
use WilokeListgoFunctionality\Framework\Payment\DirectBankTransfer\Token;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use WilokeListgoFunctionality\Framework\Payment\Checkout;
use WilokeListgoFunctionality\Framework\Payment\Receipt;
use WilokeListgoFunctionality\Framework\Store\Session;
use WilokeListgoFunctionality\Helpers\View;
use WilokeListgoFunctionality\Model\PaymentMetaModel;
use WilokeListgoFunctionality\Model\PaymentModel;
use WilokeListgoFunctionality\Model\UserModel;

class DirectBankTransferController extends Controller {
	use Configuration;

	public $nonRecurringPaymentKey = 'NonRecurringPayment';
	public $recurringPaymentKey = 'RecurringPayment';

	public function __construct() {
		add_action('wp_ajax_wiloke_submission_pay_with_banktransfer', array($this, 'preparePayment'));
		add_action('wiloke_submission/purchase-event-plan-with-banktransfer', array($this, 'buyEventPlan'));
		add_action('wp_enqueue_scripts', array($this, 'enqueueScripts'));
		add_action('wiloke_submission/payment-thankyou/afterdirectbanktranfer', array($this, 'showInvoices'));
//		add_action('wiloke_submission/after-orderstatus-changed-pricing', array($this, 'updateNextBillingDate'));
	}

	public function updateNextBillingDate($aInfo){
		if ( $aInfo['gateway'] !== 'banktransfer' || $aInfo['newStatus'] !== 'succeeded' || $aInfo['billingType'] !== wilokeRepository('app:billingTypes', true)->sub('recurring')  ){
			return false;
		}

		$aPaymentInfo = PaymentMetaModel::get($aInfo['sessionID'], wilokeRepository('paymentKeys:info'));
		if ( !empty($aPaymentInfo) ){
			$duration = abs($aPaymentInfo['plan']['info']['regular_period']);
		}else{
			$aPlanSettings = GetSettings::getPostMeta($aInfo['planID'], get_post_type($aInfo['planID']));
			$duration = $aPlanSettings['regular_period'];
		}

		$duration = empty($duration) ? 1000000000000000000000000000000 : abs($duration);
		$nextBillingDate = PaymentMetaModel::get($aInfo['sessionID'], wilokeRepository('paymentKeys:nextBillingDate'));

		$instUserModel = new UserModel();
		$instUserModel->setUserID($aInfo['userID'])
		              ->setNextBillingDate($duration+$nextBillingDate)
		              ->setPlanID($aInfo['planID'])
		              ->setSessionID($aInfo['sessionID'])
		              ->setGateway($this->gateway)
		              ->setBillingType(wilokeRepository('app:billingTypes', true)->sub('recurring'))
		              ->setUserPlan();
	}

	public function enqueueScripts(){
		wp_enqueue_script('wiloke-submission-directbanktransfer', WILOKE_LISTGO_FUNC_URL . 'public/source/js/directbanktransfer.js', array('jquery'), WILOKE_LISTGO_FC_VERSION, true);
	}

	public function preparePayment(){
		// Authentication
		$aData = $_POST;
		$aData['planID'] = Session::getSession(wilokeRepository('sessionkeys:storePlanID'));

		if ( empty($aData['planID']) ){
			wp_send_json_error(
				array(
					'msg' => esc_html__('Unauthentication', 'wiloke')
				)
			);
		}

		$aData['token'] = Token::generateToken();
		$instReceipt = new Receipt($aData);

		new Billable(array(
			'gateway' => $this->gateway,
			'planID'  => $instReceipt->planID
		));

		$aLatestSessionInfo = PaymentModel::getUserLatestSessionInfoWhereEqualToPlanID($aData['planID'], get_current_user_id());

		if ( !empty($aLatestSessionInfo) && ($aLatestSessionInfo['gateway'] == $this->gateway) ){
			$this->middleware(['validateBankTransferStatus'], array(
				'aUserPlan' => array(
					'sessionID' => $aLatestSessionInfo['ID'],
					'gateway'   => $this->gateway
				)
			));
		}

		if ( PaymentConfiguration::isNonRecurringPayment() ){
			$oPaymentMethod = new NonRecurringPaymentMethod();
		}else{
			$oPaymentMethod = new RecurringPaymentMethod();
		}

		$oCheckout = new Checkout();
		$aPaymentStatus = $oCheckout->begin($instReceipt, $oPaymentMethod);

		if ( $aPaymentStatus['status'] == 'success' ){
			// This is very important to detect remaining items
			wp_send_json_success(array(
				'redirectTo' => $this->redirectTo($aPaymentStatus['sessionID'], $instReceipt->planID)
			));
		}else{
			wp_send_json_error($aPaymentStatus);
		}
	}

	public function buyEventPlan($aData){
		$aData['planID'] = Session::getSession(wilokeRepository('sessionkeys:storePlanID'));

		if ( empty($aData['planID']) ){
			wp_send_json_error(
				array(
					'msg' => esc_html__('Unauthentication', 'wiloke')
				)
			);
		}

		$aData['token'] = Token::generateToken();
		$instReceipt = new Receipt($aData);

		new Billable(array(
			'gateway' => $this->gateway,
			'planID'  => $instReceipt->planID
		));

		$oPaymentMethod = new NonRecurringPaymentMethod();
		$oCheckout = new Checkout();
		$aPaymentStatus = $oCheckout->begin($instReceipt, $oPaymentMethod);

		if ( $aPaymentStatus['status'] == 'success' ){
			wp_send_json_success(array(
				'redirectTo' => urlencode($this->redirectTo($aPaymentStatus['sessionID'], $instReceipt->planID))
			));
		}else{
			wp_send_json_error($aPaymentStatus);
		}
	}

	public function redirectTo($sessionID, $planID){
		$aWilokeSubmissionSettings = PaymentConfiguration::get();
		$thankyouUrl = get_permalink($aWilokeSubmissionSettings['thankyou']);
		$thankyouUrl = GenerateUrl::url($thankyouUrl, array(
			'sessionID' => $sessionID,
			'planID'    => $planID,
			'gateway'   => $this->gateway
		));

		return$thankyouUrl;
	}

	public function showInvoices(){
		$this->setApiContext();

		$sessionID          = $_REQUEST['sessionID'];
		$planName           = get_the_title($_REQUEST['planID']);
		if ( !isset($_REQUEST['price']) ){
			$aPlanSettings      = GetSettings::getPostMeta($_REQUEST['planID'], get_post_type($_REQUEST['planID']));
			$price              = Render::price($aPlanSettings['price'], true);
		}else{
			$price = $_REQUEST['price'];
		}

		$aBankDetails       = $this->aBankDetails;

		View::inc('thankyou@banktransfer-invoice', array(
			'sessionID'     => $sessionID,
			'planName'      => $planName,
			'price'         => $price,
			'aBankDetails'  => $aBankDetails
		));
	}
}