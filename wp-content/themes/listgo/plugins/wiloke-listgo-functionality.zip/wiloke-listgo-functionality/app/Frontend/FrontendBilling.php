<?php
namespace WilokeListgoFunctionality\Frontend;

use WilokeListgoFunctionality\AlterTable\AlterTableInvoices;
use WilokeListgoFunctionality\AlterTable\AlterTableSessions;
use WilokeListgoFunctionality\Framework\Helpers\Render;

class FrontendBilling{
	public static $postPerPages = 20;
	public static $aInvoices;

	public function __construct() {
	    add_action('wp_ajax_wiloke_submission_download_invoice', array($this, 'downloadInvoice'));
	}

	public function exportFile($aInvoice){
		$now = gmdate("D, d M Y H:i:s");
		header("Expires: Tue, 03 Jul 2001 06:00:00 GMT");
		header("Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate");
		header("Last-Modified: {$now} GMT");

		// force download
		header("Content-Type: application/force-download");
		header("Content-Type: application/octet-stream");
		header("Content-Type: application/download");

		// disposition / encoding on response body
		header("Content-Disposition: attachment;filename=invoice-".date('Y-m-D') . '.csv');
		header("Content-Transfer-Encoding: binary");
		$csv_header = '';
		$csv_header .= 'Invoice Number, Session Number, Plan Name, Regular Price, Discount, Total, Currency, Billed At' . "\n";
		$csv_row ='';
		$csv_row .= $aInvoice['ID'] . ', ' . $aInvoice['sessionID'] . ',' . get_the_title($aInvoice['planID']) . ', ' . $aInvoice['regular_price'] . ', ' . $aInvoice['discount'] . ', ' . ($aInvoice['regular_price'] - $aInvoice['discount']) . ', ' . $aInvoice['currency'] . ', ' . $aInvoice['created_at']  . "\n";
		echo $csv_header . $csv_row;
		die();
	}

	public function downloadInvoice(){
	    if ( !is_user_logged_in() ){
	        wp_die( esc_html__('You do not have permission to access this page.', 'wiloke') );
        }

        global $wpdb;

		$invoicesTbl = $wpdb->prefix . AlterTableInvoices::$tblName;
		$sessionTbl  = $wpdb->prefix . AlterTableSessions::$tblName;

		$aInvoice = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT $invoicesTbl.*, $sessionTbl.ID as sessionID, $sessionTbl.userID, $sessionTbl.gateway, $sessionTbl.billing_type, $sessionTbl.planID FROM $invoicesTbl LEFT JOIN $sessionTbl ON ($invoicesTbl.sessionID=$sessionTbl.ID) WHERE $sessionTbl.userID=%d AND $invoicesTbl.ID=%d ORDER BY $invoicesTbl.ID DESC LIMIT 1",
				get_current_user_id(), $_GET['id']
			),
            ARRAY_A
		);

		if ( empty($aInvoice) ){
			wp_die( esc_html__('This invoice does not exist.', 'wiloke') );
        }

        $this->exportFile($aInvoice);
    }

	public static function getInvoices($aQuery=array()){
		global $wpdb;
		$paged = isset($aQuery['paged']) ? $aQuery['paged'] : 1;
		$invoicesTbl = $wpdb->prefix . AlterTableInvoices::$tblName;
		$sessionTbl  = $wpdb->prefix . AlterTableSessions::$tblName;

		$offset = ($paged - 1)*self::$postPerPages;
		self::$postPerPages = isset($aQuery['posts_per_page']) && !empty($aQuery['posts_per_page']) ? $aQuery['posts_per_page'] : self::$postPerPages;

		$aInvoices = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT SQL_CALC_FOUND_ROWS $invoicesTbl.*, $sessionTbl.ID as sessionID, $sessionTbl.userID, $sessionTbl.gateway, $sessionTbl.billing_type, $sessionTbl.planID FROM $invoicesTbl LEFT JOIN $sessionTbl ON ($invoicesTbl.sessionID=$sessionTbl.ID) WHERE $sessionTbl.userID=%d ORDER BY $invoicesTbl.ID DESC LIMIT %d OFFSET %d",
				get_current_user_id(), self::$postPerPages, $offset
			)
		);
		$total = $wpdb->get_var("SELECT FOUND_ROWS()");

		return array(
			'oInvoices' => $aInvoices,
			'total'     => $total
		);
	}

	public static function renderInvoiceHead(){
		?>
		<tr>
			<th class="invoices-id manage-column check-column"><?php esc_html_e('ID', 'wiloke'); ?></th>
			<th class="invoices-package manage-column"><?php esc_html_e('Session ID', 'wiloke'); ?></th>
			<th class="invoices-package manage-column"><?php esc_html_e('Plan Name', 'wiloke'); ?></th>
			<th class="invoices-package manage-column"><?php esc_html_e('Regular Price', 'wiloke'); ?></th>
			<th class="invoices-package manage-column"><?php esc_html_e('Discount', 'wiloke'); ?></th>
			<th class="invoices-date manage-column"><?php esc_html_e('Total', 'wiloke'); ?></th>
			<th class="invoices-date manage-column"><?php esc_html_e('Billed At', 'wiloke'); ?></th>
			<th class="invoices-date manage-column"><?php esc_html_e('Download', 'wiloke'); ?></th>
		</tr>
		<?php
	}

	public static function renderBillingItem($oBilling){
	    $symbol = Render::getCurrencyBySymbol($oBilling->currency);
		?>
		<tr>
			<td class="invoices-id check-column manage-column"><?php echo esc_html($oBilling->ID); ?></td>
			<td class="invoices-id check-column manage-column"><?php echo esc_html($oBilling->sessionID); ?></td>
			<td class="invoices-id check-column manage-column"><?php echo get_the_title($oBilling->planID); ?></td>
			<td class="invoices-id check-column manage-column"><?php Render::price($oBilling->regular_price, false, $symbol); ?></td>
			<td class="invoices-id check-column manage-column"><?php Render::price($oBilling->discount, false, $symbol); ?></td>
			<td class="invoices-id check-column manage-column"><?php Render::price($oBilling->regular_price - $oBilling->discount, false, $symbol); ?></td>
			<td class="invoices-id check-column manage-column"><?php echo esc_html($oBilling->created_at); ?></td>
			<td class="invoices-id check-column manage-column"><a id="wiloke-listgo-download-invoice-<?php echo esc_attr($oBilling->ID); ?>" class="wiloke-listgo-download-invoice" data-invoiceid="<?php echo esc_attr($oBilling->ID); ?>" href="<?php echo esc_url(admin_url("admin-ajax.php?action=wiloke_submission_download_invoice&amp;id=".$oBilling->ID)); ?>"><?php esc_html_e('Download CSV', 'wiloke') ?></a></td>
		</tr>
		<?php
	}

}