<?php
namespace WilokeListgoFunctionality\Frontend;


use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use WilokeListgoFunctionality\Model\StripeModel;

class FrontendStripe{
	public function __construct() {
		add_action('wp_enqueue_scripts', array($this, 'enqueueScripts'), 10);
	}

	public function enqueueScripts(){
		global $post;

		$aConfiguration = PaymentConfiguration::get();

		$isAllowEnqueue = isset($post->ID) && ( ($post->ID == $aConfiguration['checkout']) || ($post->ID == $aConfiguration['myaccount']) );
		$isAllowEnqueue = apply_filters('wiloke-submission/is-allow-enqueue-stripe-script', $isAllowEnqueue, $post);

		if ( !$isAllowEnqueue ){
			return false;
		}

		if ( !PaymentConfiguration::checkGateway('stripe') ){
			return false;
		}

		wp_enqueue_script('stripe', 'https://checkout.stripe.com/checkout.js', array('jquery'), WILOKE_LISTGO_FC_VERSION, true );

		wp_localize_script(
			'stripe',
			'WILOKE_SUBMISSION_STRIPE_CONFIGURATION',
			array(
				'publishableKey' => $aConfiguration['stripe_publishable_key'],
				'hasCustomerID' => is_user_logged_in() && !empty(StripeModel::getCustomerID(get_current_user_id())) ? 'yes' : 'no'
			)
		);

//		wp_register_script('wiloke-listgo-stripe', plugin_dir_url(dirname(__FILE__)) . '../public/source/js/stripe.js', array('jquery'), WILOKE_LISTGO_FC_VERSION, true );
	}
}