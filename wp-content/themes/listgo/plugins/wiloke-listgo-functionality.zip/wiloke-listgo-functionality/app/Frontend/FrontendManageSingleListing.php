<?php
namespace WilokeListgoFunctionality\Frontend;

use WilokeListgoFunctionality\CustomerPlan\CustomerPlan;
use WilokeListgoFunctionality\Framework\Helpers\AddListingHelpers;
use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
use WilokeListgoFunctionality\Model\UserModel;
use WilokeListgoFunctionality\Submit\AddListing;

class FrontendManageSingleListing{
	protected $designSingleListingsKey = 'wiloke_design_single_listing_tab';
	protected $aDesignSingleListing;
	public $isSupportedTimeKit;
	protected $isDisableContactForm=null;
	protected $customFieldKeys = 'wiloke_listgo_my_custom_fields';
	protected $aCustomFields = array();
	public $latLng = null;
	public $isSupportedFBChat = null;
	protected $aFBChatSettings = array();

	public function __construct() {
		add_shortcode('wilokeMyCustomField', array($this, 'myCustomFields'));
		add_shortcode('wilokeTimekit', array($this, 'renderTimeKit'));
		add_shortcode('wilokeContent', array($this, 'renderListingContent'));
		add_shortcode('wilokeReview', array($this, 'renderReview'));
		add_shortcode('wilokeContactFormAndMap', array($this, 'renderContactFormAndMap'));
		add_shortcode('wilokeCoupon', array($this, 'renderCoupon'));
		add_shortcode('wilokeAFC', array($this, 'renderAFCCustomField'));
		add_action('wp_enqueue_scripts', array($this, 'enqueueScripts'));
		add_action('wiloke/listgo/template/single-listing-elements/tabs-nav', array($this, 'renderListingTabs'), 10, 1);
		add_action('wiloke/listgo/template/single-listing-elements/tabs-content', array($this, 'renderTabContents'), 10, 1);
        add_action('wiloke/listgo/after_body', array($this, 'printFBScript'));
        add_action('wp_footer', array($this, 'renderFBChat'));
	}

	public function isSupportedFBChat(){
	    if ( $this->isSupportedFBChat !== null ){
	        return $this->isSupportedFBChat;
        }

		global $post, $wiloke;

	    if ( is_page_template('wiloke-submission/addlisting.php') || is_page_template('wiloke-submission/checkout.php') || is_author() ){
	        return '';
        }

		if ( (!is_singular('listing') ) || (is_singular('listing') && isset($post->ID) && user_can($post->post_author, 'edit_theme_options')) ){
			$this->isSupportedFBChat = true;
			$this->aFBChatSettings['apiID'] = isset($wiloke->aThemeOptions['fb_app_api_id']) ? $wiloke->aThemeOptions['fb_app_api_id'] : '';
			$this->aFBChatSettings['fanpageID'] = isset($wiloke->aThemeOptions['fb_app_panpage_id']) ? $wiloke->aThemeOptions['fb_app_panpage_id'] : '';

			if ( empty($this->aFBChatSettings['apiID']) || empty($this->aFBChatSettings['fanpageID']) ){
				$this->isSupportedFBChat = false;
				return false;
			}
			return true;
		}


		$planID = GetSettings::getPostMeta($post->ID, wilokeRepository('app:belongsToPlanID'));
		if ( empty($planID) ){
			$this->isSupportedFBChat = false;
			return false;
		}

		$aPlanSettings = GetSettings::getPostMeta($post->ID, 'toggle_fb_customchat');
		if ( isset($aPlanSettings['toggle_fb_customchat']) && ($aPlanSettings['toggle_fb_customchat'] == 'disable') ){
			$this->isSupportedFBChat = false;
			return false;
		}

		$this->aFBChatSettings = get_user_meta($post->post_author, 'wiloke_fb_chat', true);

		if ( empty($this->aFBChatSettings) || empty($this->aFBChatSettings['apiID']) || empty($this->aFBChatSettings['fanpageID']) ){
			$this->isSupportedFBChat = false;
			return false;
		}

		$this->isSupportedFBChat = true;
		return true;
    }

	public function printFBScript(){
        if ( !$this->isSupportedFBChat() ){
            return '';
        }
		?>
        <script>
			window.fbAsyncInit = function() {
				FB.init({
					appId      : '<?php echo esc_js($this->aFBChatSettings['apiID']); ?>',
					xfbml      : true,
					autoLogAppEvents : true,
					version    : 'v2.11'
				});
			};

			(function(d, s, id){
				var js, fjs = d.getElementsByTagName(s)[0];
				if (d.getElementById(id)) {return;}
				js = d.createElement(s); js.id = id;
				js.src = "https://connect.facebook.net/en_US/sdk.js";
				fjs.parentNode.insertBefore(js, fjs);
			}(document, 'script', 'facebook-jssdk'));
        </script>
        <?php
	}

	function renderFBChat(){
	    if ( !$this->isSupportedFBChat() ){
	        return '';
        }
		?>
        <div class="fb-customerchat"  page_id="<?php echo esc_attr($this->aFBChatSettings['fanpageID']); ?>" minimized="true"></div>
		<?php
	}

	public function getMyCustomFieldSettings($post){
		if( !empty($this->aCustomFields) ){
			return $this->aCustomFields;
		}

		$this->aCustomFields = GetSettings::getPostMeta($post->ID, $this->customFieldKeys);
		return $this->aCustomFields;
	}

	public function isDisableContactForm(){
	    global $post;

	    if ( $this->isDisableContactForm !== null ){
	        return $this->isDisableContactForm;
        }

		$this->isDisableContactForm = false;
		$planID = GetSettings::getPostMeta($post->ID, wilokeRepository('app:belongsToPlanID'));

		if ( !empty($planID) ){
			$aPlanSettings = GetSettings::getPostMeta($planID, get_post_type($planID));

			$this->isDisableContactForm = isset($aPlanSettings['toggle_contact_form']) && $aPlanSettings['toggle_contact_form'] == 'disable';
		}
        return $this->isDisableContactForm;
    }

	public function isSupportedTimekit(){
		global $post;
		if ( $this->isSupportedTimeKit !== null ){
			return $this->isSupportedTimeKit;
		}

		$this->isSupportedTimeKit = true;
		if ( !is_singular('listing') ){
			$this->isSupportedTimeKit = false;
			return false;
		}

		$planID = get_post_meta($post->ID, wilokeRepository('app:belongsToPlanID'), true);
		if ( !empty($planID) ){
			$aPlanSettings = get_post_meta($planID, 'pricing_settings', true);
			if ( isset($aPlanSettings['toggle_timekit']) && $aPlanSettings['toggle_timekit'] == 'disable' ){
				$this->isSupportedTimeKit = false;
			}
		}
        return $this->isSupportedTimeKit;
	}

    public function renderTimekit($aAtts){
	    $this->isSupportedTimeKit();
	    if ( !$this->isSupportedTimeKit || !is_singular('listing') ){
	        return '';
        }

	    wp_enqueue_script('timekit');
	    wp_enqueue_script('listgo-timekit');

	    global $post;
	    $aTimeKitSettings = get_post_meta($post->ID, 'listing_timekit', true);

	    if ( empty($aTimeKitSettings) || empty($aTimeKitSettings['app']) || empty($aTimeKitSettings['apiToken']) ){
		    return '';
	    }
	    ob_start();
	    ?>
        <div class="listgo-timekit-bookingjs" data-timekit="<?php echo esc_attr(json_encode($aTimeKitSettings)); ?>"></div>
	    <?php
        $content = ob_get_contents();
        ob_end_clean();
        return $content;
    }

	public function renderCoupon($aAtts){
		$aAtts = shortcode_atts(
			array(
				'btn_name'      => 'Get Coupon Code',
                'popup_title'   => 'Use the coupon code below'
			),
			$aAtts
		);
		global $post;
		$aCoupon = GetSettings::getPostMeta($post->ID, 'listing_coupon');
		if ( empty($aCoupon['coupon_code']) ){
            return '';
        }
		if ( !empty($aCoupon['referral_link']) ) :
		?>
            <a href="javascript:void(0)" onclick="s=prompt('<?php echo esc_attr($aAtts['popup_title']); ?>','<?php echo esc_attr($aCoupon['coupon_code']); ?>'); if (s){ window.open('<?php echo esc_attr($aCoupon['referral_link']); ?>')};" class="listgo-btn listgo-btn--sm listgo-btn--round btn-primary"><?php echo esc_html($aAtts['btn_name']); ?></a>
        <?php else: ?>
            <a href="javascript:void(0)" onclick="s=prompt('<?php echo esc_attr($aAtts['popup_title']); ?>','<?php echo esc_attr($aCoupon['coupon_code']); ?>'); ?>);" class="listgo-btn listgo-btn--sm btn-primary listgo-btn--round"><?php echo esc_html($aAtts['btn_name']); ?></a>
        <?php
        endif;
    }

    public function renderAFCCustomField($aAtts){
	    global $post;
	    $aAtts = shortcode_atts(
		    array(
			    'id' => 'my_custom_field'
		    ),
		    $aAtts
	    );

	    ob_start();
        do_action('wiloke-listgo-functionality/print-custom-field/'.$aAtts['id'], $post);
        $content = ob_get_contents();
        ob_end_clean();
        return $content;
    }

	public function myCustomFields($aAtts){
		global $post;
		$aAtts = shortcode_atts(
			array(
				'type'          => 'text',
				'block_key'     => '',
				'heading'       => '',
				'headingTag'    => 'h3',
				'description'   => ''
			),
			$aAtts
		);

		$planID = \Wiloke::getPostMetaCaching($post->ID, wilokeRepository('app:belongsToPlanID'));
		$aPlanSettings = \Wiloke::getPostMetaCaching($planID, 'pricing_settings');

		if ( AddListingHelpers::isExceptThisCustomField($aPlanSettings, $aAtts['block_key']) ){
		    return '';
        }

		$this->getMyCustomFieldSettings($post);
		ob_start();

		if ( !empty($aAtts['heading']) ){
		    echo '<'.$aAtts['headingTag'] . '>' . esc_html($aAtts['heading']) . '</'.$aAtts['headingTag'].'>';
        }

		if ( !empty($aAtts['description']) ){
			echo '<p>' . esc_html($aAtts['description']) . '</p>';
		}

		switch ($aAtts['type']){
			case 'image':
				if ( isset($this->aCustomFields[$aAtts['block_key'].'_id']) && !empty($this->aCustomFields[$aAtts['block_key'].'_id']) ){
					if ( !has_filter('wiloke/listgo/templates/single-listing-elements/image') ){
						?>
                        <img src="<?php echo wp_get_attachment_image_srcset($this->aCustomFields[$aAtts['block_key'].'_id'], 'large'); ?>" alt="<?php echo esc_attr($post->post_title); ?>">
                        <?php
					}else{
						echo apply_filters('wiloke/listgo/templates/single-listing-elements/image', $aAtts['block_key'], $this->aCustomFields[$aAtts['block_key'].'_id'], $post);
					}
				}

				break;
			case 'gallery':
				if ( isset($this->aCustomFields[$aAtts['block_key']]) && !empty($this->aCustomFields[$aAtts['block_key']]) ){
					$galleryIDs = array_keys($this->aCustomFields[$aAtts['block_key']]);
					if ( !has_filter('wiloke/listgo/templates/single-listing-elements/gallery') ){
						echo do_shortcode('[gallery ids="'.implode(',', $galleryIDs).'"]');
					}else{
						echo apply_filters('wiloke/listgo/templates/single-listing-elements/gallery', $aAtts['block_key'], $galleryIDs, $post);
					}
				}
				break;
			case 'select':
				if ( isset($this->aCustomFields[$aAtts['block_key']]) && !empty($this->aCustomFields[$aAtts['block_key']]) ){
					$values = $this->aCustomFields[$aAtts['block_key']];
					if ( !has_filter('wiloke/listgo/templates/single-listing-elements/select') ){
						if ( !is_array($values) ){
							\Wiloke::wiloke_kses_simple_html($values);
						}else{
							?>
                            <ul>
								<?php foreach ($values as $val): ?>
                                    <li><?php \Wiloke::wiloke_kses_simple_html($val); ?></li>
								<?php endforeach; ?>
                            </ul>
							<?php
						}
					}else{
						echo apply_filters('wiloke/listgo/templates/single-listing-elements/select', $aAtts['block_key'], $values, $post);
					}
				}
				break;
			default:
				if ( isset($this->aCustomFields[$aAtts['block_key']]) && !empty($this->aCustomFields[$aAtts['block_key']]) ){
					$value = $this->aCustomFields[$aAtts['block_key']];
					if ( !has_filter('wiloke/listgo/templates/single-listing-elements/'.$aAtts['type']) ){
						\Wiloke::wiloke_kses_simple_html($value);
					}else{
						echo apply_filters('wiloke/listgo/templates/single-listing-elements/'.$aAtts['type'], $aAtts['block_key'], $value, $post);
					}
				}
				break;
		}
		$content = ob_get_contents();
		ob_end_clean();
		return $content;
	}

	public function renderReview(){
	    ob_start();
		comments_template();
		$content = ob_get_contents();
		ob_end_clean();
		return $content;
	}

	public function renderListingContent(){
		ob_start();
	    global $post;
		do_action('wiloke/listgo/templates/single-listing/after_tab-description_open', $post);
		?>
		<div class="listing-single__content">
		<?php
			do_action('wiloke/listgo/templates/single-listing/after_listing_content_open', $post);
			the_content();
			wp_link_pages();
			do_action('wiloke/listgo/templates/single-listing/before_listing_content_close', $post);
		?>
		</div>
		<?php
		do_action('wiloke/listgo/templates/single-listing/before_tab-description_close', $post);
		$content = ob_get_contents();
		ob_end_clean();
		return $content;
	}

	public function renderContactFormAndMap($post){
		ob_start();
		global $post, $wiloke;

		$this->isDisableContactForm();
		$hasContactForm = false;
		if ( $this->latLng === null ){
			$aSettings = GetSettings::getPostMeta($post->ID, 'listing_settings');
			if ( isset($aSettings['map']['latlong']) ){
				$this->latLng = $aSettings['map']['latlong'];
			}
        }

		if ( !$this->isDisableContactForm ) {
			$hasContactForm = isset($wiloke->aThemeOptions['listing_contactform7']) && !empty($wiloke->aThemeOptions['listing_contactform7']) && defined('WPCF7_PLUGIN');
		}

        if ( !$hasContactForm && empty($this->latLng) ){
		    return '';
        }

        if ( $hasContactForm && !empty($this->latLng) ){
            $className = 'col-md-6';
        }else{
	        $className = 'col-md-12';
        }

		?>
		<div class="row">
            <?php if ( !$this->isDisableContactForm ) : ?>
			<div class="<?php echo esc_attr($className); ?>">
				<div class="listing-single__contact form">
					<?php
					if ( $hasContactForm ){
						echo do_shortcode('[contact-form-7 id="'.esc_attr($wiloke->aThemeOptions['listing_contactform7']).'" title="Contact Form"]');
					}else{
						\WilokeAlert::render_alert( esc_html__('Please go to Appearance -> Theme Options -> Listing Settings and assign a conform to Set Contact Form 7 setting.', 'listgo'), 'warning' );
					}
					?>
				</div>
			</div>
            <?php endif; ?>
			<?php
			if ( isset($this->latLng) ) :
				$marker = '';
				$aListingListingCat = \Wiloke::getPostTerms($post, 'listing_cat');
				if ( isset($aListingListingCat[0]) && !empty($aListingListingCat[0]) ){
					$aCatOptions = \Wiloke::getTermOption($aListingListingCat[0]->term_id);
					if ( isset($aCatOptions['map_marker_image']) ){
						$marker = $aCatOptions['map_marker_image'];
					}
				}
				?>
				<div class="<?php echo esc_attr($className); ?>">
					<div id="listing-single__map" class="listing-single__map" data-map="<?php echo esc_attr($this->latLng); ?>" data-marker="<?php echo esc_url($marker); ?>"></div>
				</div>
			<?php endif; ?>
		</div>
		<?php
		$content = ob_get_contents();
		ob_end_clean();
		return $content;
	}

	public function renderTabContents($post){
		$status = '';
		foreach ($this->aDesignSingleListing as $aTabContent) :
			if($aTabContent['toggle'] === 'false' || $aTabContent['toggle'] === false){
				continue;
			}

			$status = empty($status) ? 'active' : 'default-status';

			if ( strpos($aTabContent['content'], 'ContactFormAndMap') !== false ){
				$status .= ' has-single-map';
				$this->isDisableContactForm();

				if ( $this->isDisableContactForm ) {
					if ( $this->latLng === null ){
						$aSettings = GetSettings::getPostMeta($post->ID, 'listing_settings');
						if ( isset($aSettings['map']['latlong']) && !empty($aSettings['map']['latlong']) ){
							$this->latLng = $aSettings['map']['latlong'];
						}else{
							$this->latLng = '';
							continue;
						}
				    }

				    if ( empty($this->latLng) ){
					    continue;
                    }
				}
			}
			?>
			<div id="tab-<?php echo esc_attr($aTabContent['key']); ?>" class="tab__panel <?php echo esc_attr($status); ?>">
				<?php
				if ( !empty($aTabContent['content']) ) :
					echo do_shortcode(stripslashes($aTabContent['content']));
				endif;
				?>
			</div>
			<?php
		endforeach;
	}

	public function generateTabByName($name){
		return md5($name);
	}

	public function renderListingTabs(){
	    global $post;
		$this->aDesignSingleListing = GetSettings::getOptions($this->designSingleListingsKey);

		if ( !empty($this->aDesignSingleListing) ){
			$this->aDesignSingleListing = maybe_unserialize($this->aDesignSingleListing);
		}else{
			$this->aDesignSingleListing = wilokeDesignAddListingRepository()->get('settings:aDesignSingleListing');
		}

		$status = '';
		foreach ($this->aDesignSingleListing as $key => $aTab){
			if ( $aTab['toggle'] === 'false' || $aTab['toggle'] === false ){
				continue;
			}
			$status = empty($status) ? 'active' : 'default-status';

			switch ($aTab['content']) {
				case (strpos($aTab['content'], 'ContactFormAndMap') !== false):
					$this->aDesignSingleListing[$key]['key'] = 'contact-and-map';
					break;
				case (strpos($aTab['content'], 'wilokeContent') !== false):
					$this->aDesignSingleListing[$key]['key'] = 'description';
					break;
				case (strpos($aTab['content'], 'wilokeReview') !== false):
					$this->aDesignSingleListing[$key]['key'] = 'review';
					break;
				default:
					$this->aDesignSingleListing[$key]['key'] = md5($aTab['name']);
					break;
			}
			
			if ( strpos($aTab['content'], 'ContactFormAndMap') !== false ){
				$status .= ' has-single-map';
                $this->isDisableContactForm();
                if ( $this->isDisableContactForm ) {
	                $aSettings = GetSettings::getPostMeta($post->ID, 'listing_settings');
	                if ( isset($aSettings['map']['latlong']) && !empty($aSettings['map']['latlong']) ){
                        $this->latLng = $aSettings['map']['latlong'];
	                }else{
                        continue;
	                }
                }
			}
			
			?>
			<li class="<?php echo esc_attr($status); ?>"><a href="#tab-<?php echo esc_attr($this->aDesignSingleListing[$key]['key']); ?>"><?php echo esc_html($aTab['name']); ?></a></li>
			<?php
		}
	}

	public function enqueueScripts(){
		if ( is_singular('listing') && is_user_logged_in() ){
			wp_enqueue_media();
		}
	}

	public static function packageAllow($target){
		global $post;

		if ( !isset($post->post_type) || $post->post_type !== 'listing' ){
			return true;
		}

		$packageID = \Wiloke::getPostMetaCaching($post->ID, AddListing::$packageIDOfListing);
		if ( empty($packageID) ){
			return true;
		}

		$aCustomerPlan = UserModel::getLatestPlanByPlanType('pricing');
		if ( !isset($aCustomerPlan['planID']) || empty($aCustomerPlan['planID']) ){
			return false;
		}

		$aPackageSettings = \Wiloke::getPostMetaCaching($aCustomerPlan['planID'], 'pricing_settings');
		if ( !isset($aPackageSettings[$target]) || ($aPackageSettings[$target] == 'enable') ){
			return true;
		}

		return false;
	}
}