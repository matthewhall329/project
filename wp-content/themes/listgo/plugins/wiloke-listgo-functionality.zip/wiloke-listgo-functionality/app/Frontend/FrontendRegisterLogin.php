<?php
namespace WilokeListgoFunctionality\Frontend;


use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;

class FrontendRegisterLogin {
	public static function quickLoginRegisters(){
		if ( is_user_logged_in() || (PaymentConfiguration::getField('toggle') == 'disable') ){
			return '';
		}
		?>
		<div class="header__user">
			<div class="tb">
				<div class="tb__cell">
					<div class="user__icon" data-modal="#modal-login">
						<svg version="1.0" xmlns="http://www.w3.org/2000/svg"
						     width="23px" height="23px" viewBox="0 0 448.000000 432.000000"
						     preserveAspectRatio="xMidYMid meet">
							<g transform="translate(0.000000,432.000000) scale(0.100000,-0.100000)"
							   fill="#fff" stroke="none">
								<path d="M2100 4314 c-84 -11 -201 -39 -280 -66 -191 -68 -331 -157 -481 -307
                            -188 -188 -299 -392 -355 -651 -26 -119 -26 -381 0 -500 55 -257 169 -466 355
                            -651 237 -237 514 -360 846 -375 224 -10 415 31 623 133 l112 56 48 -18 c208
                            -78 490 -269 657 -446 287 -303 482 -715 521 -1101 l7 -68 -1913 0 -1913 0 7
                            67 c43 417 266 864 582 1162 97 92 114 119 114 179 0 108 -99 183 -202 152
                            -51 -15 -214 -171 -331 -315 -306 -379 -488 -871 -491 -1327 -1 -149 4 -165
                            68 -212 l27 -21 2139 0 2139 0 27 21 c65 48 69 62 68 217 -5 520 -233 1063
                            -614 1461 -165 173 -334 302 -551 422 -57 32 -106 59 -108 60 -2 2 26 42 61
                            89 180 239 269 530 254 825 -16 330 -139 606 -375 841 -182 182 -382 293 -631
                            350 -83 19 -331 33 -410 23z m371 -343 c179 -46 319 -127 449 -260 129 -130
                            212 -278 257 -457 24 -95 24 -333 0 -428 -46 -185 -125 -324 -262 -461 -137
                            -137 -276 -216 -461 -262 -95 -24 -333 -24 -428 0 -182 46 -328 128 -462 261
                            -133 134 -215 280 -261 462 -24 95 -24 333 0 428 45 179 128 327 257 457 147
                            150 309 236 513 275 100 19 299 12 398 -15z"></path>
							</g>
						</svg>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
}