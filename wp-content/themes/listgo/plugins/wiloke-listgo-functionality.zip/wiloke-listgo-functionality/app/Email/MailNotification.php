<?php
namespace WilokeListgoFunctionality\Email;


use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
use WilokeListgoFunctionality\Framework\Helpers\Render;
use WilokeListgoFunctionality\Framework\Payment\DirectBankTransfer\Configuration;
use WilokeListgoFunctionality\Framework\Payment\PaymentConfiguration;
use WilokeListgoFunctionality\Model\PaymentMetaModel;
use WilokeListgoFunctionality\Model\PaymentModel;

class MailNotification extends SendMail {
	use Configuration;

	public $aBeforeListingStatus = array('renew', 'pending', 'expired', 'processing');

	public function __construct() {
		parent::__construct();
		add_action('wiloke-submission/mail', array($this, 'detectMailStatus'), 10, 1);
		add_action('post_updated', array($this, 'listingApproved'), 10, 3);
		add_action('post_updated', array($this, 'eventCreated'), 10, 3);
	}

	public function resetNotificationTime($userID){
		if ( \Wiloke::$wilokePredis ){
			\Wiloke::$wilokePredis->del(\Wiloke::$prefix.'notification_latest_check|'.$userID);
			delete_option(\Wiloke::$prefix.'notification_latest_check|'.$userID);
		}
	}

	public function listingApproved($postID, $oPostAfter, $oPostBefore){
		if ( $oPostAfter->post_type !== 'listing' || !in_array($oPostBefore->post_status, $this->aBeforeListingStatus) ){
			return false;
		}

		if ( $oPostAfter->post_status === 'publish' ){
			$this->getOptions();
			$aUserInfo = get_userdata($oPostBefore->post_author);
			$this->resetNotificationTime($oPostBefore->post_author);
			$customerContent = $this->oSettings->mail_listing_approved;

			$customerContent = $this->defaultReplace($customerContent, $oPostAfter);

			$this->subject = esc_html__('Your submission has been approved', 'wiloke');
			$this->to = $aUserInfo->user_email;
			$this->body = $customerContent;
			$this->specialEmail();
		}
	}

	public function eventCreated($postID, $oPostAfter, $oPostBefore){
		if ( $oPostAfter->post_type !== 'event'  ){
			return false;
		}

		if ( $oPostAfter->post_status !== 'publish' ){
		    return false;
        }

		$this->getOptions();
		$aEventSettings = GetSettings::getPostMeta($postID, 'event_settings');
		$aUserInfo = get_userdata($oPostBefore->post_author);
		$customerContent = $this->oSettings->event_published;
        $customerContent = str_replace('%listing_url%', get_permalink($aEventSettings['belongs_to']),$customerContent );
		$customerContent = $this->defaultReplace($customerContent, $oPostAfter);

		$this->subject = esc_html__('Your event has been published', 'wiloke');
		$this->to = $aUserInfo->user_email;
		$this->body = $customerContent;
		$this->specialEmail();

		$this->subject = esc_html__('A new event has been created', 'wiloke');
		$this->to = get_option('admin_email');
		$this->body = sprintf(esc_html__('%s created a new event: %s on %s. Event details: %s', 'wiloke'), $aUserInfo->display_name, get_permalink($oPostAfter->post_title), $this->oSettings->brandname, get_permalink($aEventSettings['belongs_to']));
		$this->specialEmail();
    }

	public function detectMailStatus($aInfo){
		$this->getOptions();
		$post = $customerSubject = $customerEmail = $adminSubject = '';

		switch ($aInfo['type']){
			case 'claimStatus':
				if ( $aInfo['status'] == 'approved' ){
					$customerSubject = esc_html__('Your claim request has been approved', 'wiloke');
					$customerContent = $this->oSettings->mail_claim_approved;
					$post       = get_post($aInfo['listingID']);
					$oUserInfo  = get_userdata($post->post_author);
					$customerEmail = $oUserInfo->user_email;
				}elseif($aInfo['status'] == 'decline'){
					$customerSubject = esc_html__('Your claim request has been declined', 'wiloke');
					$customerContent = $this->oSettings->mail_claim_rejected;
					$post     = get_post($aInfo['listingID']);
					$oUserInfo = get_userdata($post->post_author);
					$customerEmail = $oUserInfo->user_email;
				}

				break;
			case 'userClaimedListing':
				$adminSubject = esc_html__('Notification of claim listing', 'wiloke');
				$oUserInfo  = get_userdata($aInfo['aInfo']['claimerID']);
				$post = get_post($aInfo['aInfo']['listingID']);

				$adminContent    = '<strong>' . $oUserInfo->display_name . '</strong>' . esc_html__( ' has claimed ', 'wiloke') .  '<strong>' . $post->post_title . '</strong>' . ' on %brand%';
				break;
			case 'submittedPost':
				$customerSubject = esc_html__('Your article has been submitted.', 'wiloke');
				$post     = get_post($aInfo['listingID']);
				$oUserInfo  = get_userdata($post->post_author);
				$customerEmail = $oUserInfo->user_email;
				$customerContent = $this->oSettings->mail_listing_submitted;

				$adminSubject = esc_html__('Notification of listing submission', 'wiloke');
				$adminContent    = $oUserInfo->display_name . esc_html__( ' submitted ', 'wiloke') . '<a href="'.esc_url(get_permalink($aInfo['listingID'])).'">'.get_permalink($aInfo['listingID']) . '</a>' .  esc_html__( ' to your site', 'wiloke');
				break;
			case 'postApproved':
				$customerSubject = esc_html__('Your submission has been approved', 'wiloke');
				$post     = get_post($aInfo['listingID']);
				$oUserInfo  = get_userdata($post->post_author);
				$customerEmail = $oUserInfo->user_email;
				$customerContent =  $this->oSettings->mail_listing_approved;
				break;
			case 'paymentSucceeded':
				$post = get_post($aInfo['listingID']);
				$customerContent = $this->oSettings->mail_completed_payment;
				$aSessionInfo = PaymentModel::getSessionInfo($aInfo['aInfo']['sessionID']);
				$oUserInfo  = get_userdata($aSessionInfo['userID']);
				$customerEmail = $oUserInfo->user_email;
				$customerSubject = esc_html__('Your payment has been succeeded', 'wiloke');
				$total = abs($aInfo['aInfo']['regular_price']) - abs($aInfo['aInfo']['discount']);

				ob_start();
				?>
                <table class="wiloke-table">
                    <thead>
                    <tr>
                        <th><?php esc_html_e('Invoice Number', 'wiloke'); ?></th>
                        <th><?php esc_html_e('Payment Gateway', 'wiloke'); ?></th>
                        <th><?php esc_html_e('Plan Name', 'wiloke'); ?></th>
                        <th><?php esc_html_e('Total', 'wiloke'); ?></th>
                        <th><?php esc_html_e('Currency', 'wiloke'); ?></th>
                        <th><?php esc_html_e('Billed at', 'wiloke'); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td><?php echo esc_html($aInfo['aInfo']['invoiceID']); ?></td>
                        <td><?php echo esc_html($aSessionInfo['gateway']); ?></td>
                        <td><?php echo get_the_title($aSessionInfo['planID']); ?></td>
                        <td><?php echo esc_html(PaymentConfiguration::renderTotal($total, $aSessionInfo['gateway'], $aSessionInfo['billing_type'])); ?></td>
                        <td><?php echo esc_html($aInfo['aInfo']['currency']); ?></td>
                        <td><?php echo esc_html($aInfo['aInfo']['billed_at']); ?></td>
                    </tr>
                    </tbody>
                </table>
				<?php
				$invoiceDetail = ob_get_contents();
				ob_end_clean();
				$customerContent = str_replace(
					array(
						'%invoice_details%'
					),
					array(
						$invoiceDetail
					),
					$customerContent
				);

				$adminSubject = esc_html__('Notification of invoice', 'wiloke');
				$adminContent = $oUserInfo->display_name . esc_html__( ' paid ', 'wiloke') . Render::price($total, true) . esc_html__(' to you', 'wiloke') . esc_html__( '. Invoice ID: ', 'wiloke') . $aInfo['aInfo']['invoiceID'];
				break;

			case 'sessionStatus':
				switch ($aInfo['status']){
					case 'subscription_created':
						if ( $aInfo['billingType'] == wilokeRepository('app:billingTypes', true)->sub('recurring') ){
							$aSessionInfo = PaymentModel::getSessionInfo($aInfo['sessionID']);
							$oUserInfo  = get_userdata($aSessionInfo['userID']);
							$customerSubject = $oUserInfo->user_email;
							$customerEmail = esc_html__('Your subscription has been created', 'wiloke');
							$customerContent = $this->oSettings->mail_subscription_created;

							ob_start();
							?>
							<table class="wiloke-table">
								<thead>
                                    <tr>
                                        <th><?php esc_html_e('Session Number', 'wiloke'); ?></th>
                                        <th><?php esc_html_e('Gateway', 'wiloke'); ?></th>
                                        <th><?php esc_html_e('Plan Name', 'wiloke'); ?></th>
                                        <th><?php esc_html_e('Created at', 'wiloke'); ?></th>
                                    </tr>
								</thead>
								<tbody>
                                    <tr>
                                        <td><?php echo esc_html($aSessionInfo['ID']); ?></td>
                                        <td><?php echo esc_html($aSessionInfo['gateway']); ?></td>
                                        <td><?php echo get_the_title($aSessionInfo['planID']); ?></td>
                                        <td><?php echo esc_html($aSessionInfo['created_at']); ?></td>
                                    </tr>
								</tbody>
							</table>
							<?php
							$sessionTbl = ob_get_contents();
							ob_end_clean();
							$customerContent = str_replace(
								'%subscription_details%',
								$sessionTbl,
								$customerContent
							);

							$adminSubject = esc_html__('Notification of the new subscription', 'wiloke');
							$adminContent = sprintf(__('%s just created a new session #%d. The details information %s', $oUserInfo->display_name, $aSessionInfo['ID'], $sessionTbl));
						}
						break;

					case 'sessionCancelled':
						$customerContent = $this->oSettings->mail_subscription_created;
						$aSessionInfo = PaymentModel::getSessionInfo($aInfo['sessionID']);
						$oUserInfo  = get_userdata($aSessionInfo['userID']);
						$customerSubject = esc_html__('Your subscription has been canceled', 'wiloke');
						$customerContent = str_replace(
							'%subscription_number%',
							$aInfo['sessionID'],
							$customerContent
						);
						$customerEmail = $oUserInfo->user_email;

						$adminSubject = esc_html__('Notification of cancel subscription', 'wiloke');
						$adminContent = sprintf(__('%s just cancelled his/her subscription #%d. The details information %s', $oUserInfo->display_name, $aSessionInfo['ID']));
						break;

					case 'sessionFailed':
						$customerContent = $this->oSettings->mail_subscription_created;
						$aSessionInfo = PaymentModel::getSessionInfo($aInfo['sessionID']);
						$oUserInfo  = get_userdata($aSessionInfo['userID']);
						$customerSubject = esc_html__('Your subscription has been failed', 'wiloke');
						$customerContent = str_replace(
							'%subscription_number%',
							$aInfo['sessionID'],
							$customerContent
						);

						$adminSubject = esc_html__('Notification of failure subscription', 'wiloke');
						$customerEmail = $oUserInfo->user_email;

						break;

					case 'sessionSuspended':
						$customerContent = $this->oSettings->mail_subscription_suspended;
						$aSessionInfo = PaymentModel::getSessionInfo($aInfo['sessionID']);
						$oUserInfo  = get_userdata($aSessionInfo['userID']);
						$customerSubject = esc_html__('Your subscription has been suspended', 'wiloke');

						$customerContent = str_replace(
							'%subscription_number%',
							$aInfo['sessionID'],
							$customerContent
						);
						$customerEmail = $oUserInfo->user_email;

						$adminSubject = esc_html__('Notification of suspend subscription', 'wiloke');
						$adminContent = sprintf(__('%s just change his/her subscription #%d to suspend status. The details information %s', $oUserInfo->display_name, $aSessionInfo['ID']));
						break;
				}
				break;

			case 'banktransferProcessing':
				$customerContent = $this->oSettings->mail_bank_transfer_processing_order;
				$aPaymentInfo = PaymentModel::getSessionInfo($aInfo['sessionID']);
				$oUserInfo  = get_userdata($aPaymentInfo['userID']);
				$customerSubject = esc_html__('Your bank transfer has been ordered.', 'wiloke');
                $aPaymentMeta = PaymentMetaModel::get($aInfo['sessionID'], wilokeRepository('paymentKeys:info'));
                $aPlanInfo = $aPaymentMeta['plan']['info'];

				ob_start();
				?>
                <table class="wiloke-table">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Session Number', 'wiloke'); ?></th>
                            <th><?php esc_html_e('Plan', 'wiloke'); ?></th>
                            <th><?php esc_html_e('Total', 'wiloke'); ?></th>
                            <th><?php esc_html_e('Payment Method', 'wiloke'); ?></th>
                            <th><?php esc_html_e('Created at', 'wiloke'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td><?php echo esc_html($aPaymentInfo['ID']); ?></td>
                        <td><?php echo get_the_title($aPaymentInfo['planID']); ?></td>
                        <td><?php Render::price($aPlanInfo['price']); ?></td>
                        <td><?php echo esc_html($aPaymentInfo['gateway']); ?></td>
                        <td><?php echo esc_html($aPaymentInfo['created_at']); ?></td>
                    </tr>
                    </tbody>
                </table>
				<?php
				$orderDetails = ob_get_contents();
				ob_end_clean();


				$aBankDetails = PaymentConfiguration::getBankAccounts();
                ob_start();
				?>
                <table class="wiloke-table">
                    <tr>
                        <th><?php esc_html_e('Account Name', 'wiloke'); ?></th>
                        <th><?php esc_html_e('Account Number', 'wiloke'); ?></th>
                        <th><?php esc_html_e('Bank Name', 'wiloke'); ?></th>
                        <th><?php esc_html_e('Short Code', 'wiloke'); ?></th>
                        <th><?php esc_html_e('IBAN', 'wiloke'); ?></th>
                        <th><?php esc_html_e('BIC/Swift', 'wiloke'); ?></th>
                    </tr>
					<?php foreach ($aBankDetails as $aBankDetail) : ?>
                        <tr>
                            <td><?php echo esc_html($aBankDetail['bank_transfer_account_name']); ?></td>
                            <td><?php echo esc_html($aBankDetail['bank_transfer_account_number']); ?></td>
                            <td><?php echo esc_html($aBankDetail['bank_transfer_name']); ?></td>
                            <td><?php echo esc_html($aBankDetail['bank_transfer_short_code']); ?></td>
                            <td><?php echo esc_html($aBankDetail['bank_transfer_iban']); ?></td>
                            <td><?php echo esc_html($aBankDetail['bank_transfer_swift']); ?></td>
                        </tr>
					<?php endforeach; ?>
                </table>
                <?php
                $bankAccounts = ob_get_contents();
                ob_end_clean();

				$customerContent = str_replace(
					array(
						'%customer%',
						'%order_details%',
                        '%bank_accounts%'
                    ),
					array(
                        $oUserInfo->display_name,
						$orderDetails,
						$bankAccounts
					),
					$customerContent
				);
				$customerEmail = $oUserInfo->user_email;

				$adminSubject = esc_html__('Notification of suspend subscription', 'wiloke');
				$adminContent = sprintf(__('%s just change his/her subscription #%d to suspend status. The details information %s', $oUserInfo->display_name, $aPaymentInfo['ID']));
				break;
		}

		if ( !empty($customerContent) ){
			$customerContent = $this->defaultReplace($customerContent, $post);
			$this->to = $customerEmail;
			$this->subject = $customerSubject;
			$this->body = $customerContent;
			$this->specialEmail();
		}

		if ( !empty($adminContent) ){
			$content = $this->defaultReplace($adminContent, $post);
			$this->to = get_option('admin_email');
			$this->subject = $adminSubject;
			$this->body = $content;
			$this->specialEmail();
		}
	}
}