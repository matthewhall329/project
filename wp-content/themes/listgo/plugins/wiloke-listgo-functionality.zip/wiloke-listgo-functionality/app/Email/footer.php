<!-- ======= start footer ======= -->

<table cellpadding="0" cellspacing="0" border="0" width="100%">
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
    <tr>
        <td class="two-column" style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;text-align:center;font-size:0;"><!--[if (gte mso 9)|(IE)]>
            <table width="100%" style="border-spacing:0" >
                <tr>
                    <td width="50%" valign="top" style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;" >
            <![endif]-->

            <div class="column" style="width:100%;max-width:399px;display:inline-block;vertical-align:top;">
                <table class="contents" style="border-spacing:0; width:100%">
                    <tr>
                        <td width="39%" align="right" style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;"><a href="{{wiloke_siteurl}}" target="_blank"><img src="{{wiloke_logo}}" alt="" width="59" height="59" style="border-width:0; max-width:59px;height:auto; display:block; padding-right:20px" /></a></td>
                        <td width="61%" align="left" valign="middle" style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;"><p style="color:#787777; font-size:13px; text-align:left; font-family: Verdana, Geneva, sans-serif">{{wiloke_signature}}</p></td>
                    </tr>
                </table>
            </div>

            <!--[if (gte mso 9)|(IE)]>
            </td><td width="50%" valign="top" style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;" >
            <![endif]-->

            <div class="column" style="width:100%;max-width:399px;display:inline-block;vertical-align:top;">
                <table width="100%" style="border-spacing:0">
                    <tr>
                        <td class="inner" style="padding-top:0px;padding-bottom:10px; padding-right:10px;padding-left:10px;"><table class="contents" style="border-spacing:0; width:100%">
                                <tr>
                                    <td width="32%" align="center" valign="top" style="padding-top:10px"><table width="150" border="0" cellspacing="0" cellpadding="0">
                                            <tr>
                                                {{wiloke_social_networks}}
                                            </tr>
                                        </table></td>
                                </tr>
                            </table></td>
                    </tr>
                </table>
            </div>

            <!--[if (gte mso 9)|(IE)]>
            </td>
            </tr>
            </table>
            <![endif]--></td>
    </tr>
    <tr>
        <td height="30">&nbsp;</td>
    </tr>
</table>

<!-- ======= end footer ======= --></td>
</tr>
</table>
<!--[if (gte mso 9)|(IE)]>
</td>
</tr>
</table>
<![endif]-->
</div></td>
</tr>
</table>
</center>
</body>
</html>