<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=<?php bloginfo( 'charset' ); ?>" />
    <!--[if !mso]><!-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!--<![endif]-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo esc_html($this->oSettings->brandname); ?></title>
    <style type="text/css">
        * {
            -webkit-font-smoothing: antialiased;
        }
        body {
            Margin: 0;
            padding: 0;
            min-width: 100%;
            font-family: Arial, sans-serif;
            -webkit-font-smoothing: antialiased;
            mso-line-height-rule: exactly;
            font-size: 16px;
        }
        table {
            border-spacing: 0;
            color: #333333;
            font-family: Arial, sans-serif;
        }
        img {
            border: 0;
        }
        .wrapper {
            width: 100%;
            table-layout: fixed;
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%;
        }
        .webkit {
            max-width: 800px;
        }
        .outer {
            Margin: 0 auto;
            width: 100%;
            max-width: 800px;
        }
        .full-width-image img {
            width: 100%;
            max-width: 800px;
            height: auto;
        }
        .inner {
            padding: 10px;
        }
        p {
            Margin: 0;
            padding-bottom: 10px;
        }
        .h1 {
            font-size: 21px;
            font-weight: bold;
            Margin-top: 15px;
            Margin-bottom: 5px;
            font-family: Arial, sans-serif;
            -webkit-font-smoothing: antialiased;
        }
        .h2 {
            font-size: 18px;
            font-weight: bold;
            Margin-top: 10px;
            Margin-bottom: 5px;
            font-family: Arial, sans-serif;
            -webkit-font-smoothing: antialiased;
        }
        .one-column .contents {
            text-align: left;
            font-family: Arial, sans-serif;
            -webkit-font-smoothing: antialiased;
        }
        .one-column p {
            font-size: 14px;
            Margin-bottom: 10px;
            font-family: Arial, sans-serif;
            -webkit-font-smoothing: antialiased;
        }
        .two-column {
            text-align: center;
            font-size: 0;
        }
        .two-column .column {
            width: 100%;
            max-width: 300px;
            display: inline-block;
            vertical-align: top;
        }
        .contents {
            width: 100%;
        }
        .two-column .contents {
            font-size: 14px;
            text-align: left;
        }
        .two-column img {
            width: 100%;
            max-width: 280px;
            height: auto;
        }
        .two-column .text {
            padding-top: 10px;
        }
        .three-column {
            text-align: center;
            font-size: 0;
            padding-top: 10px;
            padding-bottom: 10px;
        }
        .three-column .column {
            width: 100%;
            max-width: 200px;
            display: inline-block;
            vertical-align: top;
        }
        .three-column .contents {
            font-size: 14px;
            text-align: center;
        }
        .three-column img {
            width: 100%;
            max-width: 180px;
            height: auto;
        }
        .three-column .text {
            padding-top: 10px;
        }
        .img-align-vertical img {
            display: inline-block;
            vertical-align: middle;
        }

        .wiloke-table{
            margin-bottom: 20px;
            margin-top: 20px;
        }

        .wiloke-table td{
            font-size: 16px;
        }

        .wiloke-table td, .wiloke-table th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        .wiloke-table tr:nth-child(even){background-color: #f2f2f2;}
        .wiloke-table tr:hover {background-color: #ddd;}
        .wiloke-table th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #eeeeee;
        }

        @media only screen and (max-device-width: 480px) {
            table[class=hide], img[class=hide], td[class=hide] {
                display: none !important;
            }

            .contents1 {
                width: 100%;
            }

            .contents1 {
                width: 100%;
            }
        }
    </style>
    <!--[if (gte mso 9)|(IE)]>
    <style type="text/css">
        table {border-collapse: collapse !important;}
    </style>
    <![endif]-->
</head>

<body style="margin:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;min-width:100%;background-color:#f3f2f0;">
<center class="wrapper" style="width:100%;table-layout:fixed;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;background-color:#f3f2f0;">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#f3f2f0;" bgcolor="#f3f2f0;">
        <tr>
            <td width="100%"><div class="webkit" style="max-width:800px;Margin:0 auto;">

                    <!--[if (gte mso 9)|(IE)]>

                    <table width="800" align="center" cellpadding="0" cellspacing="0" border="0" style="border-spacing:0" >
                        <tr>
                            <td style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;" >
                    <![endif]-->

                    <!-- ======= start main body ======= -->
                    <table class="outer" align="center" cellpadding="0" cellspacing="0" border="0" style="border-spacing:0;Margin:0 auto;width:100%;max-width:800px;">
                        <tr>
                            <td style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;"><!-- ======= start header ======= -->

                                <table border="0" width="100%" cellpadding="0" cellspacing="0"  >
                                    <tr>
                                        <td><table style="width:100%;" cellpadding="0" cellspacing="0" border="0">
                                                <tbody>
                                                <tr>
                                                    <td align="center"><center>
                                                            <table border="0" align="center" width="100%" cellpadding="0" cellspacing="0" style="Margin: 0 auto;">
                                                                <tbody>
                                                                <tr>
                                                                    <td class="one-column" style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;"><table border="0" cellpadding="0" cellspacing="0" width="100%" style="border-spacing:0">
                                                                            <tr>
                                                                                <td>&nbsp;</td>
                                                                            </tr>
                                                                        </table></td>
                                                                </tr>
                                                                </tbody>
                                                            </table>
                                                        </center></td>
                                                </tr>
                                                </tbody>
                                            </table></td>
                                    </tr>
                                </table>
                                <table border="0" width="100%" cellpadding="0" cellspacing="0"  >
                                    <tr>
                                        <td><table style="width:100%;" cellpadding="0" cellspacing="0" border="0">
                                                <tbody>
                                                <tr>
                                                    <td align="center"><center>
                                                            <table border="0" align="center" width="100%" cellpadding="0" cellspacing="0" style="Margin: 0 auto;">
                                                                <tbody>
                                                                <tr>
                                                                    <td class="one-column" style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;" bgcolor="#FFFFFF"><!-- ======= start header ======= -->

                                                                        <table cellpadding="0" cellspacing="0" border="0" width="100%" style="border-left:1px solid #e8e7e5; border-right:1px solid #e8e7e5; border-top:1px solid #e8e7e5">
                                                                            <tr>
                                                                                <td>&nbsp;</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>&nbsp;</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td class="two-column" style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;text-align:center;font-size:0;" ><!--[if (gte mso 9)|(IE)]>
                                                                                    <table width="100%" style="border-spacing:0" >
                                                                                        <tr>
                                                                                            <td width="20%" valign="top" style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:30px;" >
                                                                                    <![endif]-->

                                                                                    <div class="column" style="width:100%;max-width:220px;display:inline-block;vertical-align:top;">
                                                                                        <table class="contents" style="border-spacing:0; width:100%"  >
                                                                                            <tr>
                                                                                                <td style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0px;" align="left"><a href="{{wiloke_siteurl}}" target="_blank"><img src="{{wiloke_logo}}" alt="" width="60" height="60" style="border-width:0; max-width:60px;height:auto; display:block" align="left"/></a></td>
                                                                                            </tr>
                                                                                        </table>
                                                                                    </div>

                                                                                    <!--[if (gte mso 9)|(IE)]>
                                                                                    </td><td width="80%" valign="top" style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;" >
                                                                                    <![endif]-->

                                                                                    <div class="column" style="width:100%;max-width:515px;display:inline-block;vertical-align:top;">
                                                                                        <table width="100%" style="border-spacing:0">
                                                                                            <tr>
                                                                                                <td class="inner" style="padding-top:0px;padding-bottom:10px; padding-right:10px;padding-left:10px;"><table class="contents" style="border-spacing:0; width:100%" bgcolor="#FFFFFF">
                                                                                                        <tr>
                                                                                                            <td width="57%" align="right" valign="top"><img src="https://gallery.mailchimp.com/fdcaf86ecc5056741eb5cbc18/images/b39b534d-6718-43bb-85fa-1cc212eb91c1.jpg" width="25" height="9" style="border-width:0; max-width:25px;height:auto; display:block; max-height:9px; padding-top:4px; padding-left:10px" alt=""/></td>
                                                                                                            <td width="43%" align="left" valign="top"><font style="font-size:11px; text-decoration:none; color:#474b53; font-family: Verdana, Geneva, sans-serif; text-align:left; line-height:16px; padding-bottom:30px"><a href="{{wiloke_siteurl}}" target="_blank" style="color:#474b53; text-decoration:none">Sign Into Your Account</a></font></td>
                                                                                                        </tr>
                                                                                                    </table></td>
                                                                                            </tr>
                                                                                        </table>
                                                                                    </div>

                                                                                    <!--[if (gte mso 9)|(IE)]>
                                                                                    </td>
                                                                                    </tr>
                                                                                    </table>
                                                                                    <![endif]--></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td height="80">&nbsp;</td>
                                                                            </tr>
                                                                        </table></td>
                                                                </tr>
                                                                </tbody>
                                                            </table>
                                                        </center></td>
                                                </tr>
                                                </tbody>
                                            </table></td>
                                    </tr>
                                </table>

                                <!-- ======= end header ======= -->