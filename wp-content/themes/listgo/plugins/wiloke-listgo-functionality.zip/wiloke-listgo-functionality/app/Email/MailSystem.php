<?php
namespace WilokeListgoFunctionality\Email;

class MailSystem {
	public function __construct() {
	}


}