<!-- ======= start hero image ======= --><!-- ======= end hero image ======= -->

<!-- ======= start hero article ======= -->

<table class="one-column" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-spacing:0; border-left:1px solid #e8e7e5; border-right:1px solid #e8e7e5; border-bottom:1px solid #e8e7e5" bgcolor="#FFFFFF">
    <tr>
        <td align="left" style="padding:0px 40px 40px 40px">
            <p style="color:#000000; font-size:16px; text-align:left; font-family: Verdana, Geneva, sans-serif; line-height:22px">
                {{wiloke_content}}
            </p>
            <br />
            <br />
            <p style="color:#000000; font-size:16px; text-align:left; font-family: Verdana, Geneva, sans-serif; line-height:22px; font-style: italic">{{best_regard}}</p>
        </td>
    </tr>
</table>

<!-- ======= end hero article ======= -->