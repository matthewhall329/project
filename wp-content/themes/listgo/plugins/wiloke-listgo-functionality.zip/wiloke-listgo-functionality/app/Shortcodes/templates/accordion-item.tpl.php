<script id="wiloke-accordion-item" type="text/html">
	<div class="row">
		<div class="col-sm-8">
			<div class="addlisting-popup__field">
				<input type="text" name="title" value="<%= title %>">
			</div>
		</div>
		<div class="col-sm-12">
			<div class="addlisting-popup__field">
				<textarea name="description" id="" cols="30" rows="3"><%= description %></textarea>
			</div>
		</div>
	</div>
</script>