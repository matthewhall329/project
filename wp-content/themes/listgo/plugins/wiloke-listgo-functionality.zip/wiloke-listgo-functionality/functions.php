<?php
use WilokeListgoFunctionality\Framework\UserPlan\RemainingItemsFactory;
use WilokeListgoFunctionality\Framework\Config\Repository;
use \WilokeListgoFunctionality\Framework\Helpers\GetSettings;


/**
 * Determining Remaining Item Gateway
 *
 * @param number $planID
 * @param array $aUserPlan
 * @param array $sessionID
 * @param number $userID
 *
 * @return object
 */
if ( !function_exists('wilokeGetRemainingItems') ) {
	function wilokeGetRemainingItems($planID, $aUserPlan, $userID=null){
		$instRemainingItemsFactory = new RemainingItemsFactory();
		$instRemainingItemsFactory->setUserPlan($planID, $aUserPlan, $userID);
		return $instRemainingItemsFactory->determineInstance();
	}
}

/**
 * Get Configuration by the specified key
 *
 * @param string $key. It should follow this structure: fileName:arrKey
 * @param bool $isChainingAble Optional
 *
 * @return mixed
 */
if ( !function_exists('wilokeRepository') ){
	function wilokeRepository($key, $isChainingAble=false){
		$instance = new Repository();
		return $instance->get($key, $isChainingAble);
	}
}

/**
 * Get Wiloke Submission Meta
 *
 * @param number @sessionID
 * @param string $metaKey
 *
 * @return mixed
 */
if ( !function_exists('wilokeGetSubmissionMeta') ) {
	function wilokeGetSubmissionMeta( $sessionID, $metaKey ) {
		return GetSettings::getWilokeSubmissionMeta( $sessionID, $metaKey );
	}
}