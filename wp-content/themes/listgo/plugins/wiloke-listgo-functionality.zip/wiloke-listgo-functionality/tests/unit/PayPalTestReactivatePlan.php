<?php
use PHPUnit\Framework\TestCase;


class PayPalTestReactivatePlan extends TestCase{
	public function testReactivate(){
		$instPayPalRenewPlan = new \WilokeListgoFunctionality\Framework\Payment\PayPal\PayPalReactivePlan('I-K4UHC9H220CH');
		$aReactivationStatus = $instPayPalRenewPlan->processReactivating();
		var_export($aReactivationStatus);die();
	}
}