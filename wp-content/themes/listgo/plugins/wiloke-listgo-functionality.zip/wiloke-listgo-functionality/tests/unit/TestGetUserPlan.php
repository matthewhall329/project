<?php
class TestGetUserPlan extends PHPUnit\Framework\TestCase{
	public function testUserPlan(){
		$userID = 1;
		$aUserPlan = \WilokeListgoFunctionality\Model\UserModel::getAllPlansByUserID($userID);
		echo '<pre>';
		var_export($aUserPlan);
		echo '</pre>';
		die();
	}
}