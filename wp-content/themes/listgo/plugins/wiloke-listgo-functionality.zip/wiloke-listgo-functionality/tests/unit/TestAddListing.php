<?php
use PHPUnit\Framework\TestCase;
use WilokeListgoFunctionality\Controllers\AddListingController;

class TestAddListing extends WP_Ajax_UnitTestCase{
	public $userID;
	public $planID;
	public $postTitle;
	public $postContent;
	public $postType;

	public function setup(){
		$this->userID = 1;
		$this->planID = 212;
		$this->postTitle = 'Test Title';
		$this->postContent = 'Test Content';
		$this->postType = 'listing';
		wp_set_current_user( $this->userID);
	}

	public function testAddAListing(){
		$_POST['listingID'] = null;
		$_POST['planID'] = $this->planID;

		$_POST['formData'] = array(
			array(
				'name'  => 'title',
				'value' => $this->postTitle
			),
			array(
				'name'  => 'description',
				'value' => $this->postContent
			)
		);
		$this->_handleAjax( 'my_test_add_listing' );
		$aResponse = $this->_last_response;
	}
}