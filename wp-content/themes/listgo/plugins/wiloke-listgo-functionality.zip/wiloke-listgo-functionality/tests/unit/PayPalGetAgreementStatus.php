<?php
use PHPUnit\Framework\TestCase;


class PayPalGetAgreementStatus extends TestCase{
	public function testGetStatus(){
//		var_export((curl_version()));die();
//		$test = \WilokeListgoFunctionality\Framework\Payment\PayPal\PayPalHelps::billingAgreementStatus('I-E2VY8MRBU1E0');
		$test = \WilokeListgoFunctionality\Framework\Payment\PayPal\PayPalHelps::billingAgreementStatus('I-R2WVV77NBCH7');
		var_export($test);die();
	}
}