<?php
use PHPUnit\Framework\TestCase;


class PayPalChangePlan extends TestCase{
	public $userID = 1;

	public function setup(){
		$this->userID = 1;
		wp_set_current_user( $this->userID);
	}

	public function testChangingPlan(){
		$planID = 14;
		$instChangePlan = new \WilokeListgoFunctionality\Framework\Payment\PayPal\ChangePlan($this->userID, $planID);
		var_export($instChangePlan);die();
	}
}
