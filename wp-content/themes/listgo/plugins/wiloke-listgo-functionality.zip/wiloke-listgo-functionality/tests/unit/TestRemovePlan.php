<?php
use PHPUnit\Framework\TestCase;


class TestRemovePlan extends TestCase{
	public function testRemoveSubscription(){
		$userID = 1;
		$oldPlanID = 14;

		\WilokeListgoFunctionality\Model\UserModel::removeUserPlanByPlanID($userID, $oldPlanID);

		var_export(WilokeListgoFunctionality\Model\UserModel::getAllPlansByUserID($userID));die();
	}
}