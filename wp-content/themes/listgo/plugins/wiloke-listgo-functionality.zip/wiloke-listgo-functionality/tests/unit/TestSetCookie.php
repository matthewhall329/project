<?php
use PHPUnit\Framework\TestCase;


class TestSetCookie extends TestCase{
	public function testSetCookieValue(){
		setcookie('testfat', 'ddd', 0, '/');
		var_export($_COOKIE['testfat']);
		setcookie('testfat', 'xxx', 0, '/');
	}
}