<?php
use PHPUnit\Framework\TestCase;

class TestGetPayPalInfo extends TestCase{
	public function testGetAgreementInfo(){
		$info = \WilokeListgoFunctionality\Framework\Payment\PayPal\PayPalHelps::getAgreementInfo('I-1EGUNXYFSJXL');
		var_export($info);die();
	}
}