<?php
use PHPUnit\Framework\TestCase;


class TestGetPaymentInfo extends TestCase{
	public function testGetPayPalInfo(){
		$test = \WilokeListgoFunctionality\Model\PaymentMetaModel::get(21, 'payment_info');
		var_export($test);
		die();
	}
}