<?php
use PHPUnit\Framework\TestCase;

class TestUserMeta extends TestCase{
	public function testGetUserMeta(){
		$userID = 1;
		$aUserMeta = \Wiloke::getUserMeta($userID);
		echo '<pre>';
		var_export($aUserMeta);
		echo '</pre>';
		die();
	}
}