<?php
use WilokeListgoFunctionality\Framework\Payment\PayPal\RemainingItemsInNonRecurringPayPal;
use PHPUnit\Framework\TestCase;


class TestGetRemainingNonRecurringItems extends TestCase{
	public function testGetRemainingItems(){
		$aUserInfo = \WilokeListgoFunctionality\Model\UserModel::getPlansByUserID(1);
		$aUserInfo['userID'] = 1;
		$aUserInfo['planID'] = 14;
		$inst = new RemainingItemsInNonRecurringPayPal($aUserInfo);
		var_export($inst->remainingItems());die();
	}
}