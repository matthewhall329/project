<?php
use WilokeListgoFunctionality\Framework\Payment\PayPal\RemainingItemsInNonRecurringPayPal;
use PHPUnit\Framework\TestCase;


class TestGetRemainingNonRecurringItems extends TestCase{
	public function testGetRemainingItems(){
		$aUserInfo = \WilokeListgoFunctionality\Model\UserModel::getUserDetailPlan(1, 14);
		$aUserInfo['userID'] = 1;
		$aUserInfo['planID'] = 14;
		$inst = new \WilokeListgoFunctionality\Framework\Payment\PayPal\RemainingItemsInRecurringPayPal($aUserInfo);
		var_export($inst->remainingItems());die();
	}
}