<?php
use PHPUnit\Framework\TestCase;


class PayPalTestSuspended extends TestCase{
	public function testSuspended(){
		$instPayPalRenewPlan = new \WilokeListgoFunctionality\Framework\Payment\PayPal\PayPalSuspendPlan('I-K4UHC9H220CH');
		$aReactivationStatus = $instPayPalRenewPlan->processSuspending();
		\WilokeListgoFunctionality\Model\PaymentModel::updateToSuspendedStatusWhereEqualToSessionID(41);
		var_export($aReactivationStatus);die();
	}
}