;(function ($) {
	'use strict';
	
	function generalSettings() {
		let $datePicker = $('.wiloke_datepicker');

		$datePicker.each(function () {
			$(this).datepicker({
				dateFormat: $(this).data('dateformat')
			});
		});

		$(document).tooltip();

		let $formUI = $('.form.ui');
		if ( $formUI.length ){
			$formUI.find('.dropdown').dropdown({
				forceSelection: false
			})
		}
	}

	function datePicker() {
		$('#filter-by-date').on('change', function () {
			let $period = $('#filter-by-period'),
				val = $(this).val();
			if ( val === 'period' ){
				$period.removeClass('hidden');
			}else{
				$period.addClass('hidden');
			}
		}).trigger('change');
	}

	function deletePayment() {
		let xhrDeleteOrder = false;
		$('.js_delete_payment').on('click', function (event) {
			event.preventDefault();
			let $target      = $(event.currentTarget),
				wantToDelete = confirm('Warning: Once this order has been deleted, all listings and invoices that belong to this order will also be moved in trash as well. Clicking Ok to continue deleting, Cancel to leave.');

			if ( wantToDelete ){
				$target.html('Removing...');
				let paymentID = $target.data('paymentid');

				if ( xhrDeleteOrder && xhrDeleteOrder.status !== 200 ){
					xhrDeleteOrder.abort();
				}

				xhrDeleteOrder = $.ajax({
					type: 'POST',
					data: {action: 'wiloke_submission_delete_order', payment_ID: paymentID},
					url: ajaxurl,
					success: (response=>{
						if ( response.success ){
							$target.closest('tr.item').remove();
						}else{
							alert('Something went error');
						}
					})
				})
			}
		});
	}
	
	function scrollTop($scrollTo) {
		$('html, body').animate({
			scrollTop: $scrollTo.offset().top - 100
		}, 600);
	}

	function addNewOrder() {
		let $app = $('#wiloke-submission-add-new-order');
		if ( $app.length ){
			let $msg = $app.find('#wiloke-submission-message-after-addnew');
			$app.on('submit', function (event) {
				event.preventDefault();
				let $userID         = $('#add_new_order_user_ID'),
				    $packageID      = $('#add_new_order_packageid'),
				    $packageType    = $('#add_new_order_package_type'),
				    $eventPlanID    = $('#add_new_order_add_event_planid'),
				    $orderStatus    = $('#add_new_order_status'),
					userId          = $userID.val(),
					packageType     = $packageType.val(),
					packageID       = '',
					orderStatus     = $orderStatus.val();

				if ( $userID.val() === '' ){
					$userID.closest('.field').addClass('error');
					return false;
				}


				if ( packageType === 'pricing' ){
					packageID = $packageID.val();
					if ( packageID === '' ){
						$packageID.closest('.field').addClass('error');
						return false;
					}
				}else{
					packageID = $eventPlanID.val();
					if ( packageID === '' ){
						$eventPlanID.closest('.field').addClass('error');
						return false;
					}
				}

				if ( orderStatus  === '' ){
					$orderStatus.closest('.field').addClass('error');
					return false;
				}

				$msg.addClass('hidden');
				$app.addClass('loading');

				$.ajax({
					type: 'POST',
					url: ajaxurl,
					data: {action: 'wiloke_submission_add_new_order', package_type: packageType, user_ID: userId, package_ID: packageID, order_status: orderStatus},
					success: function (response) {
						$app.removeClass('loading');
						$msg.css('display', 'block');
						if ( response.success ){
							$msg.removeClass('hidden error').addClass('success').html(response.data.message);
							setTimeout((()=>{
								window.location.href = response.data.redirect;
							}), 700);
						}else{
							_.forEach(response.data, (msg, key)=>{
								let $field = $('#'+key);
								if ( $field.length && key !== 'message' ){
									$field.closest('.field').addClass('error');
								}else{
									$msg.removeClass('hidden success').addClass('error').html(msg);
								}
							})
						}
					}
				})
			});
		}
	}

	function createSession() {
		let $formSession = $('#wiloke-submission-create-session');

		$formSession.on('submit', function (event) {
			event.preventDefault();

			$formSession.addClass('loading');

			$.ajax({
				type: 'POST',
				data: {
					action: 'wiloke_submission_create_session',
					data: $formSession.serializeArray()
				},
				url: ajaxurl,
				success: function (response) {
					$formSession.removeClass('loading');
					if ( !response.success ){
						alert(response.data.msg);
					}else{
						window.location.href = decodeURIComponent(response.data.redirectTo);
					}
				}
			})
		});

	}

	class WilokeInstallSubmissionPage{
		constructor(){
			this.$app = $('#ws-install-pages');
			this.runApp();
		}

		runApp(){
			if ( this.$app.length ){
				let xhr = null;
				let $msg = this.$app.find('.message');
				this.$app.on('submit', ((event)=>{
					event.preventDefault();

					if ( xhr !== null && xhr.status !== 200 ){
						return false;
					}

					this.$app.addClass('loading');

					$.ajax({
						type: 'POST',
						url: ajaxurl,
						data: {action: 'wiloke_submission_install_pages'},
						success: (response=>{
							if ( response.success ){
								$msg.html(response.data.message).removeClass('error info').addClass('success');
								this.$app.addClass('success');
							}else{
								$msg.html(response.data.message).removeClass('success info').addClass('error');
								this.$app.addClass('error');
							}

							this.$app.removeClass('loading');
						})
					})
				}));
			}
		}
	}

	let oCacheStore = {
		set: function (key, val) {
			localStorage.setItem(key, val);
		},
		get: function (key) {
			return localStorage.getItem(key);
		},
		destroy: function (key) {
			localStorage.removeItem(key);
		}
	}

	function toggleSegment() {
		let $wrapper = $('#wiloke-submission-wrapper');
		$wrapper.find('.header.toggle-anchor').on('click', function (event) {
			event.preventDefault();
			let $this = $(this),
				signID = $this.attr('id');
			if ( typeof signID !== 'undefined' ){
				if ( oCacheStore.get(signID) === 'clicked' ){
					oCacheStore.destroy(signID);
				}else{
					oCacheStore.set(signID, 'clicked');
				}
			}
			$this.nextAll().fadeToggle();
		});

		$wrapper.find('.toggle-anchor').each(function () {
			let $this = $(this), signID = $this.attr('id');

			if ( oCacheStore.get(signID) === 'clicked' ){
				$this.trigger('click');
			}
		});
	}
	
	$(document).ready(function () {
		createSession();
		generalSettings();
		datePicker();
		deletePayment();
		addNewOrder();
		toggleSegment();
		new WilokeInstallSubmissionPage();
	});
	
})(jQuery);