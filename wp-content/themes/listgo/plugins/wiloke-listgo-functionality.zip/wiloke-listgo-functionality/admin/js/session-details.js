;(function ($) {
	'use strict';
	let $app = $('#wiloke-submission-change-customer-order');
	let $msg = $('#wiloke-submission-message-after-update');

	function scrollTop($scrollTo) {
		$('html, body').animate({
			scrollTop: $scrollTo.offset().top - 100
		}, 600);
	}

	function updateSession() {
		if ( $app.length ){
			$app.on('submit', function(event) {
				event.preventDefault();

				$msg.addClass('hidden');
				$app.addClass('loading');

				$.ajax({
					type: 'POST',
					url: ajaxurl,
					data: {action: 'wiloke_submission_update_session', data: $app.serializeArray()},
					success: function (response) {
						if ( response.success ){
							$app.removeClass('error').addClass('success');
						}else{
							$app.addClass('error').removeClass('success');
						}

						$msg.css('display', 'block');
						$msg.html(response.data.msg);
						$app.removeClass('loading');
						scrollTop($msg);
					}
				})
			});
		}
	}

	function changePlan(){
		let $changePlanBtn = $('#wiloke-submission-change-my-plan');
		if ( $changePlanBtn.length ){
			$changePlanBtn.on('click', function(event) {
				event.preventDefault();

				let confirmation = confirm("Press Oke to confirm this action");

				if ( !confirmation ){
					return false;
				}

				$msg.addClass('hidden');
				$changePlanBtn.addClass('loading');

				let newPlanID       = $app.find('[name="change_to_new_plan"]').val(),
					currentPlanID   = $app.find('[name="planID"]').val();

				$.ajax({
					type: 'POST',
					url: ajaxurl,
					data: {
						action: 'wiloke_submission_change_plan',
						sessionID: $app.find('[name="sessionID"]').val(),
						currentPlanID: currentPlanID,
						userID: $app.find('[name="userID"]').val(),
						newPlanID: newPlanID,
						gateway: $app.find('[name="gateway"]').val()
					},
					success: function (response) {
						if ( response.success ){
							$msg.removeClass('error').addClass('success');
							$app.find('[name="planID"]').val(newPlanID);
						}else{
							$msg.addClass('error').removeClass('success');
						}

						$msg.css('display', 'block');
						$msg.html(response.data.msg);
						$changePlanBtn.removeClass('loading');
						scrollTop($msg);
					}
				})
			});
		}
	}

	function changeOrderStatus() {
		let $changeOrderStatus = $('#wiloke-submission-change-order-status');
		if ( $changeOrderStatus.length ){
			$changeOrderStatus.on('click', function(event) {
				event.preventDefault();
				let confirmation = confirm("Press Oke to confirm this action");
				if ( !confirmation ){
					return false;
				}
				$msg.addClass('hidden');
				$changeOrderStatus.addClass('loading');
				let newOrderStatus = $app.find('[name="change_to_new_order_status"]').val();
				$.ajax({
					type: 'POST',
					url: ajaxurl,
					data: {
						action: 'wiloke_submission_change_order_status',
						sessionID: $app.find('[name="sessionID"]').val(),
						userID: $app.find('[name="userID"]').val(),
						planID: $app.find('[name="planID"]').val(),
						currentStatus: $app.find('[name="order_status"]').val(),
						newStatus: newOrderStatus,
						gateway: $app.find('[name="gateway"]').val(),
						billing_type: $app.find('[name="billing_type"]').val()
					},
					success: function (response) {
						if ( response.success ){
							$msg.removeClass('error').addClass('success');
							$app.find('[name="order_status"]').val(newOrderStatus);
						}else{
							$msg.addClass('error').removeClass('success');
						}

						$msg.css('display', 'block');
						$msg.html(response.data.msg);
						$changeOrderStatus.removeClass('loading');
						scrollTop($msg);
					}
				})
			});
		}
	}

	function chargeTheNextBillingDate() {
		let $chargeBtn = $('#wiloke-charge-the-next-billing-date');
		if ( $chargeBtn.length ){
			$chargeBtn.on('click', function(event) {
				event.preventDefault();

				let confirmation = confirm("Press Oke to confirm this action");

				if ( !confirmation ){
					return false;
				}

				$msg.addClass('hidden');
				$chargeBtn.addClass('loading');

				$.ajax({
					type: 'POST',
					url: ajaxurl,
					data: {action: 'wiloke_submission_charge_next_billing_date', data: $app.serializeArray()},
					success: function (response) {
						if ( response.success ){
							$msg.removeClass('error').addClass('success');
							setTimeout(function () {
								location.reload();
							}, 4000);
						}else{
							$msg.addClass('error').removeClass('success');
						}
						$msg.css('display', 'block');
						$msg.html(response.data.msg);
						$chargeBtn.removeClass('loading');
						scrollTop($msg);
					}
				})
			});
		}
	}

	$(document).ready(function () {
		updateSession();
		chargeTheNextBillingDate();
		changePlan();
		changeOrderStatus();
	})

})(jQuery);