<?php
use WilokeListgoFunctionality\Helpers\AddListingHTML;
$aDefault = array(
	'restaurant_name' => '',
	'restaurant_id' => ''
);
$aOpenTableData = array();
if ( !empty($postID) ){
	$aOpenTableData = \Wiloke::getPostMetaCaching($postID, 'listing_open_table_settings');
}

$aOpenTableData = wp_parse_args($aOpenTableData, $aDefault);

?>
<div class="<?php echo esc_attr(\WilokeListgoFunctionality\Framework\Helpers\AddListingHelpers::toggleClass($aPackageSettings, 'toggle_open_table',  'add-listing-group')); ?>">
	<?php if ( !empty($aBlock['blockName']) ) : ?>
	<h4 class="add-listing-title"><?php echo esc_html($aBlock['blockName']); ?></h4>
	<?php endif; ?>

	<div class="row">
		<div class="col-sm-12">
			<div class="form-item">
				<?php AddListingHTML::renderLabelAndDesc('restaurant-name', $aFieldSettings); ?>
				<span class="input-text">
	                <input id="restaurant-name" type="text" name="listing_open_table_settings[restaurant_name]" value="<?php echo esc_attr($aOpenTableData['restaurant_name']); ?>">
	                <input id="restaurant-id" type="hidden" name="listing_open_table_settings[restaurant_id]" value="<?php echo esc_attr($aOpenTableData['restaurant_id']); ?>">
                </span>
			</div>
		</div>
	</div>

</div>