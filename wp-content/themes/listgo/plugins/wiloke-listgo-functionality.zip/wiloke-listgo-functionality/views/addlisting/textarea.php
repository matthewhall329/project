<?php
if ( isset($aMyCustomFields[$aBlock['blockKey']]) ){
	$aFieldSettings['value'] = $aMyCustomFields[$aBlock['blockKey']];
}else{
	$aFieldSettings['value'] = '';
}
$aFieldSettings['title'] = $aBlock['blockName'];
?>

<div class="<?php echo esc_attr(\WilokeListgoFunctionality\Framework\Helpers\AddListingHelpers::toggleCustomFieldClass($aPackageSettings, $aBlock['blockKey'], 'add-listing-group')); ?>">
	<div class="row">
		<div class="col-sm-12">
			<?php
			\WilokeListgoFunctionality\Helpers\AddListingHTML::textereaField($aBlock['blockKey'], $aFieldSettings);
			?>
		</div>
	</div>
</div>