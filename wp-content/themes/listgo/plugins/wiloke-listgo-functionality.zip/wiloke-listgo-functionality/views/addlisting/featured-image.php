<?php
use WilokeListgoFunctionality\Helpers\AddListingHTML;

if ( !empty($postID) ){
	$aFieldSettings['value'] = get_post_thumbnail_id($postID);
	$aFieldSettings['url']   = get_the_post_thumbnail_url($postID);
}else{
	$aFieldSettings['value'] = $aFieldSettings['url'] = '';
}
?>
<!-- Featured -->
<div class="add-listing-group">
    <div class="row">
        <div class="col-sm-12">
            <?php
            if ( is_user_logged_in() ) :
                ?>
                <div class="form-item upload-file">
                    <!-- Featured Image And Header Image -->
                    <?php AddListingHTML::renderLabelAndDesc('wiloke_feature_image', $aFieldSettings); ?>
                    <div class="add-listing__upload-img add-listing__upload-single wiloke-add-featured-image">
                        <div class="add-listing__upload-preview" style="<?php if (!empty($aFieldSettings['value'])){?>background-image: url(<?php echo esc_url($aFieldSettings['url']); ?>)<?php }; ?>">
                            <span class="add-listing__upload-placeholder"><i class="icon_image"></i><span class="add-listing__upload-placeholder-title"><?php esc_html_e('Featured Image', 'wiloke'); ?></span></span>
                        </div>
                        <input type="hidden" id="featured_image" class="wiloke-insert-id" name="featured_image" value="<?php echo esc_attr($aFieldSettings['value']); ?>" <?php AddListingHTML::printRequiredAttribute($aFieldSettings); ?>>
                    </div>
                </div>
            <?php else : ?>
                <div class="form-item upload-file featured-image-wrapper">
                    <?php AddListingHTML::renderLabelAndDesc('wiloke_feature_image', $aFieldSettings); ?>
                    <div id="wiloke-show-featured-image" class="wil-addlisting-gallery">
                        <ul class="wil-addlisting-gallery__list single-upload"></ul>
                    </div>
                    <label class="input-upload-file">
                        <input type="hidden" id="featured_image" class="wiloke-insert-id" name="featured_image" value="">
                        <input id="wiloke-upload-feature-image" class="wiloke-simple-upload wiloke_feature_image" name="wiloke_raw_featured_image" type="file" value="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17"><path d="M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z"></path></svg>
                        <span><?php echo esc_attr($aBlock['blockName']); ?></span>
                    </label>
                    <span class="input-text wiloke-submission-reminder"><?php echo esc_html__('The image size should smaller or equal ', 'wiloke') . \WilokePublic::getMaxFileSize(); ?></span>
                </div>
                <?php
            endif;
            ?>
        </div>
    </div>
</div>
<!-- End / Featured -->