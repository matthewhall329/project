<?php
if ( isset($aMyCustomField[$aBlock['blockKey']]) ){
	$aFieldSettings['value'] = $aMyCustomField[$aBlock['blockKey']];
}else{
	$aFieldSettings['value'] = '';
}
$aFieldSettings['title'] = $aBlock['blockName'];
?>

<div class="add-listing-group">
	<div class="row">
		<div class="col-sm-12">
			<?php
			\WilokeListgoFunctionality\Helpers\AddListingHTML::checkboxField($aBlock['blockKey'], $aFieldSettings);
			?>
		</div>
	</div>
</div>