<?php
use WilokeListgoFunctionality\Helpers\AddListingHTML;
$aDefault = array(
	'iframe_src'       => ''
);

$aSettings = array();
if ( !empty($postID) ){
	$aSettings = \Wiloke::getPostMetaCaching($postID, 'listing_facebook_fanpage');
}

$aSettings = wp_parse_args($aSettings, $aDefault);
?>
<div class="<?php echo esc_attr(\WilokeListgoFunctionality\Framework\Helpers\AddListingHelpers::toggleClass($aPackageSettings, 'toggle_facebook_fanpage',  'add-listing-group')); ?>">
	<?php if ( !empty($aBlock['blockName']) ) : ?>
		<h4 class="add-listing-title"><?php echo esc_html($aBlock['blockName']); ?></h4>
	<?php endif; ?>
	<?php if ( !empty($aBlock['blockDescription']) ) : ?>
		<p class="add-listing-description"><?php Wiloke::wiloke_kses_simple_html(stripslashes($aBlock['blockDescription'])); ?></p>
	<?php endif; ?>

	<div class="row">
		<div class="col-sm-12">
			<div class="form-item">
				<label class="label" for="app-label"><?php echo esc_html($aFieldSettings['iframeScLabel']); ?></label>
				<span class="input-text">
                <input id="app-label" type="text" name="listing_facebook_fanpage[iframe_src]" value="<?php echo esc_attr($aSettings['iframe_src']); ?>">
            </span>
			</div>
		</div>
	</div>

</div>