<?php
use WilokeListgoFunctionality\Helpers\AddListingHTML;
global $wiloke;
?>
<!-- Title Category and Map -->
<div class="add-listing-group add-listing-group-has-preview">
    <?php if ( $aFieldSettings['listing_title']['toggle'] == 'true' ): ?>
	<!-- Listing Title -->
	<div class="row">
		<div class="col-sm-6">
			<?php
            $aFieldSettings['listing_title']['value'] = !empty($postID) ? get_the_title($postID) : '';
			$aFieldSettings['listing_title']['class'] = 'add-listing-input-title';
            AddListingHTML::textField('listing_title', $aFieldSettings['listing_title']);
            ?>
		</div>
	</div>
    <?php endif; ?>
	<!-- End / Listing Title -->

	<!-- Listing Category -->
    <?php
    if ( $aFieldSettings['listing_cats']['toggle'] == 'true'  ) :
	    $aListingCats = get_terms(
		    array(
			    'taxonomy'  => 'listing_cat',
			    'hide_empty'=> false
		    )
	    );
        if ( (!empty($aListingCats) && !is_wp_error($aListingCats)) ) :
    ?>
	<div class="row">
		<div class="col-sm-6">
            <?php
            $aOptions = array();
            foreach ($aListingCats as $oListingCat){
	            $aOptions[$oListingCat->term_id] = $oListingCat->name;
            }
            $aCurrentCats = \Wiloke::getPostTerms($postID, 'listing_cat');
            $aFieldSettings['listing_cats']['options'] = $aOptions;
            $aFieldSettings['listing_cats']['value'] = !empty($aCurrentCats) ? $aCurrentCats = array_map(function($oTerm){
	            return $oTerm->term_id;
            }, $aCurrentCats): '';

            $aFieldSettings['listing_cats']['class'] = 'add-listing-input-categories';
            $aFieldSettings['listing_cats']['isMultiple'] = 'true';
            AddListingHTML::selectTwoField('listing_cats', $aFieldSettings['listing_cats']);
            ?>
		</div>
	</div>
    <?php
        endif;
    endif;
    ?>
	<!-- END / Listing Category -->

    <!-- Listing Location -->
	<?php
    if ( $aFieldSettings['listing_location']['toggle'] == 'true'  ) :
	    $aListingLocations = get_terms(
		    array(
			    'taxonomy'  => 'listing_location',
			    'hide_empty'=> false
		    )
	    );
	    if ( (!empty($aListingLocations) && !is_wp_error($aListingLocations)) ) :
    ?>
            <div class="row">
                <div class="col-sm-6">
                    <?php
                    $aOptions = array();
                    foreach ($aListingLocations as $aListingLocation){
                        $aOptions[$aListingLocation->term_id] = $aListingLocation->name;
                    }
                    $aCurrentLocation = \Wiloke::getPostTerms($postID, 'listing_location');

                    $aFieldSettings['listing_location']['options']      = $aOptions;
                    $aFieldSettings['listing_location']['value']        = !empty($aCurrentLocation) ? $aCurrentLocation = array_map(function($oTerm){
	                    return $oTerm->term_id;
                    }, $aCurrentLocation): '';
                    $aFieldSettings['listing_location']['class']        = 'add-listing-input-location';

                    AddListingHTML::selectTwoField('listing_location', $aFieldSettings['listing_location']);
                    ?>
                </div>
            </div>
	<?php
        endif;
    endif;
    ?>
    <!-- End / Listing Location -->

	<!-- Listing Location And Map  -->
	<?php if ( $aFieldSettings['google_address']['toggle'] == 'true'  ) : ?>
	<div class="row">
		<div class="col-sm-6">
            <?php
            $aFieldSettings['google_address']['value']  = isset($aPostMeta['map']) ? $aPostMeta['map'] : '';
            AddListingHTML::googleAddress($aFieldSettings['google_address']);
			if ( !isset($wiloke->aThemeOptions['general_map_api']) || empty($wiloke->aThemeOptions['general_map_api']) ) {
				WilokeAlert::message(esc_html__('Please go to Appearance -> Theme Options -> General and supply your Google API key', 'wiloke'), false);
			}
			?>
		</div>
	</div>

	<div class="add-listing-group-preview">
		<img src="<?php echo esc_url(get_template_directory_uri() . '/img/preview/2a.jpg'); ?>" alt="<?php esc_html_e('Preview Image', 'wiloke'); ?>">
	</div>

	<div class="add-listing-group-preview-map">
		<div id="wiloke-map"></div>
	</div>
    <?php endif; ?>
	<!-- End / Listing Map -->
</div>
<!-- End / Title Category and Map -->