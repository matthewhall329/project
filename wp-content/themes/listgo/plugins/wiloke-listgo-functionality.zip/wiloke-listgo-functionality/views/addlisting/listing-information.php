<?php
$aSocials = array(
	'facebook', 'twitter', 'google-plus', 'linkedin', 'tumblr', 'instagram', 'flickr', 'pinterest', 'medium', 'tripadvisor', 'wikipedia', 'vimeo', 'youtube', 'whatsapp', 'vkontakte', 'odnoklassniki'
);
$aSocialMedia  = \Wiloke::getPostMetaCaching($postID, 'listing_social_media');

?>

<div class="add-listing-group">
	<?php if ( !empty($aBlock['blockName']) ) : ?>
	<h4 class="add-listing-title"><?php echo esc_html($aBlock['blockName']); ?></h4>
	<?php endif; ?>

	<?php if ( !empty($aBlock['blockDescription']) ) : ?>
	<p class="add-listing-description"><?php Wiloke::wiloke_kses_simple_html($aBlock['blockDescription']); ?></p>
	<?php endif; ?>

	<!-- Social Media -->
	<div class="row">
		<div class="col-sm-4">
			<div class="form-item">
				<label for="listing_phone" class="label"><?php esc_html_e('Phone', 'wiloke'); ?></label>
				<span class="input-text">
                    <input id="listing_phone" type="text" name="listing_phonenumber" value="<?php echo isset($aPostMeta['phone_number']) ? esc_html($aPostMeta['phone_number']) : ''; ?>">
                </span>
			</div>
		</div>
		<div class="col-sm-4">
			<div class="form-item">
				<label for="listing_website" class="label"><?php esc_html_e('Website', 'wiloke'); ?></label>
				<span class="input-text">
                    <input id="listing_website" type="text" name="listing_website" value="<?php echo isset($aPostMeta['website']) ? esc_url($aPostMeta['website']) : ''; ?>">
                </span>
			</div>
		</div>
        <div class="col-sm-4">
            <div class="form-item">
                <label for="contact_email" class="label"><?php esc_html_e('Contact Email', 'wiloke'); ?></label>
                <span class="input-text">
                    <input id="contact_email" type="text" name="contact_email" value="<?php echo isset($aPostMeta['contact_email']) ? esc_attr($aPostMeta['contact_email']) : ''; ?>">
                </span>
            </div>
        </div>

		<div class="wiloke-listgo-social-networks">
			<?php foreach ($aSocials as $social) :
				$icon = $social;
				if ( $social == 'google-plus' ){
					$name = esc_html__('Google+', 'wiloke');
				}else if ( $social == 'wikipedia' ){
					$icon = 'wikipedia-w';
					$name = esc_html__('Wikipedia', 'wiloke');
				}else if($social == 'bloglovin'){
					$icon = 'fa-heart';
					$name = esc_html__('Bloglovin', 'wiloke');
				}else{
					$name = ucfirst($social);
				}
				?>
				<div class="col-sm-6">
					<div class="<?php echo esc_attr(\WilokeListgoFunctionality\Framework\Helpers\AddListingHelpers::toggleSocialNetworkClass($aPackageSettings, $social, 'form-item')); ?>">
						<label for="<?php echo esc_attr($social); ?>" class="label"><?php echo esc_html($name); ?></label>
						<span class="input-text input-icon-left">
	                        <input id="<?php echo esc_attr($social); ?>" name="listing[social][<?php echo esc_attr($social); ?>]" type="text" value="<?php echo isset($aSocialMedia[$social]) ? esc_url($aSocialMedia[$social]) : ''; ?>">
	                        <i class="input-icon fa fa-<?php echo esc_attr($icon); ?>"></i>
	                    </span>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
	<!-- END / Social Media -->
</div>