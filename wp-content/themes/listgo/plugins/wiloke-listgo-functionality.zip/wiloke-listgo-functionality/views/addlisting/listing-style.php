<?php
use WilokeListGoFunctionality\Submit\AddListing as WilokeAddListing;

global $wiloke;

$aListingTemplates = apply_filters('wiloke/wiloke-listgo-functionality/views/addlisting/listing-style', array(
	'templates/single-listing-traditional.php' => array(
		'preview-title' => '1a.jpg',
		'preview-category' => '1b.jpg',
		'preview' => '1.jpg',
		'name' => esc_html__('Classic', 'wiloke')
	),
	'templates/single-listing-creative-sidebar.php' => array(
		'preview-title' => '6a.jpg',
		'preview-category' => '6b.jpg',
		'preview' => '6.jpg',
		'name' => esc_html__('Creative Sidebar', 'wiloke')
	),
	'templates/single-listing-lively.php' => array(
		'preview-title' => '7a.jpg',
		'preview-category' => '7b.jpg',
		'preview' => '7.jpg',
		'name' => esc_html__('Lively', 'wiloke')
	),
	'templates/single-listing-blurbehind.php' => array(
		'preview-title' => '2a.jpg',
		'preview-category' => '2b.jpg',
		'preview' => '2.jpg',
		'name' => esc_html__('Blur Behind', 'wiloke')
	),
	'templates/single-listing-creative.php' => array(
		'preview-title' => '3a.jpg',
		'preview-category' => '3b.jpg',
		'preview' => '3.jpg',
		'name' => esc_html__('Creative', 'wiloke')
	),
	'templates/single-listing-lisa.php' => array(
		'preview-title' => '4a.jpg',
		'preview-category' => '4b.jpg',
		'preview' => '4.jpg',
		'name' => esc_html__('Lisa', 'wiloke')
	),
	'templates/single-listing-howard-roark.php' => array(
		'preview-title' => '5a.jpg',
		'preview-category' => '5b.jpg',
		'preview' => '5.jpg',
		'name' => esc_html__('Howard Roark', 'wiloke')
	)
));

$defaultTemplate = $wiloke->aThemeOptions['listing_layout'];
if ( empty($defaultTemplate) ){
	$defaultTemplateName = $aListingTemplates[$defaultTemplate];
	unset($aListingTemplates[$defaultTemplate]);
	$aListingTemplates = array_merge(array($defaultTemplate=>$defaultTemplateName), $aListingTemplates);
}

if ( empty($postID) ){
	$currentTemplate = $defaultTemplate;
}else{
	$currentTemplate   = get_page_template_slug($postID);
	$currentTemplate   = !empty($currentTemplate) ? $currentTemplate : 'templates/single-listing-traditional.php';
}

?>
<!-- Group Style -->
<div class="add-listing-group">
	<?php if ( !empty($aBlock['blockName']) ) : ?>
	<label for="listing_template" class="label"><?php echo esc_html($aBlock['blockName']); ?></label>
	<?php endif; ?>
	<?php if ( !empty($aFieldSettings['description']) ) : ?>
	<div class="description"><?php echo esc_html($aFieldSettings['description']); ?></div>
	<?php endif; ?>
	<div class="add-listing__style owl-carousel">
		<?php
		foreach ( $aListingTemplates as $templateName => $aTemplate ) :
			$templateStatus = 'enable';
			if ( $templateName !== $defaultTemplate ){
				if ( isset($aPackageSettings['toggle_listing_template']) && ($aPackageSettings['toggle_listing_template'] == 'disable')  ){
					$templateStatus = 'disable';
				}
			}
			?>
			<div class="add-listing__style-item <?php echo esc_attr($currentTemplate===$templateName) ? 'add-listing__style-selected' : ''; ?> <?php echo esc_attr($templateStatus); ?>" data-preview-title="<?php echo esc_url(WilokeAddListing::getImgPreview($aTemplate['preview-title'])); ?>" data-preview-category="<?php echo esc_url(WilokeAddListing::getImgPreview($aTemplate['preview-category'])); ?>" data-template="<?php echo esc_attr($templateName); ?>">
				<div class="add-listing__style-media">
					<div class="add-listing__style-img">
						<img data-src="<?php echo esc_url(WilokeAddListing::getImgPreview($aTemplate['preview'])); ?>" alt="<?php echo esc_attr($templateName); ?>" class="owl-lazy">
					</div>
					<span class="add-listing__style-status"><i class="icon_check"></i></span>
				</div>
				<span class="add-listing__style-label" data-activated="<?php esc_html_e('Activated', 'wiloke'); ?>"><?php echo esc_html($aTemplate['name']); ?></span>
			</div>
		<?php endforeach; ?>
	</div>
	<input id="listing_style" type="hidden" name="listing_style" value="<?php echo esc_attr($currentTemplate); ?>">
</div>
<!-- End Group Style -->