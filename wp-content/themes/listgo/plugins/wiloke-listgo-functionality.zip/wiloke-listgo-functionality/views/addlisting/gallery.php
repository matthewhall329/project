<?php
if ( $aBlock['blockKey'] == 'gallery_settings' ){
	$groupClass = \WilokeListgoFunctionality\Framework\Helpers\AddListingHelpers::toggleClass($aPackageSettings, $aBlock['blockKey'], 'add-listing-group');
}else{
	$groupClass = \WilokeListgoFunctionality\Framework\Helpers\AddListingHelpers::toggleCustomFieldClass($aPackageSettings, $aBlock['blockKey'], 'add-listing-group');
}
?>
<div class="<?php echo esc_attr($groupClass); ?>">
    <?php
    $aFieldSettings['value'] = array();
    if ( !empty($postID) ){
        if ( $aBlock['blockKey'] == 'gallery_settings' ){
            $aGalleries = \WilokeListgoFunctionality\Framework\Helpers\GetSettings::getPostMeta($postID, 'gallery_settings');
            if ( isset($aGalleries['gallery']) && !empty($aGalleries['gallery']) ){
                foreach ( $aGalleries['gallery'] as $id => $url  ){
                    $aFieldSettings['value'][] = $id;
                }
            }
        }else{
            if ( isset($aMyCustomFields[$aBlock['blockKey']]) && !empty($aMyCustomFields[$aBlock['blockKey']]) ){
                foreach ( $aMyCustomFields[$aBlock['blockKey']] as $id => $url  ){
                    $aFieldSettings['value'][] = $id;
                }
            }
        }
    }
    $aFieldSettings['isMultiple'] = 'true';
    $aFieldSettings['title'] = $aBlock['blockName'];
    ?>
	<div class="row">
		<div class="col-sm-12">
			<?php
			\WilokeListgoFunctionality\Helpers\AddListingHTML::uploadImages($aBlock['blockKey'], $aFieldSettings);
			?>
		</div>
	</div>
</div>
