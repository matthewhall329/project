<?php
use WilokeListgoFunctionality\Helpers\AddListingHTML;
$aDefault = array(
	'description' => '',
	'coupon_code' => '',
	'referral_link' => ''
);
$aCoupon = array();
if ( !empty($postID) ){
	$aCoupon = \Wiloke::getPostMetaCaching($postID, 'listing_coupon');
}

$aCoupon = wp_parse_args($aCoupon, $aDefault);
?>
<div class="<?php echo esc_attr(\WilokeListgoFunctionality\Framework\Helpers\AddListingHelpers::toggleClass($aPackageSettings, 'toggle_coupon',  'add-listing-group')); ?>">
	<?php if ( !empty($aBlock['blockName']) ) : ?>
		<h4 class="add-listing-title"><?php echo esc_html($aBlock['blockName']); ?></h4>
	<?php endif; ?>
	<?php if ( !empty($aBlock['blockDescription']) ) : ?>
        <p class="add-listing-description"><?php Wiloke::wiloke_kses_simple_html($aBlock['blockDescription']); ?></p>
	<?php endif; ?>

	<div class="row">
		<div class="col-sm-4">
			<div class="form-item">
                <label class="label" for="coupon-description"><?php echo esc_html($aFieldSettings['description_title']); ?></label>
				<span class="input-text">
	                <input id="coupon-description" type="text" name="listing_coupon[description]" value="<?php echo esc_attr($aCoupon['description']); ?>" placeholder="<?php echo esc_html($aFieldSettings['placeholder']); ?>">
                </span>
			</div>
		</div>
		<div class="col-sm-4">
			<div class="form-item">
                <label class="label" for="coupon-code"><?php echo esc_html($aFieldSettings['coupon_code']); ?></label>
				<span class="input-text">
	                <input id="coupon-code" type="text" name="listing_coupon[coupon_code]" value="<?php echo esc_attr($aCoupon['coupon_code']); ?>">
                </span>
			</div>
		</div>
		<div class="col-sm-4">
			<div class="form-item">
                <label class="label" for="coupon-referral_link"><?php echo esc_html($aFieldSettings['referral_link']); ?></label>
				<span class="input-text">
	                <input id="coupon-referral_link" type="url" name="listing_coupon[referral_link]" value="<?php echo esc_attr($aCoupon['referral_link']); ?>">
                </span>
			</div>
		</div>
	</div>

</div>