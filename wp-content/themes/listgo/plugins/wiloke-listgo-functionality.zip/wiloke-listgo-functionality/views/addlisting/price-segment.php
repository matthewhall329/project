<?php
use WilokeListgoFunctionality\Helpers\AddListingHTML;
global $wiloke;
$aPriceSegment = array_merge(
	array(
		''   => esc_html__('Rather not say', 'listgo')
	),
	$wiloke->aConfigs['frontend']['price_segmentation']
);

$aPrice = Wiloke::getPostMetaCaching($postID, 'listing_price');

$aPrice = wp_parse_args(
	$aPrice,
	array(
		'price_segment' => '',
		'price_from'  => '',
		'price_to'    => ''
	)
);

foreach ( $aPriceSegment as $segment => $definition ){
	$aSegments['options'][$segment] = isset($wiloke->aThemeOptions['header_search_'.$segment.'_cost_label']) ? $wiloke->aThemeOptions['header_search_'.$segment.'_cost_label'] : $definition;
}
$aSegments['value'] = $aPrice['price_segment'];
$aSegments['title'] = $aFieldSettings['segmentation_title'];
$aSegments['isRequired'] = $aFieldSettings['isRequired'];

$aMinimumSettings['title'] = $aFieldSettings['minimum_price_title'];
$aMinimumSettings['isRequired'] = $aFieldSettings['isRequired'];
$aMinimumSettings['value'] = $aPrice['price_from'];

$aMaximumSettings['title'] = $aFieldSettings['maximum_price_title'];
$aMaximumSettings['isRequired'] = $aFieldSettings['isRequired'];
$aMaximumSettings['value'] = $aPrice['price_to'];
?>
<div id="<?php echo esc_attr($aBlock['blockKey']); ?>-wrapper" class="add-listing-group">
	<?php if ( !empty($aBlock['blockName']) ) : ?>
        <h4 class="add-listing-title"><?php echo esc_html($aBlock['blockName']); ?></h4>
	<?php endif; ?>

	<?php if ( !empty($aFieldSettings['description']) ) : ?>
    <p class="add-listing-description"><?php Wiloke::wiloke_kses_simple_html($aFieldSettings['description']); ?></p>
	<?php endif; ?>

    <div class="row">
        <div class="col-sm-4">
            <?php AddListingHTML::selectField('listing_price[price_segment]', $aSegments); ?>
        </div>
        <div class="col-sm-4">
            <?php AddListingHTML::textField('listing_price[price_from]', $aMinimumSettings); ?>
        </div>
        <div class="col-sm-4">
            <?php AddListingHTML::textField('listing_price[price_to]', $aMaximumSettings); ?>
        </div>
    </div>
</div>
