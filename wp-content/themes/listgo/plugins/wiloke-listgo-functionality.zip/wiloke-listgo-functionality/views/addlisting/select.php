<?php
if ( isset($aMyCustomFields[$aBlock['blockKey']]) ){
	$aFieldSettings['value'] = $aMyCustomFields[$aBlock['blockKey']];
}else{
	$aFieldSettings['value'] = '';
}
?>
<div class="<?php echo esc_attr(\WilokeListgoFunctionality\Framework\Helpers\AddListingHelpers::toggleCustomFieldClass($aPackageSettings, $aBlock['blockKey'], 'add-listing-group')); ?>">
	<div class="row">
		<div class="col-sm-12">
			<?php
			if ( empty($aFieldSettings['options']) ){
				\WilokeListgoFunctionality\Frontend\FrontendListingManagement::message(
					array(
						'message' => sprintf(esc_html__('You have to provide options value for this field: %s', 'wiloke'), $aBlock['blockName'])
					),
					'danger'
				);

				return '';
			}

			$aOptions = explode(',', $aFieldSettings['options']);
			$aOptions = array_map('trim', $aOptions);
			$aOptions = array_combine(array_values($aOptions), $aOptions);
			$aFieldSettings['options'] = $aOptions;
			$aFieldSettings['title'] = $aBlock['blockName'];

			if ( $aFieldSettings['is_multiple_select'] == 'false' ){
				\WilokeListgoFunctionality\Helpers\AddListingHTML::selectField($aBlock['blockKey'], $aFieldSettings);
			}else{
				$aFieldSettings['isMultiple'] = $aFieldSettings['is_multiple_select'];
				\WilokeListgoFunctionality\Helpers\AddListingHTML::selectTwoField($aBlock['blockKey'], $aFieldSettings);
			}

			?>
		</div>
	</div>
</div>