<?php
$isEnableMediaBtn = true;
if ( $aBlock['blockKey'] == 'listing_content' ){
	$isEnableMediaBtn = !isset($aPackageSettings['toggle_allow_embed_video']) || $aPackageSettings['toggle_allow_embed_video'] != 'disable';
	$aFieldSettings['value'] = empty($postID) ? '' : get_post_field('post_content',$postID);
}else{
	$aFieldSettings['value'] = isset($aMyCustomFields[$aBlock['blockKey']]) ? $aMyCustomFields[$aBlock['blockKey']] : '';
}
$aFieldSettings['title'] = $aBlock['blockName'];
?>
<div id="<?php echo esc_attr($aBlock['blockKey']); ?>-wrapper" class="add-listing-group">
    <div class="row">
        <!-- Listing Content -->
        <div class="col-sm-12">
            <?php \WilokeListgoFunctionality\Helpers\AddListingHTML::wpEditor($aBlock['blockKey'], $aFieldSettings, $isEnableMediaBtn); ?>
        </div>
        <!-- End / Listing Content -->
    </div>
</div>