<?php
use WilokeListGoFunctionality\Submit\AddListing as WilokeAddListing;
use WilokeListGoFunctionality\Frontend\FrontendListingManagement;
$checkOutUrl = \WilokePublic::getPaymentField('checkout');
$checkOutUrl = !empty($checkOutUrl) ? get_permalink($checkOutUrl) : '#';
?>
<?php include get_template_directory() . '/wiloke-submission/signup-signin-in-addlisting.php'; ?>

<!-- Submit -->
<div class="add-listing-group last-child">
	<div class="row">
		<div class="col-sm-12">
			<div class="add-listing-actions">
				<div id="wiloke-print-msg-here" class="wiloke-print-msg-here"></div>
				<div class="profile-actions__right">
					<?php if ( WilokeAddListing::isEditingPublishedListing($postID) ) : ?>
						<button data-edittype="<?php echo esc_attr(FrontendListingManagement::publishedListingEditable()) ?>" id="wiloke-listgo-update-listing" class="listgo-btn btn-primary" href="<?php echo esc_url(get_permalink($postID)); ?>"><?php esc_html_e('Update', 'wiloke'); ?></button>
					<?php else: ?>
						<button type="submit" id="wiloke-listgo-preview-listing" class="listgo-btn btn-primary" href="<?php echo esc_url($checkOutUrl); ?>"><?php esc_html_e('Preview', 'wiloke'); ?></button>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- End / Submit -->