<?php
use WilokeListgoFunctionality\Framework\Helpers\GetSettings;
global $wiloke;
$toggleBusinessHoursStatus = GetSettings::getPostMeta($postID, 'wiloke_toggle_business_hours');
$aBusinessHours = Wiloke::getPostMetaCaching($postID, 'wiloke_listgo_business_hours');
?>
<div class="add-listing-group">
    <div class="row">
	<div class="col-sm-12">
		<div class="form-item">
			<?php if ( !empty($aBlock['blockName']) ) : ?>
			<label class="input-toggle">
				<?php echo esc_html($aBlock['blockName']); ?>
				<input type="checkbox" id="toggle-business-hours" name="toggle_business_hours" value="enable" <?php checked($toggleBusinessHoursStatus, 'enable'); ?>>
				<span></span>
			</label>
			<?php endif; ?>

			<div id="table-businees-hour">
				<table class="table table-bordered profile-hour">
					<thead>
						<tr>
							<th><?php esc_html_e('Day', 'wiloke'); ?></th>
							<th><?php esc_html_e('Start time', 'wiloke'); ?></th>
							<th><?php esc_html_e('End time', 'wiloke'); ?></th>
							<th><?php esc_html_e('Closed', 'wiloke'); ?></th>
						</tr>
					</thead>
					<?php
					$aDaysInWeek = array(
						esc_html__('Monday', 'wiloke'),
						esc_html__('Tuesday', 'wiloke'),
						esc_html__('Wednesday', 'wiloke'),
						esc_html__('Thursday', 'wiloke'),
						esc_html__('Friday', 'wiloke'),
						esc_html__('Saturday', 'wiloke'),
						esc_html__('Sunday', 'wiloke')
					);
					foreach ( $wiloke->aConfigs['frontend']['listing']['business_hours']['days'] as $key => $day ) :
						$aValues = isset($aBusinessHours[$key]) ? $aBusinessHours[$key] : $wiloke->aConfigs['frontend']['listing']['business_hours']['default'];
					?>
						<tr>
							<td class="business-day" data-title="<?php esc_html_e('Day', 'wiloke'); ?>"><?php echo esc_html($aDaysInWeek[$key]); ?></td>
							<td class="business-start" data-title="<?php esc_html_e('Start time', 'wiloke'); ?>">
								<span class="listgo-bsh-item"><input type="number" name="listgo_bh[<?php echo esc_attr($key) ?>][start_hour]" max="<?php echo esc_attr(apply_filters('wiloke/listgo/wiloke-submission/addlisting/time_format', 12)); ?>" min="0" value="<?php echo strlen($aValues['start_hour']) == 1 ?  0 . esc_attr($aValues['start_hour']) : esc_attr($aValues['start_hour']); ?>"></span>
								<span class="listgo-bsh-item"><input type="number" name="listgo_bh[<?php echo esc_attr($key) ?>][start_minutes]" max="60" min="0" value="<?php echo strlen($aValues['start_minutes']) == 1 ? 0 . esc_attr($aValues['start_minutes']) : esc_attr($aValues['start_minutes']); ?>"></span>
								<span class="listgo-bsh-item listgo-bsh-item-last">
									<select name="listgo_bh[<?php echo esc_attr($key) ?>][start_format]" class="listgo-time-format">
	                                    <option value="AM" <?php selected($aValues['start_format'], 'AM'); ?>><?php esc_html_e('AM', 'wiloke'); ?></option>
	                                    <option value="PM" <?php selected($aValues['start_format'], 'PM'); ?>><?php esc_html_e('PM', 'wiloke'); ?></option>
                                    </select>
								</span>
							</td>
							<td class="business-end" data-title="<?php esc_html_e('End time', 'wiloke'); ?>">
								<span class="listgo-bsh-item"><input type="number" name="listgo_bh[<?php echo esc_attr($key) ?>][close_hour]" max="<?php echo esc_attr(apply_filters('wiloke/listgo/wiloke-submission/addlisting/time_format', 12)); ?>" min="0" value="<?php echo strlen($aValues['close_hour']) == 1 ? 0 . esc_attr($aValues['close_hour']) : esc_attr($aValues['close_hour']); ?>"></span>
								<span class="listgo-bsh-item"><input type="number" name="listgo_bh[<?php echo esc_attr($key) ?>][close_minutes]" max="60" min="0" value="<?php echo strlen($aValues['close_minutes'])  == 1 ? 0 . esc_attr($aValues['close_minutes']) : esc_attr($aValues['close_minutes']); ?>"></span>
									<span class="listgo-bsh-item listgo-bsh-item-last"><span class="listgo-bsh-item listgo-bsh-item-last">
	                                    <select name="listgo_bh[<?php echo esc_attr($key) ?>][close_format]" class="listgo-time-format">
	                                        <option value="AM" <?php selected($aValues['close_format'], 'AM'); ?>><?php esc_html_e('AM', 'wiloke'); ?></option>
	                                        <option value="PM" <?php selected($aValues['close_format'], 'PM'); ?>><?php esc_html_e('PM', 'wiloke'); ?></option>
	                                    </select>
	                                </span>
								</span>
							</td>
							<td class="business-close" data-title="<?php  esc_html_e('Close', 'listgo'); ?>">
								<label for="bh-closed-<?php echo esc_attr($key); ?>" class="input-checkbox">
									<input id="bh-closed-<?php echo esc_attr($key); ?>" type="checkbox" name="listgo_bh[<?php echo esc_attr($key) ?>][closed]" value="1" <?php echo isset($aValues['closed']) && $aValues['closed'] == 1 ? 'checked' : ''; ?>>
									<span></span>
								</label>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>
			</div>
		</div>
	</div>
</div>
</div>