<?php
use WilokeListgoFunctionality\Helpers\AddListingHTML;
$aDefault = array(
	'app'       => '',
	'email'     => '',
	'apiToken'  => '',
	'calendar'  => '',
	'name'      => '',
	'avatar'    => ''
);

$aTimeKitSettings = array();
if ( !empty($postID) ){
	$aTimeKitSettings = \Wiloke::getPostMetaCaching($postID, 'listing_timekit');
}

$aFields = array(
	'app'=>array(
		'appLabel',
		'appPlaceholder'
	),
	'email'=>array(
		'emailLabel',
		'emailPlaceholder'
	),
	'apiToken'=>array(
		'apiTokenLabel',
		'apiTokenPlaceholder'
	),
	'calendar'=>array(
		'calendarLabel',
		'calendarPlaceholder'
	),
	'name'=>array(
		'nameLabel',
		'namePlaceholder'
	),
	'avatar'=>array(
		'avatarLabel',
		'avatarPlaceholder'
	)
);

$aTimeKitSettings = wp_parse_args($aTimeKitSettings, $aDefault);
?>
<div class="<?php echo esc_attr(\WilokeListgoFunctionality\Framework\Helpers\AddListingHelpers::toggleClass($aPackageSettings, 'toggle_timekit',  'add-listing-group')); ?>">
	<?php if ( !empty($aBlock['blockName']) ) : ?>
		<h4 class="add-listing-title"><?php echo esc_html($aBlock['blockName']); ?></h4>
	<?php endif; ?>
	<?php if ( !empty($aBlock['blockDescription']) ) : ?>
		<p class="add-listing-description"><?php Wiloke::wiloke_kses_simple_html($aBlock['blockDescription']); ?></p>
	<?php endif; ?>

	<div class="row">
		<?php foreach ($aFields as $fieldKey => $aFieldOptions) : ?>
		<div class="col-sm-6">
			<div class="form-item">
				<label class="label" for="app-label"><?php echo esc_html($aFieldSettings[$aFieldOptions[0]]); ?></label>
				<span class="input-text">
	                <input id="app-label" type="text" name="listing_timekit[<?php echo esc_attr($fieldKey); ?>]" value="<?php echo esc_attr($aTimeKitSettings[$fieldKey]); ?>" placeholder="<?php echo isset($aFieldOptions[1]) ? esc_attr($aFieldSettings[$aFieldOptions[1]]) : '';  ?>">
                </span>
			</div>
		</div>
		<?php endforeach; ?>
	</div>

</div>