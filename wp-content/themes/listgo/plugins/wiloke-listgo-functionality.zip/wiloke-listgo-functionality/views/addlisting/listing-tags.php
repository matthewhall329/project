<?php
$aRawTags = Wiloke::getPostTerms($postID, 'listing_tag');
$aFieldSettings['title'] = $aBlock['blockName'];
?>
<div class="add-listing-group">
	<div class="row">
	    <?php
	    if ( $aFieldSettings['mode'] == 'user' ) :

		    if ( !empty($aRawTags) && !is_wp_error($aRawTags) ){
			    $aCurrentTags = array_map(function($oTerm){
				    return $oTerm->slug;
			    }, $aRawTags);
		    }else{
			    $aCurrentTags = array();
		    }

		    $aFieldSettings['value'] = !empty($aCurrentTags) && !is_wp_error($aCurrentTags) ? implode(',', $aCurrentTags) : '';
	    ?>
	        <div class="col-sm-12">
		        <?php \WilokeListgoFunctionality\Helpers\AddListingHTML::textereaField('listing_tags', $aFieldSettings); ?>
	        </div>
	    <?php else:
		    $aListingTags = get_terms(
			    array(
				    'taxonomy'  => 'listing_tag',
				    'hide_empty'=> false
			    )
		    );

	        if ( empty($aListingTags) || is_wp_error($aListingTags) ){
                if ( current_user_can('editor') ){
                    \WilokeListgoFunctionality\Frontend\FrontendListingManagement::message(
                        array(
                            'message' => esc_html__('You have to create one Listing Tag at least', 'wiloke')
                        ),
                        'danger'
                    );
                }else{
	                \WilokeListgoFunctionality\Frontend\FrontendListingManagement::message(
		                array(
			                'message' => esc_html__('Whoops! There are no Listing Tags now. Please contact the admininstrator to report this issue', 'wiloke')
		                ),
		                'danger'
	                );
                }
	            return '';
            }

	        $aOptions = array();
	        foreach ($aListingTags as $oListingTag){
		        $aOptions[$oListingTag->term_id] = $oListingTag->name;
	        }

		    if ( !empty($aRawTags) && !is_wp_error($aRawTags) ){
			    $aCurrentTags = array_map(function($oTerm){
				    return $oTerm->term_id;
			    }, $aRawTags);
		    }else{
			    $aCurrentTags = array();
		    }

		    $aFieldSettings['options'] = $aOptions;
		    $aFieldSettings['class'] = 'add-listing-input-tags';
		    $aFieldSettings['value'] = $aCurrentTags;
		    $aFieldSettings['isMultiple'] = 'true';
		    ?>
	        <div class="col-sm-12">
	            <?php \WilokeListgoFunctionality\Helpers\AddListingHTML::selectTwoField('listing_tags', $aFieldSettings); ?>
	        </div>
	    <?php
	    endif;
	    ?>
	</div>
</div>

