<div class="container">
	<div class="row">
		<div class="col-md-12">
			<h3><?php esc_html_e('Thank for your submission. Your order has been received.', 'wiloke'); ?></h3>
			<table class="table">
				<tr>
					<th><?php esc_html_e('Order Number', 'wiloke'); ?></th>
					<th><?php esc_html_e('Date', 'wiloke'); ?></th>
					<th><?php esc_html_e('Plan', 'wiloke'); ?></th>
					<th><?php esc_html_e('Total', 'wiloke'); ?></th>
					<th><?php esc_html_e('Payment Method', 'wiloke'); ?></th>
				</tr>
				<tr>
					<td><?php echo esc_html($sessionID); ?></td>
					<td><?php echo get_the_date(get_option('date_format')); ?></td>
					<td><?php echo esc_html($planName); ?></td>
					<td><?php echo esc_html($price); ?></td>
					<td><?php esc_html_e('Direct Bank Transfer', 'wiloke'); ?></td>
				</tr>
			</table>
		</div>

		<div class="col-md-12">
			<div class="wiloke-bacs-bank-details">
				<h3><?php esc_html_e('Our bank details', 'wiloke'); ?></h3>
				<p><?php esc_html_e('Please use Order Number as the payment reference.', 'wiloke'); ?></p>
				<table class="table">
					<tr>
						<th><?php esc_html_e('Account Name', 'wiloke'); ?></th>
						<th><?php esc_html_e('Account Number', 'wiloke'); ?></th>
						<th><?php esc_html_e('Bank Name', 'wiloke'); ?></th>
						<th><?php esc_html_e('Short Code', 'wiloke'); ?></th>
						<th><?php esc_html_e('IBAN', 'wiloke'); ?></th>
						<th><?php esc_html_e('BIC/Swift', 'wiloke'); ?></th>
					</tr>
					<?php foreach ($aBankDetails as $aBankDetail) : ?>
						<tr>
							<td><?php echo esc_html($aBankDetail['bank_transfer_account_name']); ?></td>
							<td><?php echo esc_html($aBankDetail['bank_transfer_account_number']); ?></td>
							<td><?php echo esc_html($aBankDetail['bank_transfer_name']); ?></td>
							<td><?php echo esc_html($aBankDetail['bank_transfer_short_code']); ?></td>
							<td><?php echo esc_html($aBankDetail['bank_transfer_iban']); ?></td>
							<td><?php echo esc_html($aBankDetail['bank_transfer_swift']); ?></td>
						</tr>
					<?php endforeach; ?>
				</table>
			</div>
		</div>
	</div>
</div>