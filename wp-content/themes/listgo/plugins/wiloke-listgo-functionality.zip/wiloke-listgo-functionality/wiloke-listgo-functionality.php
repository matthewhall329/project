<?php
/*
 * Plugin Name: Wiloke Listgo Functionality
 * Plugin URI: https://wiloke.com
 * Author: Wiloke
 * Author URI: https://wiloke.com
 * Version: 1.6.4.2
 * Description: This plugin is required with List Go
 * Text Domain: wiloke
 * Domain Path: /languages/
 */

if ( !defined('ABSPATH') ){
    die();
}

if ( !defined('WILOKE_DS') ){
	define('WILOKE_DS', '/');
}

define('WILOKE_PLUGIN_FOLDER', plugin_basename(dirname(__FILE__)));
define('WILOKE_LISTGO_FC_VERSION', '1.6.4.2');
define('WILOKE_LISTGO_FUNC_PATH', plugin_dir_path(__FILE__));
define('WILOKE_LISTGO_FUNC_URL', plugin_dir_url(__FILE__));

add_action( 'plugins_loaded', 'wiloke_listgo_functionality_load_textdomain' );
/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 */
function wiloke_listgo_functionality_load_textdomain() {
	load_plugin_textdomain( 'wiloke', false, basename(dirname(__FILE__)) . '/languages' );
}

add_action('wp_enqueue_scripts', 'WilokeListgoFunctionalityScripts');
add_action('admin_enqueue_scripts', 'WilokeListgoFunctionalityScripts');

function WilokeListgoFunctionalityScripts(){
	$url = plugin_dir_url(__FILE__);
	wp_localize_script('jquery-migrate', 'WILOKE_LISTGO_FUNCTIONALITY', array('url'=>$url));
}

function wiloke_error_while_adding_listing($line, $file){
	if ( current_user_can('publish_posts') ){
		wp_die( sprintf(__('We found an error on the line %s in the %s of wiloke-listgo-functionality plugin. Please contact us at sale@wiloke.com or piratesmorefun@gmail.com to report this issue', 'wiloke'), $line, $file) );
	}else{
		wp_die( esc_html__('Something went wrong', 'wiloke') );
	}
}

$oTheme = wp_get_theme();
$themeName = strtolower($oTheme->name);
if ( strpos($themeName, 'listgo') === false ){
	return false;
}

require 'vendor/autoload.php';
$GLOBALS['WilokeListgoFunctionalityApp'] = require 'config/app.php';

use WilokeListgoFunctionality\Register\RegisterPostType;
use WilokeListgoFunctionality\Register\RegisterTaxonomy;
use WilokeListgoFunctionality\Register\RegisterReport;
use WilokeListgoFunctionality\Register\RegisterFollow;
use WilokeListgoFunctionality\Register\RegisterPricingSettings;
use WilokeListgoFunctionality\Register\RegisterWilokeSubmission;
use WilokeListgoFunctionality\Register\RegisterBadges;
use WilokeListgoFunctionality\Register\RegisterWelcome;
use WilokeListgoFunctionality\Register\RegisterAddNewOrder;
use WilokeListgoFunctionality\Register\RegisterClaim;
use WilokeListgoFunctionality\Register\RegisterEventPricing;

use WilokeListgoFunctionality\Register\RegisterEmailNotificationSubMenu;
use WilokeListgoFunctionality\Register\RegisterSubscriptionSubMenu;
use WilokeListgoFunctionality\Register\RegisterSaleSubMenu;
use WilokeListgoFunctionality\Register\RegisterSessionDetail;
use WilokeListgoFunctionality\Register\RegisterInvoicesSubMenu;

register_activation_hook( __FILE__, array('WilokeListgoFunctionality\Register\RegisterWilokeSubmission', 'setDefaultSubmissionPages') );

use WilokeListgoFunctionality\AlterTable\AlterTableComments;
use WilokeListgoFunctionality\AlterTable\AlterTableReviews;
use WilokeListgoFunctionality\AlterTable\AlterTableFavirote;
use WilokeListgoFunctionality\AlterTable\AlterTableReport;
use WilokeListgoFunctionality\AlterTable\AltertableFollowing;
use WilokeListgoFunctionality\AlterTable\AlterTablePaymentHistory;
use WilokeListgoFunctionality\AlterTable\AlterTablePaymentRelationships;
use WilokeListgoFunctionality\AlterTable\AlterTablePaymentEventRelationship;
use WilokeListgoFunctionality\AlterTable\AlterTablePackageStatus;
use WilokeListgoFunctionality\AlterTable\AlterTableNotifications;
use WilokeListgoFunctionality\AlterTable\AlterTableBusinessHours;
use WilokeListgoFunctionality\AlterTable\AlterTablePriceSegment;
use WilokeListgoFunctionality\AlterTable\AlterTableGeoPosition;
use WilokeListgoFunctionality\Framework\Payment\AdminManagement;

use WilokeListgoFunctionality\AlterTable\AlterTableInvoices;

use WilokeListgoFunctionality\Submit\AddListing;
use WilokeListgoFunctionality\Submit\User;

use WilokeListgoFunctionality\Frontend\Notification as WilokeFrontendNotification;
use WilokeListgoFunctionality\Frontend\FrontendBusinessHours as WilokeBusinessHours;
use WilokeListgoFunctionality\Frontend\FrontendPriceSegment as WilokePriceSegment;
use WilokeListgoFunctionality\Frontend\FrontendRating as WilokeFrontendRating;
use WilokeListgoFunctionality\Frontend\FrontendFavorites as WilokeFrontendFavorites;
use WilokeListgoFunctionality\Frontend\FrontendEvents as WilokeFrontendEvents;
use WilokeListgoFunctionality\Frontend\FrontendClaimListing as WilokeFrontendClaim;
use WilokeListgoFunctionality\Frontend\FrontendListingManagement as WilokeFrontendListingManagement;
use WilokeListgoFunctionality\Frontend\FrontendManageSingleListing as WilokeFrontendManageSingleListing;
use WilokeListgoFunctionality\Frontend\FrontendStripe as WilokeFrontendStripe;
use WilokeListgoFunctionality\Frontend\FrontendTwoCheckout;
use WilokeListgoFunctionality\Frontend\FrontendBilling;

use WilokeListgoFunctionality\CustomerPlan\CustomerPlan as WilokeCustomerPlan;

/*
 * Model
 */
use WilokeListgoFunctionality\Model\GeoPosition;
use WilokeListgoFunctionality\Model\Listing as WilokeModelListing;
use WilokeListgoFunctionality\Model\Review as WilokeReview;

/**
 * Add Rating Column To Comment Table
 *
 * @since 1.0
 * @author Wiloke
 */
new AlterTableComments;
new AlterTableReviews;
new AlterTableFavirote;
new AlterTableReport;
new AltertableFollowing;
new AlterTablePaymentHistory;
new AlterTablePaymentRelationships;
new AlterTablePaymentEventRelationship;
new AlterTablePackageStatus;
new AlterTableNotifications;
new AlterTableBusinessHours;
new AlterTablePriceSegment;
new AlterTableGeoPosition;
new AlterTableInvoices;

new AddListing;
register_deactivation_hook( __FILE__, 'wilokeListgoRemoveOldShedules' );
function wilokeListgoRemoveOldShedules(){
	wp_clear_scheduled_hook('wiloke_submission/automatically_delete_listing');
}

new User;
register_activation_hook( __FILE__, array('WilokeListgoFunctionality\Submit\User', 'addRoles') );

/**
 * Register Post Type and Register Taxonomy
 *
 * @since 1.0
 * @author Wiloke
 */
new RegisterPostType;
new RegisterTaxonomy;
new RegisterReport;
new RegisterFollow;
new RegisterPricingSettings;
new RegisterWilokeSubmission;
new RegisterBadges;
new RegisterWelcome;
new RegisterClaim;
new RegisterEventPricing;
new RegisterEmailNotificationSubMenu;
new RegisterSubscriptionSubMenu;
new RegisterSaleSubMenu;
new RegisterSessionDetail;
new RegisterAddNewOrder;
new RegisterInvoicesSubMenu;

new WilokeFrontendNotification;
$oBusinessHours     = new WilokeBusinessHours;
$oPriceSegment      = new WilokePriceSegment;
$oFrontPageRating   = new WilokeFrontendRating;
new WilokeFrontendClaim;
new WilokeFrontendFavorites;
new WilokeFrontendListingManagement;
new WilokeFrontendManageSingleListing;

new WilokeFrontendStripe;
new WilokeFrontendEvents;
new WilokeCustomerPlan;
new FrontendTwoCheckout;
new FrontendBilling;
//new AlterTableStripeRecurringPayment;

/*
 * New Functions
 */
use WilokeListgoFunctionality\AlterTable\AlterTableSessions;
use WilokeListgoFunctionality\AlterTable\AlterTablePlanRelationships;
use WilokeListgoFunctionality\AlterTable\AlterTablePaymentMeta;
use WilokeListgoFunctionality\AlterTable\AlterTableRecurringPayment;

new AlterTableSessions;
new AlterTablePlanRelationships;
new AlterTablePaymentMeta;
new AlterTableRecurringPayment;

use WilokeListgoFunctionality\Framework\Config\Repository;
new Repository;

# Controllers
use WilokeListgoFunctionality\Controllers\PayPalController;
use WilokeListgoFunctionality\Controllers\StripeController;
use WilokeListgoFunctionality\Controllers\UserController;
use WilokeListgoFunctionality\Controllers\FreePlanController;
use WilokeListgoFunctionality\Controllers\AddListingController;
use WilokeListgoFunctionality\Controllers\PlanRelationshipController;
use WilokeListgoFunctionality\Controllers\AddListingBtnUrlController;
use WilokeListgoFunctionality\Controllers\ChangeAddListingPlanController;
use WilokeListgoFunctionality\Controllers\TwocheckoutController;
use WilokeListgoFunctionality\Controllers\DirectBankTransferController;
use WilokeListgoFunctionality\Controllers\SessionController;
use WilokeListgoFunctionality\Controllers\PostsManagementController;
use WilokeListgoFunctionality\Controllers\AddEventController;

new PayPalController;
new StripeController;
new FreePlanController;
new PlanRelationshipController;
new AddListingController;
new UserController;
new AddListingBtnUrlController;
new ChangeAddListingPlanController;
new TwocheckoutController;
new DirectBankTransferController;
new SessionController;
new PostsManagementController;
new AddEventController;

new AdminManagement();

/*
|--------------------------------------------------------------------------
| Checking Posts status
|--------------------------------------------------------------------------
|
| Fetching all submission listings for times per day
|
*/
register_deactivation_hook(__FILE__, array('PostsManagementController', 'unregisterCheckPostsStatusEvent'));


#Mail Notification
use WilokeListgoFunctionality\Email\MailNotification;
new MailNotification;

/*
 * Shortcodes
 * @since 1.0
 */
use WilokeListgoFunctionality\Shortcodes\Shortcodes as ListGoShortcodes;
new ListGoShortcodes;

new GeoPosition;
new WilokeReview;
$modelListing = new WilokeModelListing;
$modelListing->init();

require_once WILOKE_LISTGO_FUNC_PATH . 'functions.php';
